# 3.2.2 交付整理与验证

日期：2026-11-12（Asia/Shanghai）。

## 交付与清理范围

正式交付为 发布包/ 和 源码包/。每类交付物包含一份解压目录、同名 ZIP 和 ZIP 的 SHA256SUMS.txt。版本统一为 3.2.2。

旧发布版本、旧源码压缩包、重复源码工作区、备份、构建缓存、临时文件和实验运行数据已从正式交付目录分离，集中到项目根“待删除旧文件”。自动安全策略拒绝执行删除（提示 blocked by policy，未提供具体原因），故旧内容仍占磁盘空间；需用户手动删除该目录。最新版测量参数保留在发布目录 config/measurement-parameters.ini。运行数据不进入发布 ZIP。

源码保留 apps、core、shared、tests、CMakeLists.txt、全部界面资源、19 项回归、算法金标及构建部署脚本。原工程外的技术参数、算法、模块规范、硬件 PDF 与相机修改方案已归入 docs/reference/。历史生成的 QA 临时输出不进入新源码包，先前相机验收报告作为文档保留。

## 实际验证结果

- 174 个 apps/core/shared/tests 文件逐一与已验收 3.2.2 工作区比对：无遗漏、无内容变化。
- 独立新源码路径的全量 Release 构建通过；Qt 6.8.3 / MSVC 2022 x64 / CMake 3.30.5 / C++17。
- 执行 build.ps1 -QtRoot C:/Qt/6.8.3/msvc2022_64 -BuildDirectory <临时构建目录> -RunTests：19/19 CTest 通过，测试耗时 21.04 秒。
- 使用新源码的 deploy.ps1 部署运行库并执行 Windows 平台插件 mock 登录启动验证：通过。
- 对 37 个 EXE/DLL 检查 PE 导入依赖，按包内文件及 Windows 系统组件解析：未发现缺失依赖。
- 将便携 ZIP 解压到含中文和空格的新目录，工作目录设为项目根，PATH 仅保留 Windows/System32 与 Windows，清除继承的 Qt/TDLAS 环境变量：版本输出 3.2.2，mock 登录截图成功，进程正常退出，无标准错误。
- 新位置生成的 storage.json 数据根目录随新 EXE 路径解析，未使用原电脑工程路径。
- 发布清单与 SHA-256 校验通过。ZIP 内文件与交付目录逐一进行 SHA-256 比对；源码 ZIP 含完整工程顶层目录及 build.ps1。

登录截图见源码 docs/validation/PORTABLE_LOGIN.png。源码和发布 ZIP 的校验值分别见两类交付物的 SHA256SUMS.txt。

## 适用边界

运行发布包不需要安装 Qt SDK、Visual Studio、CMake、Python 或 PowerShell 7。目标系统为 Windows 10/11 x64，目录须可写。NI-DAQmx、摄像头等系统级硬件驱动仍需在目标电脑安装。

源码可在其他设备读取和修改；在 Windows x64 上重新编译需要 README 所列开发工具。此次完成的是本机干净构建与换路径、受限 PATH 启动验证，没有在另一台物理电脑上实测，也没有重新操作真实硬件。浓度标定与其他现场 TBD 仍见 OPEN_QUESTIONS.md。
正式 EXE SHA-256：`62cd35d5b28a89b9793f4ac435cd0097384cbe7916bbfc4df9f47234f721635e`。


