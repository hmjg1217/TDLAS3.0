# TDLAS Hydrogen UI Suite V3.2.2 部署与运行

## 运行环境

- Windows 10/11 x64。
- 发布目录必须保持完整，不能只复制 `tdlas_hydrogen_ui.exe`。
- 正式程序默认枚举 NI 与 Qt Multimedia 设备，NI 设备优先；摄像头需明确选择后才连接。软件验收使用显式 mock 环境变量，来源在界面中标注。
- NI 实采仍需目标机安装经批准版本的 NI-DAQmx，并提供现场设备配置与测试授权。

## 启动

将 `tdlas-hydrogen-ui-3.2.2-win64` 整个文件夹复制到任意 Windows 10/11 x64 目录，再运行 `启动便携版.cmd`。程序使用程序目录内的 `config/` 和 `data/` 保存设置与实验记录，可整体搬移；首次运行会自动创建这两个目录。也可运行 `run-portable.ps1`。发布包携带 Qt、Multimedia 插件和 MSVC 运行库，不需要安装 Qt 或 CMake。开发验收账号仍是临时本地身份适配器，不能用于生产账号安全验收；账号见项目 README。

便携包使用随程序目录移动的相对配置。可在启动前覆盖采集、摄像和数据位置：

```powershell
$env:TDLAS_ACQUISITION_BACKEND = 'mock' # auto | mock | nidaqmx
$env:TDLAS_CAMERA_BACKEND = 'system'    # system | mock
$env:TDLAS_STORAGE_ROOT = 'D:\TDLAS-Data'
& '.\启动便携版.cmd'
```

正式程序会枚举 NI-DAQmx 与 Qt Multimedia 设备，但不会自动打开未明确选择的摄像头。现场使用前仍需确认 NI MAX 中的 device ID、通道/量程/时钟/触发配置和摄像头授权；测试或故障隔离可设置 `TDLAS_ACQUISITION_BACKEND=mock`、`TDLAS_CAMERA_BACKEND=mock`。

开发机构建环境为 Qt 6.8.3、MSVC 2022 x64 和 CMake 3.30.5 或更新版本。源码包提供自动探测工具链的 PowerShell 构建脚本。

## 包完整性

- `release-manifest.json` 记录版本、Git revision、文件尺寸与 payload SHA-256。
- `SHA256SUMS.txt` 可用于交付后复核文件哈希。
- `docs/RELEASE_NOTES_V3.2.2.md` 记录本版功能行为、已验证范围和未关闭限制。

PowerShell 校验单个文件示例：

```powershell
Get-FileHash -Algorithm SHA256 '.\tdlas_hydrogen_ui.exe'
```

## 人工验收建议

1. 启动、登录管理员和客户端，确认页面与批准 UI 一致。
2. 两个角色分别执行开始、曲线更新、停止；确认界面明确标记模拟来源。
3. Running 期间进入摄像页，测试预览、拍照、录像与停止。
4. 检查实验目录中的 manifest、参数、raw、results、logs 和 media。
5. 断电/强退类验收必须使用测试数据目录；重启后可用归档恢复服务将遗留 `running` 清单标记为 `aborted`，当前未自动扫描跨进程目录。

## 已知边界

本发布包完成无真实硬件的软件集成验收。氢浓度标定、MATLAB 外部参考等价、NI/摄像头实机、生产身份、目标磁盘长时吞吐、目标机 DPI 与安装器签名仍未关闭，详见发布说明与 `docs/PROJECT_STATUS.md`。

