# TDLAS 测氢系统 3.2.2 便携发布包

在 Windows 10/11 x64 上，将完整目录放在可写位置，双击 `启动便携版.cmd` 或 `tdlas_hydrogen_ui.exe`。模拟演示：`启动便携版.cmd --mock`。不要只复制 EXE。

Qt 6.8.3、MSVC x64、多媒体插件、FFmpeg DLL、Windows 平台插件与便携配置均已随包提供。运行不需要 Qt SDK、Visual Studio、CMake、Python 或 PowerShell 7。

- 配置：`portable-config/runtime.ini` 使用相对路径，可整体搬移。
- 参数和数据：`config/`、`data/` 在使用时创建；本交付目录不含实验运行数据，保留最新版已保存的测量参数。若要恢复程序默认参数，可在程序关闭时删除 `config/measurement-parameters.ini`。
- NI 采集卡：目标机需安装适用的 NI-DAQmx 系统驱动并核实通道配置；系统驱动不能通过复制程序文件夹安装。
- 摄像头：使用 Windows/UVC 或设备厂商驱动，进入程序选择设备后连接。
- 临时开发账号：管理员 `00/00`，用户 `01/01`。

复制本文件夹或解压发布 ZIP 即可使用。源码交付物为同项目 `源码包/tdlas-hydrogen-ui-3.2.2-source.zip`；开发工具安装与重新编译方法见源码包 README。

可用 PowerShell 7 执行 `./verify-package.ps1 -PackagePath .` 复核程序与运行库哈希；运行中产生的 config/data 不属于固定程序清单。此校验命令不是运行程序的前提。

本版相机方向和缩放为设备 PTZ，90° 仅旋转软件预览。浓度尚未校准；NI 实采、现场长稳与生产身份验收边界见 `OPEN_QUESTIONS.md` 和 `RELEASE_NOTES_V3.2.2.md`。

