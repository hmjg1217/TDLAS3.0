param(
    [ValidateSet('auto', 'mock', 'nidaqmx')]
    [string]$Acquisition = 'auto',
    [ValidateSet('system', 'mock')]
    [string]$Camera = 'system'
)
$ErrorActionPreference = 'Stop'
$executable = Join-Path $PSScriptRoot 'tdlas_hydrogen_ui.exe'
if (-not (Test-Path -LiteralPath $executable)) {
    throw 'Run this launcher from the deployed portable package.'
}
$savedAcquisition = $env:TDLAS_ACQUISITION_BACKEND
$savedCamera = $env:TDLAS_CAMERA_BACKEND
try {
    if ($PSBoundParameters.ContainsKey('Acquisition')) { $env:TDLAS_ACQUISITION_BACKEND = $Acquisition }
    if ($PSBoundParameters.ContainsKey('Camera')) { $env:TDLAS_CAMERA_BACKEND = $Camera }
    Start-Process -FilePath $executable -WorkingDirectory $PSScriptRoot -WindowStyle Hidden
} finally {
    $env:TDLAS_ACQUISITION_BACKEND = $savedAcquisition
    $env:TDLAS_CAMERA_BACKEND = $savedCamera
}
