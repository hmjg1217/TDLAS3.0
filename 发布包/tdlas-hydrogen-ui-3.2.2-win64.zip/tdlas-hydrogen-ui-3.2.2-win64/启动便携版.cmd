@echo off
setlocal
cd /d "%~dp0"
if /i "%~1"=="--mock" (
  set "TDLAS_ACQUISITION_BACKEND=mock"
  set "TDLAS_CAMERA_BACKEND=mock"
  shift
)
start "TDLAS v3.2.2" /wait "%~dp0tdlas_hydrogen_ui.exe"
exit /b %errorlevel%