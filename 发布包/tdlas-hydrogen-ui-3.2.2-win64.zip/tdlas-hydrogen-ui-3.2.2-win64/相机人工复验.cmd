@echo off
setlocal
set "TDLAS_ACQUISITION_BACKEND=mock"
set "TDLAS_CAMERA_BACKEND=system"
set "TDLAS_CAMERA_DEVICE_ID="
set "QT_QPA_PLATFORM=windows"
set "QT_PLUGIN_PATH="
set "QT_QPA_PLATFORM_PLUGIN_PATH="
start "" "%~dp0tdlas_hydrogen_ui.exe"
endlocal
