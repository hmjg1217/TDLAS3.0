# TDLAS 测氢上位机工程规则

## 基线与事实源

- `apps/integrated` 构建唯一正式应用 `tdlas_hydrogen_ui.exe`；`startup`、`admin`、`client` 只用于预览和截图回归。
- 先读 `docs/PROJECT_STATUS.md`；架构、接口、计划和待确认项分别见 `docs/Software_Architecture.md`、`docs/Interface_Definition.md`、`docs/Module_Development_Plan.md`、`docs/OPEN_QUESTIONS.md`。
- UI 视觉事实源是 `docs/ui/`、各 `apps/*/docs/ui/`、已归档参考图和版本化运行截图。缺少目标 DPI/DPR 时不得宣称像素级验收。
- 原始资料按需读取（已随源码保留）：`docs/reference/TDLAS_模块化开发与增量集成规范_V1.0.md`、`docs/reference/技术参数.txt`、`docs/reference/测氢算法.txt`、`docs/reference/vvoigtshape.m`、`docs/reference/算法模块说明.md`、`docs/reference/索尼IMX415摄像头模组.pdf`。
- 资料冲突或证据不足时登记 TBD，不编造公式、单位、标定、设备协议、测试或完成状态。

## 修改边界

- 保留已批准布局、导航、QSS、资源和截图效果；不得重建主窗口或把三个预览目标发展成独立产品。
- 当前阶段以 `docs/PROJECT_STATUS.md` 为准。状态仍为“基线/架构待确认”时，除非用户明确推进阶段，不写业务、算法、硬件或存储代码。
- UI 只发出意图并消费展示模型；应用协调、领域/算法、硬件适配、存储、权限和 UI 必须分离。
- 算法不得依赖 Qt Widgets、NI-DAQmx 或摄像头；硬件特定逻辑必须位于稳定接口后的适配器中。
- 未获真实设备测试授权前只使用模拟适配器；模拟结果必须显式标记，不能描述为实机结果。
- 不移动现有 UI 文件，不批量创建空模块，不手改生成文件，不做无关重构、依赖升级、格式化、部署或推送。
- 公共合同变更必须同步接口文档和测试；保留用户已有改动。

## 数据、安全与生命周期

- 电压单位为 V，吸光度无量纲；数值 `0` 不自动代表有效测量。
- 氢浓度反演、单位、量程、精度和参考结果尚未确认；在关闭相应 TBD 前，浓度必须保持无效/未校准。
- AO 幅值按峰值解释；当前软件边界为 `-10 V` 至 `+10 V`，输出采样率至少为输出频率的 10 倍，实际设备限制仍需实测确认。
- UI 线程不得执行阻塞式采集、算法、摄像、编码或持续存储。跨线程数据携带运行 ID、序号、时间戳、有效性和错误状态，并拒绝旧运行的迟到数据。
- 停止、退出登录、切换角色、关闭和错误路径必须确定性释放任务、线程、设备句柄、文件和编码器。
- 权限由应用/系统服务执行；隐藏控件不等于授权。临时账号只用于开发路由。

## 构建与验证

在本目录运行：

```powershell
.\build.ps1 -QtRoot 'C:\Qt\6.8.3\msvc2022_64'
& 'C:\Qt\Tools\CMake_64\bin\ctest.exe' --test-dir .\build -C Release --output-on-failure
```

- 仅构建正式应用可加 `-Target integrated`；全量 UI 回归运行 `tools/capture-all.ps1`。
- UI 变化必须比较登录、管理员和客户端受影响状态；记录客户区、DPI/DPR、Qt/字体/主题和测试数据。环境未对齐时只判结构回归。
- 真实硬件、算法数值等价、部署和像素级验收分别报告，不用编译成功替代行为验证。
- 最终报告列出修改文件、实际命令和结果、截图证据、未关闭 TBD，以及仍属模拟或未实测的能力。

