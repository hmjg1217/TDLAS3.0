# TDLAS 测氢系统 3.2.2

本目录是完整、独立的源代码工程，可复制到其他电脑读取、修改和重新构建。唯一正式程序是 `apps/integrated` 构建的 `tdlas_hydrogen_ui.exe`。

## 运行发布包

解压 `tdlas-hydrogen-ui-3.2.2-win64.zip`，双击其中的 `启动便携版.cmd`；模拟演示使用 `启动便携版.cmd --mock`。必须复制完整发布目录，不能只复制 EXE。

运行环境为 Windows 10/11 x64。发布包附带 Qt 6.8.3、MSVC 和多媒体运行库，不需要 Qt SDK、Visual Studio、CMake 或 Python。目录应可写，`config/` 与 `data/` 在使用时自动创建，可随整个目录搬移；相对路径配置见 `portable-config/runtime.ini`。

真实 NI 采集设备仍需在目标电脑安装适用的 NI-DAQmx 驱动；摄像头使用 Windows/UVC 或厂商驱动。系统驱动无法通过复制 DLL 安装。临时开发账户：管理员 `00/00`，用户 `01/01`。

## 在其他电脑编译、修改

安装以下开发工具（运行发布包不需要这些工具）：

- Visual Studio 2022 或 Build Tools，包含 C++ 桌面开发、MSVC v143 x64 和 Windows SDK。
- Qt 6.8.3 `msvc2022_64`，包含 Qt Multimedia。
- CMake 3.21+，本次验证为 3.30.5。
- PowerShell 7，用于构建、部署和打包脚本。

在本 README 所在目录执行：

```powershell
./build.ps1 -QtRoot 'C:/Qt/6.8.3/msvc2022_64' -RunTests
# 仅编译正式程序
./build.ps1 -QtRoot 'C:/Qt/6.8.3/msvc2022_64' -Target integrated
# 生成完整便携发布目录及 ZIP
./deploy.ps1 -QtRoot 'C:/Qt/6.8.3/msvc2022_64' -BuildDirectory build -PackageDirectory ../../发布包
# 生成完整源码 ZIP（默认输出到本工程的上一级）
./tools/package-source.ps1
```

Qt 安装位置不同时修改 `-QtRoot`，也可通过 `QTDIR` 或脚本自动探测。构建路径由脚本自身位置计算，无需原电脑用户名或工程盘符。不要从旧电脑复制 `build*` 缓存到新电脑。

## 工程内容

- `apps/`：正式应用及共用的 startup/admin/client 界面源码和资源，均为正式程序构建所需文件。
- `core/`、`shared/`：采集、算法、摄像、存储、权限及共享资源。
- `tests/`：19 项 CTest 及 `golden/` 算法参考数据，属于源码验证材料。
- `docs/`：架构、接口、UI 规格、发布说明；`reference/` 保留原始算法、技术参数和硬件资料；`validation/` 保存本版验证记录。
- `tools/`、`build.ps1`、`deploy.ps1`：构建、验证和打包工具。

本次交付排除旧版本、重复源码、历史构建缓存、临时文件和实验运行数据。原目录的旧文件已集中到项目根的“待删除旧文件”；自动安全策略拒绝执行删除，需要手动删除该目录后才能完成磁盘清理。包内不附带编译器或 Qt SDK，安装上述开发工具即可继续开发。历史状态文档里的旧路径仅用于解释开发记录，不再是有效入口。

## 本版行为与验证边界

相机方向和缩放使用设备 Pan/Tilt/Zoom，90° 使用软件预览旋转；用户已确认取景位移、缩放和旋转正常。测量沿用连续 20 个完整周期平均后拟合。

本次整理不修改业务代码，不重新进行真实硬件测试。NI 实采、样气、浓度标定、生产身份及现场长时验收仍需完成，详见 `docs/OPEN_QUESTIONS.md`。浓度保持未校准状态。

