#include "AdminTemplateWindow.h"

#include "CameraPreviewWidget.h"
#include "ChartWidget.h"
#include "contracts/MeasurementTypes.h"

#include <QAbstractItemView>
#include <QAction>
#include <QButtonGroup>
#include <QCheckBox>
#include <QComboBox>
#include <QDir>
#include <QDoubleSpinBox>
#include <QFileInfo>
#include <QFileDialog>

#include <QFormLayout>
#include <QFrame>
#include <QGridLayout>
#include <QHeaderView>
#include <QIcon>
#include <QKeyEvent>
#include <QLabel>
#include <QMenu>
#include <QPushButton>
#include <QPainter>
#include <QResizeEvent>
#include <QScrollArea>
#include <QSignalBlocker>
#include <QSlider>
#include <QSpinBox>
#include <QStyle>
#include <QStackedWidget>
#include <QTableWidget>
#include <QTableWidgetItem>
#include <QTableView>
#include <QAbstractTableModel>
#include <QSortFilterProxyModel>
#include <QDateTimeEdit>
#include <QDialogButtonBox>
#include <QStandardPaths>
#include <QTimeZone>
#include <cmath>
#include <algorithm>
#include <QVBoxLayout>
#include <QStyleOptionButton>

namespace adminui {

namespace {

constexpr int kAiChannelsRole = Qt::UserRole + 10;
constexpr int kAoChannelsRole = Qt::UserRole + 11;

class PeakRecordTableModel final : public QAbstractTableModel {
public:
    explicit PeakRecordTableModel(QObject *parent) : QAbstractTableModel(parent) {}
    int rowCount(const QModelIndex &parent = {}) const override { return parent.isValid() ? 0 : static_cast<int>(records_.size()); }
    int columnCount(const QModelIndex &parent = {}) const override { return parent.isValid() ? 0 : 8; }
    QVariant headerData(int section, Qt::Orientation orientation, int role) const override {
        if (orientation != Qt::Horizontal || role != Qt::DisplayRole) return {};
        const QStringList names{QStringLiteral("序号 / 批次"), QStringLiteral("采集时间（本地）"),
            QStringLiteral("elapsed (s)"), QStringLiteral("峰值"), QStringLiteral("峰值位置 peakX"),
            QStringLiteral("单位"), QStringLiteral("有效性 / 原因"), QStringLiteral("runId")};
        return names.value(section);
    }
    QVariant data(const QModelIndex &index, int role) const override {
        if (!index.isValid() || index.row() >= records_.size()) return {};
        const auto &r = records_.at(index.row());
        if (role == Qt::TextAlignmentRole) return QVariant::fromValue(Qt::AlignCenter);
        if (role == Qt::ForegroundRole && r.validity != tdlas::contracts::DataValidity::Valid) return QColor(QStringLiteral("#a82d3d"));
        if (role == Qt::ToolTipRole) return QStringLiteral("%1\nUTC：%2\n%3\n设备：%4\n参数：%5\n算法：%6\n标定：%7\n实验：%8")
            .arg(r.acquiredAtUtc.toLocalTime().toString(QStringLiteral("yyyy-MM-dd HH:mm:ss.zzz ttt")),
                r.acquiredAtUtc.toString(Qt::ISODateWithMs), r.reason, r.parameters.deviceId,
                r.parameters.id, r.algorithmVersion, r.calibrationVersion, r.experimentId.value);
        if (role != Qt::DisplayRole && role != Qt::UserRole) return {};
        const bool sort = role == Qt::UserRole;
        switch (index.column()) {
        case 0: return sort ? QVariant::fromValue(r.sequence) : QVariant(QString::number(r.sequence));
        case 1: return sort ? QVariant(r.acquiredAtUtc) : QVariant(r.acquiredAtUtc.toLocalTime().toString(QStringLiteral("yyyy-MM-dd HH:mm:ss.zzz")));
        case 2: return sort ? QVariant(r.elapsedSeconds) : QVariant(QString::number(r.elapsedSeconds, 'f', 3));
        case 3: return r.peakValue ? (sort ? QVariant(*r.peakValue) : QVariant(QString::number(*r.peakValue, 'g', 10))) : QVariant(QStringLiteral("null"));
        case 4: return r.peakX ? (sort ? QVariant(*r.peakX) : QVariant(QStringLiteral("%1 %2").arg(QString::number(*r.peakX, 'g', 8), r.peakXUnit))) : QVariant(QStringLiteral("null"));
        case 5: return r.unit == QStringLiteral("1") ? QStringLiteral("无量纲") : r.unit;
        case 6: {
            const QString source = r.sourceKind == tdlas::contracts::DataSourceKind::Simulation
                ? QStringLiteral("模拟") : QStringLiteral("实采");
            return r.validity == tdlas::contracts::DataValidity::Valid
                ? QStringLiteral("有效 · %1").arg(source)
                : QStringLiteral("无效 · %1%2").arg(source,
                    r.reason.isEmpty() ? QString() : QStringLiteral("：") + r.reason);
        }
        case 7: return r.runId.value;
        default: return {};
        }
    }
    void setRecords(const QVector<tdlas::contracts::PeakRecord> &records) {
        if (records_.isEmpty() || records.isEmpty() || records_.first().runId != records.first().runId) {
            beginResetModel(); records_ = records; endResetModel(); return;
        }
        int removed = 0;
        while (removed < records_.size() && (records_.at(removed).runId != records.first().runId
            || records_.at(removed).sequence != records.first().sequence)) ++removed;
        if (removed == records_.size() || records_.at(removed).runId != records.first().runId
            || records_.at(removed).sequence != records.first().sequence
            || records.size() < records_.size() - removed
            || records.at(records_.size() - removed - 1).runId != records_.last().runId
            || records.at(records_.size() - removed - 1).sequence != records_.last().sequence) {
            beginResetModel(); records_ = records; endResetModel(); return;
        }
        if (removed) {
            beginRemoveRows({}, 0, removed - 1); records_.remove(0, removed); endRemoveRows();
        }
        if (records.size() > records_.size()) {
            const int first = static_cast<int>(records_.size());
            beginInsertRows({}, first, static_cast<int>(records.size()) - 1);
            records_ += records.mid(first); endInsertRows();
        }
    }
private:
    QVector<tdlas::contracts::PeakRecord> records_;
};



class RailButton final : public QPushButton {
public:
    using QPushButton::QPushButton;

protected:
    void paintEvent(QPaintEvent *) override
    {
        QStyleOptionButton option;
        initStyleOption(&option);
        option.text.clear();
        option.icon = QIcon();
        QPainter painter(this);
        style()->drawControl(QStyle::CE_PushButtonBevel, &option, &painter, this);
        painter.setRenderHint(QPainter::SmoothPixmapTransform);
        const int iconHeight = icon().isNull() ? 0 : iconSize().height();
        if (iconHeight > 0) {
            const QRect iconRect((width() - iconSize().width()) / 2, 7,
                                 iconSize().width(), iconHeight);
            icon().paint(&painter, iconRect, Qt::AlignCenter,
                         QIcon::Normal,
                         isChecked() ? QIcon::On : QIcon::Off);
        }
        QFont labelFont = font();
        labelFont.setPointSize(10);
        painter.setFont(labelFont);
        painter.setPen(palette().color(QPalette::Active, QPalette::ButtonText));
        const QRect labelRect(3, 9 + iconHeight, width() - 6,
                              height() - iconHeight - 12);
        painter.drawText(labelRect, Qt::AlignHCenter | Qt::AlignVCenter | Qt::TextWordWrap,
                         text());
    }
};

QPushButton *makeRailButton(const QString &text, QWidget *parent)
{
    auto *button = new RailButton(text, parent);
    button->setProperty("uiRole", QStringLiteral("railAction"));
    button->setCursor(Qt::PointingHandCursor);
    return button;
}

QString cameraDurationText(qint64 milliseconds)
{
    const qint64 totalSeconds = qMax<qint64>(0, milliseconds / 1000);
    return QStringLiteral("%1:%2:%3")
        .arg(totalSeconds / 3600, 2, 10, QLatin1Char('0'))
        .arg((totalSeconds / 60) % 60, 2, 10, QLatin1Char('0'))
        .arg(totalSeconds % 60, 2, 10, QLatin1Char('0'));
}

QLabel *makeLabel(const QString &text, const QString &role = QString(), QWidget *parent = nullptr)
{
    auto *label = new QLabel(text, parent);
    if (!role.isEmpty()) {
        label->setProperty("uiRole", role);
    }
    return label;
}

QPushButton *makeButton(const QString &text, const QString &role, bool checkable = false, QWidget *parent = nullptr)
{
    auto *button = new QPushButton(text, parent);
    button->setProperty("uiRole", role);
    button->setCheckable(checkable);
    button->setCursor(Qt::PointingHandCursor);
    return button;
}

QFrame *makePanel(const QString &title, QWidget *body, QWidget *parent = nullptr)
{
    auto *panel = new QFrame(parent);
    panel->setProperty("uiRole", QStringLiteral("panel"));
    auto *layout = new QVBoxLayout(panel);
    layout->setContentsMargins(0, 0, 0, 0);
    layout->setSpacing(0);
    auto *titleLabel = makeLabel(title, QStringLiteral("panelTitle"), panel);
    titleLabel->setMinimumHeight(42);
    titleLabel->setContentsMargins(16, 0, 12, 0);
    layout->addWidget(titleLabel);
    layout->addWidget(body, 1);
    return panel;
}

QFrame *makeMetricRow(const QString &name, const QString &value, const QString &valueObjectName, QWidget *parent)
{
    auto *row = new QFrame(parent);
    row->setProperty("uiRole", QStringLiteral("metricRow"));
    auto *layout = new QHBoxLayout(row);
    layout->setContentsMargins(18, 7, 18, 7);
    layout->setSpacing(10);
    auto *nameLabel = makeLabel(name, QStringLiteral("metricName"), row);
    auto *valueLabel = makeLabel(value, QStringLiteral("metricValue"), row);
    valueLabel->setObjectName(valueObjectName);
    valueLabel->setAlignment(Qt::AlignRight | Qt::AlignVCenter);
    layout->addWidget(nameLabel, 1);
    layout->addWidget(valueLabel, 1);
    return row;
}

QWidget *makeResultsBody(QWidget *parent)
{
    auto *body = new QWidget(parent);
    auto *layout = new QVBoxLayout(body);
    layout->setContentsMargins(14, 12, 14, 14);
    layout->setSpacing(10);
    layout->addWidget(makeMetricRow(QStringLiteral("⌁  峰值吸光度"), QStringLiteral("0.0978  · 模拟"), QStringLiteral("peakAbsorbanceValue"), body));
    layout->addWidget(makeMetricRow(QStringLiteral("☼  光强百分比"), QStringLiteral("78.65 %  · 模拟"), QStringLiteral("lightPercentValue"), body));
    layout->addWidget(makeMetricRow(QStringLiteral("◇  气体浓度"), QStringLiteral("—  未校准"), QStringLiteral("concentrationValue"), body));
    return body;
}

QWidget *makeChartBody(
    ChartWidget::Mode mode,
    const QString &xLabel,
    const QString &yLabel,
    QWidget *parent,
    const QString &objectName = {})
{
    auto *chart = new ChartWidget(mode, parent);
    chart->setAxisLabels(xLabel, yLabel);
    if (!objectName.isEmpty()) {
        chart->setObjectName(objectName);
    }
    return chart;
}

QComboBox *combo(const QStringList &items, QWidget *parent)
{
    auto *control = new QComboBox(parent);
    control->addItems(items);
    return control;
}

QDoubleSpinBox *decimalSpin(double value, double minimum, double maximum, int decimals, QWidget *parent)
{
    auto *control = new QDoubleSpinBox(parent);
    control->setRange(minimum, maximum);
    control->setDecimals(decimals);
    control->setValue(value);
    return control;
}

} // namespace

AdminTemplateWindow::AdminTemplateWindow(Screen initialScreen, QWidget *parent)
    : QWidget(parent)
{
    setObjectName(QStringLiteral("adminTemplateRoot"));
    setWindowTitle(QStringLiteral("TDLAS 测氢系统 · 管理员 Codex UI 模板"));
    setMinimumSize(1080, 680);
    resize(1504, 847);
    setFocusPolicy(Qt::StrongFocus);
    buildShell();
    buildParameterDrawer();
    buildMovementPanel();
    setScreen(initialScreen);
}

void AdminTemplateWindow::buildShell()
{
    auto *rootLayout = new QVBoxLayout(this);
    rootLayout->setContentsMargins(0, 0, 0, 0);
    rootLayout->setSpacing(0);
    rootLayout->addWidget(buildTopBar());

    auto *body = new QWidget(this);
    body->setObjectName(QStringLiteral("workspaceBody"));
    auto *bodyLayout = new QHBoxLayout(body);
    bodyLayout->setContentsMargins(0, 0, 0, 0);
    bodyLayout->setSpacing(0);
    bodyLayout->addWidget(buildSideRail());

    auto *content = new QWidget(body);
    auto *contentLayout = new QVBoxLayout(content);
    contentLayout->setContentsMargins(0, 0, 0, 0);
    contentLayout->setSpacing(0);
    contentLayout->addWidget(buildTabBar());

    pages_ = new QStackedWidget(content);
    pages_->setObjectName(QStringLiteral("pageStack"));
    pages_->addWidget(buildMainPage());
    pages_->addWidget(buildDebugPage());
    pages_->addWidget(buildPeakPage());
    cameraPage_ = buildCameraPage();
    pages_->addWidget(cameraPage_);
    contentLayout->addWidget(pages_, 1);

    bodyLayout->addWidget(content, 1);
    rootLayout->addWidget(body, 1);
}

QWidget *AdminTemplateWindow::buildTopBar()
{
    auto *bar = new QFrame(this);
    bar->setObjectName(QStringLiteral("topBar"));
    bar->setFixedHeight(64);
    auto *layout = new QHBoxLayout(bar);
    layout->setContentsMargins(22, 0, 14, 0);
    layout->setSpacing(14);

    auto *brand = makeLabel(QStringLiteral("◉  道纪量子   │   TDLAS 测氢系统"), QStringLiteral("brand"), bar);
    layout->addWidget(brand);

    layout->addSpacing(18);
    deviceStatusLabel_ = makeLabel(QStringLiteral("▣  设备状态：● 未连接"), QStringLiteral("statusPill"), bar);
    deviceStatusLabel_->setObjectName(QStringLiteral("deviceStatusLabel"));
    measurementStatusLabel_ = makeLabel(QStringLiteral("▶  采集状态：● 就绪"), QStringLiteral("statusPill"), bar);
    measurementStatusLabel_->setObjectName(QStringLiteral("measurementStatusLabel"));
    layout->addWidget(deviceStatusLabel_);
    layout->addWidget(measurementStatusLabel_);
    modeLabel_ = makeLabel(QStringLiteral("设备待识别"), QStringLiteral("modePill"), bar);
    modeLabel_->setObjectName(QStringLiteral("dataSourceModeLabel"));
    layout->addWidget(modeLabel_);
    layout->addStretch(1);

    templateNotice_ = makeLabel(QStringLiteral("UI 模板 · 无设备连接"), QStringLiteral("templateNotice"), bar);
    templateNotice_->setObjectName(QStringLiteral("templateNotice"));
    layout->addWidget(templateNotice_);
    layout->addWidget(makeButton(QStringLiteral("☼ 主题"), QStringLiteral("topAction"), false, bar));
    auto *settings = makeButton(QStringLiteral("⚙ 设置"), QStringLiteral("topAction"), false, bar);
    settings->setObjectName(QStringLiteral("settingsButton"));
    auto *settingsMenu = new QMenu(settings);
    auto *refreshDevices = settingsMenu->addAction(QStringLiteral("刷新设备识别"));
    auto *saveParameters = settingsMenu->addAction(QStringLiteral("保存参数区数据"));
    settings->setMenu(settingsMenu);
    connect(refreshDevices, &QAction::triggered, this, &AdminTemplateWindow::refreshDevicesRequested);
    connect(saveParameters, &QAction::triggered, this, &AdminTemplateWindow::saveCurrentParametersRequested);
    layout->addWidget(settings);
    return bar;
}

QWidget *AdminTemplateWindow::buildSideRail()
{
    auto *rail = new QFrame(this);
    rail->setObjectName(QStringLiteral("sideRail"));
    rail->setFixedWidth(104);
    auto *layout = new QVBoxLayout(rail);
    layout->setContentsMargins(5, 14, 5, 14);
    layout->setSpacing(4);

    auto *home = makeRailButton(QStringLiteral("主页面"), rail);
    auto *parameters = makeRailButton(QStringLiteral("参数区"), rail);
    home->setCheckable(true);
    parameters->setCheckable(true);
    startMeasurementButton_ = makeRailButton(QStringLiteral("开始采集"), rail);
    stopMeasurementButton_ = makeRailButton(QStringLiteral("停止采集"), rail);
    startMeasurementButton_->setObjectName(QStringLiteral("startAcquisitionButton"));
    stopMeasurementButton_->setObjectName(QStringLiteral("stopAcquisitionButton"));
    stopMeasurementButton_->setEnabled(false);
    auto *reset = makeRailButton(QStringLiteral("复位"), rail);
    reset->setIcon(QIcon(QStringLiteral(":/sidebar-icons/reset.png")));
    auto *save = makeRailButton(QStringLiteral("数据保存"), rail);
    save->setObjectName(QStringLiteral("saveExperimentButton"));
    home->setChecked(true);

    const QSize railIconSize(36, 36);
    home->setIcon(QIcon(QStringLiteral(":/sidebar-icons/home.png")));
    parameters->setIcon(QIcon(QStringLiteral(":/sidebar-icons/parameters.png")));
    startMeasurementButton_->setIcon(QIcon(QStringLiteral(":/sidebar-icons/start-acquisition.png")));
    stopMeasurementButton_->setIcon(QIcon(QStringLiteral(":/sidebar-icons/stop-acquisition.png")));
    save->setIcon(QIcon(QStringLiteral(":/sidebar-icons/save-data.png")));
    for (auto *button : {home, parameters, startMeasurementButton_, stopMeasurementButton_, reset, save}) {
        button->setIconSize(railIconSize);
    }

    for (auto *button : {home, parameters, startMeasurementButton_, stopMeasurementButton_, reset, save}) {
        button->setMinimumHeight(96);
        layout->addWidget(button);
    }
    layout->addStretch(1);

    connect(home, &QPushButton::clicked, this, [this, home, parameters]() {
        home->setChecked(true);
        parameters->setChecked(false);
        setScreen(Screen::Main);
    });
    connect(parameters, &QPushButton::clicked, this, [this, home, parameters](bool checked) {
        home->setChecked(!checked);
        parameters->setChecked(checked);
        setScreen(checked ? Screen::Parameters : Screen::Main);
    });
    connect(startMeasurementButton_, &QPushButton::clicked, this, &AdminTemplateWindow::startMeasurementRequested);
    connect(stopMeasurementButton_, &QPushButton::clicked, this, &AdminTemplateWindow::stopMeasurementRequested);
    connect(reset, &QPushButton::clicked, this, [this]() {
        emit resetMeasurementRequested();
        emit actionRequested(QStringLiteral("ResetMeasurement"));
    });
    connect(save, &QPushButton::clicked, this, [this]() {
        emit dataSaveLocationRequested();
    });
    return rail;
}

QWidget *AdminTemplateWindow::buildTabBar()
{
    auto *bar = new QFrame(this);
    bar->setObjectName(QStringLiteral("tabBar"));
    bar->setFixedHeight(64);
    auto *layout = new QHBoxLayout(bar);
    layout->setContentsMargins(16, 10, 16, 8);
    layout->setSpacing(12);

    tabGroup_ = new QButtonGroup(this);
    tabGroup_->setExclusive(true);
    const QStringList labels{
        QStringLiteral("⌂  主页面"),
        QStringLiteral("⚒  调试界面"),
        QStringLiteral("⌁  峰值数据"),
        QStringLiteral("▣  摄像界面")};
    for (int i = 0; i < static_cast<int>(tabButtons_.size()); ++i) {
        tabButtons_[i] = makeButton(labels.at(i), QStringLiteral("topTab"), true, bar);
        tabButtons_[i]->setMinimumWidth(170);
        tabGroup_->addButton(tabButtons_[i], i);
        layout->addWidget(tabButtons_[i]);
    }
    tabButtons_[0]->setChecked(true);
    layout->addStretch(1);

    const auto selectTab = [this](int id) {
        const std::array<Screen, 4> screens{Screen::Main, Screen::Debug, Screen::PeakData, Screen::Camera};
        setScreen(screens.at(static_cast<std::size_t>(id)));
    };
#if QT_VERSION >= QT_VERSION_CHECK(5, 15, 0)
    connect(tabGroup_, &QButtonGroup::idClicked, this, selectTab);
#else
    connect(tabGroup_, QOverload<int>::of(&QButtonGroup::buttonClicked), this, selectTab);
#endif
    return bar;
}

QWidget *AdminTemplateWindow::buildMainPage()
{
    auto *page = new QWidget(this);
    page->setObjectName(QStringLiteral("mainPage"));
    auto *grid = new QGridLayout(page);
    grid->setContentsMargins(16, 10, 16, 16);
    grid->setHorizontalSpacing(12);
    grid->setVerticalSpacing(12);

    auto *preview = new CameraPreviewWidget(page);
    grid->addWidget(makePanel(QStringLiteral("▣  摄像窗口"), preview, page), 0, 0);
    grid->addWidget(makePanel(
        QStringLiteral("⌁  FV 曲线（吸收光谱）"),
        makeChartBody(ChartWidget::Mode::FvCurve, QStringLiteral("相对频率 v_f（cm⁻¹）"), QStringLiteral("拟合吸光度"), page, QStringLiteral("fvChart")),
        page), 0, 1);
    grid->addWidget(makePanel(
        QStringLiteral("⌁  FV 峰值数据记录（实时趋势）"),
        makeChartBody(ChartWidget::Mode::PeakTrend, QStringLiteral("时间（HH:mm:ss）"), QStringLiteral("峰值吸光度"), page, QStringLiteral("peakTrendChart")),
        page), 1, 0);
    auto *resultsBody = makeResultsBody(page);
    peakValueLabel_ = resultsBody->findChild<QLabel *>(QStringLiteral("peakAbsorbanceValue"));
    lightValueLabel_ = resultsBody->findChild<QLabel *>(QStringLiteral("lightPercentValue"));
    concentrationValueLabel_ = resultsBody->findChild<QLabel *>(QStringLiteral("concentrationValue"));
    grid->addWidget(makePanel(QStringLiteral("◴  实时结果"), resultsBody, page), 1, 1);
    grid->setColumnStretch(0, 13);
    grid->setColumnStretch(1, 11);
    grid->setRowStretch(0, 1);
    grid->setRowStretch(1, 1);
    return page;
}

QWidget *AdminTemplateWindow::buildDebugPage()
{
    auto *page = new QWidget(this);
    page->setObjectName(QStringLiteral("debugPage"));
    auto *layout = new QVBoxLayout(page);
    layout->setContentsMargins(16, 10, 16, 16);
    layout->setSpacing(12);

    auto *gridHost = new QWidget(page);
    auto *grid = new QGridLayout(gridHost);
    grid->setContentsMargins(0, 0, 0, 0);
    grid->setSpacing(12);
    grid->addWidget(makePanel(QStringLiteral("⌁  原始信号（AI）"), makeChartBody(ChartWidget::Mode::RawSignal, QStringLiteral("时间（s）"), QStringLiteral("电压（V）"), page, QStringLiteral("rawSignalChart")), page), 0, 0);
    grid->addWidget(makePanel(QStringLiteral("⌁  20 周期平均信号与 Voigt 拟合（电压域）"), makeChartBody(ChartWidget::Mode::FitCurve, QStringLiteral("时间（s）"), QStringLiteral("电压（V）"), page, QStringLiteral("processedVoltageChart")), page), 0, 1);
    grid->addWidget(makePanel(QStringLiteral("⌁  FV 曲线（拟合吸光度）"), makeChartBody(ChartWidget::Mode::FvCurve, QStringLiteral("相对频率 v_f（cm⁻¹）"), QStringLiteral("拟合吸光度"), page), page), 1, 0);
    grid->addWidget(makePanel(QStringLiteral("⌁  实时峰值历史（FV 峰值）"), makeChartBody(ChartWidget::Mode::PeakTrend, QStringLiteral("时间（HH:mm:ss）"), QStringLiteral("峰值吸光度"), page, QStringLiteral("debugPeakTrendChart")), page), 1, 1);
    grid->setRowStretch(0, 1);
    grid->setRowStretch(1, 1);
    layout->addWidget(gridHost, 1);

    auto *summary = new QFrame(page);
    summary->setProperty("uiRole", QStringLiteral("resultStrip"));
    auto *summaryLayout = new QHBoxLayout(summary);
    summaryLayout->setContentsMargins(24, 6, 24, 6);
    debugPeakValueLabel_ = makeLabel(QStringLiteral("⌁ 实时峰值：  — 等待数据"), QStringLiteral("stripMetric"), summary);
    debugPeakValueLabel_->setObjectName(QStringLiteral("debugPeakAbsorbanceValue"));
    debugLightValueLabel_ = makeLabel(QStringLiteral("☼ 光强百分比：  — 等待数据"), QStringLiteral("stripMetric"), summary);
    debugConcentrationValueLabel_ = makeLabel(QStringLiteral("◇ 气体浓度：  — 未校准"), QStringLiteral("stripMetric"), summary);
    summaryLayout->addWidget(debugPeakValueLabel_);
    summaryLayout->addWidget(debugLightValueLabel_);
    summaryLayout->addWidget(debugConcentrationValueLabel_);
    layout->addWidget(summary);
    return page;
}

QWidget *AdminTemplateWindow::buildPeakPage()
{
    auto *page = new QWidget(this);
    page->setObjectName(QStringLiteral("peakPage"));
    auto *layout = new QVBoxLayout(page);
    layout->setContentsMargins(12, 8, 12, 12);
    layout->setSpacing(10);
    auto *filters = new QFrame(page);
    filters->setProperty("uiRole", QStringLiteral("filterBar"));
    auto *filterLayout = new QHBoxLayout(filters);
    filterLayout->setContentsMargins(12, 9, 12, 9);
    filterLayout->setSpacing(6);
    filterLayout->addWidget(makeLabel(QStringLiteral("时间范围："), QStringLiteral("fieldLabel"), filters));
    const QVector<QPair<QString, double>> ranges{{QStringLiteral("本次 run"), 0.0},
        {QStringLiteral("1 分钟"), 60.0}, {QStringLiteral("30 分钟"), 1800.0},
        {QStringLiteral("10 分钟"), 600.0}, {QStringLiteral("1 小时"), 3600.0}, {QStringLiteral("自定义"), -1.0}};
    for (const auto &range : ranges) {
        auto *button = makeButton(range.first, range.second == 1800.0 ? QStringLiteral("primary") : QStringLiteral("secondary"), false, filters);
        const double seconds = range.second;
        button->setObjectName(QStringLiteral("peakWindow%1Button").arg(static_cast<int>(seconds)));
        filterLayout->addWidget(button);
        connect(button, &QPushButton::clicked, this, [this, seconds, button, filters]() {
            auto apply = [this, button, filters]() {
                for (auto *filter : filters->findChildren<QPushButton *>()) {
                    if (!filter->objectName().startsWith(QStringLiteral("peakWindow"))) continue;
                    filter->setProperty("uiRole", filter == button ? QStringLiteral("primary") : QStringLiteral("secondary"));
                    filter->style()->unpolish(filter); filter->style()->polish(filter);
                }
                updatePeakRecordsView();
                for (auto *chart : findChildren<ChartWidget *>()) {
                    if (chart->mode() != ChartWidget::Mode::PeakTrend) continue;
                    if (peakCustomFromUtc_.isValid()) chart->setPeakTimeRange(peakCustomFromUtc_, peakCustomToUtc_);
                    else if (peakFilterSeconds_ == 0.0) chart->setPeakRunRange();
                    else chart->setPeakWindowSeconds(peakFilterSeconds_);
                }
            };
            if (seconds >= 0.0) {
                peakFilterSeconds_ = seconds; peakCustomFromUtc_ = {}; peakCustomToUtc_ = {};
                if (seconds == 0.0) peakRunSelect_->setCurrentIndex(0);
                apply(); return;
            }
            auto *dialog = new QDialog(this);
            dialog->setObjectName(QStringLiteral("peakCustomRangeDialog"));
            dialog->setAttribute(Qt::WA_DeleteOnClose);
            dialog->setWindowTitle(QStringLiteral("自定义采集时间范围（电脑本地时间）"));
            auto *form = new QFormLayout(dialog);
            auto *from = new QDateTimeEdit(QDateTime::currentDateTime().addSecs(-1800), dialog);
            auto *to = new QDateTimeEdit(QDateTime::currentDateTime(), dialog);
            from->setObjectName(QStringLiteral("peakRangeFrom")); to->setObjectName(QStringLiteral("peakRangeTo"));
            for (auto *edit : {from, to}) { edit->setDisplayFormat(QStringLiteral("yyyy-MM-dd HH:mm:ss.zzz")); edit->setCalendarPopup(true); }
            form->addRow(QStringLiteral("开始"), from); form->addRow(QStringLiteral("结束"), to);
            auto *buttons = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel, dialog);
            form->addRow(buttons);
            connect(buttons, &QDialogButtonBox::rejected, dialog, &QDialog::reject);
            connect(buttons, &QDialogButtonBox::accepted, dialog, [this, dialog, from, to, apply]() {
                if (from->dateTime() >= to->dateTime()) { showTemplateNotice(QStringLiteral("开始时间必须早于结束时间。")); return; }
                peakCustomFromUtc_ = from->dateTime().toUTC(); peakCustomToUtc_ = to->dateTime().toUTC();
                peakFilterSeconds_ = -1.0; apply(); peakPageChart_->setPeakLiveFollow(false); dialog->accept();
            });
            dialog->open();
        });
    }
    filterLayout->addWidget(makeLabel(QStringLiteral("run："), QStringLiteral("fieldLabel"), filters));
    peakRunSelect_ = new QComboBox(filters);
    peakRunSelect_->setObjectName(QStringLiteral("peakRunSelect"));
    peakRunSelect_->addItem(QStringLiteral("当前 run"), QStringLiteral("__current__"));
    peakRunSelect_->addItem(QStringLiteral("全部 run（分段）"), QStringLiteral("__all__"));
    peakRunSelect_->setMinimumWidth(130); peakRunSelect_->setMaximumWidth(180);
    peakRunSelect_->setSizeAdjustPolicy(QComboBox::AdjustToMinimumContentsLengthWithIcon);
    filterLayout->addWidget(peakRunSelect_);
    connect(peakRunSelect_, &QComboBox::currentIndexChanged, this, [this]() {
        updatePeakRecordsView(); peakPageChart_->resetPeakZoom();
        if (peakRunSelect_->currentData().toString() != QStringLiteral("__current__")) peakPageChart_->setPeakLiveFollow(false);
    });
    peakAutoFollow_ = new QCheckBox(QStringLiteral("自动跟随"), filters);
    peakAutoFollow_->setObjectName(QStringLiteral("peakAutoFollowCheckBox")); peakAutoFollow_->setChecked(true);
    filterLayout->addWidget(peakAutoFollow_); filterLayout->addStretch(1);
    auto *returnLive = makeButton(QStringLiteral("↶ 返回实时"), QStringLiteral("secondary"), false, filters);
    returnLive->setObjectName(QStringLiteral("peakReturnLiveButton")); filterLayout->addWidget(returnLive);
    auto *reset = makeButton(QStringLiteral("⌕ 缩放复位"), QStringLiteral("secondary"), false, filters);
    reset->setObjectName(QStringLiteral("peakResetZoomButton")); filterLayout->addWidget(reset);
    peakExportCsv_ = makeButton(QStringLiteral("▣ 导出 CSV"), QStringLiteral("secondary"), false, filters);
    peakExportCsv_->setObjectName(QStringLiteral("peakExportCsvButton"));
    peakExportCsv_->setToolTip(QStringLiteral("导出当前 run/时间筛选下全部源记录；缩放和绘图降采样不会减少导出行数。会话缓存最多 60000 条。"));
    peakExportCsv_->setEnabled(false); filterLayout->addWidget(peakExportCsv_); layout->addWidget(filters);
    auto *trendBody = new QWidget(page);
    auto *trendLayout = new QVBoxLayout(trendBody);
    trendLayout->setContentsMargins(10, 8, 10, 8); trendLayout->setSpacing(5);
    peakStats_ = makeLabel(QStringLiteral("等待采集记录"), QStringLiteral("statsLine"), trendBody);
    peakStats_->setObjectName(QStringLiteral("peakStatsLabel")); trendLayout->addWidget(peakStats_);
    auto *chartBody = makeChartBody(ChartWidget::Mode::PeakTrend, QStringLiteral("采集时间（本地 HH:mm:ss）"), QStringLiteral("峰值吸光度（无量纲）"), trendBody, QStringLiteral("peakDetailTrendChart"));
    peakPageChart_ = qobject_cast<ChartWidget *>(chartBody);
    trendLayout->addWidget(chartBody, 1);
    peakExportStatus_ = makeLabel(QStringLiteral("操作：滚轮选 X/Y · 图上两点放大 · 右键复位。导出当前筛选的完整源记录，保留原始数值精度。"), QStringLiteral("statsLine"), trendBody);
    peakExportStatus_->setObjectName(QStringLiteral("peakExportStatusLabel")); trendLayout->addWidget(peakExportStatus_);
    layout->addWidget(makePanel(QStringLiteral("⌁  峰值趋势（PeakRecord）"), trendBody, page), 5);
    peakRecordTable_ = new QTableView(page);
    peakRecordTable_->setObjectName(QStringLiteral("peakRecordTable"));
    auto *source = new PeakRecordTableModel(peakRecordTable_);
    auto *proxy = new QSortFilterProxyModel(peakRecordTable_);
    proxy->setSourceModel(source); proxy->setSortRole(Qt::UserRole); proxy->setDynamicSortFilter(true);
    peakRecordTable_->setModel(proxy); peakRecordTable_->setSortingEnabled(true);
    peakRecordTable_->sortByColumn(1, Qt::AscendingOrder);
    peakRecordTable_->setEditTriggers(QAbstractItemView::NoEditTriggers);
    peakRecordTable_->setSelectionBehavior(QAbstractItemView::SelectRows);
    peakRecordTable_->setAlternatingRowColors(true); peakRecordTable_->verticalHeader()->setVisible(false);
    peakRecordTable_->horizontalHeader()->setSectionResizeMode(QHeaderView::Interactive);
    const int widths[]{86, 230, 110, 125, 155, 90, 120, 295};
    for (int i = 0; i < 8; ++i) peakRecordTable_->setColumnWidth(i, widths[i]);
    peakRecordTable_->horizontalHeader()->setStretchLastSection(true);
    peakRecordTable_->setMinimumHeight(210);
    auto *recordsPanel = makePanel(QStringLiteral("▦  峰值记录明细 · 与趋势同源"), peakRecordTable_, page);
    auto *recordsLayout = qobject_cast<QVBoxLayout *>(recordsPanel->layout());
    auto *title = qobject_cast<QLabel *>(recordsLayout->itemAt(0)->widget());
    auto *titleActions = new QHBoxLayout(title);
    titleActions->setContentsMargins(0, 4, 12, 4); titleActions->addStretch(1);
    auto *collapse = makeButton(QStringLiteral("收起"), QStringLiteral("secondary"), true, title);
    collapse->setObjectName(QStringLiteral("peakRecordsCollapseButton")); collapse->setChecked(true);
    collapse->setMaximumWidth(80); titleActions->addWidget(collapse);
    connect(collapse, &QPushButton::toggled, this, [this, collapse, recordsPanel](bool expanded) {
        peakRecordTable_->setVisible(expanded);
        recordsPanel->setMaximumHeight(expanded ? QWIDGETSIZE_MAX : 42);
        collapse->setText(expanded ? QStringLiteral("收起") : QStringLiteral("展开"));
    });
    layout->addWidget(recordsPanel, 4);
    connect(peakAutoFollow_, &QCheckBox::toggled, this, [this](bool enabled) {
        if (enabled && peakCustomFromUtc_.isValid()) {
            peakCustomFromUtc_ = {}; peakCustomToUtc_ = {}; peakFilterSeconds_ = 1800.0;
            updatePeakRecordsView(); peakPageChart_->setPeakWindowSeconds(1800.0);
        }
        peakPageChart_->setPeakLiveFollow(enabled);
    });
    connect(peakPageChart_, &ChartWidget::peakLiveFollowChanged, this, [this](bool enabled) {
        const QSignalBlocker blocker(peakAutoFollow_); peakAutoFollow_->setChecked(enabled);
    });
    connect(reset, &QPushButton::clicked, peakPageChart_, &ChartWidget::resetPeakZoom);
    connect(returnLive, &QPushButton::clicked, this, [this]() {
        peakRunSelect_->setCurrentIndex(0);
        if (peakCustomFromUtc_.isValid()) {
            peakCustomFromUtc_ = {}; peakCustomToUtc_ = {}; peakFilterSeconds_ = 1800.0;
            peakPageChart_->setPeakWindowSeconds(1800.0);
        }
        updatePeakRecordsView(); peakPageChart_->setPeakLiveFollow(true);
    });
    connect(peakExportCsv_, &QPushButton::clicked, this, [this]() {
        if (peakFilteredRecords_.isEmpty()) return;
        emit peakCsvExportToggleRequested(peakFilteredRecords_);
    });
    return page;
}

void AdminTemplateWindow::updatePeakRecordsView()
{
    if (!peakRecordTable_) return;
    const QString choice = peakRunSelect_->currentData().toString();
    const QString run = choice == QStringLiteral("__current__") ? peakDisplayModel_.runId.value : choice;
    const QSignalBlocker blocker(peakRunSelect_);
    for (const auto &record : peakDisplayModel_.peakRecords) {
        if (peakRunSelect_->findData(record.runId.value) < 0) {
            peakRunSelect_->addItem(record.runId.value.left(8) + (record.sourceKind == tdlas::contracts::DataSourceKind::Simulation
                ? QStringLiteral(" · 模拟") : QStringLiteral(" · 实采")), record.runId.value);
        }
    }
    QDateTime newest;
    for (const auto &record : peakDisplayModel_.peakRecords) {
        if ((choice == QStringLiteral("__all__") || record.runId.value == run)
            && (!newest.isValid() || record.acquiredAtUtc > newest)) newest = record.acquiredAtUtc;
    }
    QVector<tdlas::contracts::PeakRecord> filtered;
    for (const auto &record : peakDisplayModel_.peakRecords) {
        if (choice != QStringLiteral("__all__") && record.runId.value != run) continue;
        if (peakCustomFromUtc_.isValid() && (record.acquiredAtUtc < peakCustomFromUtc_ || record.acquiredAtUtc > peakCustomToUtc_)) continue;
        if (!peakCustomFromUtc_.isValid() && peakFilterSeconds_ > 0.0 && record.acquiredAtUtc < newest.addMSecs(-qRound64(peakFilterSeconds_ * 1000.0))) continue;
        filtered.push_back(record);
    }
    peakFilteredRecords_ = filtered;
    auto *proxy = qobject_cast<QSortFilterProxyModel *>(peakRecordTable_->model());
    static_cast<PeakRecordTableModel *>(proxy->sourceModel())->setRecords(filtered);
    peakPageChart_->setPeakRecords(filtered);
    int valid = 0; for (const auto &record : filtered) if (record.validity == tdlas::contracts::DataValidity::Valid && record.peakValue) ++valid;
    peakStats_->setText(QStringLiteral("历史 %1 条  │  有效 %2  │  无效 %3  │  %4  │  时区 %5  │  缓存 %6 / 60000")
        .arg(filtered.size()).arg(valid).arg(filtered.size() - valid)
        .arg(choice == QStringLiteral("__all__") ? QStringLiteral("全部 run（各 run 分段，不跨 run 连线）") : run,
            QString::fromUtf8(QTimeZone::systemTimeZoneId())).arg(peakDisplayModel_.peakRecords.size()));
    peakExportCsv_->setEnabled(!peakExportBusy_ && !filtered.isEmpty());
}

void AdminTemplateWindow::setPeakExportBusy(bool busy)
{
    peakExportBusy_ = busy;
    if (peakExportCsv_) peakExportCsv_->setEnabled(!busy && !peakFilteredRecords_.isEmpty());
}

void AdminTemplateWindow::setPeakExportStreaming(bool streaming)
{
    peakExportStreaming_ = streaming;
    if (peakExportCsv_) {
        peakExportCsv_->setText(streaming ? QStringLiteral("■ 停止保存 CSV") : QStringLiteral("▣ 导出 CSV"));
        peakExportCsv_->setEnabled(streaming || !peakFilteredRecords_.isEmpty());
    }
    if (peakExportStatus_ && streaming)
        peakExportStatus_->setText(QStringLiteral("CSV 正在持续保存（再次点击停止）"));
}

void AdminTemplateWindow::presentPeakExportFeedback(const QString &message, bool isError)
{
    setPeakExportBusy(false);
    peakExportStatus_->setText(message); peakExportStatus_->setToolTip(message);
    peakExportStatus_->setProperty("exportError", isError);
    presentOperationalFeedback(message, isError);
}

QWidget *AdminTemplateWindow::buildCameraPage()
{
    auto *page = new QWidget(this);
    page->setObjectName(QStringLiteral("cameraPage"));
    auto *layout = new QHBoxLayout(page);
    layout->setContentsMargins(16, 10, 16, 16);
    layout->setSpacing(12);

    auto *left = new QWidget(page);
    auto *leftLayout = new QVBoxLayout(left);
    leftLayout->setContentsMargins(0, 0, 0, 0);
    leftLayout->setSpacing(12);
    auto *preview = new CameraPreviewWidget(left);
    leftLayout->addWidget(makePanel(QStringLiteral("▣  相机预览"), preview, left), 1);
    auto *captureBar = new QFrame(left);
    captureBar->setProperty("uiRole", QStringLiteral("captureBar"));
    auto *captureLayout = new QHBoxLayout(captureBar);
    captureLayout->setContentsMargins(22, 10, 22, 10);
    cameraPhotoButton_ = makeButton(QStringLiteral("▣ 拍照"), QStringLiteral("secondary"), false, captureBar);
    cameraPhotoButton_->setObjectName(QStringLiteral("cameraPhotoButton"));
    cameraPhotoButton_->setAccessibleName(QStringLiteral("拍摄实验照片"));
    cameraRecordButton_ = makeButton(QStringLiteral("▶ 开始录像"), QStringLiteral("secondary"), false, captureBar);
    cameraRecordButton_->setObjectName(QStringLiteral("cameraRecordButton"));
    cameraRecordButton_->setAccessibleName(QStringLiteral("开始实验录像"));
    cameraStopButton_ = makeButton(QStringLiteral("■ 停止录像"), QStringLiteral("secondary"), false, captureBar);
    cameraStopButton_->setObjectName(QStringLiteral("cameraStopButton"));
    cameraStopButton_->setAccessibleName(QStringLiteral("停止实验录像"));
    cameraStopButton_->setEnabled(false);
    captureLayout->addWidget(cameraPhotoButton_);
    captureLayout->addWidget(cameraRecordButton_);
    captureLayout->addWidget(cameraStopButton_);
    captureLayout->addStretch(1);
    cameraRecordingStatus_ = makeLabel(QStringLiteral("● 录像时长：00:00:00"), QStringLiteral("fieldLabel"), captureBar);
    cameraRecordingStatus_->setObjectName(QStringLiteral("cameraRecordingStatus"));
    cameraRecordingStatus_->setAccessibleName(QStringLiteral("摄像状态"));
    captureLayout->addWidget(cameraRecordingStatus_);
    leftLayout->addWidget(captureBar);
    layout->addWidget(left, 5);

    auto *right = new QWidget(page);
    auto *rightLayout = new QVBoxLayout(right);
    rightLayout->setContentsMargins(0, 0, 0, 0);
    rightLayout->setSpacing(12);

    auto *deviceBody = new QWidget(right);
    auto *deviceGrid = new QGridLayout(deviceBody);
    deviceGrid->setContentsMargins(14, 10, 14, 12);
    deviceGrid->setHorizontalSpacing(8);
    deviceGrid->setVerticalSpacing(8);
    deviceGrid->addWidget(makeLabel(QStringLiteral("相机选择"), QStringLiteral("fieldLabel"), deviceBody), 0, 0);
    cameraDeviceSelect_ = combo({QStringLiteral("USB Camera (Dev0) · 未连接")}, deviceBody);
    cameraDeviceSelect_->setObjectName(QStringLiteral("cameraDeviceSelect"));
    cameraDeviceSelect_->setAccessibleName(QStringLiteral("相机选择"));
    deviceGrid->addWidget(cameraDeviceSelect_, 0, 1);
    auto *motion = makeButton(QStringLiteral("⇄ 位移/缩放设置"), QStringLiteral("secondary"), false, deviceBody);
    deviceGrid->addWidget(motion, 0, 2);
    deviceGrid->addWidget(makeLabel(QStringLiteral("分辨率"), QStringLiteral("fieldLabel"), deviceBody), 1, 0);
    deviceGrid->addWidget(combo({QStringLiteral("1920 × 1080 (16:9)")}, deviceBody), 1, 1, 1, 2);
    deviceGrid->addWidget(makeLabel(QStringLiteral("帧率"), QStringLiteral("fieldLabel"), deviceBody), 2, 0);
    deviceGrid->addWidget(combo({QStringLiteral("30 FPS")}, deviceBody), 2, 1, 1, 2);
    rightLayout->addWidget(makePanel(QStringLiteral("☷  相机控制"), deviceBody, right));

    auto *paramBody = new QWidget(right);
    auto *paramGrid = new QGridLayout(paramBody);
    paramGrid->setContentsMargins(14, 10, 14, 12);
    paramGrid->setHorizontalSpacing(8);
    paramGrid->setVerticalSpacing(8);
    paramGrid->addWidget(makeLabel(QStringLiteral("曝光时间"), QStringLiteral("fieldLabel"), paramBody), 0, 0);
    paramGrid->addWidget(decimalSpin(10.0, 0.1, 1000.0, 2, paramBody), 0, 1);
    paramGrid->addWidget(makeLabel(QStringLiteral("ms"), QStringLiteral("fieldLabel"), paramBody), 0, 2);
    paramGrid->addWidget(new QCheckBox(QStringLiteral("自动曝光"), paramBody), 0, 3);
    paramGrid->addWidget(makeLabel(QStringLiteral("增益"), QStringLiteral("fieldLabel"), paramBody), 1, 0);
    paramGrid->addWidget(decimalSpin(6.0, 0.0, 24.0, 1, paramBody), 1, 1);
    paramGrid->addWidget(makeLabel(QStringLiteral("dB"), QStringLiteral("fieldLabel"), paramBody), 1, 2);
    paramGrid->addWidget(combo({QStringLiteral("白平衡：自动")}, paramBody), 1, 3);
    const QStringList sliderNames{QStringLiteral("亮度"), QStringLiteral("对比度"), QStringLiteral("饱和度")};
    for (int row = 0; row < sliderNames.size(); ++row) {
        paramGrid->addWidget(makeLabel(sliderNames.at(row), QStringLiteral("fieldLabel"), paramBody), row + 2, 0);
        auto *slider = new QSlider(Qt::Horizontal, paramBody);
        slider->setValue(50);
        paramGrid->addWidget(slider, row + 2, 1, 1, 2);
        auto *value = new QSpinBox(paramBody);
        value->setRange(0, 100);
        value->setValue(50);
        paramGrid->addWidget(value, row + 2, 3);
    }
    rightLayout->addWidget(makePanel(QStringLiteral("⚙  相机参数"), paramBody, right));

    auto *mediaBody = new QWidget(right);
    auto *mediaLayout = new QVBoxLayout(mediaBody);
    mediaLayout->setContentsMargins(14, 10, 14, 12);
    auto *open = makeButton(QStringLiteral("▭ 打开目录"), QStringLiteral("link"), false, mediaBody);
    mediaLayout->addWidget(open, 0, Qt::AlignRight);
    auto *thumbs = new QHBoxLayout();
    for (const QString &name : {QStringLiteral("IMG_0001.png"), QStringLiteral("IMG_0002.png"), QStringLiteral("IMG_0003.png"), QStringLiteral("VID_0001.mp4")}) {
        auto *thumb = makeButton(QStringLiteral("▧\n%1").arg(name), QStringLiteral("thumbnail"), false, mediaBody);
        if (!cameraLastMediaButton_) {
            cameraLastMediaButton_ = thumb;
            cameraLastMediaButton_->setObjectName(QStringLiteral("cameraLastMediaButton"));
        }
        thumbs->addWidget(thumb);
    }
    mediaLayout->addLayout(thumbs);
    rightLayout->addWidget(makePanel(QStringLiteral("▣  图像/视频管理 · 模拟条目"), mediaBody, right), 1);
    layout->addWidget(right, 3);

    connect(motion, &QPushButton::clicked, this, [this]() { setScreen(Screen::CameraMotion); });
    connect(cameraPhotoButton_, &QPushButton::clicked, this, &AdminTemplateWindow::capturePhotoRequested);
    connect(cameraRecordButton_, &QPushButton::clicked, this, &AdminTemplateWindow::startRecordingRequested);
    connect(cameraStopButton_, &QPushButton::clicked, this, &AdminTemplateWindow::stopRecordingRequested);
    connect(open, &QPushButton::clicked, this, &AdminTemplateWindow::openMediaDirectoryRequested);
    connect(cameraDeviceSelect_, &QComboBox::currentIndexChanged, this, [this](int index) {
        const QString cameraId = cameraDeviceSelect_->itemData(index).toString();
        if (!cameraId.isEmpty()) {
            emit cameraDeviceSelected(cameraId);
        }
    });
    for (auto *button : page->findChildren<QPushButton *>()) {
        if (button == motion || button == cameraPhotoButton_ || button == cameraRecordButton_
            || button == cameraStopButton_ || button == open) {
            continue;
        }
        connect(button, &QPushButton::clicked, this, [this, button]() {
            emit actionRequested(button->text());
            showTemplateNotice(QStringLiteral("摄像功能未接入：%1").arg(button->text().remove('\n')));
        });
    }
    return page;
}

void AdminTemplateWindow::buildParameterDrawer()
{
    parameterDrawer_ = new QFrame(this);
    parameterDrawer_->setObjectName(QStringLiteral("parameterDrawer"));
    parameterDrawer_->setVisible(false);
    auto *layout = new QVBoxLayout(parameterDrawer_);
    layout->setContentsMargins(18, 14, 18, 18);
    layout->setSpacing(10);

    auto *header = new QHBoxLayout();
    header->addWidget(makeLabel(QStringLiteral("采集参数"), QStringLiteral("drawerTitle"), parameterDrawer_));
    header->addStretch(1);
    auto *close = makeButton(QStringLiteral("×"), QStringLiteral("iconAction"), false, parameterDrawer_);
    close->setFixedSize(38, 38);
    header->addWidget(close);
    layout->addLayout(header);

    auto *formHost = new QWidget(parameterDrawer_);
    auto *form = new QFormLayout(formHost);
    form->setContentsMargins(0, 0, 0, 0);
    form->setHorizontalSpacing(12);
    form->setVerticalSpacing(12);
    form->setFieldGrowthPolicy(QFormLayout::AllNonFixedFieldsGrow);
    parameterDevice_ = combo({QStringLiteral("NI USB-6361 (Dev1) · 未连接")}, formHost);
    parameterOutputChannel_ = combo({QStringLiteral("AO0")}, formHost);
    parameterWaveform_ = combo({QStringLiteral("正弦波"), QStringLiteral("方波"),
                                QStringLiteral("三角波"), QStringLiteral("锯齿波")}, formHost);
    parameterOutputFrequency_ = decimalSpin(10.000, 0.001, 100000.0, 3, formHost);
    parameterOutputAmplitude_ = decimalSpin(2.000, 0.0, 10.0, 3, formHost);
    parameterOutputOffset_ = decimalSpin(0.000, -10.0, 10.0, 3, formHost);
    parameterInputChannel_ = combo({QStringLiteral("AI0")}, formHost);
    parameterSampleRate_ = new QSpinBox(formHost);
    parameterSampleRate_->setRange(1, 2000000);
    parameterSampleRate_->setValue(200000);
    parameterSampleRate_->setObjectName(QStringLiteral("parameterSampleRate"));
    parameterBlockSize_ = new QSpinBox(formHost);
    parameterBlockSize_->setRange(100, 1000000);
    parameterBlockSize_->setValue(100000);
    parameterBlockSize_->setObjectName(QStringLiteral("parameterBlockSize"));
    parameterInputMaximum_ = decimalSpin(10.000, -10.0, 10.0, 3, formHost);
    parameterInputMinimum_ = decimalSpin(-10.000, -10.0, 10.0, 3, formHost);
    parameterInputMaximum_->setObjectName(QStringLiteral("parameterInputMaximum"));
    parameterInputMinimum_->setObjectName(QStringLiteral("parameterInputMinimum"));
    form->addRow(QStringLiteral("1.采集卡（设备识别）"), parameterDevice_);
    form->addRow(QStringLiteral("2.输出通道"), parameterOutputChannel_);
    form->addRow(QStringLiteral("3.输出波形"), parameterWaveform_);
    form->addRow(QStringLiteral("4.波形频率"), parameterOutputFrequency_);
    form->addRow(QStringLiteral("5.波形幅值"), parameterOutputAmplitude_);
    form->addRow(QStringLiteral("6.波形偏移量"), parameterOutputOffset_);
    form->addRow(QStringLiteral("7.采集通道"), parameterInputChannel_);
    form->addRow(QStringLiteral("8.采样率（S/s）"), parameterSampleRate_);
    form->addRow(QStringLiteral("9.显示窗口读取点数"), parameterBlockSize_);
    form->addRow(QStringLiteral("10.量程上限（V）"), parameterInputMaximum_);
    form->addRow(QStringLiteral("11.量程下限（V）"), parameterInputMinimum_);
    layout->addWidget(formHost, 1);

    auto *actions = new QHBoxLayout();
    auto *save = makeButton(QStringLiteral("▣ 保存参数"), QStringLiteral("primary"), false, parameterDrawer_);
    auto *restore = makeButton(QStringLiteral("↻ 恢复默认"), QStringLiteral("secondary"), false, parameterDrawer_);
    actions->addWidget(save);
    actions->addWidget(restore);
    layout->addLayout(actions);

    connect(close, &QPushButton::clicked, this, [this]() { setScreen(Screen::Main); });
    save->setObjectName(QStringLiteral("saveParametersButton"));
    restore->setObjectName(QStringLiteral("restoreParametersButton"));
    connect(save, &QPushButton::clicked, this, [this]() {
        emit parameterDraftSubmitted(measurementParameterDraft());
    });
    connect(restore, &QPushButton::clicked, this, &AdminTemplateWindow::restoreDefaultParametersRequested);
    connect(parameterDevice_, QOverload<int>::of(&QComboBox::currentIndexChanged), this,
        [this](int) { updateParameterChannelsFromSelectedDevice(); });
}

void AdminTemplateWindow::buildMovementPanel()
{
    movementPanel_ = new QFrame(cameraPage_);
    movementPanel_->setObjectName(QStringLiteral("movementPanel"));
    movementPanel_->setVisible(false);
    auto *layout = new QVBoxLayout(movementPanel_);
    layout->setContentsMargins(16, 12, 16, 16);
    layout->setSpacing(10);

    auto *header = new QHBoxLayout();
    header->addWidget(makeLabel(QStringLiteral("⇄  位移/缩放控制"), QStringLiteral("drawerTitle"), movementPanel_));
    header->addStretch(1);
    auto *close = makeButton(QStringLiteral("×"), QStringLiteral("iconAction"), false, movementPanel_);
    close->setFixedSize(34, 34);
    header->addWidget(close);
    layout->addLayout(header);

    auto *content = new QHBoxLayout();
    auto *moveBox = new QFrame(movementPanel_);
    auto *moveGrid = new QGridLayout(moveBox);
    moveGrid->setContentsMargins(8, 8, 8, 8);
    moveGrid->addWidget(makeLabel(QStringLiteral("取景位移"), QStringLiteral("fieldLabel"), moveBox), 0, 0, 1, 3, Qt::AlignCenter);
    auto *up = makeButton(QStringLiteral("▲"), QStringLiteral("movement"), false, moveBox);
    auto *left = makeButton(QStringLiteral("◀"), QStringLiteral("movement"), false, moveBox);
    auto *right = makeButton(QStringLiteral("▶"), QStringLiteral("movement"), false, moveBox);
    auto *down = makeButton(QStringLiteral("▼"), QStringLiteral("movement"), false, moveBox);
    moveGrid->addWidget(up, 1, 1);
    moveGrid->addWidget(left, 2, 0);
    moveGrid->addWidget(right, 2, 2);
    moveGrid->addWidget(down, 3, 1);
    content->addWidget(moveBox, 3);

    auto *zoomBox = new QFrame(movementPanel_);
    auto *zoomLayout = new QVBoxLayout(zoomBox);
    zoomLayout->setContentsMargins(8, 8, 8, 8);
    zoomLayout->addWidget(makeLabel(QStringLiteral("缩放控制"), QStringLiteral("fieldLabel"), zoomBox), 0, Qt::AlignCenter);
    auto *zoomIn = makeButton(QStringLiteral("⊕\n放大"), QStringLiteral("movement"), false, zoomBox);
    auto *zoomOut = makeButton(QStringLiteral("⊖\n缩小"), QStringLiteral("movement"), false, zoomBox);
    zoomLayout->addWidget(zoomIn);
    zoomLayout->addWidget(zoomOut);
    content->addWidget(zoomBox, 2);
    layout->addLayout(content, 1);

    connect(close, &QPushButton::clicked, this, [this]() { setScreen(Screen::Camera); });
    using tdlas::camera::CameraViewOperation;
    using tdlas::camera::CameraViewState;
    const auto bindViewButton = [this](QPushButton *button, const char *name,
        const QString &description, CameraViewOperation operation, bool repeat) {
        button->setObjectName(QString::fromLatin1(name));
        button->setProperty("cameraViewControl", true);
        button->setAccessibleName(description);
        button->setProperty("cameraOperation", static_cast<int>(operation));
        button->setToolTip(description + (operation == CameraViewOperation::RotateClockwise
            ? QStringLiteral("（软件图像旋转）") : QStringLiteral("（相机设备控制，取景变化会进入照片和录像）")));
        button->setEnabled(false);
        button->setAutoRepeat(repeat);
        button->setAutoRepeatDelay(CameraViewState::repeatDelayMilliseconds);
        button->setAutoRepeatInterval(CameraViewState::repeatIntervalMilliseconds);
        connect(button, &QPushButton::clicked, this, [this, operation]() {
            emit cameraViewOperationRequested(operation);
        });
    };
    bindViewButton(up, "cameraMoveUpButton", QStringLiteral("相机向上取景"), CameraViewOperation::MoveUp, true);
    bindViewButton(down, "cameraMoveDownButton", QStringLiteral("相机向下取景"), CameraViewOperation::MoveDown, true);
    bindViewButton(left, "cameraMoveLeftButton", QStringLiteral("相机向左取景"), CameraViewOperation::MoveLeft, true);
    bindViewButton(right, "cameraMoveRightButton", QStringLiteral("相机向右取景"), CameraViewOperation::MoveRight, true);
    bindViewButton(zoomIn, "cameraZoomInButton", QStringLiteral("相机设备放大"), CameraViewOperation::ZoomIn, true);
    bindViewButton(zoomOut, "cameraZoomOutButton", QStringLiteral("相机设备缩小"), CameraViewOperation::ZoomOut, true);
    auto *viewActions = new QHBoxLayout();
    auto *rotate = makeButton(QStringLiteral("顺时针 90°"), QStringLiteral("secondary"), false, movementPanel_);
    auto *reset = makeButton(QStringLiteral("复位"), QStringLiteral("secondary"), false, movementPanel_);
    bindViewButton(rotate, "cameraRotate90Button", QStringLiteral("图像顺时针旋转90度"), CameraViewOperation::RotateClockwise, false);
    bindViewButton(reset, "cameraResetViewButton", QStringLiteral("复位设备PTZ与图像旋转"), CameraViewOperation::Reset, false);
    viewActions->addWidget(rotate);
    viewActions->addWidget(reset);
    layout->addLayout(viewActions);
    cameraControlStatus_ = makeLabel(QStringLiteral("等待有效画面和设备控制能力"), QStringLiteral("fieldLabel"), movementPanel_);
    cameraControlStatus_->setObjectName(QStringLiteral("cameraControlStatus"));
    cameraControlStatus_->setWordWrap(true);
    cameraControlStatus_->setMinimumHeight(44);
    layout->addWidget(cameraControlStatus_);
}

void AdminTemplateWindow::setScreen(Screen screen)
{
    screen_ = screen;
    int index = 0;
    if (screen == Screen::Debug) {
        index = 1;
    } else if (screen == Screen::PeakData) {
        index = 2;
    } else if (screen == Screen::Camera || screen == Screen::CameraMotion) {
        index = 3;
    }
    pages_->setCurrentIndex(index);
    selectPageButton(index);
    if (index == 2) {
        updatePeakRecordsView();
    }
    presentMeasurementDisplay(peakDisplayModel_);
    parameterDrawer_->setVisible(screen == Screen::Parameters);
    movementPanel_->setVisible(screen == Screen::CameraMotion);
    updateOverlays();
}

tdlas::contracts::ParameterDraft AdminTemplateWindow::measurementParameterDraft() const
{
    tdlas::contracts::ParameterDraft draft;
    draft.deviceId = parameterDevice_->currentData().toString();
    draft.aiChannelIds = {parameterInputChannel_->currentData().toString()};
    draft.sampleRateHz = parameterSampleRate_->value();
    draft.readSamplesPerBlock = parameterBlockSize_->value();
    draft.inputRangeMinV = parameterInputMinimum_->value();
    draft.inputRangeMaxV = parameterInputMaximum_->value();
    draft.aoEnabled = parameterOutputChannel_->currentData().toBool();
    draft.aoChannelId = draft.aoEnabled ? parameterOutputChannel_->currentData(Qt::UserRole + 1).toString() : QString();
    draft.waveform = static_cast<tdlas::contracts::Waveform>(parameterWaveform_->currentData().toInt());
    draft.outputFrequencyHz = parameterOutputFrequency_->value();
    draft.outputAmplitudePeakV = parameterOutputAmplitude_->value();
    draft.outputOffsetV = parameterOutputOffset_->value();
    draft.outputSampleRateHz = draft.aoEnabled
        ? qMax(draft.sampleRateHz, draft.outputFrequencyHz * 10.0)
        : 0.0;
    draft.algorithmParameterSetId = QStringLiteral("tdlas-v1.6-ui");
    return draft;
}

void AdminTemplateWindow::presentParameterDraft(const tdlas::contracts::ParameterDraft &draft)
{
    int deviceIndex = parameterDevice_->findData(draft.deviceId);
    if (deviceIndex < 0) {
        parameterDevice_->addItem(
            QStringLiteral("%1 · 当前不可用").arg(draft.deviceId), draft.deviceId);
        deviceIndex = parameterDevice_->count() - 1;
        parameterDevice_->setItemData(deviceIndex, draft.aiChannelIds, kAiChannelsRole);
        parameterDevice_->setItemData(
            deviceIndex,
            draft.aoChannelId.isEmpty() ? QStringList{} : QStringList{draft.aoChannelId},
            kAoChannelsRole);
    }
    parameterDevice_->setCurrentIndex(deviceIndex);
    updateParameterChannelsFromSelectedDevice(
        draft.aiChannelIds.value(0), draft.aoChannelId, draft.aoEnabled);
    parameterWaveform_->clear();
    parameterWaveform_->addItem(QStringLiteral("正弦波"), static_cast<int>(tdlas::contracts::Waveform::Sine));
    parameterWaveform_->addItem(QStringLiteral("方波"), static_cast<int>(tdlas::contracts::Waveform::Square));
    parameterWaveform_->addItem(QStringLiteral("三角波"), static_cast<int>(tdlas::contracts::Waveform::Triangle));
    parameterWaveform_->addItem(QStringLiteral("锯齿波"), static_cast<int>(tdlas::contracts::Waveform::Sawtooth));
    parameterWaveform_->setCurrentIndex(qMax(0, parameterWaveform_->findData(static_cast<int>(draft.waveform))));
    parameterOutputFrequency_->setValue(draft.outputFrequencyHz);
    parameterOutputAmplitude_->setValue(draft.outputAmplitudePeakV);
    parameterOutputOffset_->setValue(draft.outputOffsetV);
    parameterSampleRate_->setValue(qRound(draft.sampleRateHz));
    parameterBlockSize_->setValue(static_cast<int>(draft.readSamplesPerBlock));
    parameterInputMaximum_->setValue(draft.inputRangeMaxV);
    parameterInputMinimum_->setValue(draft.inputRangeMinV);
}

void AdminTemplateWindow::presentAcquisitionDevices(
    const QVector<tdlas::acquisition::AcquisitionDeviceDescriptor> &devices,
    const QString &statusMessage)
{
    const tdlas::contracts::ParameterDraft draft = measurementParameterDraft();
    const QSignalBlocker blocker(parameterDevice_);
    parameterDevice_->clear();
    for (const tdlas::acquisition::AcquisitionDeviceDescriptor &device : devices) {
        const QString source = device.sourceKind == tdlas::contracts::DataSourceKind::Simulation
            ? QStringLiteral("模拟")
            : QStringLiteral("真实设备");
        parameterDevice_->addItem(
            QStringLiteral("%1 · %2").arg(device.displayName, source), device.id);
        const int index = parameterDevice_->count() - 1;
        parameterDevice_->setItemData(index, device.aiPhysicalChannels, kAiChannelsRole);
        parameterDevice_->setItemData(index, device.aoPhysicalChannels, kAoChannelsRole);
    }
    if (devices.isEmpty()) {
        parameterDevice_->addItem(QStringLiteral("未发现采集设备"));
        parameterDevice_->setEnabled(false);
    } else {
        parameterDevice_->setEnabled(true);
        int index = parameterDevice_->findData(draft.deviceId);
        parameterDevice_->setCurrentIndex(index >= 0 ? index : 0);
    }
    updateParameterChannelsFromSelectedDevice(
        draft.aiChannelIds.value(0), draft.aoChannelId, draft.aoEnabled);
    showTemplateNotice(statusMessage);
}

void AdminTemplateWindow::updateParameterChannelsFromSelectedDevice(
    const QString &preferredAiChannel,
    const QString &preferredAoChannel,
    bool aoEnabled)
{
    if (modeLabel_) {
        const QString deviceId = parameterDevice_->currentData().toString();
        const bool simulation = deviceId.startsWith(
            QStringLiteral("mock-"), Qt::CaseInsensitive);
        modeLabel_->setText(deviceId.isEmpty()
                ? QStringLiteral("设备待识别")
                : (simulation ? QStringLiteral("模拟数据") : QStringLiteral("真实采集")));
    }
    const QStringList aiChannels = parameterDevice_->currentData(kAiChannelsRole).toStringList();
    const QStringList aoChannels = parameterDevice_->currentData(kAoChannelsRole).toStringList();

    const QSignalBlocker aiBlocker(parameterInputChannel_);
    parameterInputChannel_->clear();
    for (const QString &channel : aiChannels) {
        parameterInputChannel_->addItem(channel, channel);
    }
    if (parameterInputChannel_->count() == 0) {
        parameterInputChannel_->addItem(QStringLiteral("无可用 AI 通道"));
        parameterInputChannel_->setEnabled(false);
    } else {
        parameterInputChannel_->setEnabled(true);
        const int preferredIndex = parameterInputChannel_->findData(preferredAiChannel);
        parameterInputChannel_->setCurrentIndex(preferredIndex >= 0 ? preferredIndex : 0);
    }

    const QSignalBlocker aoBlocker(parameterOutputChannel_);
    parameterOutputChannel_->clear();
    parameterOutputChannel_->addItem(QStringLiteral("不使用输出通道"), false);
    for (const QString &channel : aoChannels) {
        parameterOutputChannel_->addItem(channel, true);
        parameterOutputChannel_->setItemData(
            parameterOutputChannel_->count() - 1, channel, Qt::UserRole + 1);
    }
    if (aoEnabled) {
        const int preferredIndex = parameterOutputChannel_->findData(
            preferredAoChannel, Qt::UserRole + 1);
        if (preferredIndex >= 0) {
            parameterOutputChannel_->setCurrentIndex(preferredIndex);
        }
    }
}

void AdminTemplateWindow::presentParameterFeedback(const QString &message, bool isError)
{
    showTemplateNotice(isError
            ? QStringLiteral("参数校验失败：%1").arg(message)
            : message);
}

void AdminTemplateWindow::presentOperationalFeedback(const QString &message, bool isError)
{
    showTemplateNotice(isError
            ? QStringLiteral("操作失败：%1").arg(message)
            : message);
}

void AdminTemplateWindow::presentMeasurementDisplay(
    const tdlas::contracts::MeasurementDisplayModel &model)
{
    const auto &before = peakDisplayModel_.peakRecords;
    const auto &after = model.peakRecords;
    const bool peakChanged = peakDisplayModel_.runId != model.runId || before.size() != after.size()
        || (!after.isEmpty() && (before.isEmpty() || before.last().sequence != after.last().sequence || before.last().runId != after.last().runId
            || before.first().runId != after.first().runId || before.first().sequence != after.first().sequence));
    QString stateText;
    switch (model.state) {
    case tdlas::contracts::MeasurementState::Idle:
        stateText = QStringLiteral("已停止");
        break;
    case tdlas::contracts::MeasurementState::Preparing:
        stateText = QStringLiteral("准备中");
        break;
    case tdlas::contracts::MeasurementState::Running:
        stateText = QStringLiteral("采集中");
        break;
    case tdlas::contracts::MeasurementState::Stopping:
        stateText = QStringLiteral("停止中");
        break;
    case tdlas::contracts::MeasurementState::Faulted:
        stateText = QStringLiteral("故障");
        break;
    }

    const bool connected = model.connectionState == tdlas::contracts::DeviceConnectionState::Connected;
    const QString source = model.sourceKind == tdlas::contracts::DataSourceKind::Simulation
        ? QStringLiteral("模拟设备")
        : QStringLiteral("NI 真实设备");
    const QString dataTag = model.sourceKind == tdlas::contracts::DataSourceKind::Simulation
        ? QStringLiteral("模拟")
        : QStringLiteral("实采");
    if (deviceStatusLabel_) {
        deviceStatusLabel_->setText(connected
                ? QStringLiteral("▣  设备状态：● %1已连接").arg(source)
                : QStringLiteral("▣  设备状态：● 未连接"));
    }
    if (modeLabel_) {
        modeLabel_->setText(model.sourceKind == tdlas::contracts::DataSourceKind::Simulation
                ? QStringLiteral("模拟数据")
                : QStringLiteral("真实采集"));
    }
    if (measurementStatusLabel_) {
        measurementStatusLabel_->setText(QStringLiteral("▶  采集状态：● %1").arg(stateText));
    }
    if (startMeasurementButton_) {
        startMeasurementButton_->setEnabled(
            model.state == tdlas::contracts::MeasurementState::Idle
            || model.state == tdlas::contracts::MeasurementState::Stopping);
    }
    if (stopMeasurementButton_) {
        stopMeasurementButton_->setEnabled(
            model.state == tdlas::contracts::MeasurementState::Preparing
            || model.state == tdlas::contracts::MeasurementState::Running);
    }
    if (peakValueLabel_) {
        peakValueLabel_->setText(model.peakAbsorbance.has_value()
                ? QStringLiteral("%1  · %2").arg(*model.peakAbsorbance, 0, 'f', 4).arg(dataTag)
                : QStringLiteral("—  等待数据"));
    }
    if (lightValueLabel_) {
        lightValueLabel_->setText(model.lightPercent.has_value()
                ? QStringLiteral("%1 %  · %2").arg(*model.lightPercent, 0, 'f', 2).arg(dataTag)
                : QStringLiteral("—  等待数据"));
    }
    if (concentrationValueLabel_) {
        concentrationValueLabel_->setText(model.concentration.has_value()
                ? QStringLiteral("%1 %2").arg(*model.concentration, 0, 'f', 3).arg(model.concentrationUnit)
                : QStringLiteral("—  未校准"));
    }

    if (debugPeakValueLabel_) {
        debugPeakValueLabel_->setText(QStringLiteral("⌁ 实时峰值：  %1").arg(peakValueLabel_->text()));
        debugLightValueLabel_->setText(QStringLiteral("☼ 光强百分比：  %1").arg(lightValueLabel_->text()));
        debugConcentrationValueLabel_->setText(QStringLiteral("◇ 气体浓度：  %1").arg(concentrationValueLabel_->text()));
    }

    for (ChartWidget *chart : findChildren<ChartWidget *>()) {
        // Keep both main/debug histories on the same completed batch even while
        // one page is hidden; switching pages must not wait for the next group.
        if (!chart->isVisible() && !(peakChanged && chart->mode() == ChartWidget::Mode::PeakTrend
                && chart != peakPageChart_)) continue;
        chart->setDataSource(model.sourceKind);
        chart->setTimeRange(model.waveformDurationSeconds);
        switch (chart->mode()) {
        case ChartWidget::Mode::RawSignal:
            chart->setSeriesData(model.rawSeries);
            break;
        case ChartWidget::Mode::FitCurve:
            chart->setSeriesData(model.processedVoltageSeries, model.fittedVoltageSeries);
            break;
        case ChartWidget::Mode::FvCurve:
            chart->setSeriesData(model.fittedAbsorbanceSeries);
            break;
        case ChartWidget::Mode::PeakTrend:
            if (chart != peakPageChart_ && peakChanged) {
                QVector<tdlas::contracts::PeakRecord> current;
                for (const auto &record : model.peakRecords) if (record.runId == model.runId) current.push_back(record);
                chart->setPeakRecords(current);
            }
            break;
        }
    }
    peakDisplayModel_ = model;
    if (peakChanged && pages_->currentIndex() == 2) updatePeakRecordsView();
    showTemplateNotice(model.statusMessage);
}

void AdminTemplateWindow::presentCameraControls(const tdlas::camera::CameraControlState &state)
{
    cameraControls_ = state;
    const auto value = [](const tdlas::camera::CameraControlRange &range) {
        return range.readable ? QString::number(range.value) : QStringLiteral("不支持");
    };
    const QString source = state.simulated ? QStringLiteral("模拟设备") : QStringLiteral("相机设备");
    cameraControlStatus_->setText(QStringLiteral("%1 · Pan %2  Tilt %3  Zoom %4\n%5")
        .arg(source, value(state.pan), value(state.tilt), value(state.zoom),
            state.message.isEmpty() ? QStringLiteral("按驱动步长控制；到达边界自动禁用") : state.message));
    cameraControlStatus_->setToolTip(QStringLiteral("设备原始值，不代表变焦倍率。Zoom 范围 %1～%2，步长 %3；90° 为软件旋转。")
        .arg(state.zoom.minimum).arg(state.zoom.maximum).arg(state.zoom.step));
    updateCameraControlButtons();
}

void AdminTemplateWindow::updateCameraControlButtons()
{
    for (QPushButton *button : movementPanel_->findChildren<QPushButton *>()) {
        if (!button->property("cameraViewControl").toBool()) continue;
        const auto operation = static_cast<tdlas::camera::CameraViewOperation>(button->property("cameraOperation").toInt());
        const bool displayOperation = operation == tdlas::camera::CameraViewOperation::RotateClockwise
            || operation == tdlas::camera::CameraViewOperation::Reset;
        button->setEnabled(cameraViewReady_ && (displayOperation
            || tdlas::camera::cameraHardwareOperationEnabled(cameraControls_, operation)));
        if (!displayOperation) {
            const auto &range = operation == tdlas::camera::CameraViewOperation::MoveLeft
                    || operation == tdlas::camera::CameraViewOperation::MoveRight ? cameraControls_.pan
                : operation == tdlas::camera::CameraViewOperation::MoveUp
                    || operation == tdlas::camera::CameraViewOperation::MoveDown ? cameraControls_.tilt : cameraControls_.zoom;
            button->setToolTip(!range.writable ? QStringLiteral("当前设备不支持此控制，或设备控制尚未就绪。")
                : QStringLiteral("设备当前值 %1，范围 %2～%3，步长 %4。%5")
                    .arg(range.value).arg(range.minimum).arg(range.maximum).arg(range.step)
                    .arg(button->isEnabled() ? QStringLiteral("直接控制相机取景，会影响照片和录像。") : QStringLiteral("已到设备边界或画面未就绪。")));
        }
    }
}

void AdminTemplateWindow::presentCameraView(const tdlas::camera::CameraViewState &state)
{
    for (CameraPreviewWidget *preview : findChildren<CameraPreviewWidget *>()) {
        preview->setViewState(state);
    }
}

void AdminTemplateWindow::presentCameraDisplay(const tdlas::camera::CameraDisplayModel &model)
{
    if (cameraDeviceSelect_) {
        const QSignalBlocker blocker(cameraDeviceSelect_);
        const bool needsExplicitChoice = model.selectedCameraId.isEmpty()
            && !model.devices.isEmpty()
            && model.devices.first().sourceKind == tdlas::contracts::DataSourceKind::RealDevice;
        const int expectedCount = model.devices.isEmpty()
            ? 1
            : model.devices.size() + (needsExplicitChoice ? 1 : 0);
        bool devicesChanged = cameraDeviceSelect_->count() != expectedCount;
        for (int index = 0; !devicesChanged && index < model.devices.size(); ++index) {
            const int comboIndex = index + (needsExplicitChoice ? 1 : 0);
            devicesChanged = cameraDeviceSelect_->itemData(comboIndex).toString()
                != model.devices.at(index).id;
        }
        if (devicesChanged) {
            cameraDeviceSelect_->clear();
            if (model.devices.isEmpty()) {
                cameraDeviceSelect_->addItem(QStringLiteral("未发现设备"));
            } else {
                if (needsExplicitChoice) {
                    cameraDeviceSelect_->addItem(QStringLiteral("请选择已授权摄像头"));
                }
                for (const tdlas::camera::CameraDeviceDescriptor &device : model.devices) {
                    const QString suffix = device.sourceKind == tdlas::contracts::DataSourceKind::Simulation
                        ? QStringLiteral(" · 模拟")
                        : QStringLiteral(" · 真实设备");
                    cameraDeviceSelect_->addItem(device.displayName + suffix, device.id);
                }
            }
        }
        const int selectedIndex = cameraDeviceSelect_->findData(model.selectedCameraId);
        if (selectedIndex >= 0 && cameraDeviceSelect_->currentIndex() != selectedIndex) {
            cameraDeviceSelect_->setCurrentIndex(selectedIndex);
        }
    }

    const bool previewReady = model.state == tdlas::camera::CameraSessionState::Previewing
        || model.state == tdlas::camera::CameraSessionState::Recording;
    const bool viewReady = previewReady && model.latestFrame.has_value() && model.latestFrame->isValid();
    cameraViewReady_ = viewReady;
    updateCameraControlButtons();
    const bool recording = model.state == tdlas::camera::CameraSessionState::Recording;
    if (cameraPhotoButton_) {
        cameraPhotoButton_->setEnabled(previewReady);
    }
    if (cameraRecordButton_) {
        cameraRecordButton_->setEnabled(previewReady && !recording);
    }
    if (cameraStopButton_) {
        cameraStopButton_->setEnabled(recording);
    }
    if (cameraRecordingStatus_) {
        const QString source = model.sourceKind == tdlas::contracts::DataSourceKind::Simulation
            ? QStringLiteral("模拟")
            : QStringLiteral("真实设备");
        cameraRecordingStatus_->setText(QStringLiteral("● 录像时长：%1 · %2")
            .arg(cameraDurationText(model.recordingDurationMilliseconds), source));
        cameraRecordingStatus_->setToolTip(model.statusMessage);
    }

    const QString previewStatus = model.state == tdlas::camera::CameraSessionState::Faulted
        ? QStringLiteral("连接已断开")
        : (model.sourceKind == tdlas::contracts::DataSourceKind::Simulation
                  ? QStringLiteral("模拟预览")
                  : QStringLiteral("实时预览"));
    const QString formatText = model.activeFormat.isValid()
        ? QStringLiteral("%1 × %2   %3 FPS")
              .arg(model.activeFormat.frameSize.width())
              .arg(model.activeFormat.frameSize.height())
              .arg(model.activeFormat.maximumFrameRate, 0, 'f', 0)
        : QStringLiteral("等待视频帧");
    for (CameraPreviewWidget *preview : findChildren<CameraPreviewWidget *>()) {
        if (model.latestFrame.has_value() && model.latestFrame->isValid()) {
            preview->setFrame(model.latestFrame->image, previewStatus, formatText);
        } else {
            preview->setFrame(QImage(), previewStatus, formatText);
        }
    }
    if (cameraLastMediaButton_ && model.lastMediaResult.has_value()) {
        const tdlas::camera::MediaResult &media = *model.lastMediaResult;
        cameraLastMediaButton_->setText(media.success
                ? QStringLiteral("▧\n%1").arg(QFileInfo(media.path).fileName())
                : QStringLiteral("▧\n保存失败"));
        cameraLastMediaButton_->setToolTip(media.success ? media.path : media.diagnostic);
    }
}

bool AdminTemplateWindow::saveCapture(const QString &path)
{
    const QFileInfo info(path);
    if (!QDir().mkpath(info.absolutePath())) {
        return false;
    }
    return grab().save(info.absoluteFilePath(), "PNG");
}

void AdminTemplateWindow::keyPressEvent(QKeyEvent *event)
{
    if (event->key() >= Qt::Key_F1 && event->key() <= Qt::Key_F6) {
        const std::array<Screen, 6> screens{Screen::Main, Screen::Parameters, Screen::Debug, Screen::PeakData, Screen::Camera, Screen::CameraMotion};
        setScreen(screens.at(static_cast<std::size_t>(event->key() - Qt::Key_F1)));
        event->accept();
        return;
    }
    if (event->key() == Qt::Key_Escape) {
        if (screen_ == Screen::Parameters) {
            setScreen(Screen::Main);
        } else if (screen_ == Screen::CameraMotion) {
            setScreen(Screen::Camera);
        } else {
            close();
        }
        event->accept();
        return;
    }
    QWidget::keyPressEvent(event);
}

void AdminTemplateWindow::resizeEvent(QResizeEvent *event)
{
    QWidget::resizeEvent(event);
    updateOverlays();
}

void AdminTemplateWindow::updateOverlays()
{
    if (parameterDrawer_) {
        parameterDrawer_->setGeometry(88, 64, qMin(410, width() - 140), qMax(300, height() - 64));
        if (parameterDrawer_->isVisible()) {
            parameterDrawer_->raise();
        }
    }
    if (movementPanel_ && cameraPage_) {
        const int panelWidth = qMin(420, cameraPage_->width() - 40);
        movementPanel_->setGeometry(qMax(18, cameraPage_->width() - panelWidth - 18), 72, panelWidth, qMin(440, cameraPage_->height() - 90));
        if (movementPanel_->isVisible()) {
            movementPanel_->raise();
        }
    }
}

void AdminTemplateWindow::selectPageButton(int index)
{
    if (index >= 0 && index < static_cast<int>(tabButtons_.size())) {
        tabButtons_[static_cast<std::size_t>(index)]->setChecked(true);
    }
}

void AdminTemplateWindow::showTemplateNotice(const QString &text)
{
    if (templateNotice_) {
        templateNotice_->setText(text);
    }
}

} // namespace adminui
