#pragma once

#include "contracts/MeasurementTypes.h"
#include "camera/CameraTypes.h"
#include "camera/CameraViewState.h"
#include "camera/CameraHardwareControls.h"
#include "acquisition/AcquisitionDeviceDiscovery.h"

#include <QWidget>

#include <array>

class QButtonGroup;
class QComboBox;
class QDoubleSpinBox;
class QFrame;
class QKeyEvent;
class QLabel;
class QPushButton;
class QResizeEvent;
class QStackedWidget;
class QSpinBox;
class QTableWidget;
class QTableView;
class QCheckBox;

namespace adminui {

class ChartWidget;

class AdminTemplateWindow final : public QWidget
{
    Q_OBJECT

public:
    enum class Screen {
        Main,
        Parameters,
        Debug,
        PeakData,
        Camera,
        CameraMotion
    };

    explicit AdminTemplateWindow(Screen initialScreen, QWidget *parent = nullptr);

    void setScreen(Screen screen);
    [[nodiscard]] bool saveCapture(const QString &path);
    void presentMeasurementDisplay(const tdlas::contracts::MeasurementDisplayModel &model);
    void presentCameraDisplay(const tdlas::camera::CameraDisplayModel &model);
    void presentCameraView(const tdlas::camera::CameraViewState &state);
    void presentCameraControls(const tdlas::camera::CameraControlState &state);
    const tdlas::camera::CameraControlState &cameraControls() const { return cameraControls_; }
    [[nodiscard]] tdlas::contracts::ParameterDraft measurementParameterDraft() const;
    void presentParameterDraft(const tdlas::contracts::ParameterDraft &draft);
    void presentAcquisitionDevices(
        const QVector<tdlas::acquisition::AcquisitionDeviceDescriptor> &devices,
        const QString &statusMessage);
    void presentParameterFeedback(const QString &message, bool isError);
    void presentOperationalFeedback(const QString &message, bool isError);
    void setPeakExportBusy(bool busy);
    void setPeakExportStreaming(bool streaming);
    void presentPeakExportFeedback(const QString &message, bool isError);

signals:
    void actionRequested(const QString &actionId);
    void startMeasurementRequested();
    void stopMeasurementRequested();
    void resetMeasurementRequested();
    void saveExperimentRequested();
    void dataSaveLocationRequested();
    void parameterDraftSubmitted(const tdlas::contracts::ParameterDraft &draft);
    void restoreDefaultParametersRequested();
    void refreshDevicesRequested();
    void saveCurrentParametersRequested();
    void cameraDeviceSelected(const QString &cameraId);
    void cameraViewOperationRequested(tdlas::camera::CameraViewOperation operation);
    void capturePhotoRequested();
    void startRecordingRequested();
    void stopRecordingRequested();
    void openMediaDirectoryRequested();
    void peakCsvExportRequested(const QString &path, const QVector<tdlas::contracts::PeakRecord> &records);
    void peakCsvExportToggleRequested(const QVector<tdlas::contracts::PeakRecord> &records);

protected:
    void keyPressEvent(QKeyEvent *event) override;
    void resizeEvent(QResizeEvent *event) override;

private:
    void buildShell();
    QWidget *buildTopBar();
    QWidget *buildSideRail();
    QWidget *buildTabBar();
    QWidget *buildMainPage();
    QWidget *buildDebugPage();
    QWidget *buildPeakPage();
    QWidget *buildCameraPage();
    void buildParameterDrawer();
    void buildMovementPanel();
    void updateCameraControlButtons();
    void updateOverlays();
    void updatePeakRecordsView();
    void selectPageButton(int index);
    void showTemplateNotice(const QString &text);
    void updateParameterChannelsFromSelectedDevice(
        const QString &preferredAiChannel = {},
        const QString &preferredAoChannel = {},
        bool aoEnabled = false);

    Screen screen_ = Screen::Main;
    QStackedWidget *pages_ = nullptr;
    QButtonGroup *tabGroup_ = nullptr;
    QFrame *parameterDrawer_ = nullptr;
    QFrame *movementPanel_ = nullptr;
    QLabel *cameraControlStatus_ = nullptr;
    tdlas::camera::CameraControlState cameraControls_;
    bool cameraViewReady_ = false;
    QWidget *cameraPage_ = nullptr;
    QLabel *templateNotice_ = nullptr;
    QLabel *deviceStatusLabel_ = nullptr;
    QLabel *measurementStatusLabel_ = nullptr;
    QLabel *modeLabel_ = nullptr;
    QLabel *peakValueLabel_ = nullptr;
    QLabel *lightValueLabel_ = nullptr;
    QLabel *concentrationValueLabel_ = nullptr;
    QLabel *debugPeakValueLabel_ = nullptr;
    QLabel *debugLightValueLabel_ = nullptr;
    QLabel *debugConcentrationValueLabel_ = nullptr;
    QComboBox *peakRunSelect_ = nullptr;
    tdlas::contracts::MeasurementDisplayModel peakDisplayModel_;
    QVector<tdlas::contracts::PeakRecord> peakFilteredRecords_;
    ChartWidget *peakPageChart_ = nullptr;
    QCheckBox *peakAutoFollow_ = nullptr;
    QPushButton *peakExportCsv_ = nullptr;
    QTableView *peakRecordTable_ = nullptr;
    QLabel *peakStats_ = nullptr;
    QLabel *peakExportStatus_ = nullptr;
    double peakFilterSeconds_ = 1800.0;
    QDateTime peakCustomFromUtc_;
    QDateTime peakCustomToUtc_;
    bool peakExportBusy_ = false;
    bool peakExportStreaming_ = false;
    QComboBox *cameraDeviceSelect_ = nullptr;
    QPushButton *cameraPhotoButton_ = nullptr;
    QPushButton *cameraRecordButton_ = nullptr;
    QPushButton *cameraStopButton_ = nullptr;
    QPushButton *cameraLastMediaButton_ = nullptr;
    QLabel *cameraRecordingStatus_ = nullptr;
    QPushButton *startMeasurementButton_ = nullptr;
    QPushButton *stopMeasurementButton_ = nullptr;
    QComboBox *parameterDevice_ = nullptr;
    QComboBox *parameterOutputChannel_ = nullptr;
    QComboBox *parameterWaveform_ = nullptr;
    QDoubleSpinBox *parameterOutputFrequency_ = nullptr;
    QDoubleSpinBox *parameterOutputAmplitude_ = nullptr;
    QDoubleSpinBox *parameterOutputOffset_ = nullptr;
    QComboBox *parameterInputChannel_ = nullptr;
    QSpinBox *parameterSampleRate_ = nullptr;
    QSpinBox *parameterBlockSize_ = nullptr;
    QDoubleSpinBox *parameterInputMaximum_ = nullptr;
    QDoubleSpinBox *parameterInputMinimum_ = nullptr;
    std::array<QPushButton *, 4> tabButtons_{};
};

} // namespace adminui
