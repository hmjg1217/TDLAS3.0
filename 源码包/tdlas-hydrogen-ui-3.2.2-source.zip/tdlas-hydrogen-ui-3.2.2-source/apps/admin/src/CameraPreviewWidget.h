#pragma once

#include <QImage>
#include <QWidget>
#include "camera/CameraViewState.h"

namespace adminui {

class CameraPreviewWidget final : public QWidget
{
    Q_OBJECT

public:
    explicit CameraPreviewWidget(QWidget *parent = nullptr);

    void setFrame(const QImage &frame, const QString &statusText, const QString &formatText);
    void clearFrame();
    void setViewState(const tdlas::camera::CameraViewState &state);
    [[nodiscard]] const tdlas::camera::CameraViewState &viewState() const { return viewState_; }

protected:
    void paintEvent(QPaintEvent *event) override;

private:
    QImage frame_;
    tdlas::camera::CameraViewState viewState_;
    QString statusText_ = QStringLiteral("模拟预览");
    QString formatText_ = QStringLiteral("1920 × 1080   30 FPS");
};

} // namespace adminui
