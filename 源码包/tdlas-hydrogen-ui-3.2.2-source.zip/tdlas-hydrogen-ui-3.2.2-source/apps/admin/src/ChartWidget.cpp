#include "ChartWidget.h"

#include <QDateTime>
#include <QMouseEvent>
#include <QPainter>
#include <QPainterPath>
#include <QWheelEvent>
#include <QToolTip>

#include <algorithm>
#include <cmath>
#include <limits>

namespace adminui {

namespace {

struct DataBounds {
    double xMinimum = 0.0;
    double xMaximum = 1.0;
    double yMinimum = 0.0;
    double yMaximum = 1.0;
};

DataBounds initialBounds(ChartWidget::Mode mode)
{
    switch (mode) {
    case ChartWidget::Mode::RawSignal:
    case ChartWidget::Mode::FitCurve:
        return {0.0, 1.0, -10.0, 10.0};
    case ChartWidget::Mode::FvCurve:
        return {-0.02, 0.02, 0.0, 0.1};
    case ChartWidget::Mode::PeakTrend:
        return {0.0, 1.0, 0.0, 1.0};
    }
    return {};
}

void expandRange(double *minimum, double *maximum, double fraction)
{
    if (qFuzzyCompare(*minimum + 1.0, *maximum + 1.0)) {
        const double padding = qMax(1.0e-6, std::abs(*minimum) * fraction);
        *minimum -= padding;
        *maximum += padding;
        return;
    }
    const double padding = (*maximum - *minimum) * fraction;
    *minimum -= padding;
    *maximum += padding;
}

void includeSeries(
    const tdlas::contracts::ChartSeriesData &series,
    DataBounds *bounds,
    bool *hasBounds,
    double *largestXStep)
{
    if (!series.isConsistent()) {
        return;
    }
    const auto xRange = std::minmax_element(series.x.cbegin(), series.x.cend());
    const auto yRange = std::minmax_element(series.y.cbegin(), series.y.cend());
    if (!*hasBounds) {
        bounds->xMinimum = *xRange.first;
        bounds->xMaximum = *xRange.second;
        bounds->yMinimum = *yRange.first;
        bounds->yMaximum = *yRange.second;
        *hasBounds = true;
    } else {
        bounds->xMinimum = qMin(bounds->xMinimum, *xRange.first);
        bounds->xMaximum = qMax(bounds->xMaximum, *xRange.second);
        bounds->yMinimum = qMin(bounds->yMinimum, *yRange.first);
        bounds->yMaximum = qMax(bounds->yMaximum, *yRange.second);
    }
    if (series.x.size() > 1) {
        *largestXStep = qMax(
            *largestXStep,
            std::abs(series.x.constLast() - series.x.constFirst())
                / static_cast<double>(series.x.size() - 1));
    }
}

DataBounds dataBounds(
    ChartWidget::Mode mode,
    const tdlas::contracts::ChartSeriesData &primary,
    const tdlas::contracts::ChartSeriesData &secondary,
    double timeRangeSeconds,
    double peakWindowSeconds)
{
    DataBounds bounds = initialBounds(mode);
    bool hasBounds = false;
    double largestXStep = 0.0;
    includeSeries(primary, &bounds, &hasBounds, &largestXStep);
    includeSeries(secondary, &bounds, &hasBounds, &largestXStep);
    if (!hasBounds) {
        return bounds;
    }

    if (mode == ChartWidget::Mode::PeakTrend) {
        bounds.xMinimum = bounds.xMaximum - peakWindowSeconds;
        bounds.yMinimum = std::numeric_limits<double>::infinity();
        bounds.yMaximum = -std::numeric_limits<double>::infinity();
        for (const auto *series : {&primary, &secondary}) {
            if (!series->isConsistent()) {
                continue;
            }
            for (qsizetype index = 0; index < series->x.size(); ++index) {
                if (series->x.at(index) >= bounds.xMinimum && series->x.at(index) <= bounds.xMaximum) {
                    bounds.yMinimum = qMin(bounds.yMinimum, series->y.at(index));
                    bounds.yMaximum = qMax(bounds.yMaximum, series->y.at(index));
                }
            }
        }
    } else if (mode == ChartWidget::Mode::RawSignal || mode == ChartWidget::Mode::FitCurve) {
        bounds.xMinimum = 0.0;
        bounds.xMaximum = qMax(timeRangeSeconds, bounds.xMaximum + largestXStep);
    } else {
        expandRange(&bounds.xMinimum, &bounds.xMaximum, 0.05);
    }

    const double yPadding = mode == ChartWidget::Mode::FvCurve ? 0.08
        : mode == ChartWidget::Mode::PeakTrend ? 0.10
                                               : 0.05;
    expandRange(&bounds.yMinimum, &bounds.yMaximum, yPadding);
    return bounds;
}

QString dataTick(double value, double step)
{
    if (std::abs(value) < step * 1.0e-6) {
        value = 0.0;
    }
    const double magnitude = std::abs(value);
    if ((magnitude > 0.0 && magnitude < 0.001) || magnitude >= 100000.0) {
        const int precision = qBound(3, static_cast<int>(std::ceil(std::log10(magnitude / step))) + 2, 8);
        return QString::number(value, 'g', precision);
    }
    const int decimals = qBound(0, static_cast<int>(std::ceil(-std::log10(step))) + 1, 8);
    return QString::number(value, 'f', decimals);
}

QString timeTick(double epochSeconds, double span)
{
    return QDateTime::fromMSecsSinceEpoch(qRound64(epochSeconds * 1000.0))
        .toLocalTime()
        .toString(span < 10.0 ? QStringLiteral("HH:mm:ss.zzz") : QStringLiteral("HH:mm:ss"));
}

} // namespace

ChartWidget::ChartWidget(Mode mode, QWidget *parent)
    : QWidget(parent)
    , mode_(mode)
{
    setObjectName(QStringLiteral("chartWidget"));
    setMinimumSize(250, 150);
    setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    setMouseTracking(mode_ == Mode::PeakTrend);
    if (mode_ == Mode::PeakTrend) {
        setToolTip(QStringLiteral("依次左键点选两个时间/峰值位置进行区间放大；滚轮在 X/Y 轴间切换；右键恢复原图。查看历史时自动暂停，按“返回实时”恢复跟随。"));
    }
    publishPeakInteraction();
    const DataBounds bounds = initialBounds(mode_);
    setProperty("xMinimum", bounds.xMinimum);
    setProperty("xMaximum", bounds.xMaximum);
    setProperty("yMinimum", bounds.yMinimum);
    setProperty("yMaximum", bounds.yMaximum);
}

void ChartWidget::setAxisLabels(const QString &xLabel, const QString &yLabel)
{
    xLabel_ = xLabel;
    yLabel_ = yLabel;
    setProperty("xLabel", xLabel_);
    setProperty("yLabel", yLabel_);
    update();
}

void ChartWidget::setTimeRange(double durationSeconds)
{
    if (std::isfinite(durationSeconds) && durationSeconds > 0.0) {
        timeRangeSeconds_ = durationSeconds;
    }
}

void ChartWidget::setPeakWindowSeconds(double seconds)
{
    if (std::isfinite(seconds) && seconds > 0.0) {
        peakWindowSeconds_ = seconds;
        peakRunRange_ = false;
        peakRangeFromUtc_ = {};
        peakRangeToUtc_ = {};
        resetPeakZoom();
    }
}

void ChartWidget::setPeakRunRange()
{
    peakRunRange_ = true;
    peakRangeFromUtc_ = {};
    peakRangeToUtc_ = {};
    resetPeakZoom();
}

void ChartWidget::setPeakTimeRange(const QDateTime &fromUtc, const QDateTime &toUtc)
{
    if (fromUtc.isValid() && toUtc.isValid() && fromUtc < toUtc) {
        peakRangeFromUtc_ = fromUtc.toUTC();
        peakRangeToUtc_ = toUtc.toUTC();
        resetPeakZoom();
    }
}

void ChartWidget::setPeakRecords(const QVector<tdlas::contracts::PeakRecord> &records)
{
    peakRecords_ = records;
    if (!records.isEmpty()) sourceKind_ = records.first().sourceKind;
    setProperty("liveSampleCount", static_cast<int>(records.size()));
    updatePeakBounds();
    update();
}

QRectF ChartWidget::plotRect() const
{
    const int left = qMin(96, qMax(86, width() / 10));
    return QRectF(left, 18, qMax(40, width() - left - 18), qMax(40, height() - 64));
}

void ChartWidget::publishPeakInteraction()
{
    setProperty("peakLiveFollow", peakLiveFollow_);
    setProperty("peakZoomed", peakZoomed_);
    setProperty("peakZoomAxis", peakZoomAlongX_ ? QStringLiteral("X") : QStringLiteral("Y"));
    setProperty("peakZoomSelectionPending", peakFirstSelection_.has_value());
    update();
}

void ChartWidget::updatePeakBounds(bool force)
{
    if (mode_ != Mode::PeakTrend || (!force && peakHasBounds_ && (!peakLiveFollow_ || peakZoomed_))) {
        return;
    }
    DataBounds bounds = initialBounds(mode_);
    double first = std::numeric_limits<double>::infinity();
    double last = -std::numeric_limits<double>::infinity();
    for (const auto &record : peakRecords_) {
        if (record.acquiredAtUtc.isValid()) {
            const double x = static_cast<double>(record.acquiredAtUtc.toMSecsSinceEpoch()) / 1000.0;
            first = qMin(first, x);
            last = qMax(last, x);
        }
    }
    if (std::isfinite(first)) {
        bounds.xMaximum = last;
        bounds.xMinimum = peakRunRange_ ? first : last - peakWindowSeconds_;
        if (peakRunRange_ && last - first < 1.0) {
            bounds.xMinimum -= 0.5;
            bounds.xMaximum += 0.5;
        }
        peakHasBounds_ = true;
    }
    if (peakRangeFromUtc_.isValid() && peakRangeToUtc_.isValid()) {
        bounds.xMinimum = static_cast<double>(peakRangeFromUtc_.toMSecsSinceEpoch()) / 1000.0;
        bounds.xMaximum = static_cast<double>(peakRangeToUtc_.toMSecsSinceEpoch()) / 1000.0;
        peakHasBounds_ = true;
    }
    double yMin = std::numeric_limits<double>::infinity();
    double yMax = -std::numeric_limits<double>::infinity();
    for (const auto &record : peakRecords_) {
        const double x = static_cast<double>(record.acquiredAtUtc.toMSecsSinceEpoch()) / 1000.0;
        if (record.acquiredAtUtc.isValid() && record.peakValue.has_value()
            && record.validity == tdlas::contracts::DataValidity::Valid
            && std::isfinite(*record.peakValue) && x >= bounds.xMinimum && x <= bounds.xMaximum) {
            yMin = qMin(yMin, *record.peakValue);
            yMax = qMax(yMax, *record.peakValue);
        }
    }
    if (std::isfinite(yMin)) {
        bounds.yMinimum = yMin;
        bounds.yMaximum = yMax;
        expandRange(&bounds.yMinimum, &bounds.yMaximum, 0.10);
    }
    setProperty("xMinimum", bounds.xMinimum);
    setProperty("xMaximum", bounds.xMaximum);
    setProperty("yMinimum", bounds.yMinimum);
    setProperty("yMaximum", bounds.yMaximum);
}

void ChartWidget::resetPeakZoom()
{
    if (mode_ == Mode::PeakTrend) {
        peakFirstSelection_.reset();
        peakZoomed_ = false;
        updatePeakBounds(true);
        publishPeakInteraction();
    }
}

void ChartWidget::setPeakLiveFollow(bool enabled)
{
    const bool changed = peakLiveFollow_ != enabled;
    peakLiveFollow_ = enabled;
    if (enabled) {
        resetPeakZoom();
    }
    publishPeakInteraction();
    if (changed) {
        emit peakLiveFollowChanged(enabled);
    }
}

void ChartWidget::wheelEvent(QWheelEvent *event)
{
    if (mode_ != Mode::PeakTrend || !plotRect().contains(event->position())) {
        QWidget::wheelEvent(event);
        return;
    }
    if (!event->angleDelta().isNull()) {
        peakZoomAlongX_ = event->angleDelta().y() > 0 || event->angleDelta().x() > 0;
        peakFirstSelection_.reset();
        publishPeakInteraction();
        QToolTip::showText(event->globalPosition().toPoint(),
            peakZoomAlongX_ ? QStringLiteral("X 方向：依次点击两个位置放大时间区间；右键复位")
                            : QStringLiteral("Y 方向：依次点击两个位置放大峰值区间；右键复位"), this);
    }
    event->accept();
}

void ChartWidget::mousePressEvent(QMouseEvent *event)
{
    const QRectF plot = plotRect();
    if (mode_ != Mode::PeakTrend || !plot.contains(event->position())) {
        QWidget::mousePressEvent(event);
        return;
    }
    if (event->button() == Qt::RightButton) {
        resetPeakZoom();
        event->accept();
        return;
    }
    if (event->button() != Qt::LeftButton || peakRecords_.isEmpty()) {
        QWidget::mousePressEvent(event);
        return;
    }
    const QPointF selected(
        property("xMinimum").toDouble() + (event->position().x() - plot.left()) / plot.width()
            * (property("xMaximum").toDouble() - property("xMinimum").toDouble()),
        property("yMaximum").toDouble() - (event->position().y() - plot.top()) / plot.height()
            * (property("yMaximum").toDouble() - property("yMinimum").toDouble()));
    setPeakLiveFollow(false);
    if (!peakFirstSelection_) {
        peakFirstSelection_ = selected;
        peakSelectionCursor_ = event->position();
    } else {
        const double a = peakZoomAlongX_ ? peakFirstSelection_->x() : peakFirstSelection_->y();
        const double b = peakZoomAlongX_ ? selected.x() : selected.y();
        if (std::abs(a - b) >= (peakZoomAlongX_ ? 0.001 : 1.0e-12)) {
            setProperty(peakZoomAlongX_ ? "xMinimum" : "yMinimum", qMin(a, b));
            setProperty(peakZoomAlongX_ ? "xMaximum" : "yMaximum", qMax(a, b));
            peakZoomed_ = true;
        }
        peakFirstSelection_.reset();
    }
    publishPeakInteraction();
    event->accept();
}

void ChartWidget::mouseMoveEvent(QMouseEvent *event)
{
    if (mode_ != Mode::PeakTrend || !plotRect().contains(event->position())) {
        QWidget::mouseMoveEvent(event);
        return;
    }
    peakSelectionCursor_ = event->position();
    if (peakFirstSelection_) {
        update();
    }
    const QRectF plot = plotRect();
    const double time = property("xMinimum").toDouble() + (event->position().x() - plot.left()) / plot.width()
        * (property("xMaximum").toDouble() - property("xMinimum").toDouble());
    const tdlas::contracts::PeakRecord *nearest = nullptr;
    double distance = std::numeric_limits<double>::infinity();
    for (const auto &record : peakRecords_) {
        if (!record.acquiredAtUtc.isValid()) continue;
        const double delta = std::abs(static_cast<double>(record.acquiredAtUtc.toMSecsSinceEpoch()) / 1000.0 - time);
        if (delta < distance) { distance = delta; nearest = &record; }
    }
    if (nearest) {
        const auto &r = *nearest;
        const QString detail = QStringLiteral("采集时间：%1\npeakValue：%2 %3  peakX：%4 %5\n批次：%6  run：%7\n质量：%8\n设备：%9  参数：%10\n算法：%11  标定：%12\n%13")
            .arg(r.acquiredAtUtc.toLocalTime().toString(QStringLiteral("yyyy-MM-dd HH:mm:ss.zzz ttt")),
                r.peakValue ? QString::number(*r.peakValue, 'g', 17) : QStringLiteral("null"), r.unit,
                r.peakX ? QString::number(*r.peakX, 'g', 17) : QStringLiteral("null"), r.peakXUnit)
            .arg(r.sequence).arg(r.runId.value, r.reason, r.parameters.deviceId, r.parameters.id,
                r.algorithmVersion, r.calibrationVersion,
                r.sourceKind == tdlas::contracts::DataSourceKind::Simulation ? QStringLiteral("模拟数据") : QStringLiteral("实采数据"));
        QToolTip::showText(event->globalPosition().toPoint(), detail, this);
    }
    event->accept();
}

void ChartWidget::setDataSource(tdlas::contracts::DataSourceKind sourceKind)
{
    sourceKind_ = sourceKind;
}

void ChartWidget::setSeriesData(
    const tdlas::contracts::ChartSeriesData &primary,
    const tdlas::contracts::ChartSeriesData &secondary)
{
    const bool keepFvScale = mode_ == Mode::FvCurve && primarySeries_.isConsistent()
        && primary.isConsistent();
    primarySeries_ = primary;
    secondarySeries_ = secondary;
    setProperty("liveSampleCount", static_cast<int>(primarySeries_.isConsistent() ? primarySeries_.y.size() : 0));
    setProperty("liveSecondarySampleCount", static_cast<int>(secondarySeries_.isConsistent() ? secondarySeries_.y.size() : 0));
    if (mode_ == Mode::FvCurve && primarySeries_.isConsistent()) {
        setProperty("curvePeak", *std::max_element(primarySeries_.y.cbegin(), primarySeries_.y.cend()));
    }
    if (primarySeries_.isConsistent()) {
        if (primarySeries_.xUnit == QStringLiteral("cm⁻¹")) {
            xLabel_ = QStringLiteral("相对频率 v_f（cm⁻¹）");
        } else if (primarySeries_.xUnit == QStringLiteral("s")) {
            xLabel_ = QStringLiteral("时间（s）");
        } else if (primarySeries_.xUnit == QStringLiteral("HH:mm:ss")) {
            xLabel_ = QStringLiteral("时间（HH:mm:ss）");
        }
        if (primarySeries_.yUnit == QStringLiteral("V")) {
            yLabel_ = QStringLiteral("电压（V）");
        }
        setProperty("xLabel", xLabel_);
        setProperty("yLabel", yLabel_);
    }
    DataBounds bounds = dataBounds(mode_, primarySeries_, secondarySeries_, timeRangeSeconds_, peakWindowSeconds_);
    if (mode_ == Mode::FvCurve && primarySeries_.isConsistent()) {
        bounds.yMinimum = qMin(0.0, bounds.yMinimum);
        if (keepFvScale) {
            bounds.yMinimum = qMin(bounds.yMinimum, property("yMinimum").toDouble());
            bounds.yMaximum = qMax(bounds.yMaximum, property("yMaximum").toDouble());
        }
    }
    setProperty("xMinimum", bounds.xMinimum);
    setProperty("xMaximum", bounds.xMaximum);
    setProperty("yMinimum", bounds.yMinimum);
    setProperty("yMaximum", bounds.yMaximum);
    update();
}

ChartWidget::Mode ChartWidget::mode() const
{
    return mode_;
}

qsizetype ChartWidget::liveSampleCount() const
{
    return primarySeries_.isConsistent() ? primarySeries_.y.size() : 0;
}

void ChartWidget::paintEvent(QPaintEvent *event)
{
    Q_UNUSED(event)
    QPainter painter(this);
    painter.setRenderHint(QPainter::Antialiasing);
    painter.fillRect(rect(), QColor(QStringLiteral("#ffffff")));

    const int left = qMin(96, qMax(86, width() / 10));
    const int right = 18;
    const int top = 18;
    const int bottom = 46;
    const QRectF plot(left, top, qMax(40, width() - left - right), qMax(40, height() - top - bottom));
    const bool hasLiveData = mode_ == Mode::PeakTrend ? !peakRecords_.isEmpty() : primarySeries_.isConsistent();
    const DataBounds bounds{property("xMinimum").toDouble(), property("xMaximum").toDouble(),
                            property("yMinimum").toDouble(), property("yMaximum").toDouble()};
    const double xSpan = qMax(1.0e-12, bounds.xMaximum - bounds.xMinimum);
    const double ySpan = qMax(1.0e-12, bounds.yMaximum - bounds.yMinimum);

    painter.setPen(QPen(QColor(QStringLiteral("#dbe8f5")), 1.0));
    for (int i = 0; i <= 5; ++i) {
        const qreal x = plot.left() + plot.width() * i / 5.0;
        painter.drawLine(QPointF(x, plot.top()), QPointF(x, plot.bottom()));
    }
    for (int i = 0; i <= 4; ++i) {
        const qreal y = plot.bottom() - plot.height() * i / 4.0;
        painter.drawLine(QPointF(plot.left(), y), QPointF(plot.right(), y));
    }

    QFont tickFont = font();
    tickFont.setPointSizeF(qMax(7.5, font().pointSizeF() - 1.0));
    painter.setFont(tickFont);
    painter.setPen(QColor(QStringLiteral("#48617f")));
    for (int i = 0; i <= 5; ++i) {
        const qreal x = plot.left() + plot.width() * i / 5.0;
        const double value = bounds.xMinimum + (bounds.xMaximum - bounds.xMinimum) * i / 5.0;
        const QString tick = hasLiveData && mode_ == Mode::PeakTrend ? timeTick(value, xSpan) : dataTick(value, xSpan / 5.0);
        const int labelWidth = mode_ == Mode::PeakTrend && xSpan < 10.0 ? 100 : 70;
        const qreal labelLeft = qBound(0.0, x - labelWidth / 2.0, static_cast<double>(width() - labelWidth));
        painter.drawText(QRectF(labelLeft, plot.bottom() + 6, labelWidth, 20), Qt::AlignHCenter | Qt::AlignTop, tick);
    }
    for (int i = 0; i <= 4; ++i) {
        const qreal y = plot.bottom() - plot.height() * i / 4.0;
        const QString tick = dataTick(bounds.yMinimum + (bounds.yMaximum - bounds.yMinimum) * i / 4.0, ySpan / 4.0);
        painter.drawText(QRectF(0, y - 10, plot.left() - 8, 20), Qt::AlignRight | Qt::AlignVCenter, tick);
    }

    painter.setPen(QPen(QColor(QStringLiteral("#8ca9cb")), 1.2));
    painter.drawLine(plot.bottomLeft(), plot.bottomRight());
    painter.drawLine(plot.bottomLeft(), plot.topLeft());

    auto buildPath = [&](const tdlas::contracts::ChartSeriesData &series) {
        QPainterPath path;
        if (!series.isConsistent()) {
            return path;
        }
        const int samples = static_cast<int>(series.y.size());
        const int maxPoints = qMax(2, static_cast<int>(plot.width() * 2.0));
        bool started = false;
        auto append = [&](int index) {
            const QPointF point(
                plot.left() + (series.x.at(index) - bounds.xMinimum) / xSpan * plot.width(),
                plot.bottom() - (series.y.at(index) - bounds.yMinimum) / ySpan * plot.height());
            if (!started) {
                path.moveTo(point);
                started = true;
            } else {
                path.lineTo(point);
            }
        };
        if (samples <= maxPoints) {
            for (int index = 0; index < samples; ++index) {
                append(index);
            }
            return path;
        }
        const int bucketWidth = qMax(1, (samples + maxPoints / 2 - 1) / (maxPoints / 2));
        for (int first = 0; first < samples; first += bucketWidth) {
            const int end = qMin(samples, first + bucketWidth);
            int minimumIndex = first;
            int maximumIndex = first;
            for (int index = first + 1; index < end; ++index) {
                if (series.y.at(index) < series.y.at(minimumIndex)) {
                    minimumIndex = index;
                }
                if (series.y.at(index) > series.y.at(maximumIndex)) {
                    maximumIndex = index;
                }
            }
            if (minimumIndex == maximumIndex) {
                append(minimumIndex);
            } else if (minimumIndex < maximumIndex) {
                append(minimumIndex);
                append(maximumIndex);
            } else {
                append(maximumIndex);
                append(minimumIndex);
            }
        }
        return path;
    };

    painter.setClipRect(plot.adjusted(-2, -2, 2, 2));
    if (mode_ == Mode::PeakTrend) {
        QPainterPath path;
        QStringList runNames;
        QVector<QPainterPath> runPaths;
        bool started = false;
        QString previousRun;
        int bucket = std::numeric_limits<int>::min();
        QVector<QPointF> points;
        auto flush = [&]() {
            if (points.isEmpty()) return;
            QVector<int> indices{0, static_cast<int>(points.size() - 1)};
            int low = 0, high = 0;
            for (int i = 1; i < points.size(); ++i) {
                if (points.at(i).y() < points.at(low).y()) low = i;
                if (points.at(i).y() > points.at(high).y()) high = i;
            }
            indices << low << high;
            std::sort(indices.begin(), indices.end());
            indices.erase(std::unique(indices.begin(), indices.end()), indices.end());
            for (int i : indices) {
                if (!started) { path.moveTo(points.at(i)); started = true; }
                else path.lineTo(points.at(i));
            }
            points.clear();
        };
        for (const auto &r : peakRecords_) {
            const bool valid = r.acquiredAtUtc.isValid() && r.peakValue.has_value()
                && r.validity == tdlas::contracts::DataValidity::Valid && std::isfinite(*r.peakValue);
            if (!previousRun.isEmpty() && previousRun != r.runId.value) {
                flush(); runNames.push_back(previousRun); runPaths.push_back(path); path = {};
                started = false; bucket = std::numeric_limits<int>::min();
            }
            if (!valid) { flush(); started = false; bucket = std::numeric_limits<int>::min(); }
            previousRun = r.runId.value;
            if (!valid) continue;
            const double x = static_cast<double>(r.acquiredAtUtc.toMSecsSinceEpoch()) / 1000.0;
            const QPointF point(plot.left() + (x - bounds.xMinimum) / xSpan * plot.width(),
                plot.bottom() - (*r.peakValue - bounds.yMinimum) / ySpan * plot.height());
            const int column = static_cast<int>(qBound(-1.0, point.x() - plot.left(), plot.width() + 1.0));
            if (column != bucket) { flush(); bucket = column; }
            points.push_back(point);
        }
        flush();
        if (!previousRun.isEmpty()) { runNames.push_back(previousRun); runPaths.push_back(path); }
        const QColor colors[]{QColor(QStringLiteral("#0879ef")), QColor(QStringLiteral("#b052db")),
            QColor(QStringLiteral("#00866f")), QColor(QStringLiteral("#df7117"))};
        int segments = 0;
        for (int run = 0; run < runPaths.size(); ++run) {
            painter.setPen(QPen(colors[run % 4], 2.5, Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin));
            painter.drawPath(runPaths.at(run));
            for (int i = 0; i < runPaths.at(run).elementCount(); ++i) if (runPaths.at(run).elementAt(i).isMoveTo()) ++segments;
            if (runNames.size() > 1 && run < 4) {
                painter.drawText(QRectF(plot.left() + 8 + run * 150, plot.top() + 24, 145, 18),
                    Qt::AlignLeft, QStringLiteral("━ %1").arg(runNames.at(run).left(12)));
            }
        }
        setProperty("peakSegmentCount", segments);
        if (peakFirstSelection_) {
            const double pixel = peakZoomAlongX_
                ? plot.left() + (peakFirstSelection_->x() - bounds.xMinimum) / xSpan * plot.width()
                : plot.bottom() - (peakFirstSelection_->y() - bounds.yMinimum) / ySpan * plot.height();
            const double cursor = peakZoomAlongX_ ? peakSelectionCursor_.x() : peakSelectionCursor_.y();
            const QRectF band = peakZoomAlongX_
                ? QRectF(qMin(pixel, cursor), plot.top(), std::abs(pixel - cursor), plot.height())
                : QRectF(plot.left(), qMin(pixel, cursor), plot.width(), std::abs(pixel - cursor));
            painter.fillRect(band, QColor(8, 121, 239, 35));
            painter.setPen(QPen(QColor(QStringLiteral("#0879ef")), 1.0, Qt::DashLine));
            if (peakZoomAlongX_) painter.drawLine(QPointF(pixel, plot.top()), QPointF(pixel, plot.bottom()));
            else painter.drawLine(QPointF(plot.left(), pixel), QPointF(plot.right(), pixel));
        }
    }
    else if (hasLiveData) {
        painter.setPen(QPen(QColor(QStringLiteral("#0879ef")), mode_ == Mode::FitCurve ? 2.1 : 2.8, Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin));
        painter.drawPath(buildPath(primarySeries_));
        if (primarySeries_.y.size() == 1) {
            painter.drawEllipse(QPointF(
                plot.left() + (primarySeries_.x.first() - bounds.xMinimum) / xSpan * plot.width(),
                plot.bottom() - (primarySeries_.y.first() - bounds.yMinimum) / ySpan * plot.height()), 2.5, 2.5);
        }
    }
    if (secondarySeries_.isConsistent()) {
        painter.setPen(QPen(QColor(QStringLiteral("#ec3f4f")), 2.0, Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin));
        painter.drawPath(buildPath(secondarySeries_));
    }
    painter.setClipping(false);

    if (hasLiveData && mode_ == Mode::FitCurve) {
        painter.setPen(QColor(QStringLiteral("#0879ef")));
        painter.drawText(QRectF(plot.left() + 8, plot.top() + 5, 120, 18), QStringLiteral("━ 20 周期平均"));
        painter.setPen(QColor(QStringLiteral("#ec3f4f")));
        painter.drawText(QRectF(plot.left() + 130, plot.top() + 5, 120, 18), QStringLiteral("━ Voigt 拟合"));
    }

    if (!hasLiveData) {
        painter.setPen(QColor(QStringLiteral("#8a9bb0")));
        painter.drawText(plot, Qt::AlignCenter, QStringLiteral("等待采集数据"));
    }
    painter.setPen(QColor(QStringLiteral("#36506f")));
    painter.drawText(QRectF(plot.left(), height() - 25, plot.width(), 20), Qt::AlignCenter, xLabel_);
    painter.save();
    painter.translate(14, plot.center().y());
    painter.rotate(-90.0);
    painter.drawText(QRectF(-plot.height() / 2.0, -9, plot.height(), 18), Qt::AlignCenter, yLabel_);
    painter.restore();

    painter.setPen(QColor(QStringLiteral("#6d86a5")));
    painter.drawText(QRectF(plot.right() - 112, plot.top() + 5, 106, 18), Qt::AlignRight,
        sourceKind_ == tdlas::contracts::DataSourceKind::Simulation
            ? QStringLiteral("SIM · 模拟数据") : QStringLiteral("NI · 实采数据"));
}

} // namespace adminui
