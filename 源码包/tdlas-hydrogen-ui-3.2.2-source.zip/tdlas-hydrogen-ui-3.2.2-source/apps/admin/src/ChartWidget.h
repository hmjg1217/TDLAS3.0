#pragma once

#include "contracts/MeasurementTypes.h"
#include <QWidget>

class QMouseEvent;
class QWheelEvent;

namespace adminui {

class ChartWidget final : public QWidget
{
    Q_OBJECT
public:
    enum class Mode { RawSignal, FitCurve, FvCurve, PeakTrend };
    explicit ChartWidget(Mode mode, QWidget *parent = nullptr);
    void setAxisLabels(const QString &xLabel, const QString &yLabel);
    void setTimeRange(double durationSeconds);
    void setPeakWindowSeconds(double seconds);
    void setPeakRunRange();
    void setPeakTimeRange(const QDateTime &fromUtc, const QDateTime &toUtc);
    void setPeakRecords(const QVector<tdlas::contracts::PeakRecord> &records);
    void resetPeakZoom();
    void setPeakLiveFollow(bool enabled);
    void setDataSource(tdlas::contracts::DataSourceKind sourceKind);
    void setSeriesData(const tdlas::contracts::ChartSeriesData &primary,
        const tdlas::contracts::ChartSeriesData &secondary = {});
    [[nodiscard]] Mode mode() const;
    [[nodiscard]] qsizetype liveSampleCount() const;
signals:
    void peakLiveFollowChanged(bool enabled);
protected:
    void paintEvent(QPaintEvent *event) override;
    void wheelEvent(QWheelEvent *event) override;
    void mousePressEvent(QMouseEvent *event) override;
    void mouseMoveEvent(QMouseEvent *event) override;
private:
    [[nodiscard]] QRectF plotRect() const;
    void updatePeakBounds(bool force = false);
    void publishPeakInteraction();
    Mode mode_;
    QString xLabel_;
    QString yLabel_;
    double timeRangeSeconds_ = 1.0;
    double peakWindowSeconds_ = 1800.0;
    bool peakRunRange_ = false;
    bool peakLiveFollow_ = true;
    bool peakZoomed_ = false;
    bool peakHasBounds_ = false;
    bool peakZoomAlongX_ = true;
    QDateTime peakRangeFromUtc_;
    QDateTime peakRangeToUtc_;
    std::optional<QPointF> peakFirstSelection_;
    QPointF peakSelectionCursor_;
    QVector<tdlas::contracts::PeakRecord> peakRecords_;
    tdlas::contracts::DataSourceKind sourceKind_ = tdlas::contracts::DataSourceKind::Simulation;
    tdlas::contracts::ChartSeriesData primarySeries_;
    tdlas::contracts::ChartSeriesData secondarySeries_;
};

} // namespace adminui
