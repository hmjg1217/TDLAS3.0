#include "ChartWidget.h"

#include <QDateTime>
#include <QPainter>
#include <QPainterPath>

#include <algorithm>
#include <cmath>
#include <limits>

namespace clientui {

namespace {

constexpr double kPeakWindowSeconds = 30.0 * 60.0;

struct DataBounds {
    double xMinimum = 0.0;
    double xMaximum = 1.0;
    double yMinimum = 0.0;
    double yMaximum = 1.0;
};

DataBounds initialBounds(ChartWidget::Mode mode)
{
    if (mode == ChartWidget::Mode::FvCurve) {
        return {-0.02, 0.02, 0.0, 0.1};
    }
    return {0.0, 1.0, 0.0, 1.0};
}

void expandRange(double *minimum, double *maximum, double fraction)
{
    if (qFuzzyCompare(*minimum + 1.0, *maximum + 1.0)) {
        const double padding = qMax(1.0e-6, std::abs(*minimum) * fraction);
        *minimum -= padding;
        *maximum += padding;
        return;
    }
    const double padding = (*maximum - *minimum) * fraction;
    *minimum -= padding;
    *maximum += padding;
}

DataBounds dataBounds(const tdlas::contracts::ChartSeriesData &series, ChartWidget::Mode mode)
{
    if (!series.isConsistent()) {
        return initialBounds(mode);
    }
    const auto xRange = std::minmax_element(series.x.cbegin(), series.x.cend());
    const auto yRange = std::minmax_element(series.y.cbegin(), series.y.cend());
    DataBounds bounds{*xRange.first, *xRange.second, *yRange.first, *yRange.second};
    if (mode == ChartWidget::Mode::PeakTrend) {
        bounds.xMinimum = bounds.xMaximum - kPeakWindowSeconds;
        bounds.yMinimum = std::numeric_limits<double>::infinity();
        bounds.yMaximum = -std::numeric_limits<double>::infinity();
        for (qsizetype index = 0; index < series.x.size(); ++index) {
            if (series.x.at(index) >= bounds.xMinimum) {
                bounds.yMinimum = qMin(bounds.yMinimum, series.y.at(index));
                bounds.yMaximum = qMax(bounds.yMaximum, series.y.at(index));
            }
        }
        expandRange(&bounds.yMinimum, &bounds.yMaximum, 0.10);
    } else {
        expandRange(&bounds.xMinimum, &bounds.xMaximum, 0.05);
        expandRange(&bounds.yMinimum, &bounds.yMaximum, 0.08);
    }
    return bounds;
}

QString dataTick(double value, double step)
{
    if (std::abs(value) < step * 1.0e-6) {
        value = 0.0;
    }
    const double magnitude = std::abs(value);
    if ((magnitude > 0.0 && magnitude < 0.001) || magnitude >= 100000.0) {
        const int precision = qBound(3, static_cast<int>(std::ceil(std::log10(magnitude / step))) + 2, 8);
        return QString::number(value, 'g', precision);
    }
    const int decimals = qBound(0, static_cast<int>(std::ceil(-std::log10(step))) + 1, 8);
    return QString::number(value, 'f', decimals);
}

QString timeTick(double epochSeconds)
{
    return QDateTime::fromSecsSinceEpoch(static_cast<qint64>(std::llround(epochSeconds)))
        .toLocalTime()
        .toString(QStringLiteral("HH:mm:ss"));
}

} // namespace

ChartWidget::ChartWidget(Mode mode, QWidget *parent)
    : QWidget(parent)
    , mode_(mode)
{
    setObjectName(QStringLiteral("chartWidget"));
    setMinimumSize(250, 150);
    setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    const DataBounds bounds = initialBounds(mode_);
    setProperty("xMinimum", bounds.xMinimum);
    setProperty("xMaximum", bounds.xMaximum);
    setProperty("yMinimum", bounds.yMinimum);
    setProperty("yMaximum", bounds.yMaximum);
}

void ChartWidget::setAxisLabels(const QString &xLabel, const QString &yLabel)
{
    xLabel_ = xLabel;
    yLabel_ = yLabel;
    setProperty("xLabel", xLabel_);
    setProperty("yLabel", yLabel_);
    update();
}

void ChartWidget::setDataSource(tdlas::contracts::DataSourceKind sourceKind)
{
    sourceKind_ = sourceKind;
}

void ChartWidget::setSeriesData(const tdlas::contracts::ChartSeriesData &series)
{
    const bool keepFvScale = mode_ == Mode::FvCurve && series_.isConsistent() && series.isConsistent();
    series_ = series;
    setProperty("liveSampleCount", static_cast<int>(series_.isConsistent() ? series_.y.size() : 0));
    if (mode_ == Mode::FvCurve && series_.isConsistent()) {
        setProperty("curvePeak", *std::max_element(series_.y.cbegin(), series_.y.cend()));
    }
    if (series_.isConsistent()) {
        if (series_.xUnit == QStringLiteral("cm⁻¹")) {
            xLabel_ = QStringLiteral("相对频率 v_f（cm⁻¹）");
        } else if (series_.xUnit == QStringLiteral("HH:mm:ss")) {
            xLabel_ = QStringLiteral("时间（HH:mm:ss）");
        }
        if (series_.yUnit == QStringLiteral("1")) {
            yLabel_ = mode_ == Mode::FvCurve
                ? QStringLiteral("拟合吸光度")
                : QStringLiteral("峰值吸光度");
        }
        setProperty("xLabel", xLabel_);
        setProperty("yLabel", yLabel_);
    }
    DataBounds bounds = dataBounds(series_, mode_);
    if (mode_ == Mode::FvCurve && series_.isConsistent()) {
        bounds.yMinimum = qMin(0.0, bounds.yMinimum);
        if (keepFvScale) {
            bounds.yMinimum = qMin(bounds.yMinimum, property("yMinimum").toDouble());
            bounds.yMaximum = qMax(bounds.yMaximum, property("yMaximum").toDouble());
        }
    }
    setProperty("xMinimum", bounds.xMinimum);
    setProperty("xMaximum", bounds.xMaximum);
    setProperty("yMinimum", bounds.yMinimum);
    setProperty("yMaximum", bounds.yMaximum);
    update();
}

ChartWidget::Mode ChartWidget::mode() const
{
    return mode_;
}

qsizetype ChartWidget::liveSampleCount() const
{
    return series_.isConsistent() ? series_.y.size() : 0;
}

void ChartWidget::paintEvent(QPaintEvent *event)
{
    Q_UNUSED(event)
    QPainter painter(this);
    painter.setRenderHint(QPainter::Antialiasing);
    painter.fillRect(rect(), QColor(QStringLiteral("#ffffff")));

    const int left = qMin(96, qMax(86, width() / 10));
    const QRectF plot(left, 18, qMax(40, width() - left - 18), qMax(40, height() - 64));
    const bool hasLiveData = series_.isConsistent();
    const DataBounds bounds{property("xMinimum").toDouble(), property("xMaximum").toDouble(),
                            property("yMinimum").toDouble(), property("yMaximum").toDouble()};
    const double xSpan = qMax(1.0e-12, bounds.xMaximum - bounds.xMinimum);
    const double ySpan = qMax(1.0e-12, bounds.yMaximum - bounds.yMinimum);

    painter.setPen(QPen(QColor(QStringLiteral("#dbe8f5")), 1.0));
    for (int i = 0; i <= 5; ++i) {
        const qreal x = plot.left() + plot.width() * i / 5.0;
        painter.drawLine(QPointF(x, plot.top()), QPointF(x, plot.bottom()));
    }
    for (int i = 0; i <= 4; ++i) {
        const qreal y = plot.bottom() - plot.height() * i / 4.0;
        painter.drawLine(QPointF(plot.left(), y), QPointF(plot.right(), y));
    }

    QFont tickFont = font();
    tickFont.setPointSizeF(qMax(7.5, font().pointSizeF() - 1.0));
    painter.setFont(tickFont);
    painter.setPen(QColor(QStringLiteral("#48617f")));
    for (int i = 0; i <= 5; ++i) {
        const qreal x = plot.left() + plot.width() * i / 5.0;
        const double value = bounds.xMinimum + (bounds.xMaximum - bounds.xMinimum) * i / 5.0;
        const QString tick = hasLiveData && mode_ == Mode::PeakTrend ? timeTick(value) : dataTick(value, xSpan / 5.0);
        const qreal labelLeft = qBound(0.0, x - 35.0, static_cast<double>(width() - 70));
        painter.drawText(QRectF(labelLeft, plot.bottom() + 6, 70, 20), Qt::AlignHCenter | Qt::AlignTop, tick);
    }
    for (int i = 0; i <= 4; ++i) {
        const qreal y = plot.bottom() - plot.height() * i / 4.0;
        const QString tick = dataTick(bounds.yMinimum + (bounds.yMaximum - bounds.yMinimum) * i / 4.0, ySpan / 4.0);
        painter.drawText(QRectF(0, y - 10, plot.left() - 8, 20), Qt::AlignRight | Qt::AlignVCenter, tick);
    }

    painter.setPen(QPen(QColor(QStringLiteral("#8ca9cb")), 1.2));
    painter.drawLine(plot.bottomLeft(), plot.bottomRight());
    painter.drawLine(plot.bottomLeft(), plot.topLeft());

    if (hasLiveData) {
        QPainterPath path;
        const int samples = static_cast<int>(series_.y.size());
        const int maxPoints = qMax(2, static_cast<int>(plot.width() * 2.0));
        bool started = false;
        auto append = [&](int index) {
            const QPointF point(
                plot.left() + (series_.x.at(index) - bounds.xMinimum) / xSpan * plot.width(),
                plot.bottom() - (series_.y.at(index) - bounds.yMinimum) / ySpan * plot.height());
            if (!started) {
                path.moveTo(point);
                started = true;
            } else {
                path.lineTo(point);
            }
        };
        if (samples <= maxPoints) {
            for (int index = 0; index < samples; ++index) {
                append(index);
            }
        } else {
            const int bucketWidth = qMax(1, (samples + maxPoints / 2 - 1) / (maxPoints / 2));
            for (int first = 0; first < samples; first += bucketWidth) {
                const int end = qMin(samples, first + bucketWidth);
                int minimumIndex = first;
                int maximumIndex = first;
                for (int index = first + 1; index < end; ++index) {
                    if (series_.y.at(index) < series_.y.at(minimumIndex)) {
                        minimumIndex = index;
                    }
                    if (series_.y.at(index) > series_.y.at(maximumIndex)) {
                        maximumIndex = index;
                    }
                }
                if (minimumIndex == maximumIndex) {
                    append(minimumIndex);
                } else if (minimumIndex < maximumIndex) {
                    append(minimumIndex);
                    append(maximumIndex);
                } else {
                    append(maximumIndex);
                    append(minimumIndex);
                }
            }
        }
        painter.setClipRect(plot.adjusted(-2, -2, 2, 2));
        painter.setPen(QPen(QColor(QStringLiteral("#0879ef")), 2.8, Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin));
        painter.drawPath(path);
        if (series_.y.size() == 1) {
            painter.drawEllipse(QPointF(
                plot.left() + (series_.x.first() - bounds.xMinimum) / xSpan * plot.width(),
                plot.bottom() - (series_.y.first() - bounds.yMinimum) / ySpan * plot.height()), 2.5, 2.5);
        }
        painter.setClipping(false);
    } else {
        painter.setPen(QColor(QStringLiteral("#8a9bb0")));
        painter.drawText(plot, Qt::AlignCenter, QStringLiteral("等待采集数据"));
    }

    painter.setPen(QColor(QStringLiteral("#36506f")));
    painter.drawText(QRectF(plot.left(), height() - 25, plot.width(), 20), Qt::AlignCenter, xLabel_);
    painter.save();
    painter.translate(14, plot.center().y());
    painter.rotate(-90.0);
    painter.drawText(QRectF(-plot.height() / 2.0, -9, plot.height(), 18), Qt::AlignCenter, yLabel_);
    painter.restore();

    painter.setPen(QColor(QStringLiteral("#6d86a5")));
    painter.drawText(QRectF(plot.right() - 120, plot.top() + 5, 114, 18), Qt::AlignRight,
        sourceKind_ == tdlas::contracts::DataSourceKind::Simulation
            ? QStringLiteral("SIM · 模拟数据") : QStringLiteral("NI · 实采数据"));
}

} // namespace clientui
