#pragma once

#include "contracts/MeasurementTypes.h"

#include <QWidget>

namespace clientui {

class ChartWidget final : public QWidget
{
    Q_OBJECT

public:
    enum class Mode {
        FvCurve,
        PeakTrend
    };

    explicit ChartWidget(Mode mode, QWidget *parent = nullptr);

    void setAxisLabels(const QString &xLabel, const QString &yLabel);
    void setDataSource(tdlas::contracts::DataSourceKind sourceKind);
    void setSeriesData(const tdlas::contracts::ChartSeriesData &series);
    [[nodiscard]] Mode mode() const;
    [[nodiscard]] qsizetype liveSampleCount() const;

protected:
    void paintEvent(QPaintEvent *event) override;

private:
    Mode mode_;
    QString xLabel_;
    QString yLabel_;
    tdlas::contracts::DataSourceKind sourceKind_ = tdlas::contracts::DataSourceKind::Simulation;
    tdlas::contracts::ChartSeriesData series_;
};

} // namespace clientui
