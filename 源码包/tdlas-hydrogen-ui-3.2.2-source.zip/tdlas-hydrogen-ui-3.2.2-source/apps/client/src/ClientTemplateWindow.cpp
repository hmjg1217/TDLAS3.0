#include "ClientTemplateWindow.h"

#include "CameraPreviewWidget.h"
#include "ChartWidget.h"
#include "contracts/MeasurementTypes.h"

#include <QAction>
#include <QButtonGroup>
#include <QCheckBox>
#include <QComboBox>
#include <QDir>
#include <QDoubleSpinBox>
#include <QFileInfo>
#include <QFormLayout>
#include <QFrame>
#include <QGridLayout>
#include <QIcon>
#include <QKeyEvent>
#include <QLabel>
#include <QMenu>
#include <QPushButton>
#include <QPainter>
#include <QResizeEvent>
#include <QScrollArea>
#include <QSignalBlocker>
#include <QSlider>
#include <QSpinBox>
#include <QStackedWidget>
#include <QVBoxLayout>
#include <QStyleOptionButton>

namespace clientui {

namespace {

constexpr int kAiChannelsRole = Qt::UserRole + 10;
constexpr int kAoChannelsRole = Qt::UserRole + 11;

class RailButton final : public QPushButton {
public:
    using QPushButton::QPushButton;

protected:
    void paintEvent(QPaintEvent *) override
    {
        QStyleOptionButton option;
        initStyleOption(&option);
        option.text.clear();
        option.icon = QIcon();
        QPainter painter(this);
        style()->drawControl(QStyle::CE_PushButtonBevel, &option, &painter, this);
        painter.setRenderHint(QPainter::SmoothPixmapTransform);
        const int iconHeight = icon().isNull() ? 0 : iconSize().height();
        if (iconHeight > 0) {
            const QRect iconRect((width() - iconSize().width()) / 2, 7,
                                 iconSize().width(), iconHeight);
            icon().paint(&painter, iconRect, Qt::AlignCenter,
                         QIcon::Normal,
                         isChecked() ? QIcon::On : QIcon::Off);
        }
        QFont labelFont = font();
        labelFont.setPointSize(10);
        painter.setFont(labelFont);
        painter.setPen(palette().color(QPalette::Active, QPalette::ButtonText));
        const QRect labelRect(3, 9 + iconHeight, width() - 6,
                              height() - iconHeight - 12);
        painter.drawText(labelRect, Qt::AlignHCenter | Qt::AlignVCenter | Qt::TextWordWrap,
                         text());
    }
};

QPushButton *makeRailButton(const QString &text, QWidget *parent)
{
    auto *button = new RailButton(text, parent);
    button->setProperty("uiRole", QStringLiteral("railAction"));
    button->setCursor(Qt::PointingHandCursor);
    return button;
}

QString cameraDurationText(qint64 milliseconds)
{
    const qint64 totalSeconds = qMax<qint64>(0, milliseconds / 1000);
    return QStringLiteral("%1:%2:%3")
        .arg(totalSeconds / 3600, 2, 10, QLatin1Char('0'))
        .arg((totalSeconds / 60) % 60, 2, 10, QLatin1Char('0'))
        .arg(totalSeconds % 60, 2, 10, QLatin1Char('0'));
}

QLabel *makeLabel(const QString &text, const QString &role = QString(), QWidget *parent = nullptr)
{
    auto *label = new QLabel(text, parent);
    if (!role.isEmpty()) {
        label->setProperty("uiRole", role);
    }
    return label;
}

QPushButton *makeButton(const QString &text, const QString &role, bool checkable = false, QWidget *parent = nullptr)
{
    auto *button = new QPushButton(text, parent);
    button->setProperty("uiRole", role);
    button->setCheckable(checkable);
    button->setCursor(Qt::PointingHandCursor);
    return button;
}

QFrame *makePanel(const QString &title, QWidget *body, QWidget *parent = nullptr)
{
    auto *panel = new QFrame(parent);
    panel->setProperty("uiRole", QStringLiteral("panel"));
    auto *layout = new QVBoxLayout(panel);
    layout->setContentsMargins(0, 0, 0, 0);
    layout->setSpacing(0);
    auto *titleLabel = makeLabel(title, QStringLiteral("panelTitle"), panel);
    titleLabel->setMinimumHeight(42);
    titleLabel->setContentsMargins(16, 0, 12, 0);
    layout->addWidget(titleLabel);
    layout->addWidget(body, 1);
    return panel;
}

QFrame *makeMetricRow(const QString &name, const QString &value, const QString &valueObjectName, QWidget *parent)
{
    auto *row = new QFrame(parent);
    row->setProperty("uiRole", QStringLiteral("metricRow"));
    auto *layout = new QHBoxLayout(row);
    layout->setContentsMargins(18, 7, 18, 7);
    layout->setSpacing(10);
    auto *nameLabel = makeLabel(name, QStringLiteral("metricName"), row);
    auto *valueLabel = makeLabel(value, QStringLiteral("metricValue"), row);
    valueLabel->setObjectName(valueObjectName);
    valueLabel->setAlignment(Qt::AlignRight | Qt::AlignVCenter);
    layout->addWidget(nameLabel, 1);
    layout->addWidget(valueLabel, 1);
    return row;
}

QWidget *makeResultsBody(QWidget *parent)
{
    auto *body = new QWidget(parent);
    auto *layout = new QVBoxLayout(body);
    layout->setContentsMargins(14, 12, 14, 14);
    layout->setSpacing(10);
    layout->addWidget(makeMetricRow(QStringLiteral("峰值吸光度"), QStringLiteral("0.0978  · 模拟"), QStringLiteral("peakAbsorbanceValue"), body));
    layout->addWidget(makeMetricRow(QStringLiteral("☼  光强百分比"), QStringLiteral("78.65 %  · 模拟"), QStringLiteral("lightPercentValue"), body));
    layout->addWidget(makeMetricRow(QStringLiteral("气体浓度"), QStringLiteral("—  未校准"), QStringLiteral("concentrationValue"), body));
    return body;
}

QComboBox *combo(const QStringList &items, QWidget *parent)
{
    auto *control = new QComboBox(parent);
    control->addItems(items);
    return control;
}

QDoubleSpinBox *decimalSpin(double value, double minimum, double maximum, int decimals, QWidget *parent)
{
    auto *control = new QDoubleSpinBox(parent);
    control->setRange(minimum, maximum);
    control->setDecimals(decimals);
    control->setValue(value);
    return control;
}

QWidget *makeSliderRow(const QString &labelText, QWidget *parent)
{
    auto *row = new QWidget(parent);
    auto *layout = new QHBoxLayout(row);
    layout->setContentsMargins(0, 0, 0, 0);
    auto *label = makeLabel(labelText, QStringLiteral("fieldLabel"), row);
    auto *slider = new QSlider(Qt::Horizontal, row);
    slider->setRange(0, 100);
    slider->setValue(50);
    auto *value = makeLabel(QStringLiteral("50"), QStringLiteral("sliderValue"), row);
    value->setMinimumWidth(34);
    value->setAlignment(Qt::AlignCenter);
    layout->addWidget(label);
    layout->addWidget(slider, 1);
    layout->addWidget(value);
    QObject::connect(slider, &QSlider::valueChanged, value, [value](int number) { value->setText(QString::number(number)); });
    return row;
}

} // namespace

ClientTemplateWindow::ClientTemplateWindow(Screen initialScreen, QWidget *parent)
    : QWidget(parent)
{
    setObjectName(QStringLiteral("clientTemplateRoot"));
    setWindowTitle(QStringLiteral("TDLAS 测氢系统 · 客户 Codex UI 模板"));
    setMinimumSize(1080, 680);
    resize(1504, 847);
    setFocusPolicy(Qt::StrongFocus);
    buildShell();
    buildParameterDrawer();
    buildMovementPanel();
    setScreen(initialScreen);
}

void ClientTemplateWindow::buildShell()
{
    auto *rootLayout = new QVBoxLayout(this);
    rootLayout->setContentsMargins(0, 0, 0, 0);
    rootLayout->setSpacing(0);
    rootLayout->addWidget(buildTopBar());

    auto *body = new QWidget(this);
    body->setObjectName(QStringLiteral("workspaceBody"));
    auto *bodyLayout = new QHBoxLayout(body);
    bodyLayout->setContentsMargins(0, 0, 0, 0);
    bodyLayout->setSpacing(0);
    bodyLayout->addWidget(buildSideRail());

    auto *content = new QWidget(body);
    auto *contentLayout = new QVBoxLayout(content);
    contentLayout->setContentsMargins(0, 0, 0, 0);
    contentLayout->setSpacing(0);
    contentLayout->addWidget(buildTabBar());

    pages_ = new QStackedWidget(content);
    pages_->setObjectName(QStringLiteral("pageStack"));
    pages_->addWidget(buildMainPage());
    cameraPage_ = buildCameraPage();
    pages_->addWidget(cameraPage_);
    contentLayout->addWidget(pages_, 1);

    bodyLayout->addWidget(content, 1);
    rootLayout->addWidget(body, 1);
}

QWidget *ClientTemplateWindow::buildTopBar()
{
    auto *bar = new QFrame(this);
    bar->setObjectName(QStringLiteral("topBar"));
    bar->setFixedHeight(64);
    auto *layout = new QHBoxLayout(bar);
    layout->setContentsMargins(22, 0, 14, 0);
    layout->setSpacing(12);

    layout->addWidget(makeLabel(QStringLiteral("◉  道纪量子   │   TDLAS 测氢系统"), QStringLiteral("brand"), bar));
    layout->addSpacing(12);
    deviceStatusLabel_ = makeLabel(QStringLiteral("设备状态：● 未连接"), QStringLiteral("statusPill"), bar);
    deviceStatusLabel_->setObjectName(QStringLiteral("deviceStatusLabel"));
    measurementStatusLabel_ = makeLabel(QStringLiteral("▶  采集状态：● 就绪"), QStringLiteral("statusPill"), bar);
    measurementStatusLabel_->setObjectName(QStringLiteral("measurementStatusLabel"));
    layout->addWidget(deviceStatusLabel_);
    layout->addWidget(measurementStatusLabel_);
    modeLabel_ = makeLabel(QStringLiteral("设备待识别"), QStringLiteral("modePill"), bar);
    modeLabel_->setObjectName(QStringLiteral("dataSourceModeLabel"));
    layout->addWidget(modeLabel_);
    layout->addStretch(1);

    templateNotice_ = makeLabel(QStringLiteral("UI 模板 · 无设备连接"), QStringLiteral("templateNotice"), bar);
    templateNotice_->setObjectName(QStringLiteral("templateNotice"));
    layout->addWidget(templateNotice_);
    auto *theme = makeButton(QStringLiteral("☼ 主题"), QStringLiteral("topAction"), false, bar);
    auto *settings = makeButton(QStringLiteral("⚙ 设置"), QStringLiteral("topAction"), false, bar);
    settings->setObjectName(QStringLiteral("settingsButton"));
    auto *settingsMenu = new QMenu(settings);
    auto *refreshDevices = settingsMenu->addAction(QStringLiteral("刷新设备识别"));
    auto *saveParameters = settingsMenu->addAction(QStringLiteral("保存参数区数据"));
    settings->setMenu(settingsMenu);
    layout->addWidget(theme);
    layout->addWidget(settings);

    connect(theme, &QPushButton::clicked, this, [this]() { showTemplateNotice(QStringLiteral("主题按钮仅发出 UI 意图")); });
    connect(refreshDevices, &QAction::triggered, this, &ClientTemplateWindow::refreshDevicesRequested);
    connect(saveParameters, &QAction::triggered, this, &ClientTemplateWindow::saveCurrentParametersRequested);
    return bar;
}

QWidget *ClientTemplateWindow::buildSideRail()
{
    auto *rail = new QFrame(this);
    rail->setObjectName(QStringLiteral("sideRail"));
    rail->setFixedWidth(104);
    auto *layout = new QVBoxLayout(rail);
    layout->setContentsMargins(5, 14, 5, 14);
    layout->setSpacing(4);

    homeRail_ = makeRailButton(QStringLiteral("主页面"), rail);
    parameterRail_ = makeRailButton(QStringLiteral("参数区"), rail);
    startMeasurementButton_ = makeRailButton(QStringLiteral("开始采集"), rail);
    stopMeasurementButton_ = makeRailButton(QStringLiteral("停止采集"), rail);
    homeRail_->setCheckable(true);
    parameterRail_->setCheckable(true);
    startMeasurementButton_->setObjectName(QStringLiteral("startAcquisitionButton"));
    stopMeasurementButton_->setObjectName(QStringLiteral("stopAcquisitionButton"));
    stopMeasurementButton_->setEnabled(false);
    auto *reset = makeRailButton(QStringLiteral("复位"), rail);
    reset->setIcon(QIcon(QStringLiteral(":/sidebar-icons/reset.png")));
    auto *save = makeRailButton(QStringLiteral("数据保存"), rail);
    save->setObjectName(QStringLiteral("saveExperimentButton"));

    const QSize railIconSize(36, 36);
    homeRail_->setIcon(QIcon(QStringLiteral(":/sidebar-icons/home.png")));
    parameterRail_->setIcon(QIcon(QStringLiteral(":/sidebar-icons/parameters.png")));
    startMeasurementButton_->setIcon(QIcon(QStringLiteral(":/sidebar-icons/start-acquisition.png")));
    stopMeasurementButton_->setIcon(QIcon(QStringLiteral(":/sidebar-icons/stop-acquisition.png")));
    save->setIcon(QIcon(QStringLiteral(":/sidebar-icons/save-data.png")));
    for (auto *button : {homeRail_, parameterRail_, startMeasurementButton_, stopMeasurementButton_, reset, save}) {
        button->setIconSize(railIconSize);
    }

    for (auto *button : {homeRail_, parameterRail_, startMeasurementButton_, stopMeasurementButton_, reset, save}) {
        button->setMinimumHeight(96);
        layout->addWidget(button);
    }
    layout->addStretch(1);

    connect(homeRail_, &QPushButton::clicked, this, [this]() { setScreen(Screen::Main); });
    connect(parameterRail_, &QPushButton::clicked, this, [this](bool checked) {
        setScreen(checked ? Screen::Parameters : Screen::Main);
    });
    connect(startMeasurementButton_, &QPushButton::clicked, this, &ClientTemplateWindow::startMeasurementRequested);
    connect(stopMeasurementButton_, &QPushButton::clicked, this, &ClientTemplateWindow::stopMeasurementRequested);
    connect(reset, &QPushButton::clicked, this, &ClientTemplateWindow::resetMeasurementRequested);
    connect(save, &QPushButton::clicked, this, &ClientTemplateWindow::dataSaveLocationRequested);
    return rail;
}

QWidget *ClientTemplateWindow::buildTabBar()
{
    auto *bar = new QFrame(this);
    bar->setObjectName(QStringLiteral("tabBar"));
    bar->setFixedHeight(64);
    auto *layout = new QHBoxLayout(bar);
    layout->setContentsMargins(16, 10, 16, 8);
    layout->setSpacing(10);

    tabGroup_ = new QButtonGroup(bar);
    tabGroup_->setExclusive(true);
    const QStringList names{QStringLiteral("主页面"), QStringLiteral("摄像界面")};
    for (int index = 0; index < names.size(); ++index) {
        auto *button = makeButton(names.at(index), QStringLiteral("topTab"), true, bar);
        button->setMinimumWidth(166);
        tabButtons_[static_cast<std::size_t>(index)] = button;
        tabGroup_->addButton(button, index);
        layout->addWidget(button);
    }
    layout->addStretch(1);

#if QT_VERSION >= QT_VERSION_CHECK(5, 15, 0)
    connect(tabGroup_, &QButtonGroup::idClicked, this, [this](int id) {
        setScreen(id == 0 ? Screen::Main : Screen::Camera);
    });
#else
    connect(tabGroup_, QOverload<int>::of(&QButtonGroup::buttonClicked), this, [this](int id) {
        setScreen(id == 0 ? Screen::Main : Screen::Camera);
    });
#endif
    return bar;
}

QWidget *ClientTemplateWindow::buildMainPage()
{
    auto *page = new QWidget(this);
    page->setObjectName(QStringLiteral("mainPage"));
    auto *grid = new QGridLayout(page);
    grid->setContentsMargins(16, 12, 16, 16);
    grid->setHorizontalSpacing(12);
    grid->setVerticalSpacing(12);

    auto *preview = new CameraPreviewWidget(page);
    auto *fv = new ChartWidget(ChartWidget::Mode::FvCurve, page);
    fv->setObjectName(QStringLiteral("fvChart"));
    fv->setAxisLabels(QStringLiteral("相对频率 v_f（cm⁻¹）"), QStringLiteral("拟合吸光度"));
    auto *peak = new ChartWidget(ChartWidget::Mode::PeakTrend, page);
    peak->setObjectName(QStringLiteral("peakTrendChart"));
    peak->setAxisLabels(QStringLiteral("时间（HH:mm:ss）"), QStringLiteral("峰值吸光度"));

    grid->addWidget(makePanel(QStringLiteral("摄像窗口"), preview, page), 0, 0);
    grid->addWidget(makePanel(QStringLiteral("FV 曲线（吸收光谱）"), fv, page), 0, 1);
    grid->addWidget(makePanel(QStringLiteral("FV 峰值数据记录（实时趋势）"), peak, page), 1, 0);
    auto *resultsBody = makeResultsBody(page);
    peakValueLabel_ = resultsBody->findChild<QLabel *>(QStringLiteral("peakAbsorbanceValue"));
    lightValueLabel_ = resultsBody->findChild<QLabel *>(QStringLiteral("lightPercentValue"));
    concentrationValueLabel_ = resultsBody->findChild<QLabel *>(QStringLiteral("concentrationValue"));
    grid->addWidget(makePanel(QStringLiteral("实时结果"), resultsBody, page), 1, 1);
    grid->setColumnStretch(0, 5);
    grid->setColumnStretch(1, 6);
    grid->setRowStretch(0, 6);
    grid->setRowStretch(1, 5);
    return page;
}

QWidget *ClientTemplateWindow::buildCameraPage()
{
    auto *page = new QWidget(this);
    page->setObjectName(QStringLiteral("cameraPage"));
    auto *grid = new QGridLayout(page);
    grid->setContentsMargins(16, 12, 16, 16);
    grid->setHorizontalSpacing(12);
    grid->setVerticalSpacing(12);

    auto *previewColumn = new QWidget(page);
    auto *previewLayout = new QVBoxLayout(previewColumn);
    previewLayout->setContentsMargins(0, 0, 0, 0);
    previewLayout->setSpacing(12);
    previewLayout->addWidget(makePanel(QStringLiteral("相机预览"), new CameraPreviewWidget(previewColumn), previewColumn), 1);

    auto *captureBar = new QFrame(previewColumn);
    captureBar->setProperty("uiRole", QStringLiteral("captureBar"));
    captureBar->setMinimumHeight(94);
    auto *captureLayout = new QHBoxLayout(captureBar);
    captureLayout->setContentsMargins(24, 14, 24, 14);
    captureLayout->setSpacing(12);
    cameraPhotoButton_ = makeButton(QStringLiteral("拍照"), QStringLiteral("secondary"), false, captureBar);
    cameraPhotoButton_->setObjectName(QStringLiteral("cameraPhotoButton"));
    cameraPhotoButton_->setAccessibleName(QStringLiteral("拍摄实验照片"));
    cameraRecordButton_ = makeButton(QStringLiteral("●  开始录像"), QStringLiteral("primary"), false, captureBar);
    cameraRecordButton_->setObjectName(QStringLiteral("cameraRecordButton"));
    cameraRecordButton_->setAccessibleName(QStringLiteral("开始实验录像"));
    cameraStopButton_ = makeButton(QStringLiteral("■  停止录像"), QStringLiteral("secondary"), false, captureBar);
    cameraStopButton_->setObjectName(QStringLiteral("cameraStopButton"));
    cameraStopButton_->setAccessibleName(QStringLiteral("停止实验录像"));
    cameraStopButton_->setEnabled(false);
    captureLayout->addWidget(cameraPhotoButton_);
    captureLayout->addWidget(cameraRecordButton_);
    captureLayout->addWidget(cameraStopButton_);
    captureLayout->addStretch(1);
    cameraRecordingStatus_ = makeLabel(QStringLiteral("●  录像时长：00:00:00  · 模拟"), QStringLiteral("recordingStatus"), captureBar);
    cameraRecordingStatus_->setObjectName(QStringLiteral("cameraRecordingStatus"));
    cameraRecordingStatus_->setAccessibleName(QStringLiteral("摄像状态"));
    captureLayout->addWidget(cameraRecordingStatus_);
    previewLayout->addWidget(captureBar);

    auto *right = new QWidget(page);
    auto *rightLayout = new QVBoxLayout(right);
    rightLayout->setContentsMargins(0, 0, 0, 0);
    rightLayout->setSpacing(12);

    auto *deviceBody = new QWidget(right);
    auto *deviceForm = new QFormLayout(deviceBody);
    deviceForm->setContentsMargins(16, 12, 16, 12);
    deviceForm->setHorizontalSpacing(12);
    deviceForm->setVerticalSpacing(8);
    cameraDeviceSelect_ = combo({QStringLiteral("未发现设备")}, deviceBody);
    cameraDeviceSelect_->setObjectName(QStringLiteral("cameraDeviceSelect"));
    cameraDeviceSelect_->setAccessibleName(QStringLiteral("相机选择"));
    auto *format = combo({QStringLiteral("1920 × 1080 (16:9)")}, deviceBody);
    auto *fps = combo({QStringLiteral("30 FPS")}, deviceBody);
    auto *motion = makeButton(QStringLiteral("↔  位移/缩放设置"), QStringLiteral("secondary"), false, deviceBody);
    deviceForm->addRow(QStringLiteral("相机选择"), cameraDeviceSelect_);
    deviceForm->addRow(QString(), motion);
    deviceForm->addRow(QStringLiteral("分辨率"), format);
    deviceForm->addRow(QStringLiteral("帧率"), fps);
    rightLayout->addWidget(makePanel(QStringLiteral("相机控制"), deviceBody, right));

    auto *parameterBody = new QWidget(right);
    auto *parameterLayout = new QVBoxLayout(parameterBody);
    parameterLayout->setContentsMargins(16, 10, 16, 12);
    parameterLayout->setSpacing(8);
    auto *exposureRow = new QWidget(parameterBody);
    auto *exposureLayout = new QHBoxLayout(exposureRow);
    exposureLayout->setContentsMargins(0, 0, 0, 0);
    exposureLayout->addWidget(makeLabel(QStringLiteral("曝光时间"), QStringLiteral("fieldLabel"), exposureRow));
    exposureLayout->addWidget(decimalSpin(10.0, 0.1, 1000.0, 1, exposureRow));
    exposureLayout->addWidget(makeLabel(QStringLiteral("ms"), QString(), exposureRow));
    exposureLayout->addStretch(1);
    exposureLayout->addWidget(new QCheckBox(QStringLiteral("自动曝光"), exposureRow));
    parameterLayout->addWidget(exposureRow);
    parameterLayout->addWidget(makeSliderRow(QStringLiteral("亮度"), parameterBody));
    parameterLayout->addWidget(makeSliderRow(QStringLiteral("对比度"), parameterBody));
    parameterLayout->addWidget(makeSliderRow(QStringLiteral("饱和度"), parameterBody));
    rightLayout->addWidget(makePanel(QStringLiteral("⚙  相机参数"), parameterBody, right));

    auto *mediaBody = new QWidget(right);
    auto *mediaLayout = new QGridLayout(mediaBody);
    mediaLayout->setContentsMargins(14, 10, 14, 12);
    mediaLayout->setSpacing(8);
    for (int index = 0; index < 4; ++index) {
        const QString name = index == 3 ? QStringLiteral("视频\nVID_0001.mp4") : QStringLiteral("图片\nIMG_000%1.png").arg(index + 1);
        auto *thumb = makeButton(name, QStringLiteral("thumbnail"), false, mediaBody);
        if (!cameraLastMediaButton_) {
            cameraLastMediaButton_ = thumb;
            cameraLastMediaButton_->setObjectName(QStringLiteral("cameraLastMediaButton"));
        }
        mediaLayout->addWidget(thumb, 0, index);
    }
    rightLayout->addWidget(makePanel(QStringLiteral("图像/视频管理       打开目录"), mediaBody, right), 1);

    grid->addWidget(previewColumn, 0, 0);
    grid->addWidget(right, 0, 1);
    grid->setColumnStretch(0, 5);
    grid->setColumnStretch(1, 3);

    connect(cameraPhotoButton_, &QPushButton::clicked, this, &ClientTemplateWindow::capturePhotoRequested);
    connect(cameraRecordButton_, &QPushButton::clicked, this, &ClientTemplateWindow::startRecordingRequested);
    connect(cameraStopButton_, &QPushButton::clicked, this, &ClientTemplateWindow::stopRecordingRequested);
    connect(cameraLastMediaButton_, &QPushButton::clicked, this, &ClientTemplateWindow::openMediaDirectoryRequested);
    connect(cameraDeviceSelect_, &QComboBox::currentIndexChanged, this, [this](int index) {
        const QString cameraId = cameraDeviceSelect_->itemData(index).toString();
        if (!cameraId.isEmpty()) {
            emit cameraDeviceSelected(cameraId);
        }
    });
    connect(motion, &QPushButton::clicked, this, [this]() { setScreen(Screen::CameraMotion); });
    return page;
}

void ClientTemplateWindow::buildParameterDrawer()
{
    parameterDrawer_ = new QFrame(this);
    parameterDrawer_->setObjectName(QStringLiteral("parameterDrawer"));
    auto *layout = new QVBoxLayout(parameterDrawer_);
    layout->setContentsMargins(18, 16, 18, 18);
    layout->setSpacing(12);

    auto *header = new QHBoxLayout;
    header->addWidget(makeLabel(QStringLiteral("采集参数 · UI 草案"), QStringLiteral("drawerTitle"), parameterDrawer_));
    header->addStretch(1);
    auto *close = makeButton(QStringLiteral("×"), QStringLiteral("iconAction"), false, parameterDrawer_);
    header->addWidget(close);
    layout->addLayout(header);
    layout->addWidget(makeLabel(QStringLiteral("未连接设备；字段值仅用于布局，不会创建硬件任务。"), QStringLiteral("drawerNote"), parameterDrawer_));

    auto *scroll = new QScrollArea(parameterDrawer_);
    scroll->setWidgetResizable(true);
    scroll->setFrameShape(QFrame::NoFrame);
    auto *formHost = new QWidget(scroll);
    auto *form = new QFormLayout(formHost);
    form->setContentsMargins(0, 4, 8, 4);
    form->setHorizontalSpacing(12);
    form->setVerticalSpacing(10);
    parameterDevice_ = combo({QStringLiteral("未发现设备")}, formHost);
    parameterOutputChannel_ = combo({QStringLiteral("不使用输出通道")}, formHost);
    parameterWaveform_ = combo({QStringLiteral("正弦波"), QStringLiteral("方波"),
                                QStringLiteral("三角波"), QStringLiteral("锯齿波")}, formHost);
    parameterOutputFrequency_ = decimalSpin(10.0, 0.0, 100000.0, 2, formHost);
    parameterOutputAmplitude_ = decimalSpin(1.0, -10.0, 10.0, 3, formHost);
    parameterOutputOffset_ = decimalSpin(0.0, -10.0, 10.0, 3, formHost);
    parameterInputChannel_ = combo({QStringLiteral("待设备枚举")}, formHost);
    parameterSampleRate_ = decimalSpin(100000.0, 1.0, 10000000.0, 0, formHost);
    parameterSampleRate_->setObjectName(QStringLiteral("parameterSampleRate"));
    parameterBlockSize_ = new QSpinBox(formHost);
    parameterBlockSize_->setRange(1, 1000000);
    parameterBlockSize_->setValue(100000);
    parameterBlockSize_->setObjectName(QStringLiteral("parameterBlockSize"));
    parameterInputMaximum_ = decimalSpin(10.0, -1000.0, 1000.0, 2, formHost);
    parameterInputMinimum_ = decimalSpin(-10.0, -1000.0, 1000.0, 2, formHost);
    parameterInputMaximum_->setObjectName(QStringLiteral("parameterInputMaximum"));
    parameterInputMinimum_->setObjectName(QStringLiteral("parameterInputMinimum"));
    form->addRow(QStringLiteral("采集卡"), parameterDevice_);
    form->addRow(QStringLiteral("输出通道"), parameterOutputChannel_);
    form->addRow(QStringLiteral("输出波形"), parameterWaveform_);
    form->addRow(QStringLiteral("波形频率"), parameterOutputFrequency_);
    form->addRow(QStringLiteral("波形幅值"), parameterOutputAmplitude_);
    form->addRow(QStringLiteral("波形偏移量"), parameterOutputOffset_);
    form->addRow(QStringLiteral("采集通道"), parameterInputChannel_);
    form->addRow(QStringLiteral("采样率"), parameterSampleRate_);
    form->addRow(QStringLiteral("显示窗口读取点数"), parameterBlockSize_);
    form->addRow(QStringLiteral("量程上限"), parameterInputMaximum_);
    form->addRow(QStringLiteral("量程下限"), parameterInputMinimum_);
    scroll->setWidget(formHost);
    layout->addWidget(scroll, 1);

    auto *actions = new QHBoxLayout;
    auto *cancel = makeButton(QStringLiteral("取消"), QStringLiteral("secondary"), false, parameterDrawer_);
    auto *save = makeButton(QStringLiteral("保存参数"), QStringLiteral("primary"), false, parameterDrawer_);
    actions->addWidget(cancel);
    actions->addWidget(save);
    layout->addLayout(actions);

    connect(close, &QPushButton::clicked, this, [this]() { setScreen(Screen::Main); });
    connect(cancel, &QPushButton::clicked, this, [this]() { setScreen(Screen::Main); });
    save->setObjectName(QStringLiteral("saveParametersButton"));
    connect(save, &QPushButton::clicked, this, [this]() {
        emit parameterDraftSubmitted(measurementParameterDraft());
    });
    connect(parameterDevice_, QOverload<int>::of(&QComboBox::currentIndexChanged), this,
        [this](int) { updateParameterChannelsFromSelectedDevice(); });
    parameterDrawer_->hide();
}

void ClientTemplateWindow::buildMovementPanel()
{
    movementPanel_ = new QFrame(cameraPage_);
    movementPanel_->setObjectName(QStringLiteral("movementPanel"));
    auto *layout = new QVBoxLayout(movementPanel_);
    layout->setContentsMargins(18, 14, 18, 16);
    layout->setSpacing(10);

    auto *header = new QHBoxLayout;
    header->addWidget(makeLabel(QStringLiteral("↔  位移/缩放控制"), QStringLiteral("drawerTitle"), movementPanel_));
    header->addStretch(1);
    auto *close = makeButton(QStringLiteral("×"), QStringLiteral("iconAction"), false, movementPanel_);
    header->addWidget(close);
    layout->addLayout(header);

    auto *columns = new QHBoxLayout;
    auto *direction = new QWidget(movementPanel_);
    auto *directionLayout = new QGridLayout(direction);
    directionLayout->addWidget(makeLabel(QStringLiteral("取景位移"), QStringLiteral("fieldLabel"), direction), 0, 0, 1, 3);
    auto *up = makeButton(QStringLiteral("▲"), QStringLiteral("movement"), false, direction);
    auto *left = makeButton(QStringLiteral("◀"), QStringLiteral("movement"), false, direction);
    auto *right = makeButton(QStringLiteral("▶"), QStringLiteral("movement"), false, direction);
    auto *down = makeButton(QStringLiteral("▼"), QStringLiteral("movement"), false, direction);
    directionLayout->addWidget(up, 1, 1);
    directionLayout->addWidget(left, 2, 0);
    directionLayout->addWidget(right, 2, 2);
    directionLayout->addWidget(down, 3, 1);
    columns->addWidget(direction, 2);

    auto *divider = new QFrame(movementPanel_);
    divider->setFrameShape(QFrame::VLine);
    columns->addWidget(divider);

    auto *zoom = new QWidget(movementPanel_);
    auto *zoomLayout = new QVBoxLayout(zoom);
    zoomLayout->addWidget(makeLabel(QStringLiteral("缩放控制"), QStringLiteral("fieldLabel"), zoom));
    auto *zoomIn = makeButton(QStringLiteral("⊕\n放大"), QStringLiteral("movement"), false, zoom);
    auto *zoomOut = makeButton(QStringLiteral("⊖\n缩小"), QStringLiteral("movement"), false, zoom);
    zoomLayout->addWidget(zoomIn);
    zoomLayout->addWidget(zoomOut);
    columns->addWidget(zoom, 1);
    layout->addLayout(columns, 1);

    connect(close, &QPushButton::clicked, this, [this]() { setScreen(Screen::Camera); });
    using tdlas::camera::CameraViewOperation;
    using tdlas::camera::CameraViewState;
    const auto bindViewButton = [this](QPushButton *button, const char *name,
        const QString &description, CameraViewOperation operation, bool repeat) {
        button->setObjectName(QString::fromLatin1(name));
        button->setProperty("cameraViewControl", true);
        button->setAccessibleName(description);
        button->setProperty("cameraOperation", static_cast<int>(operation));
        button->setToolTip(description + (operation == CameraViewOperation::RotateClockwise
            ? QStringLiteral("（软件图像旋转）") : QStringLiteral("（相机设备控制，取景变化会进入照片和录像）")));
        button->setEnabled(false);
        button->setAutoRepeat(repeat);
        button->setAutoRepeatDelay(CameraViewState::repeatDelayMilliseconds);
        button->setAutoRepeatInterval(CameraViewState::repeatIntervalMilliseconds);
        connect(button, &QPushButton::clicked, this, [this, operation]() {
            emit cameraViewOperationRequested(operation);
        });
    };
    bindViewButton(up, "cameraMoveUpButton", QStringLiteral("相机向上取景"), CameraViewOperation::MoveUp, true);
    bindViewButton(down, "cameraMoveDownButton", QStringLiteral("相机向下取景"), CameraViewOperation::MoveDown, true);
    bindViewButton(left, "cameraMoveLeftButton", QStringLiteral("相机向左取景"), CameraViewOperation::MoveLeft, true);
    bindViewButton(right, "cameraMoveRightButton", QStringLiteral("相机向右取景"), CameraViewOperation::MoveRight, true);
    bindViewButton(zoomIn, "cameraZoomInButton", QStringLiteral("相机设备放大"), CameraViewOperation::ZoomIn, true);
    bindViewButton(zoomOut, "cameraZoomOutButton", QStringLiteral("相机设备缩小"), CameraViewOperation::ZoomOut, true);
    auto *viewActions = new QHBoxLayout();
    auto *rotate = makeButton(QStringLiteral("顺时针 90°"), QStringLiteral("secondary"), false, movementPanel_);
    auto *reset = makeButton(QStringLiteral("复位"), QStringLiteral("secondary"), false, movementPanel_);
    bindViewButton(rotate, "cameraRotate90Button", QStringLiteral("图像顺时针旋转90度"), CameraViewOperation::RotateClockwise, false);
    bindViewButton(reset, "cameraResetViewButton", QStringLiteral("复位设备PTZ与图像旋转"), CameraViewOperation::Reset, false);
    viewActions->addWidget(rotate);
    viewActions->addWidget(reset);
    layout->addLayout(viewActions);
    cameraControlStatus_ = makeLabel(QStringLiteral("等待有效画面和设备控制能力"), QStringLiteral("fieldLabel"), movementPanel_);
    cameraControlStatus_->setObjectName(QStringLiteral("cameraControlStatus"));
    cameraControlStatus_->setWordWrap(true);
    cameraControlStatus_->setMinimumHeight(44);
    layout->addWidget(cameraControlStatus_);
    movementPanel_->hide();
}

void ClientTemplateWindow::setScreen(Screen screen)
{
    screen_ = screen;
    const bool camera = screen == Screen::Camera || screen == Screen::CameraMotion;
    pages_->setCurrentIndex(camera ? 1 : 0);
    selectPageButton(camera ? 1 : 0);
    parameterDrawer_->setVisible(screen == Screen::Parameters);
    movementPanel_->setVisible(screen == Screen::CameraMotion);
    homeRail_->setChecked(screen == Screen::Main || screen == Screen::Parameters);
    parameterRail_->setChecked(screen == Screen::Parameters);
    updateOverlays();
    presentMeasurementDisplay(measurementDisplayModel_);
    if (parameterDrawer_->isVisible()) {
        parameterDrawer_->raise();
    }
    if (movementPanel_->isVisible()) {
        movementPanel_->raise();
    }
}

tdlas::contracts::ParameterDraft ClientTemplateWindow::measurementParameterDraft() const
{
    tdlas::contracts::ParameterDraft draft;
    draft.deviceId = parameterDevice_->currentData().toString();
    draft.aiChannelIds = {parameterInputChannel_->currentData().toString()};
    draft.sampleRateHz = parameterSampleRate_->value();
    draft.readSamplesPerBlock = parameterBlockSize_->value();
    draft.inputRangeMinV = parameterInputMinimum_->value();
    draft.inputRangeMaxV = parameterInputMaximum_->value();
    draft.aoEnabled = parameterOutputChannel_->currentData().toBool();
    draft.aoChannelId = draft.aoEnabled ? parameterOutputChannel_->currentData(Qt::UserRole + 1).toString() : QString();
    draft.waveform = static_cast<tdlas::contracts::Waveform>(parameterWaveform_->currentData().toInt());
    draft.outputFrequencyHz = parameterOutputFrequency_->value();
    draft.outputAmplitudePeakV = parameterOutputAmplitude_->value();
    draft.outputOffsetV = parameterOutputOffset_->value();
    draft.outputSampleRateHz = draft.aoEnabled
        ? qMax(draft.sampleRateHz, draft.outputFrequencyHz * 10.0)
        : 0.0;
    draft.algorithmParameterSetId = QStringLiteral("tdlas-v1.6-ui");
    return draft;
}

void ClientTemplateWindow::presentParameterDraft(const tdlas::contracts::ParameterDraft &draft)
{
    int deviceIndex = parameterDevice_->findData(draft.deviceId);
    if (deviceIndex < 0) {
        parameterDevice_->addItem(
            QStringLiteral("%1 · 当前不可用").arg(draft.deviceId), draft.deviceId);
        deviceIndex = parameterDevice_->count() - 1;
        parameterDevice_->setItemData(deviceIndex, draft.aiChannelIds, kAiChannelsRole);
        parameterDevice_->setItemData(
            deviceIndex,
            draft.aoChannelId.isEmpty() ? QStringList{} : QStringList{draft.aoChannelId},
            kAoChannelsRole);
    }
    parameterDevice_->setCurrentIndex(deviceIndex);
    updateParameterChannelsFromSelectedDevice(
        draft.aiChannelIds.value(0), draft.aoChannelId, draft.aoEnabled);
    parameterWaveform_->clear();
    parameterWaveform_->addItem(QStringLiteral("正弦波"), static_cast<int>(tdlas::contracts::Waveform::Sine));
    parameterWaveform_->addItem(QStringLiteral("方波"), static_cast<int>(tdlas::contracts::Waveform::Square));
    parameterWaveform_->addItem(QStringLiteral("三角波"), static_cast<int>(tdlas::contracts::Waveform::Triangle));
    parameterWaveform_->addItem(QStringLiteral("锯齿波"), static_cast<int>(tdlas::contracts::Waveform::Sawtooth));
    parameterWaveform_->setCurrentIndex(qMax(0, parameterWaveform_->findData(static_cast<int>(draft.waveform))));
    parameterOutputFrequency_->setValue(draft.outputFrequencyHz);
    parameterOutputAmplitude_->setValue(draft.outputAmplitudePeakV);
    parameterOutputOffset_->setValue(draft.outputOffsetV);
    parameterSampleRate_->setValue(draft.sampleRateHz);
    parameterBlockSize_->setValue(static_cast<int>(draft.readSamplesPerBlock));
    parameterInputMaximum_->setValue(draft.inputRangeMaxV);
    parameterInputMinimum_->setValue(draft.inputRangeMinV);
}

void ClientTemplateWindow::presentAcquisitionDevices(
    const QVector<tdlas::acquisition::AcquisitionDeviceDescriptor> &devices,
    const QString &statusMessage)
{
    const tdlas::contracts::ParameterDraft draft = measurementParameterDraft();
    const QSignalBlocker blocker(parameterDevice_);
    parameterDevice_->clear();
    for (const tdlas::acquisition::AcquisitionDeviceDescriptor &device : devices) {
        const QString source = device.sourceKind == tdlas::contracts::DataSourceKind::Simulation
            ? QStringLiteral("模拟")
            : QStringLiteral("真实设备");
        parameterDevice_->addItem(
            QStringLiteral("%1 · %2").arg(device.displayName, source), device.id);
        const int index = parameterDevice_->count() - 1;
        parameterDevice_->setItemData(index, device.aiPhysicalChannels, kAiChannelsRole);
        parameterDevice_->setItemData(index, device.aoPhysicalChannels, kAoChannelsRole);
    }
    if (devices.isEmpty()) {
        parameterDevice_->addItem(QStringLiteral("未发现采集设备"));
        parameterDevice_->setEnabled(false);
    } else {
        parameterDevice_->setEnabled(true);
        const int index = parameterDevice_->findData(draft.deviceId);
        parameterDevice_->setCurrentIndex(index >= 0 ? index : 0);
    }
    updateParameterChannelsFromSelectedDevice(
        draft.aiChannelIds.value(0), draft.aoChannelId, draft.aoEnabled);
    showTemplateNotice(statusMessage);
}

void ClientTemplateWindow::updateParameterChannelsFromSelectedDevice(
    const QString &preferredAiChannel,
    const QString &preferredAoChannel,
    bool aoEnabled)
{
    if (modeLabel_) {
        const QString deviceId = parameterDevice_->currentData().toString();
        const bool simulation = deviceId.startsWith(
            QStringLiteral("mock-"), Qt::CaseInsensitive);
        modeLabel_->setText(deviceId.isEmpty()
                ? QStringLiteral("设备待识别")
                : (simulation ? QStringLiteral("模拟数据") : QStringLiteral("真实采集")));
    }
    const QStringList aiChannels = parameterDevice_->currentData(kAiChannelsRole).toStringList();
    const QStringList aoChannels = parameterDevice_->currentData(kAoChannelsRole).toStringList();

    const QSignalBlocker aiBlocker(parameterInputChannel_);
    parameterInputChannel_->clear();
    for (const QString &channel : aiChannels) {
        parameterInputChannel_->addItem(channel, channel);
    }
    if (parameterInputChannel_->count() == 0) {
        parameterInputChannel_->addItem(QStringLiteral("无可用 AI 通道"));
        parameterInputChannel_->setEnabled(false);
    } else {
        parameterInputChannel_->setEnabled(true);
        const int preferredIndex = parameterInputChannel_->findData(preferredAiChannel);
        parameterInputChannel_->setCurrentIndex(preferredIndex >= 0 ? preferredIndex : 0);
    }

    const QSignalBlocker aoBlocker(parameterOutputChannel_);
    parameterOutputChannel_->clear();
    parameterOutputChannel_->addItem(QStringLiteral("不使用输出通道"), false);
    for (const QString &channel : aoChannels) {
        parameterOutputChannel_->addItem(channel, true);
        parameterOutputChannel_->setItemData(
            parameterOutputChannel_->count() - 1, channel, Qt::UserRole + 1);
    }
    if (aoEnabled) {
        const int preferredIndex = parameterOutputChannel_->findData(
            preferredAoChannel, Qt::UserRole + 1);
        if (preferredIndex >= 0) {
            parameterOutputChannel_->setCurrentIndex(preferredIndex);
        }
    }
}

void ClientTemplateWindow::presentParameterFeedback(const QString &message, bool isError)
{
    showTemplateNotice(isError
            ? QStringLiteral("参数校验失败：%1").arg(message)
            : message);
}

void ClientTemplateWindow::presentOperationalFeedback(const QString &message, bool isError)
{
    showTemplateNotice(isError
            ? QStringLiteral("操作失败：%1").arg(message)
            : message);
}

void ClientTemplateWindow::presentMeasurementDisplay(
    const tdlas::contracts::MeasurementDisplayModel &model)
{
    measurementDisplayModel_ = model;
    QString stateText;
    switch (model.state) {
    case tdlas::contracts::MeasurementState::Idle:
        stateText = QStringLiteral("已停止");
        break;
    case tdlas::contracts::MeasurementState::Preparing:
        stateText = QStringLiteral("准备中");
        break;
    case tdlas::contracts::MeasurementState::Running:
        stateText = QStringLiteral("采集中");
        break;
    case tdlas::contracts::MeasurementState::Stopping:
        stateText = QStringLiteral("停止中");
        break;
    case tdlas::contracts::MeasurementState::Faulted:
        stateText = QStringLiteral("故障");
        break;
    }

    const bool connected = model.connectionState == tdlas::contracts::DeviceConnectionState::Connected;
    const QString source = model.sourceKind == tdlas::contracts::DataSourceKind::Simulation
        ? QStringLiteral("模拟设备")
        : QStringLiteral("NI 真实设备");
    const QString dataTag = model.sourceKind == tdlas::contracts::DataSourceKind::Simulation
        ? QStringLiteral("模拟")
        : QStringLiteral("实采");
    if (deviceStatusLabel_) {
        deviceStatusLabel_->setText(connected
                ? QStringLiteral("设备状态：● %1已连接").arg(source)
                : QStringLiteral("设备状态：● 未连接"));
    }
    if (modeLabel_) {
        modeLabel_->setText(model.sourceKind == tdlas::contracts::DataSourceKind::Simulation
                ? QStringLiteral("模拟数据")
                : QStringLiteral("真实采集"));
    }
    if (measurementStatusLabel_) {
        measurementStatusLabel_->setText(QStringLiteral("▶  采集状态：● %1").arg(stateText));
    }
    if (startMeasurementButton_) {
        startMeasurementButton_->setEnabled(
            model.state == tdlas::contracts::MeasurementState::Idle
            || model.state == tdlas::contracts::MeasurementState::Stopping);
    }
    if (stopMeasurementButton_) {
        stopMeasurementButton_->setEnabled(
            model.state == tdlas::contracts::MeasurementState::Preparing
            || model.state == tdlas::contracts::MeasurementState::Running);
    }
    if (peakValueLabel_) {
        peakValueLabel_->setText(model.peakAbsorbance.has_value()
                ? QStringLiteral("%1  · %2").arg(*model.peakAbsorbance, 0, 'f', 4).arg(dataTag)
                : QStringLiteral("—  等待数据"));
    }
    if (lightValueLabel_) {
        lightValueLabel_->setText(model.lightPercent.has_value()
                ? QStringLiteral("%1 %  · %2").arg(*model.lightPercent, 0, 'f', 2).arg(dataTag)
                : QStringLiteral("—  等待数据"));
    }
    if (concentrationValueLabel_) {
        concentrationValueLabel_->setText(model.concentration.has_value()
                ? QStringLiteral("%1 %2").arg(*model.concentration, 0, 'f', 3).arg(model.concentrationUnit)
                : QStringLiteral("—  未校准"));
    }

    for (ChartWidget *chart : findChildren<ChartWidget *>()) {
        if (!chart->isVisible()) continue;
        chart->setDataSource(model.sourceKind);
        chart->setSeriesData(chart->mode() == ChartWidget::Mode::FvCurve
                ? model.fittedAbsorbanceSeries
                : model.peakTrendSeries);
    }
    showTemplateNotice(model.statusMessage);
}

void ClientTemplateWindow::presentCameraControls(const tdlas::camera::CameraControlState &state)
{
    cameraControls_ = state;
    const auto value = [](const tdlas::camera::CameraControlRange &range) {
        return range.readable ? QString::number(range.value) : QStringLiteral("不支持");
    };
    const QString source = state.simulated ? QStringLiteral("模拟设备") : QStringLiteral("相机设备");
    cameraControlStatus_->setText(QStringLiteral("%1 · Pan %2  Tilt %3  Zoom %4\n%5")
        .arg(source, value(state.pan), value(state.tilt), value(state.zoom),
            state.message.isEmpty() ? QStringLiteral("按驱动步长控制；到达边界自动禁用") : state.message));
    cameraControlStatus_->setToolTip(QStringLiteral("设备原始值，不代表变焦倍率。Zoom 范围 %1～%2，步长 %3；90° 为软件旋转。")
        .arg(state.zoom.minimum).arg(state.zoom.maximum).arg(state.zoom.step));
    updateCameraControlButtons();
}

void ClientTemplateWindow::updateCameraControlButtons()
{
    for (QPushButton *button : movementPanel_->findChildren<QPushButton *>()) {
        if (!button->property("cameraViewControl").toBool()) continue;
        const auto operation = static_cast<tdlas::camera::CameraViewOperation>(button->property("cameraOperation").toInt());
        const bool displayOperation = operation == tdlas::camera::CameraViewOperation::RotateClockwise
            || operation == tdlas::camera::CameraViewOperation::Reset;
        button->setEnabled(cameraViewReady_ && (displayOperation
            || tdlas::camera::cameraHardwareOperationEnabled(cameraControls_, operation)));
        if (!displayOperation) {
            const auto &range = operation == tdlas::camera::CameraViewOperation::MoveLeft
                    || operation == tdlas::camera::CameraViewOperation::MoveRight ? cameraControls_.pan
                : operation == tdlas::camera::CameraViewOperation::MoveUp
                    || operation == tdlas::camera::CameraViewOperation::MoveDown ? cameraControls_.tilt : cameraControls_.zoom;
            button->setToolTip(!range.writable ? QStringLiteral("当前设备不支持此控制，或设备控制尚未就绪。")
                : QStringLiteral("设备当前值 %1，范围 %2～%3，步长 %4。%5")
                    .arg(range.value).arg(range.minimum).arg(range.maximum).arg(range.step)
                    .arg(button->isEnabled() ? QStringLiteral("直接控制相机取景，会影响照片和录像。") : QStringLiteral("已到设备边界或画面未就绪。")));
        }
    }
}

void ClientTemplateWindow::presentCameraView(const tdlas::camera::CameraViewState &state)
{
    for (CameraPreviewWidget *preview : findChildren<CameraPreviewWidget *>()) {
        preview->setViewState(state);
    }
}

void ClientTemplateWindow::presentCameraDisplay(const tdlas::camera::CameraDisplayModel &model)
{
    if (cameraDeviceSelect_) {
        const QSignalBlocker blocker(cameraDeviceSelect_);
        const bool needsExplicitChoice = model.selectedCameraId.isEmpty()
            && !model.devices.isEmpty()
            && model.devices.first().sourceKind == tdlas::contracts::DataSourceKind::RealDevice;
        const int expectedCount = model.devices.isEmpty()
            ? 1
            : model.devices.size() + (needsExplicitChoice ? 1 : 0);
        bool devicesChanged = cameraDeviceSelect_->count() != expectedCount;
        for (int index = 0; !devicesChanged && index < model.devices.size(); ++index) {
            const int comboIndex = index + (needsExplicitChoice ? 1 : 0);
            devicesChanged = cameraDeviceSelect_->itemData(comboIndex).toString()
                != model.devices.at(index).id;
        }
        if (devicesChanged) {
            cameraDeviceSelect_->clear();
            if (model.devices.isEmpty()) {
                cameraDeviceSelect_->addItem(QStringLiteral("未发现设备"));
            } else {
                if (needsExplicitChoice) {
                    cameraDeviceSelect_->addItem(QStringLiteral("请选择已授权摄像头"));
                }
                for (const tdlas::camera::CameraDeviceDescriptor &device : model.devices) {
                    const QString suffix = device.sourceKind == tdlas::contracts::DataSourceKind::Simulation
                        ? QStringLiteral(" · 模拟")
                        : QStringLiteral(" · 真实设备");
                    cameraDeviceSelect_->addItem(device.displayName + suffix, device.id);
                }
            }
        }
        const int selectedIndex = cameraDeviceSelect_->findData(model.selectedCameraId);
        if (selectedIndex >= 0 && cameraDeviceSelect_->currentIndex() != selectedIndex) {
            cameraDeviceSelect_->setCurrentIndex(selectedIndex);
        }
    }

    const bool previewReady = model.state == tdlas::camera::CameraSessionState::Previewing
        || model.state == tdlas::camera::CameraSessionState::Recording;
    const bool viewReady = previewReady && model.latestFrame.has_value() && model.latestFrame->isValid();
    cameraViewReady_ = viewReady;
    updateCameraControlButtons();
    const bool recording = model.state == tdlas::camera::CameraSessionState::Recording;
    if (cameraPhotoButton_) {
        cameraPhotoButton_->setEnabled(previewReady);
    }
    if (cameraRecordButton_) {
        cameraRecordButton_->setEnabled(previewReady && !recording);
    }
    if (cameraStopButton_) {
        cameraStopButton_->setEnabled(recording);
    }
    if (cameraRecordingStatus_) {
        const QString source = model.sourceKind == tdlas::contracts::DataSourceKind::Simulation
            ? QStringLiteral("模拟")
            : QStringLiteral("真实设备");
        cameraRecordingStatus_->setText(QStringLiteral("●  录像时长：%1  · %2")
            .arg(cameraDurationText(model.recordingDurationMilliseconds), source));
        cameraRecordingStatus_->setToolTip(model.statusMessage);
    }

    const QString previewStatus = model.state == tdlas::camera::CameraSessionState::Faulted
        ? QStringLiteral("连接已断开")
        : (model.sourceKind == tdlas::contracts::DataSourceKind::Simulation
                  ? QStringLiteral("模拟预览")
                  : QStringLiteral("实时预览"));
    const QString formatText = model.activeFormat.isValid()
        ? QStringLiteral("%1 × %2   %3 FPS")
              .arg(model.activeFormat.frameSize.width())
              .arg(model.activeFormat.frameSize.height())
              .arg(model.activeFormat.maximumFrameRate, 0, 'f', 0)
        : QStringLiteral("等待视频帧");
    for (CameraPreviewWidget *preview : findChildren<CameraPreviewWidget *>()) {
        if (model.latestFrame.has_value() && model.latestFrame->isValid()) {
            preview->setFrame(model.latestFrame->image, previewStatus, formatText);
        } else {
            preview->setFrame(QImage(), previewStatus, formatText);
        }
    }
    if (cameraLastMediaButton_ && model.lastMediaResult.has_value()) {
        const tdlas::camera::MediaResult &media = *model.lastMediaResult;
        cameraLastMediaButton_->setText(media.success
                ? QStringLiteral("%1\n%2")
                      .arg(media.mediaType == tdlas::camera::MediaType::Photo
                              ? QStringLiteral("图片")
                              : QStringLiteral("视频"),
                          QFileInfo(media.path).fileName())
                : QStringLiteral("媒体\n保存失败"));
        cameraLastMediaButton_->setToolTip(media.success ? media.path : media.diagnostic);
    }
}

bool ClientTemplateWindow::saveCapture(const QString &path)
{
    const QFileInfo info(path);
    if (!info.absolutePath().isEmpty() && !QDir().mkpath(info.absolutePath())) {
        return false;
    }
    return grab().save(path, "PNG");
}

void ClientTemplateWindow::keyPressEvent(QKeyEvent *event)
{
    switch (event->key()) {
    case Qt::Key_F1:
        setScreen(Screen::Main);
        return;
    case Qt::Key_F2:
        setScreen(Screen::Parameters);
        return;
    case Qt::Key_F3:
        setScreen(Screen::Camera);
        return;
    case Qt::Key_F4:
        setScreen(Screen::CameraMotion);
        return;
    case Qt::Key_Escape:
        if (screen_ == Screen::Parameters) {
            setScreen(Screen::Main);
        } else if (screen_ == Screen::CameraMotion) {
            setScreen(Screen::Camera);
        } else {
            close();
        }
        return;
    default:
        break;
    }
    QWidget::keyPressEvent(event);
}

void ClientTemplateWindow::resizeEvent(QResizeEvent *event)
{
    QWidget::resizeEvent(event);
    updateOverlays();
}

void ClientTemplateWindow::updateOverlays()
{
    if (parameterDrawer_) {
        parameterDrawer_->setGeometry(88, 64, qMin(420, qMax(360, width() / 3)), qMax(240, height() - 64));
    }
    if (movementPanel_ && cameraPage_) {
        const int panelWidth = qMin(410, qMax(350, cameraPage_->width() / 3));
        const int panelHeight = qMin(440, qMax(420, cameraPage_->height() / 2));
        movementPanel_->setGeometry(qMax(12, cameraPage_->width() - panelWidth - 24), 96, panelWidth, panelHeight);
    }
}

void ClientTemplateWindow::selectPageButton(int index)
{
    for (std::size_t item = 0; item < tabButtons_.size(); ++item) {
        tabButtons_[item]->setChecked(static_cast<int>(item) == index);
    }
}

void ClientTemplateWindow::showTemplateNotice(const QString &text)
{
    templateNotice_->setText(text);
}

} // namespace clientui
