#include "IntegratedApplicationController.h"

#include "AdminTemplateWindow.h"
#include "ClientTemplateWindow.h"
#include "storage/PeakRecordCsvExporter.h"
#include "camera/MockCameraDevice.h"
#include "camera/QtMultimediaCameraDevice.h"

#include <QApplication>
#include <QDebug>
#include <QDesktopServices>
#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QFileDialog>
#include <QTextStream>
#include <QFormLayout>
#include <QDateTimeEdit>
#include <QDialog>
#include <QDialogButtonBox>
#include <QStandardPaths>
#include <QMetaObject>
#include <QSettings>
#include <QStandardPaths>
#include <QThread>
#include <QUuid>
#include <QUrl>
#include <QWidget>

#include <algorithm>
#include <memory>

namespace {

std::unique_ptr<tdlas::camera::ICameraDevice> createCameraDevice()
{
    const QString backend = qEnvironmentVariable("TDLAS_CAMERA_BACKEND").trimmed().toLower();
    if (backend == QStringLiteral("mock")) {
        return std::make_unique<tdlas::camera::MockCameraDevice>();
    }
    return std::make_unique<tdlas::camera::QtMultimediaCameraDevice>();
}

QString configuredInitialCameraId()
{
    const QString backend = qEnvironmentVariable("TDLAS_CAMERA_BACKEND").trimmed().toLower();
    if (backend == QStringLiteral("mock")) {
        return QStringLiteral("mock-camera-0");
    }
    return qEnvironmentVariable("TDLAS_CAMERA_DEVICE_ID").trimmed();
}

tdlas::acquisition::AcquisitionBackendPolicy acquisitionBackendPolicy()
{
    const QString backend = qEnvironmentVariable("TDLAS_ACQUISITION_BACKEND").trimmed().toLower();
    if (backend == QStringLiteral("mock")) {
        return tdlas::acquisition::AcquisitionBackendPolicy::MockOnly;
    }
    if (backend == QStringLiteral("nidaqmx")) {
        return tdlas::acquisition::AcquisitionBackendPolicy::NidaqmxOnly;
    }
    return tdlas::acquisition::AcquisitionBackendPolicy::Auto;
}

tdlas::application::MeasurementApplicationOptions measurementOptions()
{
    tdlas::application::MeasurementApplicationOptions options;
    options.displayRefreshIntervalMilliseconds = 33;
    options.sourceKind = acquisitionBackendPolicy()
            == tdlas::acquisition::AcquisitionBackendPolicy::MockOnly
        ? tdlas::contracts::DataSourceKind::Simulation
        : tdlas::contracts::DataSourceKind::RealDevice;
    return options;
}

QString parameterConfigurationPath()
{
    const QString overridePath = qEnvironmentVariable("TDLAS_PARAMETER_CONFIG").trimmed();
    if (!overridePath.isEmpty()) {
        return QFileInfo(overridePath).absoluteFilePath();
    }
    return QDir(QStandardPaths::writableLocation(QStandardPaths::AppConfigLocation))
        .filePath(QStringLiteral("measurement-parameters.ini"));
}

std::optional<tdlas::contracts::ParameterDraft> loadParameterDraft()
{
    QSettings settings(parameterConfigurationPath(), QSettings::IniFormat);
    settings.beginGroup(QStringLiteral("measurement"));
    if (settings.value(QStringLiteral("schemaVersion")).toInt() != 1) {
        settings.endGroup();
        return std::nullopt;
    }
    tdlas::contracts::ParameterDraft draft;
    draft.deviceId = settings.value(QStringLiteral("deviceId")).toString();
    draft.aiChannelIds = settings.value(QStringLiteral("aiChannelIds")).toStringList();
    draft.sampleRateHz = settings.value(QStringLiteral("sampleRateHz")).toDouble();
    draft.readSamplesPerBlock = settings.value(QStringLiteral("readSamplesPerBlock")).toLongLong();
    draft.inputRangeMinV = settings.value(QStringLiteral("inputRangeMinV"), -10.0).toDouble();
    draft.inputRangeMaxV = settings.value(QStringLiteral("inputRangeMaxV"), 10.0).toDouble();
    draft.aoEnabled = settings.value(QStringLiteral("aoEnabled"), false).toBool();
    draft.aoChannelId = settings.value(QStringLiteral("aoChannelId")).toString();
    draft.waveform = static_cast<tdlas::contracts::Waveform>(
        settings.value(QStringLiteral("waveform"), 0).toInt());
    draft.outputFrequencyHz = settings.value(QStringLiteral("outputFrequencyHz")).toDouble();
    draft.outputAmplitudePeakV = settings.value(QStringLiteral("outputAmplitudePeakV")).toDouble();
    draft.outputOffsetV = settings.value(QStringLiteral("outputOffsetV")).toDouble();
    draft.outputSampleRateHz = settings.value(QStringLiteral("outputSampleRateHz")).toDouble();
    draft.algorithmParameterSetId = settings.value(
        QStringLiteral("algorithmParameterSetId"), QStringLiteral("tdlas-v1.6-ui")).toString();
    settings.endGroup();
    return draft;
}

bool saveParameterDraft(const tdlas::contracts::ParameterDraft &draft, QString *diagnostic)
{
    const QString path = parameterConfigurationPath();
    if (!QDir().mkpath(QFileInfo(path).absolutePath())) {
        if (diagnostic) {
            *diagnostic = QStringLiteral("cannot create parameter configuration directory: %1").arg(path);
        }
        return false;
    }
    QSettings settings(path, QSettings::IniFormat);
    settings.beginGroup(QStringLiteral("measurement"));
    settings.setValue(QStringLiteral("schemaVersion"), 1);
    settings.setValue(QStringLiteral("deviceId"), draft.deviceId);
    settings.setValue(QStringLiteral("aiChannelIds"), draft.aiChannelIds);
    settings.setValue(QStringLiteral("sampleRateHz"), draft.sampleRateHz);
    settings.setValue(QStringLiteral("readSamplesPerBlock"), static_cast<qlonglong>(draft.readSamplesPerBlock));
    settings.setValue(QStringLiteral("inputRangeMinV"), draft.inputRangeMinV);
    settings.setValue(QStringLiteral("inputRangeMaxV"), draft.inputRangeMaxV);
    settings.setValue(QStringLiteral("aoEnabled"), draft.aoEnabled);
    settings.setValue(QStringLiteral("aoChannelId"), draft.aoChannelId);
    settings.setValue(QStringLiteral("waveform"), static_cast<int>(draft.waveform));
    settings.setValue(QStringLiteral("outputFrequencyHz"), draft.outputFrequencyHz);
    settings.setValue(QStringLiteral("outputAmplitudePeakV"), draft.outputAmplitudePeakV);
    settings.setValue(QStringLiteral("outputOffsetV"), draft.outputOffsetV);
    settings.setValue(QStringLiteral("outputSampleRateHz"), draft.outputSampleRateHz);
    settings.setValue(QStringLiteral("algorithmParameterSetId"), draft.algorithmParameterSetId);
    settings.endGroup();
    settings.sync();
    if (settings.status() == QSettings::NoError) {
        return true;
    }
    if (diagnostic) {
        *diagnostic = QStringLiteral("QSettings status %1 at %2")
            .arg(static_cast<int>(settings.status()))
            .arg(path);
    }
    return false;
}

tdlas::acquisition::AcquisitionDeviceDescriptor mockAcquisitionDescriptor()
{
    tdlas::acquisition::AcquisitionDeviceDescriptor descriptor;
    descriptor.id = QStringLiteral("mock-acquisition-0");
    descriptor.displayName = QStringLiteral("模拟采集设备 (mock-acquisition-0)");
    descriptor.productType = QStringLiteral("Mock");
    descriptor.aiPhysicalChannels = {QStringLiteral("sim/ai0")};
    descriptor.sourceKind = tdlas::contracts::DataSourceKind::Simulation;
    return descriptor;
}

QString readStyleSheet(const QString &resourcePath)
{
    QFile styleFile(resourcePath);
    if (!styleFile.open(QIODevice::ReadOnly | QIODevice::Text)) {
        return {};
    }
    return QString::fromUtf8(styleFile.readAll());
}

tdlas::storage::StorageConfiguration loadStorageConfiguration()
{
    tdlas::storage::StorageConfiguration defaults;
    const QString rootOverride = qEnvironmentVariable("TDLAS_STORAGE_ROOT");
    defaults.rootDirectory = rootOverride;
    if (defaults.rootDirectory.isEmpty()) {
        defaults.rootDirectory = QDir(QStandardPaths::writableLocation(QStandardPaths::AppLocalDataLocation))
            .filePath(QStringLiteral("experiments"));
    }
    QString configurationPath = qEnvironmentVariable("TDLAS_STORAGE_CONFIG");
    if (configurationPath.isEmpty()) {
        configurationPath = QDir(QStandardPaths::writableLocation(QStandardPaths::AppConfigLocation))
            .filePath(QStringLiteral("storage.json"));
    }
    tdlas::storage::StorageOperationResult operation;
    tdlas::storage::StorageConfiguration configuration =
        tdlas::storage::StorageConfigurationStore::loadOrCreate(
            configurationPath, defaults, &operation);
    if (!operation.success) {
        qWarning().noquote() << operation.code << operation.diagnostic;
    }
    if (!rootOverride.isEmpty()) {
        configuration.rootDirectory = rootOverride;
    }
    return configuration;
}

tdlas::system::SystemRole systemRole(authentication::UserRole role)
{
    if (role == authentication::UserRole::Administrator) {
        return tdlas::system::SystemRole::Administrator;
    }
    if (role == authentication::UserRole::Client) {
        return tdlas::system::SystemRole::Client;
    }
    return tdlas::system::SystemRole::Invalid;
}

void applyStyleSheet(QApplication &application, const QString &resourcePath)
{
    application.setStyleSheet(readStyleSheet(resourcePath));
}

QWidget *createRoleWindow(authentication::UserRole role)
{
    if (role == authentication::UserRole::Administrator) {
        return new adminui::AdminTemplateWindow(adminui::AdminTemplateWindow::Screen::Main);
    }
    if (role == authentication::UserRole::Client) {
        return new clientui::ClientTemplateWindow(clientui::ClientTemplateWindow::Screen::Main);
    }
    return nullptr;
}

QString stylePathForRole(authentication::UserRole role)
{
    return role == authentication::UserRole::Administrator
        ? QStringLiteral(":/styles/admin.qss")
        : QStringLiteral(":/styles/client.qss");
}

} // namespace

IntegratedApplicationController::IntegratedApplicationController(
    QApplication &application,
    QObject *parent)
    : QObject(parent)
    , application_(application)
    , acquisitionDevice_(acquisitionBackendPolicy())
    , storageConfiguration_(loadStorageConfiguration())
    , storageRepository_(storageConfiguration_)
    , cameraService_(createCameraDevice(), storageConfiguration_.rootDirectory)
    , auditSink_(QDir(storageConfiguration_.rootDirectory).filePath(QStringLiteral("system-logs")))
    , measurementService_(
          acquisitionDevice_, tdlasAlgorithmProcessor_, storageRepository_, measurementOptions())
{
    currentParameterDraft_ = loadParameterDraft().value_or(
        tdlas::contracts::ParameterDraft::mockDefaults());
    tdlas::contracts::ParameterCommitResult initialCommit = parameterService_.commit(currentParameterDraft_);
    if (!initialCommit.isSuccess()) {
        currentParameterDraft_ = tdlas::contracts::ParameterDraft::mockDefaults();
        (void)parameterService_.commit(currentParameterDraft_);
    }
}

IntegratedApplicationController::~IntegratedApplicationController()
{
    if (peakStreamFile_) {
        peakStreamFile_->flush();
        peakStreamFile_->close();
        delete peakStreamFile_;
        peakStreamFile_ = nullptr;
    }
    if (peakExportThread_) {
        peakExportThread_->wait();
    }
    if (deviceDiscoveryThread_) {
        deviceDiscoveryThread_->quit();
        deviceDiscoveryThread_->wait();
    }
    cameraService_.shutdown();
    if (measurementService_.state() == tdlas::contracts::MeasurementState::Preparing
        || measurementService_.state() == tdlas::contracts::MeasurementState::Running
        || measurementService_.state() == tdlas::contracts::MeasurementState::Stopping) {
        (void)measurementService_.stop(measurementService_.currentRunId());
    }
    delete roleWindow_.data();
    delete loginWindow_.data();
}

void IntegratedApplicationController::start()
{
    if (loginWindow_ || roleWindow_) {
        return;
    }

    currentRole_ = authentication::UserRole::Invalid;
    applyStyleSheet(application_, QStringLiteral(":/styles/startup.qss"));

    loginWindow_ = new StartupTemplateWindow(StartupTemplateWindow::Screen::Login);
    loginWindow_->setAttribute(Qt::WA_DeleteOnClose);
    connect(
        loginWindow_,
        &StartupTemplateWindow::loginSubmitted,
        this,
        &IntegratedApplicationController::handleLogin);
    loginWindow_->show();
}

authentication::UserRole IntegratedApplicationController::currentRole() const
{
    return currentRole_;
}

StartupTemplateWindow *IntegratedApplicationController::loginWindow() const
{
    return loginWindow_.data();
}

QWidget *IntegratedApplicationController::roleWindow() const
{
    return roleWindow_.data();
}

void IntegratedApplicationController::handleLogin(
    const QString &username,
    const QString &password)
{
    const authentication::UserRole role = authenticator_.authenticate(username, password);
    if (role == authentication::UserRole::Invalid) {
        recordAudit(
            QStringLiteral("authentication"),
            QStringLiteral("login"),
            QStringLiteral("denied"),
            QStringLiteral("temporary credential adapter rejected credentials"));
        loginWindow_->setLoginMessage(QStringLiteral("账号或密码错误。"), true);
        loginWindow_->clearPassword(true);
        return;
    }

    const QDateTime issuedAtUtc = QDateTime::currentDateTimeUtc();
    session_ = tdlas::system::SessionContext{
        QUuid::createUuid().toString(QUuid::WithoutBraces),
        username,
        systemRole(role),
        issuedAtUtc,
        issuedAtUtc.addSecs(8 * 60 * 60),
        QStringLiteral("temporary-local-development")};
    recordAudit(
        QStringLiteral("authentication"),
        QStringLiteral("login"),
        QStringLiteral("allowed"));

    loginWindow_->setLoginBusy(true);
    loginWindow_->clearPassword();
    loginWindow_->hide();
    applyStyleSheet(application_, stylePathForRole(role));

    roleWindow_ = createRoleWindow(role);
    if (!roleWindow_) {
        applyStyleSheet(application_, QStringLiteral(":/styles/startup.qss"));
        loginWindow_->setLoginBusy(false);
        loginWindow_->setLoginMessage(QStringLiteral("无法打开目标界面。"), true);
        loginWindow_->show();
        return;
    }

    currentRole_ = role;
    bindMeasurementWorkflow(roleWindow_);
    bindCameraWorkflow(roleWindow_);
    roleWindow_->setAttribute(Qt::WA_DeleteOnClose);
    roleWindow_->show();
    roleWindow_->raise();
    roleWindow_->activateWindow();
    loginWindow_->close();
}

void IntegratedApplicationController::bindCameraWorkflow(QWidget *window)
{
    const auto operateView = [this, window](tdlas::camera::CameraViewOperation operation) {
        if (authorize(tdlas::system::ProtectedOperation::UseCamera, window)) {
            cameraService_.operateView(operation);
        }
    };
    const auto selectCamera = [this, window](const QString &cameraId) {
        if (!authorize(tdlas::system::ProtectedOperation::UseCamera, window)) {
            return;
        }
        cameraService_.startPreview(cameraId);
    };
    const auto capturePhoto = [this, window]() {
        if (!authorize(tdlas::system::ProtectedOperation::UseCamera, window)
            || !authorize(tdlas::system::ProtectedOperation::SaveExperiment, window)) {
            return;
        }
        const tdlas::contracts::ExperimentId experimentId = measurementService_.currentExperimentId();
        if (measurementService_.state() != tdlas::contracts::MeasurementState::Running
            || !experimentId.isValid()) {
            presentOperationalFeedback(window, QStringLiteral("请先开始实验，再拍摄关联照片。"), true);
            return;
        }
        cameraService_.capturePhoto(experimentId);
    };
    const auto startRecording = [this, window]() {
        if (!authorize(tdlas::system::ProtectedOperation::UseCamera, window)
            || !authorize(tdlas::system::ProtectedOperation::SaveExperiment, window)) {
            return;
        }
        const tdlas::contracts::ExperimentId experimentId = measurementService_.currentExperimentId();
        if (measurementService_.state() != tdlas::contracts::MeasurementState::Running
            || !experimentId.isValid()) {
            presentOperationalFeedback(window, QStringLiteral("请先开始实验，再开始关联录像。"), true);
            return;
        }
        cameraService_.startRecording(experimentId);
    };
    const auto stopRecording = [this, window]() {
        if (!authorize(tdlas::system::ProtectedOperation::UseCamera, window)) {
            return;
        }
        cameraService_.stopRecording();
    };
    const auto openMediaDirectory = [this, window]() {
        if (!authorize(tdlas::system::ProtectedOperation::UseCamera, window)) {
            return;
        }
        const auto media = cameraService_.displayModel().lastMediaResult;
        QString directory;
        if (media.has_value() && media->success && !media->path.isEmpty()) {
            directory = QFileInfo(media->path).absolutePath();
        } else {
            // Open the selected root's camera folder even before the first
            // capture so the operator can inspect the destination.
            directory = QDir(selectedDataRoot_.isEmpty() ? storageConfiguration_.rootDirectory : selectedDataRoot_)
                .filePath(QStringLiteral("拍照摄像"));
            if (!QDir().mkpath(directory)) {
                presentOperationalFeedback(window, QStringLiteral("无法创建媒体目录：%1").arg(directory), true);
                return;
            }
        }
        if (!QDesktopServices::openUrl(QUrl::fromLocalFile(directory))) {
            presentOperationalFeedback(window, QStringLiteral("无法打开媒体目录：%1").arg(directory), true);
        }
    };

    if (auto *adminWindow = qobject_cast<adminui::AdminTemplateWindow *>(window)) {
        connect(adminWindow, &adminui::AdminTemplateWindow::cameraDeviceSelected,
            adminWindow, selectCamera);
        connect(adminWindow, &adminui::AdminTemplateWindow::capturePhotoRequested,
            adminWindow, capturePhoto);
        connect(adminWindow, &adminui::AdminTemplateWindow::startRecordingRequested,
            adminWindow, startRecording);
        connect(adminWindow, &adminui::AdminTemplateWindow::stopRecordingRequested,
            adminWindow, stopRecording);
        connect(adminWindow, &adminui::AdminTemplateWindow::openMediaDirectoryRequested,
            adminWindow, openMediaDirectory);
        connect(&cameraService_, &tdlas::camera::CameraApplicationService::displayModelChanged,
            adminWindow, &adminui::AdminTemplateWindow::presentCameraDisplay);
        connect(adminWindow, &adminui::AdminTemplateWindow::cameraViewOperationRequested,
            adminWindow, operateView);
        connect(&cameraService_, &tdlas::camera::CameraApplicationService::viewStateChanged,
            adminWindow, &adminui::AdminTemplateWindow::presentCameraView);
        connect(&cameraService_, &tdlas::camera::CameraApplicationService::cameraControlsChanged,
            adminWindow, &adminui::AdminTemplateWindow::presentCameraControls);
        adminWindow->presentCameraControls(cameraService_.cameraControls());
        adminWindow->presentCameraView(cameraService_.viewState());
        adminWindow->presentCameraDisplay(cameraService_.displayModel());
    } else if (auto *clientWindow = qobject_cast<clientui::ClientTemplateWindow *>(window)) {
        connect(clientWindow, &clientui::ClientTemplateWindow::cameraDeviceSelected,
            clientWindow, selectCamera);
        connect(clientWindow, &clientui::ClientTemplateWindow::capturePhotoRequested,
            clientWindow, capturePhoto);
        connect(clientWindow, &clientui::ClientTemplateWindow::startRecordingRequested,
            clientWindow, startRecording);
        connect(clientWindow, &clientui::ClientTemplateWindow::stopRecordingRequested,
            clientWindow, stopRecording);
        connect(clientWindow, &clientui::ClientTemplateWindow::openMediaDirectoryRequested,
            clientWindow, openMediaDirectory);
        connect(&cameraService_, &tdlas::camera::CameraApplicationService::displayModelChanged,
            clientWindow, &clientui::ClientTemplateWindow::presentCameraDisplay);
        connect(clientWindow, &clientui::ClientTemplateWindow::cameraViewOperationRequested,
            clientWindow, operateView);
        connect(&cameraService_, &tdlas::camera::CameraApplicationService::viewStateChanged,
            clientWindow, &clientui::ClientTemplateWindow::presentCameraView);
        connect(&cameraService_, &tdlas::camera::CameraApplicationService::cameraControlsChanged,
            clientWindow, &clientui::ClientTemplateWindow::presentCameraControls);
        clientWindow->presentCameraControls(cameraService_.cameraControls());
        clientWindow->presentCameraView(cameraService_.viewState());
        clientWindow->presentCameraDisplay(cameraService_.displayModel());
    }

    connect(&cameraService_, &tdlas::camera::CameraApplicationService::mediaCompleted,
        window, [this, window](const tdlas::camera::MediaResult &result) {
            const QString mediaName = result.mediaType == tdlas::camera::MediaType::Photo
                ? QStringLiteral("照片")
                : QStringLiteral("录像");
            if (result.success) {
                presentOperationalFeedback(
                    window,
                    QStringLiteral("%1已保存：%2").arg(mediaName, result.path));
                recordAudit(
                    QStringLiteral("camera"),
                    QStringLiteral("save-%1").arg(tdlas::camera::mediaTypeName(result.mediaType)),
                    QStringLiteral("allowed"),
                    result.path);
            } else {
                presentOperationalFeedback(
                    window,
                    QStringLiteral("%1保存失败：%2").arg(mediaName, result.diagnostic),
                    true);
                recordAudit(
                    QStringLiteral("camera"),
                    QStringLiteral("save-%1").arg(tdlas::camera::mediaTypeName(result.mediaType)),
                    QStringLiteral("failed"),
                    result.errorCode + QStringLiteral(": ") + result.diagnostic);
            }
        });
    connect(&cameraService_, &tdlas::camera::CameraApplicationService::errorOccurred,
        window, [this, window](const tdlas::contracts::ModuleError &error) {
            presentOperationalFeedback(window, error.userMessage, true);
            recordAudit(
                QStringLiteral("camera"),
                error.code,
                QStringLiteral("failed"),
                error.diagnostic);
        });
    connect(&measurementService_, &tdlas::application::MeasurementApplicationService::displayModelChanged,
        window, [this](const tdlas::contracts::MeasurementDisplayModel &model) {
            if (model.state != tdlas::contracts::MeasurementState::Running
                && cameraService_.displayModel().state == tdlas::camera::CameraSessionState::Recording) {
                cameraService_.stopRecording();
            }
        });
    connect(window, &QObject::destroyed, this, [this]() { cameraService_.shutdown(); });

    cameraService_.refreshDevices();
    const QString initialCameraId = configuredInitialCameraId();
    if (!initialCameraId.isEmpty()) {
        cameraService_.startPreview(initialCameraId);
    }
}

void IntegratedApplicationController::bindMeasurementWorkflow(QWidget *window)
{
    const auto startMeasurement = [this, window]() {
        if (!authorize(tdlas::system::ProtectedOperation::StartMeasurement, window)
            || !authorize(tdlas::system::ProtectedOperation::SaveExperiment, window)) {
            return;
        }
        const auto snapshot = parameterService_.currentSnapshot();
        if (!snapshot.has_value()) {
            if (auto *adminWindow = qobject_cast<adminui::AdminTemplateWindow *>(window)) {
                adminWindow->presentParameterFeedback(QStringLiteral("尚无有效参数快照。"), true);
            } else if (auto *clientWindow = qobject_cast<clientui::ClientTemplateWindow *>(window)) {
                clientWindow->presentParameterFeedback(QStringLiteral("尚无有效参数快照。"), true);
            }
            return;
        }
        tdlas::contracts::StartMeasurementRequest request;
        request.parameters = *snapshot;
        request.operatorId = session_ ? session_->principalId : QString();
        (void)measurementService_.start(request);
    };
    const auto stopMeasurement = [this, window]() {
        if (!authorize(tdlas::system::ProtectedOperation::StopMeasurement, window)) {
            return;
        }
        (void)measurementService_.stop(measurementService_.currentRunId());
    };
    const auto resetMeasurement = [this, window]() {
        if (!authorize(tdlas::system::ProtectedOperation::ResetMeasurement, window)) {
            return;
        }
        (void)measurementService_.resetFault();
    };
    const auto presentSaveState = [this, window]() {
        if (!authorize(tdlas::system::ProtectedOperation::SaveExperiment, window)) {
            return;
        }
        const tdlas::contracts::ExperimentId experimentId = measurementService_.currentExperimentId();
        if (!experimentId.isValid()) {
            presentOperationalFeedback(window, QStringLiteral("尚无可保存的实验。"), true);
            return;
        }
        const tdlas::contracts::ExperimentStorageState storageState =
            measurementService_.displayModel().storageState;
        if (storageState == tdlas::contracts::ExperimentStorageState::Failed) {
            presentOperationalFeedback(
                window,
                QStringLiteral("实验保存失败：%1").arg(experimentId.value),
                true);
        } else if (storageState == tdlas::contracts::ExperimentStorageState::Saving) {
            presentOperationalFeedback(
                window,
                QStringLiteral("实验正在自动保存：%1").arg(experimentId.value));
        } else if (storageState == tdlas::contracts::ExperimentStorageState::Saved) {
            presentOperationalFeedback(
                window,
                QStringLiteral("实验已保存：%1").arg(experimentId.value));
        } else {
            presentOperationalFeedback(window, QStringLiteral("当前实验未启用文件保存。"), true);
        }
    };
    const auto chooseDataRoot = [this, window]() {
        if (!authorize(tdlas::system::ProtectedOperation::SaveExperiment, window)) return;
        const QString selected = QFileDialog::getExistingDirectory(window, QStringLiteral("选择数据保存位置"),
            selectedDataRoot_.isEmpty() ? QStandardPaths::writableLocation(QStandardPaths::DocumentsLocation) : selectedDataRoot_);
        if (selected.isEmpty()) return;
        selectedDataRoot_ = QDir(selected).absolutePath();
        cameraService_.setStorageRoot(selectedDataRoot_);
        for (const QString &folder : {QStringLiteral("CSV数据保存"), QStringLiteral("算法处理数据"), QStringLiteral("拍照摄像"), QStringLiteral("TXT")}) {
            if (!QDir().mkpath(QDir(selectedDataRoot_).filePath(folder))) {
                presentOperationalFeedback(window, QStringLiteral("无法创建数据目录：%1").arg(folder), true); return;
            }
        }
        storageConfiguration_.rootDirectory = selectedDataRoot_;
        cameraService_.setStorageRoot(selectedDataRoot_);
        lastTxtSequence_ = 0;
        presentOperationalFeedback(window, QStringLiteral("数据目录已创建：%1").arg(selectedDataRoot_));
    };
    connect(&measurementService_, &tdlas::application::MeasurementApplicationService::displayModelChanged,
        this, [this](const tdlas::contracts::MeasurementDisplayModel &model) {
            if (selectedDataRoot_.isEmpty() || model.sequence == 0 || !model.peakAbsorbance.has_value()) return;
            if (model.runId.value == lastTxtRunId_ && model.sequence <= lastTxtSequence_) return;
            const QString directory = QDir(selectedDataRoot_).filePath(QStringLiteral("TXT"));
            if (!QDir().mkpath(directory)) return;
            QFile file(QDir(directory).filePath(QStringLiteral("算法处理数据.txt")));
            if (!file.open(QIODevice::WriteOnly | QIODevice::Append | QIODevice::Text)) {
                qWarning().noquote() << "Unable to append processed measurement TXT:" << file.errorString();
                return;
            }
            QTextStream out(&file);
            if (file.size() == 0) out << QStringLiteral("时间戳,峰值吸光度,光强百分比,氢气浓度\n");
            const QDateTime timestamp = model.lastUpdatedUtc.isValid()
                ? model.lastUpdatedUtc.toLocalTime() : QDateTime::currentDateTime();
            out << '[' << timestamp.toString(Qt::ISODateWithMs) << ','
                << QString::number(*model.peakAbsorbance, 'g', 16) << ','
                << (model.lightPercent.has_value() ? QString::number(*model.lightPercent, 'g', 16) : QString()) << ','
                << (model.concentration.has_value() ? QString::number(*model.concentration, 'g', 16) : QString())
                << "]\n";
            file.flush();
            lastTxtRunId_ = model.runId.value;
            lastTxtSequence_ = model.sequence;
        });
    connect(&measurementService_, &tdlas::application::MeasurementApplicationService::displayModelChanged,
        this, [this](const tdlas::contracts::MeasurementDisplayModel &model) {
            if (!peakStreamFile_ || !peakStreamFile_->isOpen() || model.sequence == 0
                || model.sequence <= lastPeakCsvSequence_ || !model.peakAbsorbance.has_value()) return;
            QTextStream out(peakStreamFile_);
            const QDateTime timestamp = model.lastUpdatedUtc.isValid()
                ? model.lastUpdatedUtc.toLocalTime() : QDateTime::currentDateTime();
            out << timestamp.toString(Qt::ISODateWithMs) << ','
                << QString::number(*model.peakAbsorbance, 'g', 16) << ','
                << (model.lightPercent.has_value() ? QString::number(*model.lightPercent, 'g', 16) : QString()) << ','
                << (model.concentration.has_value() ? QString::number(*model.concentration, 'g', 16) : QString()) << "\n";
            peakStreamFile_->flush();
            lastPeakCsvSequence_ = model.sequence;
        });
    connect(window, &QObject::destroyed, this, [this]() {
        if (measurementService_.state() == tdlas::contracts::MeasurementState::Preparing
            || measurementService_.state() == tdlas::contracts::MeasurementState::Running
            || measurementService_.state() == tdlas::contracts::MeasurementState::Stopping) {
            (void)measurementService_.stop(measurementService_.currentRunId());
        }
    });

    if (auto *adminWindow = qobject_cast<adminui::AdminTemplateWindow *>(window)) {
        connect(adminWindow, &adminui::AdminTemplateWindow::startMeasurementRequested,
            adminWindow, startMeasurement);
        connect(adminWindow, &adminui::AdminTemplateWindow::stopMeasurementRequested,
            adminWindow, stopMeasurement);
        connect(adminWindow, &adminui::AdminTemplateWindow::resetMeasurementRequested,
            adminWindow, resetMeasurement);
        connect(adminWindow, &adminui::AdminTemplateWindow::saveExperimentRequested,
            adminWindow, presentSaveState);
        connect(adminWindow, &adminui::AdminTemplateWindow::dataSaveLocationRequested,
            adminWindow, chooseDataRoot);
        connect(adminWindow, &adminui::AdminTemplateWindow::peakCsvExportRequested,
            this, [this, adminWindow](const QString &path, const QVector<tdlas::contracts::PeakRecord> &records) {
                if (!authorize(tdlas::system::ProtectedOperation::SaveExperiment, adminWindow)) {
                    adminWindow->presentPeakExportFeedback(QStringLiteral("没有导出峰值记录的权限。"), true);
                    return;
                }
                if (peakExportThread_) {
                    adminWindow->presentPeakExportFeedback(QStringLiteral("上一次 CSV 导出仍在写入。"), true);
                    return;
                }
                adminWindow->setPeakExportBusy(true);
                auto result = std::make_shared<tdlas::storage::StorageOperationResult>();
                auto *worker = QThread::create([records, path, result]() {
                    *result = tdlas::storage::exportPeakRecordsCsv(records, path);
                });
                worker->setObjectName(QStringLiteral("tdlas-peak-csv-worker"));
                worker->setParent(this);
                peakExportThread_ = worker;
                const QPointer<adminui::AdminTemplateWindow> guard(adminWindow);
                connect(worker, &QThread::finished, this, [this, guard, result, count = records.size()]() {
                    peakExportThread_ = nullptr;
                    if (guard) {
                        guard->presentPeakExportFeedback(result->success
                            ? QStringLiteral("CSV 已写入完成，共 %1 条源记录：%2").arg(count).arg(result->path)
                            : QStringLiteral("CSV 导出失败：%1 %2").arg(result->userMessage, result->diagnostic), !result->success);
                    }
                    recordAudit(QStringLiteral("peak-records"), QStringLiteral("export-csv"),
                        result->success ? QStringLiteral("allowed") : QStringLiteral("failed"),
                        result->success ? result->path : result->code + QStringLiteral(": ") + result->diagnostic);
                });
                connect(worker, &QThread::finished, worker, &QObject::deleteLater);
                worker->start();
            });
        connect(adminWindow, &adminui::AdminTemplateWindow::peakCsvExportToggleRequested,
            this, [this, adminWindow](const QVector<tdlas::contracts::PeakRecord> &) {
                if (!authorize(tdlas::system::ProtectedOperation::SaveExperiment, adminWindow)) return;
                if (peakStreamFile_) {
                    peakStreamFile_->flush();
                    peakStreamFile_->close();
                    delete peakStreamFile_;
                    peakStreamFile_ = nullptr;
                    adminWindow->setPeakExportStreaming(false);
                    adminWindow->presentPeakExportFeedback(QStringLiteral("CSV 连续保存已停止。"), false);
                    recordAudit(QStringLiteral("peak-records"), QStringLiteral("stop-stream-csv"), QStringLiteral("allowed"));
                    return;
                }
                if (selectedDataRoot_.isEmpty()) {
                    adminWindow->presentPeakExportFeedback(QStringLiteral("请先点击侧边栏“数据保存”选择保存目录。"), true);
                    return;
                }
                const QString directory = QDir(selectedDataRoot_).filePath(QStringLiteral("CSV数据保存"));
                if (!QDir().mkpath(directory)) {
                    adminWindow->presentPeakExportFeedback(QStringLiteral("无法创建 CSV 保存目录。"), true);
                    return;
                }
                const QString path = QDir(directory).filePath(QStringLiteral("峰值数据-%1.csv")
                    .arg(QDateTime::currentDateTime().toString(QStringLiteral("yyyyMMdd-HHmmss-zzz"))));
                auto *file = new QFile(path, this);
                if (!file->open(QIODevice::WriteOnly | QIODevice::Text | QIODevice::Append)) {
                    adminWindow->presentPeakExportFeedback(QStringLiteral("CSV 打开失败：%1").arg(file->errorString()), true);
                    delete file;
                    return;
                }
                QTextStream out(file);
                out << QStringLiteral("时间戳,峰值吸光度,光强百分比,氢气浓度\n");
                file->flush();
                peakStreamFile_ = file;
                lastPeakCsvSequence_ = 0;
                adminWindow->setPeakExportStreaming(true);
                adminWindow->presentPeakExportFeedback(QStringLiteral("CSV 连续保存已开始：%1").arg(path), false);
                recordAudit(QStringLiteral("peak-records"), QStringLiteral("start-stream-csv"), QStringLiteral("allowed"), path);
            });
        connect(adminWindow, &adminui::AdminTemplateWindow::parameterDraftSubmitted,
            this, [this, adminWindow](const tdlas::contracts::ParameterDraft &draft) {
                commitParameterDraft(draft, adminWindow);
            });
        connect(adminWindow, &adminui::AdminTemplateWindow::restoreDefaultParametersRequested,
            this, [this, adminWindow]() {
                const tdlas::contracts::ParameterDraft draft = tdlas::contracts::ParameterDraft::mockDefaults();
                commitParameterDraft(draft, adminWindow);
                if (measurementService_.state() == tdlas::contracts::MeasurementState::Idle) {
                    presentParameterDraft(draft, adminWindow);
                }
            });
        connect(adminWindow, &adminui::AdminTemplateWindow::refreshDevicesRequested,
            this, [this, adminWindow]() { refreshDevices(adminWindow); });
        connect(adminWindow, &adminui::AdminTemplateWindow::saveCurrentParametersRequested,
            this, [this, adminWindow]() {
                commitParameterDraft(adminWindow->measurementParameterDraft(), adminWindow);
            });
        connect(&measurementService_, &tdlas::application::MeasurementApplicationService::displayModelChanged,
            adminWindow, &adminui::AdminTemplateWindow::presentMeasurementDisplay);
        adminWindow->presentMeasurementDisplay(measurementService_.displayModel());
        adminWindow->presentParameterDraft(currentParameterDraft_);
        refreshDevices(adminWindow);
        return;
    }

    if (auto *clientWindow = qobject_cast<clientui::ClientTemplateWindow *>(window)) {
        connect(clientWindow, &clientui::ClientTemplateWindow::startMeasurementRequested,
            clientWindow, startMeasurement);
        connect(clientWindow, &clientui::ClientTemplateWindow::stopMeasurementRequested,
            clientWindow, stopMeasurement);
        connect(clientWindow, &clientui::ClientTemplateWindow::resetMeasurementRequested,
            clientWindow, resetMeasurement);
        connect(clientWindow, &clientui::ClientTemplateWindow::saveExperimentRequested,
            clientWindow, presentSaveState);
        connect(clientWindow, &clientui::ClientTemplateWindow::dataSaveLocationRequested,
            clientWindow, chooseDataRoot);
        connect(clientWindow, &clientui::ClientTemplateWindow::parameterDraftSubmitted,
            this, [this, clientWindow](const tdlas::contracts::ParameterDraft &draft) {
                commitParameterDraft(draft, clientWindow);
            });
        connect(clientWindow, &clientui::ClientTemplateWindow::refreshDevicesRequested,
            this, [this, clientWindow]() { refreshDevices(clientWindow); });
        connect(clientWindow, &clientui::ClientTemplateWindow::saveCurrentParametersRequested,
            this, [this, clientWindow]() {
                commitParameterDraft(clientWindow->measurementParameterDraft(), clientWindow);
            });
        connect(&measurementService_, &tdlas::application::MeasurementApplicationService::displayModelChanged,
            clientWindow, &clientui::ClientTemplateWindow::presentMeasurementDisplay);
        clientWindow->presentMeasurementDisplay(measurementService_.displayModel());
        clientWindow->presentParameterDraft(currentParameterDraft_);
        refreshDevices(clientWindow);
    }
}

void IntegratedApplicationController::commitParameterDraft(
    const tdlas::contracts::ParameterDraft &draft,
    QWidget *window)
{
    if (!authorize(tdlas::system::ProtectedOperation::ModifyParameters, window)) {
        return;
    }
    if (measurementService_.state() != tdlas::contracts::MeasurementState::Idle) {
        const QString message = QStringLiteral("采集运行期间不能修改参数。");
        if (auto *adminWindow = qobject_cast<adminui::AdminTemplateWindow *>(window)) {
            adminWindow->presentParameterFeedback(message, true);
        } else if (auto *clientWindow = qobject_cast<clientui::ClientTemplateWindow *>(window)) {
            clientWindow->presentParameterFeedback(message, true);
        }
        return;
    }

    const tdlas::contracts::ParameterValidationResult validation = parameterService_.validate(draft);
    tdlas::contracts::ParameterCommitResult result;
    bool success = false;
    QString message;
    QString persistenceDiagnostic;
    if (!validation.isValid()) {
        message = validation.errors.constFirst().message;
    } else if (!saveParameterDraft(draft, &persistenceDiagnostic)) {
        message = QStringLiteral("参数校验通过，但配置文件保存失败。");
    } else {
        result = parameterService_.commit(draft);
        success = result.isSuccess();
        if (success) {
            currentParameterDraft_ = draft;
            message = QStringLiteral("参数已保存并生成快照 r%1。").arg(result.snapshot->revision);
        } else {
            message = result.validation.errors.constFirst().message;
        }
    }
    if (auto *adminWindow = qobject_cast<adminui::AdminTemplateWindow *>(window)) {
        adminWindow->presentParameterFeedback(message, !success);
    } else if (auto *clientWindow = qobject_cast<clientui::ClientTemplateWindow *>(window)) {
        clientWindow->presentParameterFeedback(message, !success);
    }
    recordAudit(
        QStringLiteral("configuration"),
        QStringLiteral("commit-parameters"),
        success ? QStringLiteral("allowed") : QStringLiteral("rejected"),
        success
            ? result.snapshot->id
            : (!persistenceDiagnostic.isEmpty()
                    ? persistenceDiagnostic
                    : validation.errors.value(0).code));
}

void IntegratedApplicationController::refreshDevices(QWidget *window)
{
    cameraService_.refreshDevices();
    if (deviceDiscoveryThread_ && deviceDiscoveryThread_->isRunning()) {
        presentOperationalFeedback(window, QStringLiteral("设备识别正在刷新，请稍候。"));
        return;
    }

    presentOperationalFeedback(window, QStringLiteral("正在刷新 NI 采集卡与摄像设备…"));
    const QPointer<QWidget> targetWindow(window);
    QThread *thread = QThread::create([this, targetWindow]() {
        const tdlas::acquisition::AcquisitionDiscoveryResult result =
            tdlas::acquisition::NidaqmxDeviceDiscovery::discover();
        QMetaObject::invokeMethod(this, [this, targetWindow, result]() {
            if (targetWindow) {
                applyDiscoveredDevices(result, targetWindow);
            }
        }, Qt::QueuedConnection);
    });
    deviceDiscoveryThread_ = thread;
    connect(thread, &QThread::finished, this, [this, thread]() {
        if (deviceDiscoveryThread_ == thread) {
            deviceDiscoveryThread_.clear();
        }
        thread->deleteLater();
    });
    thread->start();
}

void IntegratedApplicationController::applyDiscoveredDevices(
    const tdlas::acquisition::AcquisitionDiscoveryResult &result,
    QWidget *window)
{
    QVector<tdlas::acquisition::AcquisitionDeviceDescriptor> devices = result.devices;
    if (acquisitionDevice_.policy() == tdlas::acquisition::AcquisitionBackendPolicy::MockOnly) {
        devices.clear();
    }
    if (acquisitionDevice_.policy() != tdlas::acquisition::AcquisitionBackendPolicy::NidaqmxOnly) {
        devices.push_back(mockAcquisitionDescriptor());
    }

    const bool realDeviceAvailable = !result.devices.isEmpty();
    const bool currentIsMock = tdlas::acquisition::HybridAcquisitionDevice::isMockDeviceId(
        currentParameterDraft_.deviceId);
    const bool currentRealDeviceAvailable = std::any_of(
        result.devices.cbegin(), result.devices.cend(), [this](const auto &device) {
            return device.id.compare(currentParameterDraft_.deviceId, Qt::CaseInsensitive) == 0;
        });
    if (realDeviceAvailable
        && acquisitionDevice_.policy() != tdlas::acquisition::AcquisitionBackendPolicy::MockOnly
        && (currentIsMock || !currentRealDeviceAvailable)) {
        const auto &preferred = result.devices.constFirst();
        currentParameterDraft_.deviceId = preferred.id;
        currentParameterDraft_.aiChannelIds = {
            preferred.aiPhysicalChannels.value(0, QStringLiteral("%1/ai0").arg(preferred.id))};
        currentParameterDraft_.aoEnabled = false;
        currentParameterDraft_.aoChannelId.clear();
        currentParameterDraft_.outputSampleRateHz = 0.0;
        const tdlas::contracts::ParameterCommitResult commit = parameterService_.commit(currentParameterDraft_);
        if (commit.isSuccess()) {
            QString ignored;
            (void)saveParameterDraft(currentParameterDraft_, &ignored);
        }
    }

    if (auto *adminWindow = qobject_cast<adminui::AdminTemplateWindow *>(window)) {
        adminWindow->presentAcquisitionDevices(devices, result.userMessage);
        adminWindow->presentParameterDraft(currentParameterDraft_);
    } else if (auto *clientWindow = qobject_cast<clientui::ClientTemplateWindow *>(window)) {
        clientWindow->presentAcquisitionDevices(devices, result.userMessage);
        clientWindow->presentParameterDraft(currentParameterDraft_);
    }

    recordAudit(
        QStringLiteral("device-discovery"),
        QStringLiteral("refresh"),
        realDeviceAvailable ? QStringLiteral("allowed") : QStringLiteral("completed-no-device"),
        result.diagnostic);
}

void IntegratedApplicationController::presentParameterDraft(
    const tdlas::contracts::ParameterDraft &draft,
    QWidget *window)
{
    if (auto *adminWindow = qobject_cast<adminui::AdminTemplateWindow *>(window)) {
        adminWindow->presentParameterDraft(draft);
    } else if (auto *clientWindow = qobject_cast<clientui::ClientTemplateWindow *>(window)) {
        clientWindow->presentParameterDraft(draft);
    }
}

bool IntegratedApplicationController::authorize(
    tdlas::system::ProtectedOperation operation,
    QWidget *window)
{
    const tdlas::system::AuthorizationDecision decision = session_
        ? authorizationService_.authorize(*session_, operation)
        : tdlas::system::AuthorizationDecision{
            false, QStringLiteral("SESSION_MISSING"), QStringLiteral("no authenticated session")};
    recordAudit(
        QStringLiteral("authorization"),
        tdlas::system::protectedOperationName(operation),
        decision.allowed ? QStringLiteral("allowed") : QStringLiteral("denied"),
        decision.diagnostic);
    if (!decision.allowed) {
        presentOperationalFeedback(window, QStringLiteral("当前会话无权执行该操作。"), true);
    }
    return decision.allowed;
}

void IntegratedApplicationController::presentOperationalFeedback(
    QWidget *window,
    const QString &message,
    bool isError)
{
    if (auto *adminWindow = qobject_cast<adminui::AdminTemplateWindow *>(window)) {
        adminWindow->presentOperationalFeedback(message, isError);
    } else if (auto *clientWindow = qobject_cast<clientui::ClientTemplateWindow *>(window)) {
        clientWindow->presentOperationalFeedback(message, isError);
    }
}

void IntegratedApplicationController::recordAudit(
    const QString &category,
    const QString &action,
    const QString &outcome,
    const QString &diagnostic)
{
    tdlas::system::AuditEvent event;
    event.timestampUtc = QDateTime::currentDateTimeUtc();
    if (session_) {
        event.principalId = session_->principalId;
        event.sessionId = session_->sessionId;
    }
    event.category = category;
    event.action = action;
    event.outcome = outcome;
    event.experimentId = measurementService_.currentExperimentId().value;
    event.runId = measurementService_.currentRunId().value;
    event.diagnostic = diagnostic;
    const tdlas::system::AuditWriteResult result = auditSink_.record(event);
    if (!result.success) {
        qWarning().noquote() << result.code << result.diagnostic;
    }
}
