#pragma once

#include "StartupTemplateWindow.h"
#include "TemporaryCredentialAuthenticator.h"
#include "acquisition/AcquisitionDeviceDiscovery.h"
#include "acquisition/ThreadedAcquisitionDevice.h"
#include "algorithm/TdlasAlgorithmProcessor.h"
#include "application/MeasurementApplicationService.h"
#include "camera/CameraApplicationService.h"
#include "parameter/ParameterService.h"
#include "storage/FileStorageRepository.h"
#include "system/IAuditSink.h"
#include "system/RoleBasedAuthorizationService.h"

#include <QObject>
#include <QPointer>

#include <optional>

class QApplication;
class QThread;
class QFile;
class QWidget;

class IntegratedApplicationController final : public QObject
{
public:
    explicit IntegratedApplicationController(
        QApplication &application,
        QObject *parent = nullptr);
    ~IntegratedApplicationController() override;

    void start();

    [[nodiscard]] authentication::UserRole currentRole() const;
    [[nodiscard]] StartupTemplateWindow *loginWindow() const;
    [[nodiscard]] QWidget *roleWindow() const;

private:
    void handleLogin(const QString &username, const QString &password);
    void bindMeasurementWorkflow(QWidget *window);
    void bindCameraWorkflow(QWidget *window);
    void commitParameterDraft(
        const tdlas::contracts::ParameterDraft &draft,
        QWidget *window);
    void presentParameterDraft(
        const tdlas::contracts::ParameterDraft &draft,
        QWidget *window);
    void refreshDevices(QWidget *window);
    void applyDiscoveredDevices(
        const tdlas::acquisition::AcquisitionDiscoveryResult &result,
        QWidget *window);
    [[nodiscard]] bool authorize(
        tdlas::system::ProtectedOperation operation,
        QWidget *window);
    void presentOperationalFeedback(QWidget *window, const QString &message, bool isError = false);
    void recordAudit(
        const QString &category,
        const QString &action,
        const QString &outcome,
        const QString &diagnostic = {});

    QApplication &application_;
    authentication::TemporaryCredentialAuthenticator authenticator_;
    tdlas::acquisition::ThreadedAcquisitionDevice acquisitionDevice_;
    tdlas::algorithm::TdlasAlgorithmProcessor tdlasAlgorithmProcessor_;
    tdlas::parameter::ParameterService parameterService_;
    tdlas::storage::StorageConfiguration storageConfiguration_;
    tdlas::storage::FileStorageRepository storageRepository_;
    tdlas::camera::CameraApplicationService cameraService_;
    tdlas::system::RoleBasedAuthorizationService authorizationService_;
    tdlas::system::FileAuditSink auditSink_;
    tdlas::application::MeasurementApplicationService measurementService_;
    std::optional<tdlas::system::SessionContext> session_;
    authentication::UserRole currentRole_ = authentication::UserRole::Invalid;
    QPointer<StartupTemplateWindow> loginWindow_;
    QPointer<QWidget> roleWindow_;
    QPointer<QThread> deviceDiscoveryThread_;
    QPointer<QThread> peakExportThread_;
    tdlas::contracts::ParameterDraft currentParameterDraft_;
    QString selectedDataRoot_;
    tdlas::contracts::Sequence lastTxtSequence_ = 0;
    QString lastTxtRunId_;
    QFile *peakStreamFile_ = nullptr;
    tdlas::contracts::Sequence lastPeakCsvSequence_ = 0;
};
