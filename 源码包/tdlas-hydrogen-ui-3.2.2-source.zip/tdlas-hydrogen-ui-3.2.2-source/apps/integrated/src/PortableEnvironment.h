#pragma once

#include <QDir>
#include <QFileInfo>
#include <QSettings>
#include <cstdlib>

// The marker is shipped only in portable packages. Explicit environment overrides win.
inline void configurePortableEnvironment(const QString &applicationDirectory)
{
    const QDir base(applicationDirectory);
    const QString marker = base.filePath(QStringLiteral("portable-config/runtime.ini"));
    if (!QFileInfo::exists(marker)) {
        return;
    }
    QSettings settings(marker, QSettings::IniFormat);
    const auto setDefault = [](const char *name, const QString &value) {
        if (qEnvironmentVariableIsEmpty(name)) {
#ifdef Q_OS_WIN
            // Qt reads Windows environment variables through the wide CRT API.
            // qputenv with UTF-8 would be interpreted using the Windows code page.
            _wputenv_s(QString::fromLatin1(name).toStdWString().c_str(), value.toStdWString().c_str());
#else
            qputenv(name, value.toUtf8());
#endif
        }
    };
    const QString dataPath = base.absoluteFilePath(settings.value(
        QStringLiteral("paths/dataDirectory"), QStringLiteral("data")).toString());
    const QDir configPath(base.absoluteFilePath(settings.value(
        QStringLiteral("paths/configurationDirectory"), QStringLiteral("config")).toString()));
    setDefault("TDLAS_STORAGE_ROOT", QDir::cleanPath(dataPath));
    setDefault("TDLAS_STORAGE_CONFIG", configPath.filePath(QStringLiteral("storage.json")));
    setDefault("TDLAS_PARAMETER_CONFIG", configPath.filePath(QStringLiteral("measurement-parameters.ini")));
    setDefault("TDLAS_ACQUISITION_BACKEND", settings.value(
        QStringLiteral("backends/acquisition"), QStringLiteral("auto")).toString());
    setDefault("TDLAS_CAMERA_BACKEND", settings.value(
        QStringLiteral("backends/camera"), QStringLiteral("system")).toString());
}
