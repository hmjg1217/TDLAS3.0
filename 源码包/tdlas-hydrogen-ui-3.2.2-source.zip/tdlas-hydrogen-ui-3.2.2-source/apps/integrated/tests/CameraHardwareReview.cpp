// Explicit manual/bench utility: --exercise performs bounded PTZ clicks and restores values.
#include "IntegratedApplicationController.h"
#include "AdminTemplateWindow.h"
#include "ClientTemplateWindow.h"
#include "../../client/src/CameraPreviewWidget.h"
#include "../../admin/src/CameraPreviewWidget.h"
#include "camera/WindowsCameraControls.h"
#include <QApplication>
#include <QMediaDevices>
#include <QCameraDevice>
#include <QComboBox>
#include <QLineEdit>
#include <QPushButton>
#include <QElapsedTimer>
#include <QThread>
#include <QTemporaryDir>
#include <QDir>
#include <QJsonObject>
#include <QJsonArray>
#include <QJsonDocument>
#include <QFile>
#include <cstdio>
#include <functional>

using namespace tdlas::camera;
namespace {
bool waitFor(const std::function<bool()> &condition, int timeout = 10000)
{
    QElapsedTimer timer; timer.start();
    while (!condition() && timer.elapsed() < timeout) {
        QCoreApplication::processEvents(QEventLoop::AllEvents, 10); QThread::msleep(5);
    }
    return condition();
}
struct Restore {
    WindowsCameraControls &backend;
    CameraControlState before;
    bool armed = false;
    bool restore() {
        if (!armed) return true;
        bool passed = true;
        auto current = backend.read();
        for (auto axis : {CameraControlAxis::Pan, CameraControlAxis::Tilt, CameraControlAxis::Zoom}) {
            const auto original = cameraControlRange(before, axis);
            const auto actual = cameraControlRange(current, axis);
            if (!original.writable || original.value == actual.value) continue;
            QString error;
            if (!backend.write(axis, original.value, error)) { passed = false; std::fprintf(stderr,"RESTORE FAILED: %s\n",error.toUtf8().constData()); }
        }
        if (passed) armed = false;
        return passed;
    }
    ~Restore() { restore(); }
};
}

int main(int argc, char **argv)
{
    QApplication app(argc, argv);
    app.setQuitOnLastWindowClosed(false);
    const bool client = app.arguments().contains(QStringLiteral("--client"));
    const bool exercise = app.arguments().contains(QStringLiteral("--exercise"));
    const QString output = qEnvironmentVariable("TDLAS_CAMERA_QA_OUTPUT");
    QDir().mkpath(output);
    QCameraDevice selected;
    for (const auto &device : QMediaDevices::videoInputs()) {
        std::printf("CAMERA %s ID=%s\n", device.description().toUtf8().constData(), device.id().constData());
        if (device.description() == QStringLiteral("4K ZOOM CAMERA")
            && device.id().toLower().contains("vid_1bcf&pid_2cd1")) selected = device;
    }
    if (selected.isNull()) return 1;
    WindowsCameraControls backend;
    if (!backend.open(selected.id())) { std::fprintf(stderr,"OPEN: %s\n",backend.read().message.toUtf8().constData()); return 2; }
    Restore guard{backend, backend.read(), false};
    if (!guard.before.pan.writable || !guard.before.tilt.writable || !guard.before.zoom.writable) return 3;
    const auto summarize = [](const CameraControlState &state) {
        return QJsonObject{{QStringLiteral("pan"),state.pan.value},{QStringLiteral("tilt"),state.tilt.value},
            {QStringLiteral("zoom"),state.zoom.value}};
    };
    QJsonObject report{{QStringLiteral("camera"),selected.description()},{QStringLiteral("initial"),summarize(guard.before)},
        {QStringLiteral("exercise"),exercise}};
    if (!exercise) {
        std::printf("Read-only probe passed; --exercise is required to send controls.\n"); return 0;
    }
    guard.armed = true;
    QTemporaryDir temporary;
    qputenv("TDLAS_ACQUISITION_BACKEND","mock");
    qputenv("TDLAS_CAMERA_BACKEND","system");
    qputenv("TDLAS_CAMERA_DEVICE_ID", selected.id().toHex());
    qputenv("TDLAS_STORAGE_ROOT", temporary.filePath(QStringLiteral("data")).toUtf8());
    qputenv("TDLAS_STORAGE_CONFIG", temporary.filePath(QStringLiteral("storage.json")).toUtf8());
    qputenv("TDLAS_PARAMETER_CONFIG", temporary.filePath(QStringLiteral("parameters.ini")).toUtf8());
    bool passed = true;
    QJsonArray events;
    {
        IntegratedApplicationController controller(app);
        controller.start();
        auto *login = controller.loginWindow();
        login->findChild<QLineEdit *>(QStringLiteral("usernameEdit"))->setText(client ? QStringLiteral("01") : QStringLiteral("00"));
        login->findChild<QLineEdit *>(QStringLiteral("passwordEdit"))->setText(client ? QStringLiteral("01") : QStringLiteral("00"));
        login->findChild<QPushButton *>(QStringLiteral("loginButton"))->click();
        QWidget *window = controller.roleWindow();
        auto *adminWindow = qobject_cast<adminui::AdminTemplateWindow *>(window);
        auto *clientWindow = qobject_cast<clientui::ClientTemplateWindow *>(window);
        if (!adminWindow && !clientWindow) return 4;
        if (adminWindow) adminWindow->setScreen(adminui::AdminTemplateWindow::Screen::CameraMotion);
        if (clientWindow) clientWindow->setScreen(clientui::ClientTemplateWindow::Screen::CameraMotion);
        const auto controls = [&]() { return adminWindow ? adminWindow->cameraControls() : clientWindow->cameraControls(); };
        const auto capture = [&](const QString &path) { return adminWindow ? adminWindow->saveCapture(path) : clientWindow->saveCapture(path); };
        const auto ready = [&]() { return controls().pan.writable
            && window->findChild<QPushButton *>(QStringLiteral("cameraRotate90Button"))->isEnabled(); };
        if (!waitFor(ready, 15000)) { std::fprintf(stderr,"LIVE PREVIEW FAILED: %s\n",controls().message.toUtf8().constData()); return 5; }
        passed = capture(QDir(output).filePath(QStringLiteral("real-before.png")));
        const auto clickAndVerify = [&](const char *name, CameraControlAxis axis, int expected) {
            auto *button = window->findChild<QPushButton *>(QString::fromLatin1(name));
            if (!button || !button->isEnabled()) return false;
            button->click();
            const bool updated = waitFor([&]() { auto current = controls();
                return cameraControlRange(current,axis).value == expected; }, 4000);
            auto native = backend.read();
            bool correct = updated && cameraControlRange(native,axis).value == expected;
            for (auto *preview : window->findChildren<adminui::CameraPreviewWidget *>())
                correct = correct && preview->viewState().zoom == 1 && preview->viewState().offset.isNull();
            for (auto *preview : window->findChildren<clientui::CameraPreviewWidget *>())
                correct = correct && preview->viewState().zoom == 1 && preview->viewState().offset.isNull();
            events.push_back(QJsonObject{{QStringLiteral("button"),QString::fromLatin1(name)},
                {QStringLiteral("expected"),expected},{QStringLiteral("readback"),summarize(native)},{QStringLiteral("passed"),correct}});
            std::printf("NATIVE_BUTTON %s expected=%d result=%s\n",name,expected,correct?"PASS":"FAIL");
            if (correct) capture(QDir(output).filePath(QString::fromLatin1(name)+QStringLiteral(".png")));
            return correct;
        };
        for (auto axis : {CameraControlAxis::Pan,CameraControlAxis::Tilt,CameraControlAxis::Zoom}) {
            auto original = cameraControlRange(guard.before,axis);
            const bool increase = original.value < original.maximum;
            const char *positive = axis == CameraControlAxis::Pan ? "cameraMoveRightButton"
                : axis == CameraControlAxis::Tilt ? "cameraMoveUpButton" : "cameraZoomInButton";
            const char *negative = axis == CameraControlAxis::Pan ? "cameraMoveLeftButton"
                : axis == CameraControlAxis::Tilt ? "cameraMoveDownButton" : "cameraZoomOutButton";
            if (!clickAndVerify(increase?positive:negative,axis,original.value+(increase?original.step:-original.step))) { passed=false; break; }
            if (!clickAndVerify(increase?negative:positive,axis,original.value)) { passed=false; break; }
        }
        if (passed) {
            window->findChild<QPushButton *>(QStringLiteral("cameraRotate90Button"))->click();
            app.processEvents();
            passed = capture(QDir(output).filePath(QStringLiteral("real-software-rotation-90.png")));
            auto native = backend.read();
            passed = passed && summarize(native) == summarize(guard.before);
        }
    }
    const bool restored = guard.restore();
    report.insert(QStringLiteral("role"),client ? QStringLiteral("client") : QStringLiteral("admin"));
    report.insert(QStringLiteral("events"),events);
    report.insert(QStringLiteral("restored"),restored);
    report.insert(QStringLiteral("final"),summarize(backend.read()));
    report.insert(QStringLiteral("passed"),passed && restored);
    report.insert(QStringLiteral("humanVisualAcceptance"),QStringLiteral("pending user review"));
    QFile file(QDir(output).filePath(QStringLiteral("real-control-verification.json")));
    if (file.open(QIODevice::WriteOnly)) file.write(QJsonDocument(report).toJson());
    return passed && restored ? 0 : 6;
}
