#include "AdminTemplateWindow.h"
#include "ClientTemplateWindow.h"
#include "IntegratedApplicationController.h"
#include "../../admin/src/CameraPreviewWidget.h"
#include "../../client/src/CameraPreviewWidget.h"
#include "camera/CameraApplicationService.h"
#include "camera/MockCameraDevice.h"

#include <QApplication>
#include <QDir>
#include <QElapsedTimer>
#include <QFile>
#include <QImageReader>
#include <QLineEdit>
#include <QLineF>
#include <QMouseEvent>
#include <QPainter>
#include <QPushButton>
#include <QScreen>
#include <QTemporaryDir>
#include <QThread>
#include <QTimer>

#include <cmath>
#include <cstdio>
#include <functional>
#include <limits>

using namespace tdlas::camera;

namespace {
bool check(bool passed, const char *message)
{
    if (!passed) std::fprintf(stderr, "CAMERA_VIEW FAIL: %s\n", message);
    return passed;
}

bool waitFor(const std::function<bool()> &condition, int timeout = 3000)
{
    QElapsedTimer timer;
    timer.start();
    while (!condition() && timer.elapsed() < timeout) {
        QCoreApplication::processEvents(QEventLoop::AllEvents, 10);
        QThread::msleep(1);
    }
    return condition();
}

bool sameView(const CameraViewState &a, const CameraViewState &b)
{
    return std::abs(a.zoom - b.zoom) < 1e-9 && a.quarterTurns == b.quarterTurns
        && QLineF(a.offset, b.offset).length() < 1e-9;
}

bool verifyGeometry()
{
    CameraViewState state;
    state = applyCameraViewOperation(state, CameraViewOperation::RotateClockwise);
    state = applyCameraViewOperation(state, CameraViewOperation::MoveRight);
    const QRectF viewport(10, 20, 800, 400);
    const auto transform = cameraImageTransform(state, QSizeF(400, 200), viewport);
    if (!check(QLineF(transform.map(QPointF(200, 100)), viewport.center() + QPointF(40, 0)).length() < 1e-9,
            "movement must stay in screen coordinates after rotation")) return false;
    const auto top = transform.map(QPointF(200, 0));
    if (!check(top.x() > viewport.center().x() && std::abs(top.y() - viewport.center().y()) < 1e-9,
            "clockwise rotation must move the top to the right")) return false;
    const auto beforeZoom = transform.map(QPointF(120, 80));
    state = applyCameraViewOperation(state, CameraViewOperation::ZoomIn);
    const auto afterZoom = cameraImageTransform(state, QSizeF(400, 200), viewport).map(QPointF(120, 80));
    if (!check(QLineF(afterZoom, viewport.center() + (beforeZoom - viewport.center()) * 1.2).length() < 1e-9,
            "zoom anchor must be viewport centre")) return false;
    for (int i = 0; i < 1000; ++i) {
        state = applyCameraViewOperation(state, CameraViewOperation::ZoomIn);
        state = applyCameraViewOperation(state, CameraViewOperation::MoveDown);
    }
    if (!check(state.zoom == 8.0 && state.offset.y() == 0.45, "upper limits")) return false;
    for (int i = 0; i < 1000; ++i) state = applyCameraViewOperation(state, CameraViewOperation::ZoomOut);
    if (!check(state.zoom == 0.25, "lower zoom limit")) return false;
    for (const QSizeF size : {QSizeF(320, 900), QSizeF(1600, 400), QSizeF(400, 400)}) {
        const QRectF area(QPointF(0, 0), size);
        const QRectF image = cameraImageTransform(state, QSizeF(400, 200), area).mapRect(QRectF(0, 0, 400, 200));
        if (!check(image.intersects(area), "image must remain visible after resizing at limits")) return false;
    }
    state.zoom = std::numeric_limits<double>::quiet_NaN();
    state.offset = QPointF(std::numeric_limits<double>::infinity(), -1e300);
    state.quarterTurns = -9;
    state = normalizedCameraView(state);
    return check(state.zoom == 1 && state.offset == QPointF(0, -0.45) && state.quarterTurns == 3,
        "invalid numeric state must be normalized");
}

QImage markedImage()
{
    QImage image(400, 400, QImage::Format_RGB32);
    QPainter painter(&image);
    painter.fillRect(0, 0, 200, 200, Qt::red);
    painter.fillRect(200, 0, 200, 200, Qt::green);
    painter.fillRect(0, 200, 200, 200, Qt::blue);
    painter.fillRect(200, 200, 200, 200, Qt::yellow);
    painter.setPen(Qt::white);
    for (int i = 40; i < 400; i += 40) {
        painter.drawLine(i, 0, i, 399);
        painter.drawLine(0, i, 399, i);
    }
    painter.drawText(20, 25, QStringLiteral("TOP LEFT"));
    painter.drawText(220, 25, QStringLiteral("TOP RIGHT"));
    painter.drawText(20, 325, QStringLiteral("BOTTOM LEFT"));
    painter.drawText(220, 325, QStringLiteral("BOTTOM RIGHT"));
    return image;
}

template<typename Preview>
bool verifyPixels(const QString &output, const QString &role)
{
    Preview preview;
    preview.resize(402, 402);
    preview.setFrame(markedImage(), QStringLiteral("模拟方向测试"), QStringLiteral("400 × 400"));
    const auto original = preview.grab().toImage();
    CameraViewState state;
    state.quarterTurns = 1;
    preview.setViewState(state);
    const auto rotated = preview.grab().toImage();
    const qreal dpr = rotated.devicePixelRatio();
    const auto colorAt = [&](int x, int y) { return rotated.pixelColor(qRound(x * dpr), qRound(y * dpr)); };
    if (!check(colorAt(101, 101) == QColor(Qt::blue) && colorAt(301, 101) == QColor(Qt::red)
            && colorAt(101, 271) == QColor(Qt::yellow) && colorAt(301, 271) == QColor(Qt::green),
            "rendered pixels must rotate clockwise in both preview classes")) return false;
    int fixedTextPixels = 0;
    for (int y = qRound(365 * dpr); y < original.height(); ++y) {
        for (int x = 0; x < original.width(); ++x) {
            if (original.pixelColor(x, y) == QColor(Qt::white)) {
                ++fixedTextPixels;
                if (!check(rotated.pixelColor(x, y) == QColor(Qt::white), "overlay text must stay upright")) return false;
            }
        }
    }
    if (!check(fixedTextPixels > 20, "overlay text pixel evidence")) return false;
    if (!output.isEmpty()) {
        if (!original.save(QDir(output).filePath(role + QStringLiteral("-direction-before.png")))
            || !rotated.save(QDir(output).filePath(role + QStringLiteral("-direction-90.png")))) return false;
    }
    for (int i = 0; i < 3; ++i) state = applyCameraViewOperation(state, CameraViewOperation::RotateClockwise);
    preview.setViewState(state);
    return check(preview.grab().toImage() == original, "four rotations must restore exact preview pixels");
}

template<typename Window, typename Preview>
bool verifyRole(QApplication &app, const QString &account, const QString &output, const QString &role)
{
    IntegratedApplicationController controller(app);
    controller.start();
    if (!output.isEmpty() && role == QStringLiteral("admin"))
        if (!controller.loginWindow()->saveCapture(QDir(output).filePath(QStringLiteral("integrated-login.png")))) return false;
    auto *login = controller.loginWindow();
    login->findChild<QLineEdit *>(QStringLiteral("usernameEdit"))->setText(account);
    login->findChild<QLineEdit *>(QStringLiteral("passwordEdit"))->setText(account);
    login->findChild<QPushButton *>(QStringLiteral("loginButton"))->click();
    auto *window = qobject_cast<Window *>(controller.roleWindow());
    if (!check(window != nullptr, "role login")) return false;
    window->setScreen(Window::Screen::CameraMotion);
    auto *rotate = window->template findChild<QPushButton *>(QStringLiteral("cameraRotate90Button"));
    auto *reset = window->template findChild<QPushButton *>(QStringLiteral("cameraResetViewButton"));
    if (!check(rotate && reset && waitFor([&]() { return rotate->isEnabled(); }), "controls ready after first valid frame")) return false;
    const auto previews = window->template findChildren<Preview *>();
    if (!check(previews.size() == 2, "main and camera previews must both exist")) return false;
    const auto synced = [&](const CameraViewState &expected) {
        for (auto *preview : previews) if (!sameView(preview->viewState(), expected)) return false;
        return true;
    };
    if (!check(waitFor([&]() { return window->cameraControls().pan.writable; }), "mock device controls ready")) return false;
    CameraViewState expected;
    int expectedPan = 0, expectedTilt = 0, expectedZoom = 0;
    const std::pair<const char *, CameraViewOperation> operations[] = {
        {"cameraMoveUpButton", CameraViewOperation::MoveUp},
        {"cameraMoveDownButton", CameraViewOperation::MoveDown},
        {"cameraMoveLeftButton", CameraViewOperation::MoveLeft},
        {"cameraMoveRightButton", CameraViewOperation::MoveRight},
        {"cameraZoomInButton", CameraViewOperation::ZoomIn},
        {"cameraZoomOutButton", CameraViewOperation::ZoomOut},
        {"cameraRotate90Button", CameraViewOperation::RotateClockwise}};
    for (const auto &entry : operations) {
        auto *button = window->template findChild<QPushButton *>(QString::fromLatin1(entry.first));
        if (!check(button && !button->accessibleName().isEmpty(), "button accessibility and identity")) return false;
        button->click();
        switch (entry.second) {
        case CameraViewOperation::MoveUp: ++expectedTilt; break;
        case CameraViewOperation::MoveDown: --expectedTilt; break;
        case CameraViewOperation::MoveLeft: --expectedPan; break;
        case CameraViewOperation::MoveRight: ++expectedPan; break;
        case CameraViewOperation::ZoomIn: ++expectedZoom; break;
        case CameraViewOperation::ZoomOut: --expectedZoom; break;
        case CameraViewOperation::RotateClockwise: expected.quarterTurns = 1; break;
        default: break;
        }
        if (!check(waitFor([&]() { const auto &c = window->cameraControls();
                return c.pan.value == expectedPan && c.tilt.value == expectedTilt && c.zoom.value == expectedZoom;
            }) && synced(expected), "buttons must change device state and leave software pan/zoom unchanged")) return false;
    }
    for (int i = 0; i < 3; ++i) rotate->click();
    expected.quarterTurns = 0;
    if (!check(synced(expected), "four real rotation clicks")) return false;
    rotate->click();
    expected.quarterTurns = 1;
    const auto sameAfterFrames = [&]() { return synced(expected); };
    QElapsedTimer timer;
    timer.start();
    waitFor([&]() { return timer.elapsed() >= 180; });
    if (!check(sameAfterFrames(), "new frames must preserve view state")) return false;
    if (!output.isEmpty()) {
        if (!window->saveCapture(QDir(output).filePath(role + QStringLiteral("-camera-motion-90.png")))) return false;
    }
    window->setScreen(Window::Screen::Main);
    app.processEvents();
    if (!check(synced(expected), "page switch preserves view")) return false;
    if (!output.isEmpty() && !window->saveCapture(QDir(output).filePath(role + QStringLiteral("-main.png")))) return false;
    window->setScreen(Window::Screen::CameraMotion);
    app.processEvents();
    reset->click();
    if (!check(synced({}), "reset from real button")) return false;
    auto *zoom = window->template findChild<QPushButton *>(QStringLiteral("cameraZoomInButton"));
    if (!check(zoom->autoRepeat() && !rotate->autoRepeat() && !reset->autoRepeat(), "repeat policy")) return false;
    QMouseEvent press(QEvent::MouseButtonPress, QPointF(zoom->rect().center()), QPointF(zoom->mapToGlobal(zoom->rect().center())),
        Qt::LeftButton, Qt::LeftButton, Qt::NoModifier);
    app.sendEvent(zoom, &press);
    const bool repeated = waitFor([&]() { return window->cameraControls().zoom.value >= 3; }, 1000);
    QMouseEvent release(QEvent::MouseButtonRelease, QPointF(zoom->rect().center()), QPointF(zoom->mapToGlobal(zoom->rect().center())),
        Qt::LeftButton, Qt::NoButton, Qt::NoModifier);
    app.sendEvent(zoom, &release);
    if (!check(repeated, "actual held mouse button must repeat")) return false;
    reset->click();
    if (!check(waitFor([&]() { return window->cameraControls().zoom.value == 0; }), "device PTZ reset")) return false;
    if (!check(synced({}), "hardware buttons must never change software scale")) return false;
    CameraDisplayModel unavailable;
    unavailable.state = CameraSessionState::Faulted;
    window->presentCameraDisplay(unavailable);
    if (!check(!rotate->isEnabled() && !zoom->isEnabled(), "no valid frame disables controls")) return false;
    return true;
}

bool verifyServiceAndOriginalMedia(const QString &root)
{
    class StaticImageCamera final : public ICameraDevice {
    public:
        StaticImageCamera() {
            timer = new QTimer(this);
            QObject::connect(timer, &QTimer::timeout, this, [this]() {
                CameraFrame frame;
                frame.sessionId = session;
                frame.cameraId = QStringLiteral("mock-camera-0");
                frame.sequence = ++sequence;
                frame.timestamp.utc = QDateTime::currentDateTimeUtc();
                frame.pixelFormat = QStringLiteral("RGB32");
                frame.image = markedImage().scaled(160, 90);
                frame.validity = tdlas::contracts::DataValidity::Valid;
                emit frameReady(frame);
            });
        }
        QVector<CameraDeviceDescriptor> enumerateDevices() override {
            CameraDeviceDescriptor device;
            device.id = QStringLiteral("mock-camera-0");
            device.displayName = QStringLiteral("Static simulation");
            device.formats = {CameraFormat{QSize(160, 90), 30, 30, QStringLiteral("RGB32")}};
            return {device};
        }
        CameraDeviceState state() const override { return current; }
        bool connectDevice(const QString &, const CameraFormat &) override {
            current = CameraDeviceState::Connected; return true;
        }
        bool disconnectDevice() override { timer->stop(); current = CameraDeviceState::Disconnected; return true; }
        bool startPreview(const CameraSessionId &id) override {
            session = id; sequence = 0; current = CameraDeviceState::Previewing; timer->start(8); return true;
        }
        bool stopPreview() override { timer->stop(); current = CameraDeviceState::Connected; return true; }
    private:
        QTimer *timer;
        CameraSessionId session;
        quint64 sequence = 0;
        CameraDeviceState current = CameraDeviceState::Disconnected;
    };
    CameraApplicationService service(std::make_unique<StaticImageCamera>(), root);
    service.operateView(CameraViewOperation::RotateClockwise);
    if (!check(sameView(service.viewState(), {}), "service must reject operations without a frame")) return false;
    service.startPreview(QStringLiteral("mock-camera-0"));
    if (!waitFor([&]() { return service.displayModel().latestFrame.has_value(); })) return false;
    const auto imageBefore = service.displayModel().latestFrame->image;
    service.operateView(CameraViewOperation::RotateClockwise);
    service.operateView(CameraViewOperation::ZoomIn);
    service.operateView(CameraViewOperation::MoveLeft);
    if (!check(service.displayModel().latestFrame->image == imageBefore, "view operation must not modify source/display frame pixels")) return false;
    const tdlas::contracts::ExperimentId experiment{QStringLiteral("EXP-20261112T000000000Z-abcd1234")};
    QVector<MediaResult> media;
    QObject::connect(&service, &CameraApplicationService::mediaCompleted, &service,
        [&](const MediaResult &result) { media.push_back(result); });
    service.capturePhoto(experiment);
    if (!waitFor([&]() { return media.size() >= 1; }) || !media.first().success) return false;
    const QImage photo(media.first().path);
    if (!check(photo == imageBefore, "saved PNG must retain exact original pixels and orientation")) return false;
    service.startRecording(experiment);
    if (!waitFor([&]() { return service.displayModel().recordingDurationMilliseconds >= 100; })) return false;
    service.stopRecording();
    if (!waitFor([&]() { return media.size() >= 2; }) || !media.last().success) return false;
    QFile file(media.last().path);
    if (!file.open(QIODevice::ReadOnly)) return false;
    const auto mjpeg = file.readAll();
    const auto end = mjpeg.indexOf(QByteArray::fromHex("ffd9"));
    const auto videoFrame = QImage::fromData(mjpeg.left(end + 2), "JPG");
    if (!check(videoFrame.size() == QSize(160, 90)
            && videoFrame.pixelColor(20, 10).red() > 180
            && videoFrame.pixelColor(140, 10).green() > 180
            && videoFrame.pixelColor(20, 75).blue() > 180,
            "saved MJPEG must retain original landscape dimensions and corner colours")) return false;
    const auto previousSession = service.displayModel().sessionId;
    service.startPreview(QStringLiteral("mock-camera-0"));
    if (!check(sameView(service.viewState(), {}), "device selection resets view immediately")) return false;
    if (!waitFor([&]() { return service.displayModel().sessionId != previousSession
            && service.displayModel().latestFrame.has_value(); })) return false;
    service.stopPreview();
    service.operateView(CameraViewOperation::RotateClockwise);
    if (!check(sameView(service.viewState(), {}), "stop request must block operations before worker acknowledges")) return false;
    if (!waitFor([&]() { return service.displayModel().state == CameraSessionState::Idle; })) return false;
    service.operateView(CameraViewOperation::RotateClockwise);
    if (!check(sameView(service.viewState(), {}), "stopped session rejects view operations")) return false;
    service.shutdown();
    return check(!service.workerThreadRunning() && sameView(service.viewState(), {}), "shutdown releases worker and resets view");
}

bool verifyDisconnect(const QString &root)
{
    MockCameraOptions options;
    options.frameIntervalMilliseconds = 10;
    options.disconnectAfterFrames = 30;
    CameraApplicationService service(std::make_unique<MockCameraDevice>(options), root);
    service.startPreview(QStringLiteral("mock-camera-0"));
    if (!waitFor([&]() { return service.displayModel().latestFrame.has_value(); })) return false;
    service.operateView(CameraViewOperation::RotateClockwise);
    if (!check(service.viewState().quarterTurns == 1, "pre-disconnect operation")) return false;
    if (!waitFor([&]() { return service.displayModel().state == CameraSessionState::Faulted; })) return false;
    service.operateView(CameraViewOperation::ZoomIn);
    return check(sameView(service.viewState(), {}), "disconnect resets view and rejects commands");
}
} // namespace

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
    app.setQuitOnLastWindowClosed(false);
    QTemporaryDir temporary;
    if (!temporary.isValid()) return 10;
    qputenv("TDLAS_STORAGE_ROOT", temporary.filePath(QStringLiteral("data")).toUtf8());
    qputenv("TDLAS_STORAGE_CONFIG", temporary.filePath(QStringLiteral("storage.json")).toUtf8());
    qputenv("TDLAS_PARAMETER_CONFIG", temporary.filePath(QStringLiteral("parameters.ini")).toUtf8());
    qputenv("TDLAS_ACQUISITION_BACKEND", "mock");
    qputenv("TDLAS_CAMERA_BACKEND", "mock");
    const QString output = qEnvironmentVariable("TDLAS_CAMERA_QA_OUTPUT");
    if (!output.isEmpty() && !QDir().mkpath(output)) return 11;
    if (!verifyGeometry()) return 1;
    if (!verifyPixels<adminui::CameraPreviewWidget>(output, QStringLiteral("admin"))) return 2;
    if (!verifyPixels<clientui::CameraPreviewWidget>(output, QStringLiteral("client"))) return 3;
    if (!verifyServiceAndOriginalMedia(temporary.filePath(QStringLiteral("media")))) return 4;
    if (!verifyDisconnect(temporary.filePath(QStringLiteral("disconnect")))) return 7;
    if (!verifyRole<adminui::AdminTemplateWindow, adminui::CameraPreviewWidget>(app, QStringLiteral("00"), output, QStringLiteral("admin"))) return 5;
    app.processEvents();
    if (!verifyRole<clientui::ClientTemplateWindow, clientui::CameraPreviewWidget>(app, QStringLiteral("01"), output, QStringLiteral("client"))) return 6;
    std::printf("CAMERA_VIEW geometry/pixels/buttons/hold/pages/reset/original-media/shutdown PASS\n");
    std::printf("ENV Qt=%s platform=%s dpi=%.1f dpr=%.2f font=%s\n", qVersion(),
        app.platformName().toUtf8().constData(), app.primaryScreen()->logicalDotsPerInch(),
        app.primaryScreen()->devicePixelRatio(), app.font().family().toUtf8().constData());
    return 0;
}
