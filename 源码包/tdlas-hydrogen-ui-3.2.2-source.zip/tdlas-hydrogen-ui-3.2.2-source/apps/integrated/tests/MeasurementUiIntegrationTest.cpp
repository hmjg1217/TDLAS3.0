#include "AdminTemplateWindow.h"
#include "ClientTemplateWindow.h"
#include "IntegratedApplicationController.h"

#include <QApplication>
#include <QElapsedTimer>
#include <QDir>
#include <QDoubleSpinBox>
#include <QDirIterator>
#include <QFileInfo>
#include <QFileDialog>
#include <QTableView>
#include <QFile>
#include <QLabel>
#include <QLineEdit>
#include <QMenu>
#include <QPushButton>
#include <QSpinBox>
#include <QThread>
#include <QTemporaryDir>
#include <QTimer>
#include <QWidget>

#include <functional>
#include <cstdio>
#include <cmath>

namespace {

bool waitFor(const std::function<bool()> &condition, int timeoutMilliseconds = 2000)
{
    QElapsedTimer timer;
    timer.start();
    while (!condition() && timer.elapsed() < timeoutMilliseconds) {
        QCoreApplication::processEvents(QEventLoop::AllEvents, 10);
        QThread::msleep(1);
    }
    return condition();
}

bool login(
    QApplication &application,
    IntegratedApplicationController &controller,
    const QString &username,
    const QString &password)
{
    StartupTemplateWindow *window = controller.loginWindow();
    if (!window) {
        return false;
    }
    auto *usernameEdit = window->findChild<QLineEdit *>(QStringLiteral("usernameEdit"));
    auto *passwordEdit = window->findChild<QLineEdit *>(QStringLiteral("passwordEdit"));
    auto *loginButton = window->findChild<QPushButton *>(QStringLiteral("loginButton"));
    if (!usernameEdit || !passwordEdit || !loginButton) {
        return false;
    }
    usernameEdit->setText(username);
    passwordEdit->setText(password);
    loginButton->click();
    application.processEvents();
    return controller.roleWindow() != nullptr;
}

bool containsFileWithSuffix(const QString &root, const QString &suffix)
{
    QDirIterator iterator(root, QDir::Files, QDirIterator::Subdirectories);
    while (iterator.hasNext()) {
        if (iterator.next().endsWith(suffix, Qt::CaseInsensitive)) {
            return true;
        }
    }
    return false;
}

bool verifyMeasurementFlow(QWidget *window, const QString &storageRoot)
{
    auto *start = window->findChild<QPushButton *>(QStringLiteral("startAcquisitionButton"));
    auto *stop = window->findChild<QPushButton *>(QStringLiteral("stopAcquisitionButton"));
    auto *status = window->findChild<QLabel *>(QStringLiteral("measurementStatusLabel"));
    auto *chart = window->findChild<QWidget *>(QStringLiteral("fvChart"));
    auto *rawChart = window->findChild<QWidget *>(QStringLiteral("rawSignalChart"));
    auto *fitChart = window->findChild<QWidget *>(QStringLiteral("processedVoltageChart"));
    auto *peakChart = window->findChild<QWidget *>(QStringLiteral("peakTrendChart"));
    auto *peak = window->findChild<QLabel *>(QStringLiteral("peakAbsorbanceValue"));
    auto *concentration = window->findChild<QLabel *>(QStringLiteral("concentrationValue"));
    auto *blockSize = window->findChild<QSpinBox *>(QStringLiteral("parameterBlockSize"));
    auto *inputMinimum = window->findChild<QDoubleSpinBox *>(QStringLiteral("parameterInputMinimum"));
    auto *inputMaximum = window->findChild<QDoubleSpinBox *>(QStringLiteral("parameterInputMaximum"));
    auto *saveParameters = window->findChild<QPushButton *>(QStringLiteral("saveParametersButton"));
    auto *saveExperiment = window->findChild<QPushButton *>(QStringLiteral("saveExperimentButton"));
    auto *settings = window->findChild<QPushButton *>(QStringLiteral("settingsButton"));
    auto *notice = window->findChild<QLabel *>(QStringLiteral("templateNotice"));
    auto *cameraPhoto = window->findChild<QPushButton *>(QStringLiteral("cameraPhotoButton"));
    auto *cameraRecord = window->findChild<QPushButton *>(QStringLiteral("cameraRecordButton"));
    auto *cameraStop = window->findChild<QPushButton *>(QStringLiteral("cameraStopButton"));
    auto *cameraStatus = window->findChild<QLabel *>(QStringLiteral("cameraRecordingStatus"));
    if (!start || !stop || !status || !chart || !peak || !concentration || !peakChart
        || !blockSize || !inputMinimum || !inputMaximum || !saveParameters || !saveExperiment || !settings
        || !settings->menu() || settings->menu()->actions().size() != 2 || !notice
        || !cameraPhoto || !cameraRecord || !cameraStop || !cameraStatus
        || blockSize->value() != 256
        || !start->isEnabled() || stop->isEnabled()) {
        std::fprintf(stderr, "M4_UI failed initial widget contract\n");
        return false;
    }
    if (!waitFor([&]() { return cameraPhoto->isEnabled() && cameraRecord->isEnabled(); })) {
        std::fprintf(stderr, "M7_UI camera preview did not become ready\n");
        return false;
    }
    cameraPhoto->click();
    if (!waitFor([&]() { return notice->text().contains(QStringLiteral("请先开始实验")); })) {
        std::fprintf(stderr, "M7_UI accepted unassociated photo\n");
        return false;
    }

    const double validMinimum = inputMinimum->value();
    inputMinimum->setValue(inputMaximum->value());
    saveParameters->click();
    if (!waitFor([&]() { return notice->text().contains(QStringLiteral("校验失败")); })) {
        std::fprintf(stderr, "M4_UI validation failure message timeout: %s\n", notice->text().toUtf8().constData());
        return false;
    }
    inputMinimum->setValue(validMinimum);
    settings->menu()->actions().at(1)->trigger();
    if (!waitFor([&]() { return notice->text().contains(QStringLiteral("生成快照")); })) {
        std::fprintf(stderr, "M4_UI snapshot message timeout: %s\n", notice->text().toUtf8().constData());
        return false;
    }
    if (!QFileInfo(QDir(storageRoot).absoluteFilePath(QStringLiteral("../parameters.ini"))).isFile()) {
        std::fprintf(stderr, "parameter persistence file was not created\n");
        return false;
    }

    QElapsedTimer firstSpectrumTimer;
    firstSpectrumTimer.start();
    start->click();
    if (!waitFor([&]() {
            return chart->property("liveSampleCount").toInt() > 0
                && status->text().contains(QStringLiteral("采集中"));
        })) {
        std::fprintf(
            stderr,
            "M4_UI data timeout count=%d status=%s notice=%s peak=%s\n",
            chart->property("liveSampleCount").toInt(),
            status->text().toUtf8().constData(),
            notice->text().toUtf8().constData(),
            peak->text().toUtf8().constData());
        return false;
    }
    std::printf("DISPLAY_LATENCY role=%s first_spectrum_ms=%lld\n",
        rawChart ? "admin" : "client", static_cast<long long>(firstSpectrumTimer.elapsed()));
    const bool adminSecondaryReady = !qobject_cast<adminui::AdminTemplateWindow *>(window)
        || chart->property("liveSecondarySampleCount").toInt() == 0;
    auto *debugPeak = window->findChild<QLabel *>(QStringLiteral("debugPeakAbsorbanceValue"));
    if (rawChart && (!debugPeak || !debugPeak->text().endsWith(peak->text()))) {
        std::fprintf(stderr, "debug peak does not match the current measurement\n");
        return false;
    }
    const bool axisLabelsReady = chart->property("xLabel").toString().contains(QStringLiteral("cm⁻¹"))
        && chart->property("yLabel").toString().contains(QStringLiteral("吸光度"));
    if (start->isEnabled() || !stop->isEnabled()
        || !peak->text().contains(QStringLiteral("模拟"))
        || !concentration->text().contains(QStringLiteral("未校准"))
        || chart->property("liveSampleCount").toInt() != 155
        || !adminSecondaryReady
        || (qobject_cast<adminui::AdminTemplateWindow *>(window)
            && !fitChart)
        || peakChart->property("liveSampleCount").toInt() <= 0
        || !peakChart->property("xLabel").toString().contains(QStringLiteral("HH:mm:ss"))
        || std::abs(peakChart->property("xMaximum").toDouble() - peakChart->property("xMinimum").toDouble() - 1800.0) > 1.0e-6
        || !axisLabelsReady
        || chart->property("xMinimum").toDouble() >= 0.0
        || chart->property("xMaximum").toDouble() <= 0.0) {
        std::fprintf(
            stderr,
            "M4_UI count=%d secondary=%d xmin=%.17g xmax=%.17g peak=%s concentration=%s status=%s\n",
            chart->property("liveSampleCount").toInt(),
            chart->property("liveSecondarySampleCount").toInt(),
            chart->property("xMinimum").toDouble(),
            chart->property("xMaximum").toDouble(),
            peak->text().toUtf8().constData(),
            concentration->text().toUtf8().constData(),
            status->text().toUtf8().constData());
        return false;
    }

    if (auto *adminWindow = qobject_cast<adminui::AdminTemplateWindow *>(window)) {
        adminWindow->setScreen(adminui::AdminTemplateWindow::Screen::Debug);
        QCoreApplication::processEvents();
        auto *debugTrend = window->findChild<QWidget *>(QStringLiteral("debugPeakTrendChart"));
        if (!debugTrend || debugTrend->property("liveSampleCount").toInt()
                != peakChart->property("liveSampleCount").toInt()) return false;
        if (!rawChart || rawChart->property("liveSampleCount").toInt() != 256
            || !rawChart->property("xLabel").toString().contains(QStringLiteral("时间（s）"))
            || !rawChart->property("yLabel").toString().contains(QStringLiteral("电压（V）"))
            || rawChart->property("xMaximum").toDouble() <= 0.04
            || rawChart->property("xMaximum").toDouble() >= 0.06
            || !fitChart || fitChart->property("liveSampleCount").toInt() != 257
            || fitChart->property("liveSecondarySampleCount").toInt() != 155) {
            std::fprintf(stderr, "debug charts did not show the current acquisition data\n");
            return false;
        }
        adminWindow->setScreen(adminui::AdminTemplateWindow::Screen::Main);
        QCoreApplication::processEvents();
    }

    if (auto *adminWindow = qobject_cast<adminui::AdminTemplateWindow *>(window)) {
        for (int seconds : {3600, 1800}) {
            auto *filter = window->findChild<QPushButton *>(QStringLiteral("peakWindow%1Button").arg(seconds));
            if (!filter) {
                return false;
            }
            filter->click();
            if (std::abs(peakChart->property("xMaximum").toDouble()
                         - peakChart->property("xMinimum").toDouble() - seconds) > 1.0e-6) {
                return false;
            }
        }
    }
    const QString captureRoot = qEnvironmentVariable("TDLAS_QA_CAPTURE_DIR").trimmed();
    const auto captureFvFrame = [&](const QString &suffix) {
        if (captureRoot.isEmpty()) return true;
        if (auto *admin = qobject_cast<adminui::AdminTemplateWindow *>(window)) {
            return admin->saveCapture(QDir(captureRoot).filePath(QStringLiteral("admin-fv-%1.png").arg(suffix)));
        }
        auto *client = qobject_cast<clientui::ClientTemplateWindow *>(window);
        return client && client->saveCapture(QDir(captureRoot).filePath(QStringLiteral("client-fv-%1.png").arg(suffix)));
    };
    if (!captureFvFrame(QStringLiteral("before"))) return false;
    double minimumPeak = chart->property("curvePeak").toDouble();
    double maximumPeak = minimumPeak;
    double previousScale = chart->property("yMaximum").toDouble();
    QElapsedTimer variationTimer;
    variationTimer.start();
    int previousRecords = peakChart->property("liveSampleCount").toInt();
    int batches = 0;
    double previousPeak = minimumPeak;
    while (variationTimer.elapsed() < 1600) {
        QCoreApplication::processEvents(QEventLoop::AllEvents, 10);
        const double current = chart->property("curvePeak").toDouble();
        const int records = peakChart->property("liveSampleCount").toInt();
        if (records == previousRecords && current != previousPeak) return false;
        if (records > previousRecords) ++batches;
        previousRecords = records;
        previousPeak = current;
        minimumPeak = qMin(minimumPeak, current);
        maximumPeak = qMax(maximumPeak, current);
        const double scale = chart->property("yMaximum").toDouble();
        if (scale < previousScale - 1.e-12) return false;
        previousScale = scale;
        QThread::msleep(1);
    }
    if (!(minimumPeak > 0.0 && maximumPeak > minimumPeak * 1.001) || batches < 2
        || !captureFvFrame(QStringLiteral("after"))) return false;
    std::printf("FV_VARIATION role=%s min=%.9g max=%.9g fixed_scale_max=%.9g fitted_only=PASS\n",
        rawChart ? "admin" : "client", minimumPeak, maximumPeak, previousScale);
    if (!captureRoot.isEmpty()) {
        if (auto *adminWindow = qobject_cast<adminui::AdminTemplateWindow *>(window)) {
            if (!adminWindow->saveCapture(QDir(captureRoot).filePath(QStringLiteral("admin-main-running.png")))) {
                return false;
            }
            adminWindow->setScreen(adminui::AdminTemplateWindow::Screen::Debug);
            QCoreApplication::processEvents();
            if (!adminWindow->saveCapture(QDir(captureRoot).filePath(QStringLiteral("admin-debug-running.png")))) {
                return false;
            }
            adminWindow->setScreen(adminui::AdminTemplateWindow::Screen::PeakData);
            QCoreApplication::processEvents();
            if (!adminWindow->saveCapture(QDir(captureRoot).filePath(QStringLiteral("admin-peak-running.png")))) return false;
            adminWindow->setScreen(adminui::AdminTemplateWindow::Screen::Main);
            QCoreApplication::processEvents();
        } else if (auto *clientWindow = qobject_cast<clientui::ClientTemplateWindow *>(window)) {
            if (!clientWindow->saveCapture(QDir(captureRoot).filePath(QStringLiteral("client-main-running.png")))) {
                return false;
            }
        }
        std::printf("CAPTURE_ENV qt=%s widget=%dx%d dpr=%.3f dpi=%d font=%s platform=%s\n",
            qVersion(), window->width(), window->height(), window->devicePixelRatioF(),
            window->logicalDpiX(), window->font().family().toUtf8().constData(),
            qPrintable(QGuiApplication::platformName()));
    }

    cameraPhoto->click();
    if (!waitFor([&]() {
            return containsFileWithSuffix(storageRoot, QStringLiteral(".png"));
        })) {
        std::fprintf(stderr, "M7_UI photo save timeout: %s\n", notice->text().toUtf8().constData());
        return false;
    }
    cameraRecord->click();
    if (!waitFor([&]() { return cameraStop->isEnabled() && !cameraRecord->isEnabled(); })) {
        std::fprintf(stderr, "M7_UI recording did not start\n");
        return false;
    }
    if (!waitFor([&]() { return status->text().contains(QStringLiteral("采集中")); }, 300)) {
        std::fprintf(stderr, "M7_UI measurement state changed during recording\n");
        return false;
    }
    QElapsedTimer recordingDelay;
    recordingDelay.start();
    while (recordingDelay.elapsed() < 180) {
        QCoreApplication::processEvents(QEventLoop::AllEvents, 10);
        QThread::msleep(1);
    }
    cameraStop->click();
    if (!waitFor([&]() {
            return containsFileWithSuffix(storageRoot, QStringLiteral(".mjpeg"))
                && cameraRecord->isEnabled() && !cameraStop->isEnabled();
        })) {
        std::fprintf(stderr, "M7_UI video save timeout: %s\n", notice->text().toUtf8().constData());
        return false;
    }
    if (!status->text().contains(QStringLiteral("采集中"))) {
        std::fprintf(stderr, "M7_UI camera flow interrupted measurement\n");
        return false;
    }

    // The sidebar now selects the data directory through a modal dialog.
    const auto selectDataDirectory = [&]() {
        bool selected = false;
        QTimer dialogTimer;
        dialogTimer.setInterval(10);
        QObject::connect(&dialogTimer, &QTimer::timeout, window, [&]() {
            if (auto *dialog = window->findChild<QFileDialog *>()) {
                dialog->setDirectory(storageRoot);
                dialog->selectFile(storageRoot);
                selected = QMetaObject::invokeMethod(dialog, "accept", Qt::DirectConnection);
            }
        });
        dialogTimer.start();
        saveExperiment->click();
        dialogTimer.stop();
        return selected && notice->text().contains(QStringLiteral("数据目录已创建"));
    };
    if (!selectDataDirectory()) {
        std::fprintf(stderr, "data directory selection failed: %s\n", notice->text().toUtf8().constData());
        return false;
    }
    stop->click();
    if (!waitFor([&]() { return status->text().contains(QStringLiteral("已停止")); })) {
        std::fprintf(stderr, "stop failed: %s\n", status->text().toUtf8().constData());
        return false;
    }
    const int sampleCount = chart->property("liveSampleCount").toInt();
    if (!selectDataDirectory()) {
        std::fprintf(stderr, "stopped directory selection failed: %s\n", notice->text().toUtf8().constData());
        return false;
    }
    if (auto *adminWindow = qobject_cast<adminui::AdminTemplateWindow *>(window)) {
        adminWindow->setScreen(adminui::AdminTemplateWindow::Screen::PeakData);
        QCoreApplication::processEvents();
        auto *records = window->findChild<QTableView *>(QStringLiteral("peakRecordTable"));
        auto *exportButton = window->findChild<QPushButton *>(QStringLiteral("peakExportCsvButton"));
        auto *exportStatus = window->findChild<QLabel *>(QStringLiteral("peakExportStatusLabel"));
        if (!records || !exportButton || !exportStatus || records->model()->rowCount() < 1 || !exportButton->isEnabled()) return false;
        const QDateTime acquiredLocal = QDateTime::fromString(records->model()->index(0, 1).data().toString(), QStringLiteral("yyyy-MM-dd HH:mm:ss.zzz"));
        if (!acquiredLocal.isValid() || std::abs(acquiredLocal.msecsTo(QDateTime::currentDateTime())) > 10000) return false;
        exportButton->click();
        if (!waitFor([&]() { return exportStatus->text().contains(QStringLiteral("CSV 连续保存已开始")) && exportButton->isEnabled(); })) {
            std::fprintf(stderr, "Peak export failed: %s\n", exportStatus->text().toUtf8().constData());
            return false;
        }
        const QDir csvDirectory(QDir(storageRoot).filePath(QStringLiteral("CSV数据保存")));
        const auto csvFiles = csvDirectory.entryList({QStringLiteral("*.csv")}, QDir::Files);
        if (csvFiles.isEmpty()) return false;
        QFile csv(csvDirectory.filePath(csvFiles.last()));
        if (!csv.open(QIODevice::ReadOnly)) return false;
        const QByteArray content = csv.readAll();
        if (!content.contains(QStringLiteral("峰值吸光度").toUtf8())) return false;
        exportButton->click();
        if (!waitFor([&]() { return exportStatus->text().contains(QStringLiteral("CSV 连续保存已停止")); })) return false;
        std::printf("PEAK_CSV continuous_save_toggle=PASS\n");
    }
    return start->isEnabled() && !stop->isEnabled()
        && chart->property("liveSampleCount").toInt() == sampleCount;
}

} // namespace

int main(int argc, char *argv[])
{
    QCoreApplication::setAttribute(Qt::AA_DontUseNativeDialogs);
    QApplication application(argc, argv);
    application.setQuitOnLastWindowClosed(false);
    QTemporaryDir storage;
    if (!storage.isValid()) {
        return 7;
    }
    qputenv("TDLAS_STORAGE_ROOT", storage.filePath(QStringLiteral("data")).toUtf8());
    qputenv("TDLAS_STORAGE_CONFIG", storage.filePath(QStringLiteral("storage.json")).toUtf8());
    qputenv("TDLAS_PARAMETER_CONFIG", storage.filePath(QStringLiteral("parameters.ini")).toUtf8());
    qputenv("TDLAS_ACQUISITION_BACKEND", QByteArrayLiteral("mock"));
    qputenv("TDLAS_CAMERA_BACKEND", QByteArrayLiteral("mock"));

    {
        IntegratedApplicationController controller(application);
        controller.start();
        if (!login(application, controller, QStringLiteral("00"), QStringLiteral("00"))) {
            return 1;
        }
        if (!qobject_cast<adminui::AdminTemplateWindow *>(controller.roleWindow())) {
            return 2;
        }
        if (!verifyMeasurementFlow(controller.roleWindow(), storage.filePath(QStringLiteral("data")))) {
            return 3;
        }
    }
    application.processEvents();

    {
        IntegratedApplicationController controller(application);
        controller.start();
        if (!login(application, controller, QStringLiteral("01"), QStringLiteral("01"))) {
            return 4;
        }
        if (!qobject_cast<clientui::ClientTemplateWindow *>(controller.roleWindow())) {
            return 5;
        }
        if (!verifyMeasurementFlow(controller.roleWindow(), storage.filePath(QStringLiteral("data")))) {
            return 6;
        }
    }

    return 0;
}
