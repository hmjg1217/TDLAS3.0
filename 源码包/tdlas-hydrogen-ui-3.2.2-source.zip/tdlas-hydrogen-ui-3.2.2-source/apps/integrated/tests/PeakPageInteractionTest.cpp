#include "AdminTemplateWindow.h"
#include "ChartWidget.h"
#include <QApplication>
#include <QCheckBox>
#include <QComboBox>
#include <QDateTimeEdit>
#include <QDialog>
#include <QDialogButtonBox>
#include <QDir>
#include <QElapsedTimer>
#include <QFile>
#include <QFileDialog>
#include <QFont>
#include <QLabel>
#include <QLineEdit>
#include <QMouseEvent>
#include <QPushButton>
#include <QTableView>
#include <QTemporaryDir>
#include <QWheelEvent>
#include <cmath>
#include <cstdio>

#define CHECK(condition) do { if (!(condition)) { std::fprintf(stderr, "Peak UI assertion failed at line %d\n", __LINE__); return 1; } } while (false)

void click(QWidget *widget, const QPointF &point, Qt::MouseButton button = Qt::LeftButton) {
    QMouseEvent press(QEvent::MouseButtonPress, point, widget->mapToGlobal(point.toPoint()), button, button, Qt::NoModifier);
    QApplication::sendEvent(widget, &press);
    QMouseEvent release(QEvent::MouseButtonRelease, point, widget->mapToGlobal(point.toPoint()), button, Qt::NoButton, Qt::NoModifier);
    QApplication::sendEvent(widget, &release);
}
void wheel(QWidget *widget, const QPointF &point, int delta) {
    QWheelEvent event(point, widget->mapToGlobal(point.toPoint()), {}, QPoint(0, delta), Qt::NoButton, Qt::NoModifier, Qt::NoScrollPhase, false);
    QApplication::sendEvent(widget, &event);
}
double span(QWidget *chart, const char *a, const char *b) { return chart->property(b).toDouble() - chart->property(a).toDouble(); }

int main(int argc, char **argv) {
    QApplication application(argc, argv);
    application.setFont(QFont(QStringLiteral("Microsoft YaHei UI"), 10));
    QFile style(QStringLiteral(":/styles/admin.qss"));
    if (style.open(QIODevice::ReadOnly)) application.setStyleSheet(QString::fromUtf8(style.readAll()));
    using namespace tdlas::contracts;
    adminui::AdminTemplateWindow window(adminui::AdminTemplateWindow::Screen::PeakData);
    window.show(); application.processEvents();
    auto *chart = window.findChild<adminui::ChartWidget *>(QStringLiteral("peakDetailTrendChart"));
    auto *table = window.findChild<QTableView *>(QStringLiteral("peakRecordTable"));
    auto *follow = window.findChild<QCheckBox *>(QStringLiteral("peakAutoFollowCheckBox"));
    auto *live = window.findChild<QPushButton *>(QStringLiteral("peakReturnLiveButton"));
    auto *reset = window.findChild<QPushButton *>(QStringLiteral("peakResetZoomButton"));
    auto *exportButton = window.findChild<QPushButton *>(QStringLiteral("peakExportCsvButton"));
    auto *runs = window.findChild<QComboBox *>(QStringLiteral("peakRunSelect"));
    auto *wholeRun = window.findChild<QPushButton *>(QStringLiteral("peakWindow0Button"));
    CHECK(chart && table && follow && live && reset && exportButton && runs && wholeRun);
    CHECK(table->model()->rowCount() == 0 && !exportButton->isEnabled());
    MeasurementDisplayModel model; model.runId = {QStringLiteral("current-run")};
    model.sourceKind = DataSourceKind::Simulation; model.state = MeasurementState::Running;
    const QDateTime now = QDateTime::currentDateTimeUtc(); model.runStartedAtUtc = now.addSecs(-120);
    auto add = [&](int sequence, const RunId &run, const QDateTime &time) {
        PeakRecord r; r.sequence = sequence; r.runId = run; r.acquiredAtUtc = time;
        r.elapsedSeconds = sequence * 2.0; r.peakValue = 0.1 + 0.01 * std::sin(sequence * 0.2); r.peakX = 0.001;
        r.peakXUnit = QStringLiteral("cm⁻¹"); r.validity = DataValidity::Valid;
        r.sourceKind = DataSourceKind::Simulation; r.parameters = ParameterSnapshot::mockDefaults();
        r.algorithmVersion = QStringLiteral("fixture-v1"); r.reason = QStringLiteral("确定性模拟测试记录");
        model.peakRecords.push_back(r);
    };
    for (int i = 1; i <= 20; ++i) add(i, {QStringLiteral("previous-run")}, now.addSecs(-240 + i * 2));
    for (int i = 1; i <= 61; ++i) add(i, model.runId, now.addSecs(-122 + i * 2));
    model.peakRecords[45].peakValue.reset(); model.peakRecords[45].peakX.reset();
    model.peakRecords[45].validity = DataValidity::Invalid; model.peakRecords[45].reason = QStringLiteral("注入空曲线：应在此断线");
    window.presentMeasurementDisplay(model); application.processEvents();
    CHECK(table->model()->rowCount() == 61 && chart->property("liveSampleCount").toInt() == 61);
    CHECK(table->model()->index(0, 1).data().toString() == model.peakRecords.at(20).acquiredAtUtc.toLocalTime().toString(QStringLiteral("yyyy-MM-dd HH:mm:ss.zzz")));
    CHECK(table->model()->index(25, 3).data().toString() == QStringLiteral("null"));
    wholeRun->click(); application.processEvents();
    const QString captureRoot = qEnvironmentVariable("TDLAS_QA_CAPTURE_DIR");
    if (!captureRoot.isEmpty()) CHECK(window.saveCapture(QDir(captureRoot).filePath(QStringLiteral("admin-peak-fixture.png"))));
    const int left = qMin(96, qMax(86, chart->width() / 10));
    const QRectF plot(left, 18, chart->width() - left - 18, chart->height() - 64);
    auto point = [&](double x, double y) { return QPointF(plot.left() + plot.width() * x, plot.top() + plot.height() * y); };
    const double xSpan = span(chart, "xMinimum", "xMaximum");
    const double ySpan = span(chart, "yMinimum", "yMaximum");
    wheel(chart, point(0.5, 0.5), -120);
    CHECK(chart->property("peakZoomAxis").toString() == QStringLiteral("Y"));
    CHECK(span(chart, "xMinimum", "xMaximum") == xSpan && span(chart, "yMinimum", "yMaximum") == ySpan);
    click(chart, point(0.2, 0.2)); CHECK(chart->property("peakZoomSelectionPending").toBool() && !follow->isChecked());
    click(chart, point(0.8, 0.8));
    CHECK(chart->property("peakZoomed").toBool() && std::abs(span(chart, "yMinimum", "yMaximum") - ySpan * 0.6) < 1e-10);
    CHECK(span(chart, "xMinimum", "xMaximum") == xSpan);
    reset->click(); wheel(chart, point(0.5, 0.5), 120);
    click(chart, point(0.2, 0.4)); click(chart, point(0.8, 0.6));
    CHECK(std::abs(span(chart, "xMinimum", "xMaximum") - xSpan * 0.6) < 1e-5);
    const double frozen = chart->property("xMaximum").toDouble();
    add(62, model.runId, now.addSecs(2)); window.presentMeasurementDisplay(model); application.processEvents();
    CHECK(chart->property("xMaximum").toDouble() == frozen && table->model()->rowCount() == 62);
    if (!captureRoot.isEmpty()) CHECK(window.saveCapture(QDir(captureRoot).filePath(QStringLiteral("admin-peak-zoomed.png"))));
    click(chart, point(0.5, 0.5), Qt::RightButton);
    CHECK(!chart->property("peakZoomed").toBool() && !chart->property("peakZoomSelectionPending").toBool());
    CHECK(span(chart, "xMinimum", "xMaximum") > xSpan);
    live->click(); CHECK(follow->isChecked());
    const double before = chart->property("xMaximum").toDouble();
    add(63, model.runId, now.addSecs(4)); window.presentMeasurementDisplay(model);
    CHECK(chart->property("xMaximum").toDouble() > before);
    auto *minute = window.findChild<QPushButton *>(QStringLiteral("peakWindow60Button")); CHECK(minute);
    minute->click(); CHECK(table->model()->rowCount() == 31);
    wholeRun->click(); runs->setCurrentIndex(runs->findData(QStringLiteral("previous-run")));
    CHECK(table->model()->rowCount() == 20 && !follow->isChecked());
    runs->setCurrentIndex(1); CHECK(table->model()->rowCount() == model.peakRecords.size());
    application.processEvents();
    if (!captureRoot.isEmpty()) CHECK(window.saveCapture(QDir(captureRoot).filePath(QStringLiteral("admin-peak-multiple-runs.png"))));
    auto *collapse = window.findChild<QPushButton *>(QStringLiteral("peakRecordsCollapseButton")); CHECK(collapse);
    collapse->click(); CHECK(!table->isVisible()); collapse->click(); CHECK(table->isVisible());
    auto *custom = window.findChild<QPushButton *>(QStringLiteral("peakWindow-1Button")); CHECK(custom); custom->click(); application.processEvents();
    auto *rangeDialog = window.findChild<QDialog *>(QStringLiteral("peakCustomRangeDialog")); CHECK(rangeDialog);
    rangeDialog->findChild<QDateTimeEdit *>(QStringLiteral("peakRangeFrom"))->setDateTime(now.addSecs(-30).toLocalTime());
    rangeDialog->findChild<QDateTimeEdit *>(QStringLiteral("peakRangeTo"))->setDateTime(now.addSecs(-10).toLocalTime());
    rangeDialog->findChild<QDialogButtonBox *>()->button(QDialogButtonBox::Ok)->click(); application.processEvents();
    CHECK(table->model()->rowCount() == 11);
    int requestedCount = 0;
    QObject::connect(&window, &adminui::AdminTemplateWindow::peakCsvExportToggleRequested, &window,
        [&](const QVector<PeakRecord> &records) { requestedCount = static_cast<int>(records.size()); });
    exportButton->click(); application.processEvents();
    CHECK(requestedCount == 11);
    CHECK(exportButton->text().contains(QStringLiteral("导出 CSV")));
    window.setPeakExportStreaming(true);
    CHECK(exportButton->text().contains(QStringLiteral("停止保存 CSV")));
    window.setPeakExportStreaming(false);
    CHECK(exportButton->text().contains(QStringLiteral("导出 CSV")));
    std::printf("Peak UI: local timestamps, two-click X/Y zoom, wheel axis only, frozen history, right-click reset, live follow, run/time filters, collapse and export snapshot: PASS\n");
    std::printf("CAPTURE_ENV qt=%s widget=%dx%d dpr=%.3f dpi=%d font=%s platform=%s\n", qVersion(), window.width(), window.height(), window.devicePixelRatioF(), window.logicalDpiX(), window.font().family().toUtf8().constData(), qPrintable(QGuiApplication::platformName()));
    return 0;
}
