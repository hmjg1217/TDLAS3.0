param(
    [string]$QtRoot = $env:QTDIR,
    [ValidateSet('Debug', 'Release', 'RelWithDebInfo', 'MinSizeRel')]
    [string]$Configuration = 'Release',
    [string]$BuildDirectory = 'build',
    [ValidateSet('all', 'integrated', 'startup', 'admin', 'client')]
    [string]$Target = 'all',
    [switch]$RunTests
)

$ErrorActionPreference = 'Stop'

$projectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
. (Join-Path $PSScriptRoot 'tools\resolve-environment.ps1')
$toolchain = Resolve-TdlasEnvironment -QtRoot $QtRoot
$cmake = $toolchain.CMake
$resolvedQtRoot = $toolchain.QtRoot
if ($RunTests -and $Target -ne 'all') { throw 'Use -Target all with -RunTests to build all test binaries.' }

$buildPath = if ([System.IO.Path]::IsPathRooted($BuildDirectory)) {
    $BuildDirectory
} else {
    Join-Path $projectRoot $BuildDirectory
}

& $cmake -S $projectRoot -B $buildPath -G 'Visual Studio 17 2022' -A x64 "-DCMAKE_PREFIX_PATH=$resolvedQtRoot"
if ($LASTEXITCODE -ne 0) {
    throw "CMake 配置失败，退出码 $LASTEXITCODE"
}

$targetMap = @{
    integrated = 'tdlas_hydrogen_ui'
    startup = 'tdlas_startup_codex_template'
    admin = 'tdlas_admin_codex_template'
    client = 'tdlas_client_codex_template'
}
$buildArguments = @('--build', $buildPath, '--config', $Configuration, '--parallel')
if ($Target -ne 'all') {
    $buildArguments += @('--target', $targetMap[$Target])
}

& $cmake @buildArguments
if ($LASTEXITCODE -ne 0) {
    throw "构建失败，退出码 $LASTEXITCODE"
}

Write-Host "构建完成：$buildPath\bin\$Configuration"
if ($RunTests) {
    & $toolchain.CTest --test-dir $buildPath -C $Configuration --output-on-failure --timeout 120
    if ($LASTEXITCODE -ne 0) { throw "CTest failed: $LASTEXITCODE" }
}
