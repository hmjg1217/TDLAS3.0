#include "acquisition/AcquisitionDeviceDiscovery.h"

#include "acquisition/DynamicNidaqmxDriver.h"

namespace tdlas::acquisition {

namespace {

bool succeeded(NidaqmxStatus status)
{
    return status >= 0;
}

} // namespace

AcquisitionDiscoveryResult NidaqmxDeviceDiscovery::discover()
{
    AcquisitionDiscoveryResult result;
    DynamicNidaqmxDriver driver;
    if (!driver.load(&result.diagnostic)) {
        result.userMessage = QStringLiteral("未安装或无法加载 NI-DAQmx 运行库。");
        return result;
    }
    result.driverAvailable = true;

    QStringList deviceIds;
    NidaqmxStatus status = driver.systemDeviceNames(&deviceIds);
    if (!succeeded(status)) {
        result.userMessage = QStringLiteral("NI-DAQmx 设备枚举失败。");
        result.diagnostic = driver.errorText(status);
        return result;
    }

    for (const QString &deviceId : deviceIds) {
        AcquisitionDeviceDescriptor descriptor;
        descriptor.id = deviceId.trimmed();
        descriptor.sourceKind = contracts::DataSourceKind::RealDevice;
        status = driver.deviceProductType(descriptor.id, &descriptor.productType);
        if (!succeeded(status)) {
            continue;
        }

        QString channelDiagnostic;
        const NidaqmxStatus aiStatus = driver.deviceAiPhysicalChannels(
            descriptor.id, &descriptor.aiPhysicalChannels);
        const NidaqmxStatus aoStatus = driver.deviceAoPhysicalChannels(
            descriptor.id, &descriptor.aoPhysicalChannels);
        if (!succeeded(aiStatus)) {
            channelDiagnostic += QStringLiteral(" AI: %1").arg(driver.errorText(aiStatus));
        }
        if (!succeeded(aoStatus)) {
            channelDiagnostic += QStringLiteral(" AO: %1").arg(driver.errorText(aoStatus));
        }
        if (!channelDiagnostic.isEmpty()) {
            result.diagnostic += QStringLiteral("%1:%2;").arg(descriptor.id, channelDiagnostic);
        }

        descriptor.displayName = descriptor.productType.isEmpty()
            ? descriptor.id
            : QStringLiteral("%1 (%2)").arg(descriptor.productType, descriptor.id);
        result.devices.push_back(descriptor);
    }

    result.userMessage = result.devices.isEmpty()
        ? QStringLiteral("未发现 NI-DAQmx 采集设备，请检查 NI MAX、驱动和连接。")
        : QStringLiteral("已识别 %1 个 NI-DAQmx 采集设备。").arg(result.devices.size());
    return result;
}

} // namespace tdlas::acquisition
