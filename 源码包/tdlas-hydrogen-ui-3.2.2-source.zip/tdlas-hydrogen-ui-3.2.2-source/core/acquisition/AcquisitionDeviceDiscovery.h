#pragma once

#include "contracts/MeasurementTypes.h"

#include <QString>
#include <QStringList>
#include <QVector>

namespace tdlas::acquisition {

struct AcquisitionDeviceDescriptor {
    QString id;
    QString displayName;
    QString productType;
    QStringList aiPhysicalChannels;
    QStringList aoPhysicalChannels;
    contracts::DataSourceKind sourceKind = contracts::DataSourceKind::RealDevice;
};

struct AcquisitionDiscoveryResult {
    QVector<AcquisitionDeviceDescriptor> devices;
    bool driverAvailable = false;
    QString userMessage;
    QString diagnostic;
};

class NidaqmxDeviceDiscovery final
{
public:
    [[nodiscard]] static AcquisitionDiscoveryResult discover();
};

} // namespace tdlas::acquisition
