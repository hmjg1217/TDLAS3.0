#include "acquisition/DynamicNidaqmxDriver.h"

#include <QByteArray>
#include <QStringList>

#include <limits>

namespace tdlas::acquisition {

namespace {

constexpr qint32 kTerminalConfigurationDefault = -1;
constexpr qint32 kUnitsVolts = 10348;
constexpr qint32 kRisingEdge = 10280;
constexpr qint32 kContinuousSamples = 10123;
constexpr quint32 kGroupByChannel = 0;

QStringList splitDaqmxList(const QByteArray &value)
{
    QStringList result;
    const QStringList parts = QString::fromUtf8(value.constData()).split(
        QLatin1Char(','), Qt::SkipEmptyParts);
    for (const QString &part : parts) {
        const QString trimmed = part.trimmed();
        if (!trimmed.isEmpty()) {
            result.push_back(trimmed);
        }
    }
    return result;
}

} // namespace

DynamicNidaqmxDriver::DynamicNidaqmxDriver()
    : library_(QStringLiteral("nicaiu"))
{
}

DynamicNidaqmxDriver::~DynamicNidaqmxDriver()
{
    if (library_.isLoaded()) {
        library_.unload();
    }
}

template<typename Function>
bool DynamicNidaqmxDriver::resolve(Function *target, const char *symbol, QString *diagnostic)
{
    *target = reinterpret_cast<Function>(library_.resolve(symbol));
    if (*target) {
        return true;
    }
    if (diagnostic) {
        *diagnostic = QStringLiteral("NI-DAQmx symbol is unavailable: %1 (%2)")
            .arg(QString::fromLatin1(symbol), library_.errorString());
    }
    return false;
}

bool DynamicNidaqmxDriver::load(QString *diagnostic)
{
    if (library_.isLoaded()) {
        return true;
    }
#if !defined(Q_OS_WIN)
    if (diagnostic) {
        *diagnostic = QStringLiteral("NI-DAQmx dynamic adapter is supported only on Windows");
    }
    return false;
#else
    if (!library_.load()) {
        if (diagnostic) {
            *diagnostic = QStringLiteral("Unable to load nicaiu.dll: %1").arg(library_.errorString());
        }
        return false;
    }
    const bool resolved = resolve(&createTask_, "DAQmxCreateTask", diagnostic)
        && resolve(&startTask_, "DAQmxStartTask", diagnostic)
        && resolve(&stopTask_, "DAQmxStopTask", diagnostic)
        && resolve(&clearTask_, "DAQmxClearTask", diagnostic)
        && resolve(&createAiVoltageChannel_, "DAQmxCreateAIVoltageChan", diagnostic)
        && resolve(&createAoVoltageChannel_, "DAQmxCreateAOVoltageChan", diagnostic)
        && resolve(&configureSampleClock_, "DAQmxCfgSampClkTiming", diagnostic)
        && resolve(&getSampleClockRate_, "DAQmxGetSampClkRate", diagnostic)
        && resolve(&readAnalog_, "DAQmxReadAnalogF64", diagnostic)
        && resolve(&writeAnalog_, "DAQmxWriteAnalogF64", diagnostic)
        && resolve(&getAvailableSamples_, "DAQmxGetReadAvailSampPerChan", diagnostic)
        && resolve(&getSystemDeviceNames_, "DAQmxGetSysDevNames", diagnostic)
        && resolve(&getDeviceAiPhysicalChannels_, "DAQmxGetDevAIPhysicalChans", diagnostic)
        && resolve(&getDeviceAoPhysicalChannels_, "DAQmxGetDevAOPhysicalChans", diagnostic)
        && resolve(&getDeviceProductType_, "DAQmxGetDevProductType", diagnostic)
        && resolve(&getErrorString_, "DAQmxGetErrorString", diagnostic);
    if (!resolved) {
        library_.unload();
    }
    return resolved;
#endif
}

bool DynamicNidaqmxDriver::isLoaded() const
{
    return library_.isLoaded();
}

NidaqmxStatus DynamicNidaqmxDriver::systemDeviceNames(QStringList *deviceIds)
{
    const NidaqmxStatus required = getSystemDeviceNames_(nullptr, 0);
    if (required < 0) {
        return required;
    }
    QByteArray buffer(required > 0 ? required : 4096, '\0');
    const NidaqmxStatus status = getSystemDeviceNames_(
        buffer.data(), static_cast<quint32>(buffer.size()));
    if (status >= 0 && deviceIds) {
        *deviceIds = splitDaqmxList(buffer);
    }
    return status;
}

NidaqmxStatus DynamicNidaqmxDriver::deviceAiPhysicalChannels(
    const QString &deviceId,
    QStringList *channelIds)
{
    const QByteArray device = deviceId.toUtf8();
    const NidaqmxStatus required = getDeviceAiPhysicalChannels_(device.constData(), nullptr, 0);
    if (required < 0) {
        return required;
    }
    QByteArray buffer(required > 0 ? required : 8192, '\0');
    const NidaqmxStatus status = getDeviceAiPhysicalChannels_(
        device.constData(), buffer.data(), static_cast<quint32>(buffer.size()));
    if (status >= 0 && channelIds) {
        *channelIds = splitDaqmxList(buffer);
    }
    return status;
}

NidaqmxStatus DynamicNidaqmxDriver::deviceAoPhysicalChannels(
    const QString &deviceId,
    QStringList *channelIds)
{
    const QByteArray device = deviceId.toUtf8();
    const NidaqmxStatus required = getDeviceAoPhysicalChannels_(device.constData(), nullptr, 0);
    if (required < 0) {
        return required;
    }
    QByteArray buffer(required > 0 ? required : 4096, '\0');
    const NidaqmxStatus status = getDeviceAoPhysicalChannels_(
        device.constData(), buffer.data(), static_cast<quint32>(buffer.size()));
    if (status >= 0 && channelIds) {
        *channelIds = splitDaqmxList(buffer);
    }
    return status;
}

NidaqmxStatus DynamicNidaqmxDriver::deviceProductType(
    const QString &deviceId,
    QString *productType)
{
    const QByteArray device = deviceId.toUtf8();
    NidaqmxStatus required = getDeviceProductType_(device.constData(), nullptr, 0);
    if (required < 0) {
        return required;
    }
    const qsizetype capacity = required > 0 ? required : 1024;
    QByteArray buffer(capacity, '\0');
    const NidaqmxStatus status = getDeviceProductType_(
        device.constData(), buffer.data(), static_cast<quint32>(buffer.size()));
    if (status >= 0 && productType) {
        *productType = QString::fromUtf8(buffer.constData()).trimmed();
    }
    return status;
}

NidaqmxStatus DynamicNidaqmxDriver::createTask(NidaqmxTaskHandle *taskHandle)
{
    return createTask_("", taskHandle);
}

NidaqmxStatus DynamicNidaqmxDriver::createAiVoltageChannel(
    NidaqmxTaskHandle taskHandle,
    const QString &physicalChannel,
    double minimumV,
    double maximumV)
{
    const QByteArray channel = physicalChannel.toUtf8();
    return createAiVoltageChannel_(
        taskHandle, channel.constData(), "", kTerminalConfigurationDefault,
        minimumV, maximumV, kUnitsVolts, nullptr);
}

NidaqmxStatus DynamicNidaqmxDriver::createAoVoltageChannel(
    NidaqmxTaskHandle taskHandle,
    const QString &physicalChannel,
    double minimumV,
    double maximumV)
{
    const QByteArray channel = physicalChannel.toUtf8();
    return createAoVoltageChannel_(
        taskHandle, channel.constData(), "", minimumV, maximumV, kUnitsVolts, nullptr);
}

NidaqmxStatus DynamicNidaqmxDriver::configureContinuousSampleClock(
    NidaqmxTaskHandle taskHandle,
    double sampleRateHz,
    quint64 driverBufferSamplesPerChannel)
{
    return configureSampleClock_(
        taskHandle, "", sampleRateHz, kRisingEdge, kContinuousSamples,
        driverBufferSamplesPerChannel);
}

NidaqmxStatus DynamicNidaqmxDriver::sampleClockRate(
    NidaqmxTaskHandle taskHandle,
    double *sampleRateHz)
{
    return getSampleClockRate_(taskHandle, sampleRateHz);
}

NidaqmxStatus DynamicNidaqmxDriver::writeAnalogF64(
    NidaqmxTaskHandle taskHandle,
    const QVector<double> &channelMajorSamples,
    qint32 samplesPerChannel,
    qint32 *samplesWrittenPerChannel)
{
    return writeAnalog_(
        taskHandle, samplesPerChannel, 0, 0.0, kGroupByChannel,
        channelMajorSamples.constData(), samplesWrittenPerChannel, nullptr);
}

NidaqmxStatus DynamicNidaqmxDriver::startTask(NidaqmxTaskHandle taskHandle)
{
    return startTask_(taskHandle);
}

NidaqmxStatus DynamicNidaqmxDriver::availableSamplesPerChannel(
    NidaqmxTaskHandle taskHandle,
    quint32 *availableSamples)
{
    return getAvailableSamples_(taskHandle, availableSamples);
}

NidaqmxStatus DynamicNidaqmxDriver::readAnalogF64(
    NidaqmxTaskHandle taskHandle,
    qint32 samplesPerChannel,
    QVector<double> *channelMajorSamples,
    qint32 *samplesReadPerChannel)
{
    if (!channelMajorSamples
        || channelMajorSamples->size() > static_cast<qsizetype>(std::numeric_limits<quint32>::max())) {
        return -1;
    }
    return readAnalog_(
        taskHandle, samplesPerChannel, 0.0, kGroupByChannel,
        channelMajorSamples->data(), static_cast<quint32>(channelMajorSamples->size()),
        samplesReadPerChannel, nullptr);
}

NidaqmxStatus DynamicNidaqmxDriver::stopTask(NidaqmxTaskHandle taskHandle)
{
    return stopTask_(taskHandle);
}

NidaqmxStatus DynamicNidaqmxDriver::clearTask(NidaqmxTaskHandle taskHandle)
{
    return clearTask_(taskHandle);
}

QString DynamicNidaqmxDriver::errorText(NidaqmxStatus status) const
{
    if (!getErrorString_) {
        return QStringLiteral("NI-DAQmx status %1").arg(status);
    }
    NidaqmxStatus required = getErrorString_(status, nullptr, 0);
    if (required < 0) {
        return QStringLiteral("NI-DAQmx status %1").arg(status);
    }
    const qsizetype capacity = required > 0 ? required : 2048;
    QByteArray buffer(capacity, '\0');
    const NidaqmxStatus result = getErrorString_(
        status, buffer.data(), static_cast<quint32>(buffer.size()));
    if (result < 0 || buffer.constData()[0] == '\0') {
        return QStringLiteral("NI-DAQmx status %1").arg(status);
    }
    return QString::fromUtf8(buffer.constData()).trimmed();
}

} // namespace tdlas::acquisition
