#pragma once

#include "acquisition/INidaqmxDriver.h"

#include <QLibrary>
#include <QStringList>

namespace tdlas::acquisition {

class DynamicNidaqmxDriver final : public INidaqmxDriver
{
public:
    DynamicNidaqmxDriver();
    ~DynamicNidaqmxDriver() override;

    [[nodiscard]] bool load(QString *diagnostic) override;
    [[nodiscard]] bool isLoaded() const override;
    [[nodiscard]] NidaqmxStatus systemDeviceNames(QStringList *deviceIds);
    [[nodiscard]] NidaqmxStatus deviceAiPhysicalChannels(
        const QString &deviceId,
        QStringList *channelIds);
    [[nodiscard]] NidaqmxStatus deviceAoPhysicalChannels(
        const QString &deviceId,
        QStringList *channelIds);
    [[nodiscard]] NidaqmxStatus deviceProductType(
        const QString &deviceId,
        QString *productType) override;
    [[nodiscard]] NidaqmxStatus createTask(NidaqmxTaskHandle *taskHandle) override;
    [[nodiscard]] NidaqmxStatus createAiVoltageChannel(
        NidaqmxTaskHandle taskHandle,
        const QString &physicalChannel,
        double minimumV,
        double maximumV) override;
    [[nodiscard]] NidaqmxStatus createAoVoltageChannel(
        NidaqmxTaskHandle taskHandle,
        const QString &physicalChannel,
        double minimumV,
        double maximumV) override;
    [[nodiscard]] NidaqmxStatus configureContinuousSampleClock(
        NidaqmxTaskHandle taskHandle,
        double sampleRateHz,
        quint64 driverBufferSamplesPerChannel) override;
    [[nodiscard]] NidaqmxStatus sampleClockRate(
        NidaqmxTaskHandle taskHandle,
        double *sampleRateHz) override;
    [[nodiscard]] NidaqmxStatus writeAnalogF64(
        NidaqmxTaskHandle taskHandle,
        const QVector<double> &channelMajorSamples,
        qint32 samplesPerChannel,
        qint32 *samplesWrittenPerChannel) override;
    [[nodiscard]] NidaqmxStatus startTask(NidaqmxTaskHandle taskHandle) override;
    [[nodiscard]] NidaqmxStatus availableSamplesPerChannel(
        NidaqmxTaskHandle taskHandle,
        quint32 *availableSamples) override;
    [[nodiscard]] NidaqmxStatus readAnalogF64(
        NidaqmxTaskHandle taskHandle,
        qint32 samplesPerChannel,
        QVector<double> *channelMajorSamples,
        qint32 *samplesReadPerChannel) override;
    [[nodiscard]] NidaqmxStatus stopTask(NidaqmxTaskHandle taskHandle) override;
    [[nodiscard]] NidaqmxStatus clearTask(NidaqmxTaskHandle taskHandle) override;
    [[nodiscard]] QString errorText(NidaqmxStatus status) const override;

private:
    template<typename Function>
    [[nodiscard]] bool resolve(Function *target, const char *symbol, QString *diagnostic);

#if defined(Q_OS_WIN)
#define TDLAS_NIDAQMX_CALL __stdcall
#else
#define TDLAS_NIDAQMX_CALL
#endif
    using CreateTaskFunction = NidaqmxStatus (TDLAS_NIDAQMX_CALL *)(const char *, NidaqmxTaskHandle *);
    using StartTaskFunction = NidaqmxStatus (TDLAS_NIDAQMX_CALL *)(NidaqmxTaskHandle);
    using StopTaskFunction = NidaqmxStatus (TDLAS_NIDAQMX_CALL *)(NidaqmxTaskHandle);
    using ClearTaskFunction = NidaqmxStatus (TDLAS_NIDAQMX_CALL *)(NidaqmxTaskHandle);
    using CreateAiVoltageChannelFunction = NidaqmxStatus (TDLAS_NIDAQMX_CALL *)(
        NidaqmxTaskHandle, const char *, const char *, qint32, double, double, qint32, const char *);
    using CreateAoVoltageChannelFunction = NidaqmxStatus (TDLAS_NIDAQMX_CALL *)(
        NidaqmxTaskHandle, const char *, const char *, double, double, qint32, const char *);
    using ConfigureSampleClockFunction = NidaqmxStatus (TDLAS_NIDAQMX_CALL *)(
        NidaqmxTaskHandle, const char *, double, qint32, qint32, quint64);
    using GetSampleClockRateFunction = NidaqmxStatus (TDLAS_NIDAQMX_CALL *)(
        NidaqmxTaskHandle, double *);
    using ReadAnalogFunction = NidaqmxStatus (TDLAS_NIDAQMX_CALL *)(
        NidaqmxTaskHandle, qint32, double, quint32, double *, quint32, qint32 *, quint32 *);
    using WriteAnalogFunction = NidaqmxStatus (TDLAS_NIDAQMX_CALL *)(
        NidaqmxTaskHandle, qint32, quint32, double, quint32, const double *, qint32 *, quint32 *);
    using GetAvailableSamplesFunction = NidaqmxStatus (TDLAS_NIDAQMX_CALL *)(NidaqmxTaskHandle, quint32 *);
    using GetSystemStringFunction = NidaqmxStatus (TDLAS_NIDAQMX_CALL *)(char *, quint32);
    using GetDeviceStringFunction = NidaqmxStatus (TDLAS_NIDAQMX_CALL *)(const char *, char *, quint32);
    using GetDeviceProductTypeFunction = NidaqmxStatus (TDLAS_NIDAQMX_CALL *)(const char *, char *, quint32);
    using GetErrorStringFunction = NidaqmxStatus (TDLAS_NIDAQMX_CALL *)(NidaqmxStatus, char *, quint32);
#undef TDLAS_NIDAQMX_CALL

    QLibrary library_;
    CreateTaskFunction createTask_ = nullptr;
    StartTaskFunction startTask_ = nullptr;
    StopTaskFunction stopTask_ = nullptr;
    ClearTaskFunction clearTask_ = nullptr;
    CreateAiVoltageChannelFunction createAiVoltageChannel_ = nullptr;
    CreateAoVoltageChannelFunction createAoVoltageChannel_ = nullptr;
    ConfigureSampleClockFunction configureSampleClock_ = nullptr;
    GetSampleClockRateFunction getSampleClockRate_ = nullptr;
    ReadAnalogFunction readAnalog_ = nullptr;
    WriteAnalogFunction writeAnalog_ = nullptr;
    GetAvailableSamplesFunction getAvailableSamples_ = nullptr;
    GetSystemStringFunction getSystemDeviceNames_ = nullptr;
    GetDeviceStringFunction getDeviceAiPhysicalChannels_ = nullptr;
    GetDeviceStringFunction getDeviceAoPhysicalChannels_ = nullptr;
    GetDeviceProductTypeFunction getDeviceProductType_ = nullptr;
    GetErrorStringFunction getErrorString_ = nullptr;
};

} // namespace tdlas::acquisition
