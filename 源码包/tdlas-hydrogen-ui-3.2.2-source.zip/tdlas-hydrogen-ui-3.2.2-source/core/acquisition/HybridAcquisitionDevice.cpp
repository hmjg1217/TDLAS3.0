#include "acquisition/HybridAcquisitionDevice.h"

#include <QDateTime>

namespace tdlas::acquisition {

HybridAcquisitionDevice::HybridAcquisitionDevice(
    AcquisitionBackendPolicy policy,
    QObject *parent)
    : IAcquisitionDevice(parent)
    , policy_(policy)
{
    forwardSignals(mockDevice_);
    forwardSignals(nidaqmxDevice_);
}

contracts::DeviceConnectionState HybridAcquisitionDevice::connectionState() const
{
    return activeDevice_
        ? activeDevice_->connectionState()
        : contracts::DeviceConnectionState::Disconnected;
}

contracts::AcquisitionState HybridAcquisitionDevice::acquisitionState() const
{
    return activeDevice_
        ? activeDevice_->acquisitionState()
        : contracts::AcquisitionState::Idle;
}

bool HybridAcquisitionDevice::connectDevice(const QString &deviceId)
{
    const bool mockRequested = isMockDeviceId(deviceId);
    if ((mockRequested && policy_ == AcquisitionBackendPolicy::NidaqmxOnly)
        || (!mockRequested && policy_ == AcquisitionBackendPolicy::MockOnly)) {
        reportUnavailable(
            QStringLiteral("ACQUISITION_BACKEND_DISABLED"),
            QStringLiteral("所选采集设备后端当前未启用。"),
            deviceId);
        return false;
    }

    IAcquisitionDevice *requestedDevice = mockRequested
        ? static_cast<IAcquisitionDevice *>(&mockDevice_)
        : static_cast<IAcquisitionDevice *>(&nidaqmxDevice_);
    if (activeDevice_ && activeDevice_ != requestedDevice) {
        if (!activeDevice_->disconnectDevice()) {
            return false;
        }
    }
    activeDevice_ = requestedDevice;
    return activeDevice_->connectDevice(deviceId);
}

bool HybridAcquisitionDevice::disconnectDevice()
{
    if (!activeDevice_) {
        return true;
    }
    const bool disconnected = activeDevice_->disconnectDevice();
    if (disconnected) {
        activeDevice_ = nullptr;
    }
    return disconnected;
}

bool HybridAcquisitionDevice::configure(const contracts::ParameterSnapshot &snapshot)
{
    return activeDevice_ && activeDevice_->configure(snapshot);
}

bool HybridAcquisitionDevice::start(const contracts::RunId &runId)
{
    return activeDevice_ && activeDevice_->start(runId);
}

bool HybridAcquisitionDevice::stop()
{
    return !activeDevice_ || activeDevice_->stop();
}

bool HybridAcquisitionDevice::isMockDeviceId(const QString &deviceId)
{
    return deviceId.trimmed().startsWith(QStringLiteral("mock-"), Qt::CaseInsensitive)
        || deviceId.trimmed().startsWith(QStringLiteral("sim/"), Qt::CaseInsensitive);
}

void HybridAcquisitionDevice::forwardSignals(IAcquisitionDevice &device)
{
    connect(&device, &IAcquisitionDevice::connectionStateChanged, this,
        [this, &device](contracts::DeviceConnectionState state) {
            if (activeDevice_ == &device) {
                emit connectionStateChanged(state);
            }
        });
    connect(&device, &IAcquisitionDevice::acquisitionStateChanged, this,
        [this, &device](contracts::AcquisitionState state) {
            if (activeDevice_ == &device) {
                emit acquisitionStateChanged(state);
            }
        });
    connect(&device, &IAcquisitionDevice::rawDataReady, this,
        [this, &device](const contracts::RawDataBlock &block) {
            if (activeDevice_ == &device) {
                emit rawDataReady(block);
            }
        });
    connect(&device, &IAcquisitionDevice::errorOccurred, this,
        [this, &device](const contracts::ModuleError &error) {
            if (activeDevice_ == &device) {
                emit errorOccurred(error);
            }
        });
}

void HybridAcquisitionDevice::reportUnavailable(
    const QString &code,
    const QString &message,
    const QString &diagnostic)
{
    contracts::ModuleError error;
    error.code = code;
    error.category = QStringLiteral("acquisition");
    error.severity = contracts::ErrorSeverity::Recoverable;
    error.userMessage = message;
    error.diagnostic = diagnostic;
    error.timestamp.utc = QDateTime::currentDateTimeUtc();
    error.retryable = true;
    emit errorOccurred(error);
}

} // namespace tdlas::acquisition
