#pragma once

#include "acquisition/IAcquisitionDevice.h"
#include "acquisition/MockAcquisitionDevice.h"
#include "acquisition/NidaqmxAcquisitionDevice.h"

namespace tdlas::acquisition {

enum class AcquisitionBackendPolicy {
    Auto,
    MockOnly,
    NidaqmxOnly
};

class HybridAcquisitionDevice final : public IAcquisitionDevice
{
    Q_OBJECT

public:
    explicit HybridAcquisitionDevice(
        AcquisitionBackendPolicy policy = AcquisitionBackendPolicy::Auto,
        QObject *parent = nullptr);

    [[nodiscard]] contracts::DeviceConnectionState connectionState() const override;
    [[nodiscard]] contracts::AcquisitionState acquisitionState() const override;
    [[nodiscard]] bool connectDevice(const QString &deviceId) override;
    [[nodiscard]] bool disconnectDevice() override;
    [[nodiscard]] bool configure(const contracts::ParameterSnapshot &snapshot) override;
    [[nodiscard]] bool start(const contracts::RunId &runId) override;
    [[nodiscard]] bool stop() override;

    [[nodiscard]] AcquisitionBackendPolicy policy() const { return policy_; }
    [[nodiscard]] static bool isMockDeviceId(const QString &deviceId);

private:
    void forwardSignals(IAcquisitionDevice &device);
    void reportUnavailable(const QString &code, const QString &message, const QString &diagnostic);

    AcquisitionBackendPolicy policy_ = AcquisitionBackendPolicy::Auto;
    MockAcquisitionDevice mockDevice_;
    NidaqmxAcquisitionDevice nidaqmxDevice_;
    IAcquisitionDevice *activeDevice_ = nullptr;
};

} // namespace tdlas::acquisition
