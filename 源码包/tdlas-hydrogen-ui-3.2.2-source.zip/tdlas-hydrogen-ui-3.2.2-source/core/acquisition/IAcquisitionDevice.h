#pragma once

#include "contracts/MeasurementTypes.h"

#include <QObject>

namespace tdlas::acquisition {

class IAcquisitionDevice : public QObject
{
    Q_OBJECT

public:
    explicit IAcquisitionDevice(QObject *parent = nullptr)
        : QObject(parent)
    {
    }
    ~IAcquisitionDevice() override = default;

    [[nodiscard]] virtual contracts::DeviceConnectionState connectionState() const = 0;
    [[nodiscard]] virtual contracts::AcquisitionState acquisitionState() const = 0;
    [[nodiscard]] virtual bool connectDevice(const QString &deviceId) = 0;
    [[nodiscard]] virtual bool disconnectDevice() = 0;
    [[nodiscard]] virtual bool configure(const contracts::ParameterSnapshot &snapshot) = 0;
    [[nodiscard]] virtual bool start(const contracts::RunId &runId) = 0;
    [[nodiscard]] virtual bool stop() = 0;

signals:
    void connectionStateChanged(tdlas::contracts::DeviceConnectionState state);
    void acquisitionStateChanged(tdlas::contracts::AcquisitionState state);
    void rawDataReady(const tdlas::contracts::RawDataBlock &block);
    void errorOccurred(const tdlas::contracts::ModuleError &error);
};

} // namespace tdlas::acquisition
