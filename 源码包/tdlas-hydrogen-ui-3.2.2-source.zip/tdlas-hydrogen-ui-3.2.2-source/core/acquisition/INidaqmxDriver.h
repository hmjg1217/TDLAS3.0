#pragma once

#include <QString>
#include <QVector>

namespace tdlas::acquisition {

using NidaqmxStatus = qint32;
using NidaqmxTaskHandle = void *;

class INidaqmxDriver
{
public:
    virtual ~INidaqmxDriver() = default;

    [[nodiscard]] virtual bool load(QString *diagnostic) = 0;
    [[nodiscard]] virtual bool isLoaded() const = 0;
    [[nodiscard]] virtual NidaqmxStatus deviceProductType(
        const QString &deviceId,
        QString *productType) = 0;
    [[nodiscard]] virtual NidaqmxStatus createTask(NidaqmxTaskHandle *taskHandle) = 0;
    [[nodiscard]] virtual NidaqmxStatus createAiVoltageChannel(
        NidaqmxTaskHandle taskHandle,
        const QString &physicalChannel,
        double minimumV,
        double maximumV) = 0;
    [[nodiscard]] virtual NidaqmxStatus createAoVoltageChannel(
        NidaqmxTaskHandle taskHandle,
        const QString &physicalChannel,
        double minimumV,
        double maximumV) = 0;
    [[nodiscard]] virtual NidaqmxStatus configureContinuousSampleClock(
        NidaqmxTaskHandle taskHandle,
        double sampleRateHz,
        quint64 driverBufferSamplesPerChannel) = 0;
    [[nodiscard]] virtual NidaqmxStatus sampleClockRate(
        NidaqmxTaskHandle taskHandle,
        double *sampleRateHz) = 0;
    [[nodiscard]] virtual NidaqmxStatus writeAnalogF64(
        NidaqmxTaskHandle taskHandle,
        const QVector<double> &channelMajorSamples,
        qint32 samplesPerChannel,
        qint32 *samplesWrittenPerChannel) = 0;
    [[nodiscard]] virtual NidaqmxStatus startTask(NidaqmxTaskHandle taskHandle) = 0;
    [[nodiscard]] virtual NidaqmxStatus availableSamplesPerChannel(
        NidaqmxTaskHandle taskHandle,
        quint32 *availableSamples) = 0;
    [[nodiscard]] virtual NidaqmxStatus readAnalogF64(
        NidaqmxTaskHandle taskHandle,
        qint32 samplesPerChannel,
        QVector<double> *channelMajorSamples,
        qint32 *samplesReadPerChannel) = 0;
    [[nodiscard]] virtual NidaqmxStatus stopTask(NidaqmxTaskHandle taskHandle) = 0;
    [[nodiscard]] virtual NidaqmxStatus clearTask(NidaqmxTaskHandle taskHandle) = 0;
    [[nodiscard]] virtual QString errorText(NidaqmxStatus status) const = 0;
};

} // namespace tdlas::acquisition
