#include "acquisition/MockAcquisitionDevice.h"

#include <QDateTime>

#include <cmath>
#include <utility>

namespace tdlas::acquisition {

namespace {

constexpr double kPi = 3.14159265358979323846;

double gaussian(double x, double center, double width)
{
    const double normalized = (x - center) / width;
    return std::exp(-0.5 * normalized * normalized);
}

} // namespace

MockAcquisitionDevice::MockAcquisitionDevice(QObject *parent)
    : MockAcquisitionDevice(MockAcquisitionOptions{}, parent)
{
}

MockAcquisitionDevice::MockAcquisitionDevice(
    const MockAcquisitionOptions &options,
    QObject *parent)
    : IAcquisitionDevice(parent)
    , options_(options)
    , rawBuffer_(options.rawBufferCapacity)
{
    blockTimer_.setInterval(qMax(1, options_.blockIntervalMilliseconds));
    blockTimer_.setTimerType(Qt::PreciseTimer);
    connect(&blockTimer_, &QTimer::timeout, this, &MockAcquisitionDevice::generateBlock);
}

contracts::DeviceConnectionState MockAcquisitionDevice::connectionState() const
{
    return connectionState_;
}

contracts::AcquisitionState MockAcquisitionDevice::acquisitionState() const
{
    return acquisitionState_;
}

bool MockAcquisitionDevice::connectDevice(const QString &deviceId)
{
    if (connectionState_ == contracts::DeviceConnectionState::Connected) {
        return deviceId == QStringLiteral("mock-acquisition-0");
    }
    if (deviceId != QStringLiteral("mock-acquisition-0")) {
        setConnectionState(contracts::DeviceConnectionState::Faulted);
        reportError(QStringLiteral("MOCK_DEVICE_NOT_FOUND"), QStringLiteral("未找到模拟采集设备。"), deviceId);
        return false;
    }
    setConnectionState(contracts::DeviceConnectionState::Connecting);
    setConnectionState(contracts::DeviceConnectionState::Connected);
    return true;
}

bool MockAcquisitionDevice::disconnectDevice()
{
    if (connectionState_ == contracts::DeviceConnectionState::Disconnected) {
        return true;
    }
    if (acquisitionState_ != contracts::AcquisitionState::Idle) {
        if (!stop()) {
            return false;
        }
    }
    setConnectionState(contracts::DeviceConnectionState::Disconnecting);
    parameters_ = {};
    runId_ = {};
    rawBuffer_.clear();
    setConnectionState(contracts::DeviceConnectionState::Disconnected);
    return true;
}

bool MockAcquisitionDevice::configure(const contracts::ParameterSnapshot &snapshot)
{
    if (connectionState_ != contracts::DeviceConnectionState::Connected
        || acquisitionState_ != contracts::AcquisitionState::Idle) {
        reportError(QStringLiteral("MOCK_CONFIGURE_STATE"), QStringLiteral("模拟设备当前不能配置。"), QStringLiteral("device is not connected and idle"));
        return false;
    }
    QString diagnostic;
    if (!snapshot.isValid(&diagnostic) || snapshot.deviceId != QStringLiteral("mock-acquisition-0")) {
        reportError(QStringLiteral("MOCK_CONFIGURE_INVALID"), QStringLiteral("模拟采集参数无效。"), diagnostic);
        return false;
    }
    setAcquisitionState(contracts::AcquisitionState::Configuring);
    parameters_ = snapshot;
    setAcquisitionState(contracts::AcquisitionState::Idle);
    return true;
}

bool MockAcquisitionDevice::start(const contracts::RunId &runId)
{
    if (acquisitionState_ == contracts::AcquisitionState::Running) {
        return runId == runId_;
    }
    if (connectionState_ != contracts::DeviceConnectionState::Connected
        || acquisitionState_ != contracts::AcquisitionState::Idle
        || !runId.isValid() || parameters_.id.isEmpty()) {
        reportError(QStringLiteral("MOCK_START_STATE"), QStringLiteral("模拟采集无法启动。"), QStringLiteral("device is not configured and idle"));
        return false;
    }

    runId_ = runId;
    sequence_ = 0;
    generatedSampleCount_ = 0;
    rawBuffer_.clear();
    drainScheduled_ = false;
    monotonicClock_.start();
    setAcquisitionState(contracts::AcquisitionState::Running);
    blockTimer_.start();
    QTimer::singleShot(0, this, &MockAcquisitionDevice::generateBlock);
    return true;
}

bool MockAcquisitionDevice::stop()
{
    if (acquisitionState_ == contracts::AcquisitionState::Idle) {
        return true;
    }
    if (acquisitionState_ != contracts::AcquisitionState::Running
        && acquisitionState_ != contracts::AcquisitionState::Stopping
        && acquisitionState_ != contracts::AcquisitionState::Faulted) {
        return false;
    }
    if (acquisitionState_ != contracts::AcquisitionState::Faulted) {
        setAcquisitionState(contracts::AcquisitionState::Stopping);
    }
    blockTimer_.stop();
    rawBuffer_.clear();
    drainScheduled_ = false;
    setAcquisitionState(contracts::AcquisitionState::Idle);
    return true;
}

qsizetype MockAcquisitionDevice::bufferedBlockCount() const
{
    return rawBuffer_.size();
}

quint64 MockAcquisitionDevice::droppedBlockCount() const
{
    return rawBuffer_.droppedBlockCount();
}

void MockAcquisitionDevice::generateBlock()
{
    if (acquisitionState_ != contracts::AcquisitionState::Running) {
        return;
    }
    if (options_.faultAfterGeneratedBlocks > 0
        && sequence_ >= options_.faultAfterGeneratedBlocks) {
        enterInjectedFault();
        return;
    }

    contracts::RawDataBlock block;
    block.runId = runId_;
    block.streamId = QStringLiteral("mock-ai-stream-0");
    block.sequence = ++sequence_;
    block.sampleStart.utc = QDateTime::currentDateTimeUtc();
    block.sampleStart.monotonicNanoseconds = monotonicClock_.nsecsElapsed();
    block.sampleRateHz = parameters_.sampleRateHz;
    block.sampleCountPerChannel = parameters_.readSamplesPerBlock;
    block.validity = contracts::DataValidity::Valid;
    block.diagnostic = QStringLiteral("deterministic mock acquisition");

    const bool reference = parameters_.algorithmParameterSetId == QStringLiteral("tdlas-v1.6-reference");
    const double cycleSamples = reference ? 500.0 : parameters_.sampleRateHz
        / (parameters_.aoEnabled ? parameters_.outputFrequencyHz : 20.0);
    for (const QString &channelId : parameters_.aiChannelIds) {
        contracts::ChannelSamples channel;
        channel.channelId = channelId;
        channel.samplesV.reserve(parameters_.readSamplesPerBlock);
        for (qsizetype index = 0; index < parameters_.readSamplesPerBlock; ++index) {
            const double sample = static_cast<double>(generatedSampleCount_ + static_cast<quint64>(index));
            const double phase = std::fmod(sample, cycleSamples) / cycleSamples;
            const double carrier = 0.015 * std::sin(2.0 * kPi * phase * 17.0);
            // UI simulation is a continuous 20 Hz sawtooth with cycle-varying
            // absorption and deterministic sensor noise, independent of read size.
            const double cycle = std::floor(sample / cycleSamples);
            const double depth = 0.10 * (1.0 + 0.30 * std::sin(cycle * 0.71));
            const double noise = 0.002 * std::sin(sample * 1.738)
                + 0.001 * std::sin(sample * 0.317);
            const double voltage = reference
                ? 0.92 - 0.56 * gaussian(phase, 0.52, 0.075) + carrier
                : 0.70 + 0.50 * phase - depth * gaussian(phase, 0.56, 0.035) + noise;
            channel.samplesV.push_back(voltage);
        }
        block.channels.push_back(channel);
    }
    generatedSampleCount_ += static_cast<quint64>(parameters_.readSamplesPerBlock);
    rawBuffer_.push(std::move(block));
    if (!drainScheduled_) {
        drainScheduled_ = true;
        QTimer::singleShot(0, this, &MockAcquisitionDevice::drainBuffer);
    }
}

void MockAcquisitionDevice::drainBuffer()
{
    drainScheduled_ = false;
    if (acquisitionState_ != contracts::AcquisitionState::Running) {
        rawBuffer_.clear();
        return;
    }
    while (const auto block = rawBuffer_.takeOldest()) {
        emit rawDataReady(*block);
        if (acquisitionState_ != contracts::AcquisitionState::Running) {
            rawBuffer_.clear();
            return;
        }
    }
}

void MockAcquisitionDevice::enterInjectedFault()
{
    blockTimer_.stop();
    rawBuffer_.clear();
    setAcquisitionState(contracts::AcquisitionState::Faulted);
    reportError(
        QStringLiteral("MOCK_INJECTED_FAULT"),
        QStringLiteral("模拟采集发生测试故障。"),
        QStringLiteral("configured fault after %1 generated block(s)")
            .arg(options_.faultAfterGeneratedBlocks));
}

void MockAcquisitionDevice::setConnectionState(contracts::DeviceConnectionState state)
{
    if (state == connectionState_) {
        return;
    }
    connectionState_ = state;
    emit connectionStateChanged(state);
}

void MockAcquisitionDevice::setAcquisitionState(contracts::AcquisitionState state)
{
    if (state == acquisitionState_) {
        return;
    }
    acquisitionState_ = state;
    emit acquisitionStateChanged(state);
}

void MockAcquisitionDevice::reportError(const QString &code, const QString &message, const QString &diagnostic)
{
    contracts::ModuleError error;
    error.code = code;
    error.category = QStringLiteral("acquisition");
    error.userMessage = message;
    error.diagnostic = diagnostic;
    error.timestamp.utc = QDateTime::currentDateTimeUtc();
    error.retryable = true;
    error.requiresStop = acquisitionState_ == contracts::AcquisitionState::Running;
    if (runId_.isValid()) {
        error.runId = runId_;
    }
    emit errorOccurred(error);
}

} // namespace tdlas::acquisition
