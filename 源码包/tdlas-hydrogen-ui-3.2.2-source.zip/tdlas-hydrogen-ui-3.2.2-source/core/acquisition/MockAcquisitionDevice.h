#pragma once

#include "acquisition/IAcquisitionDevice.h"
#include "acquisition/RawDataBuffer.h"

#include <QElapsedTimer>
#include <QTimer>

namespace tdlas::acquisition {

struct MockAcquisitionOptions {
    int blockIntervalMilliseconds = 30;
    qsizetype rawBufferCapacity = 8;
    quint64 faultAfterGeneratedBlocks = 0;
};

class MockAcquisitionDevice final : public IAcquisitionDevice
{
    Q_OBJECT

public:
    explicit MockAcquisitionDevice(QObject *parent = nullptr);
    MockAcquisitionDevice(
        const MockAcquisitionOptions &options,
        QObject *parent = nullptr);

    [[nodiscard]] contracts::DeviceConnectionState connectionState() const override;
    [[nodiscard]] contracts::AcquisitionState acquisitionState() const override;
    [[nodiscard]] bool connectDevice(const QString &deviceId) override;
    [[nodiscard]] bool disconnectDevice() override;
    [[nodiscard]] bool configure(const contracts::ParameterSnapshot &snapshot) override;
    [[nodiscard]] bool start(const contracts::RunId &runId) override;
    [[nodiscard]] bool stop() override;
    [[nodiscard]] qsizetype bufferedBlockCount() const;
    [[nodiscard]] quint64 droppedBlockCount() const;

private:
    void generateBlock();
    void drainBuffer();
    void enterInjectedFault();
    void setConnectionState(contracts::DeviceConnectionState state);
    void setAcquisitionState(contracts::AcquisitionState state);
    void reportError(const QString &code, const QString &message, const QString &diagnostic);

    QTimer blockTimer_;
    QElapsedTimer monotonicClock_;
    MockAcquisitionOptions options_;
    RawDataBuffer rawBuffer_;
    contracts::DeviceConnectionState connectionState_ = contracts::DeviceConnectionState::Disconnected;
    contracts::AcquisitionState acquisitionState_ = contracts::AcquisitionState::Idle;
    contracts::ParameterSnapshot parameters_;
    contracts::RunId runId_;
    contracts::Sequence sequence_ = 0;
    quint64 generatedSampleCount_ = 0;
    bool drainScheduled_ = false;
};

} // namespace tdlas::acquisition
