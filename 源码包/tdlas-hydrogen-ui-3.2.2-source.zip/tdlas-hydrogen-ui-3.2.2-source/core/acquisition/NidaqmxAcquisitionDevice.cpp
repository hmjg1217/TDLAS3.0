#include "acquisition/NidaqmxAcquisitionDevice.h"

#include "acquisition/DynamicNidaqmxDriver.h"

#include <QDateTime>

#include <cmath>
#include <limits>
#include <utility>

namespace tdlas::acquisition {

namespace {

constexpr double kPi = 3.14159265358979323846;

bool succeeded(NidaqmxStatus status)
{
    return status >= 0;
}

} // namespace

NidaqmxAcquisitionDevice::NidaqmxAcquisitionDevice(QObject *parent)
    : NidaqmxAcquisitionDevice(std::make_unique<DynamicNidaqmxDriver>(), {}, parent)
{
}

NidaqmxAcquisitionDevice::NidaqmxAcquisitionDevice(
    std::unique_ptr<INidaqmxDriver> driver,
    const NidaqmxAcquisitionOptions &options,
    QObject *parent)
    : IAcquisitionDevice(parent)
    , driver_(std::move(driver))
    , options_(options)
{
    options_.pollIntervalMilliseconds = qMax(1, options_.pollIntervalMilliseconds);
    options_.acquisitionTimeoutMilliseconds = qMax(1, options_.acquisitionTimeoutMilliseconds);
    options_.driverBufferBlocks = qMax(2, options_.driverBufferBlocks);
    options_.maxBlocksPerPoll = qMax(1, options_.maxBlocksPerPoll);
    options_.maxAoWaveformSamples = qMax<qsizetype>(2, options_.maxAoWaveformSamples);
    pollTimer_.setInterval(options_.pollIntervalMilliseconds);
    pollTimer_.setTimerType(Qt::PreciseTimer);
    connect(&pollTimer_, &QTimer::timeout, this, &NidaqmxAcquisitionDevice::pollAvailableData);
}

NidaqmxAcquisitionDevice::~NidaqmxAcquisitionDevice()
{
    pollTimer_.stop();
    QString ignored;
    (void)releaseTasks(true, &ignored);
}

contracts::DeviceConnectionState NidaqmxAcquisitionDevice::connectionState() const
{
    return connectionState_;
}

contracts::AcquisitionState NidaqmxAcquisitionDevice::acquisitionState() const
{
    return acquisitionState_;
}

bool NidaqmxAcquisitionDevice::connectDevice(const QString &deviceId)
{
    const QString requestedDevice = deviceId.trimmed();
    if (connectionState_ == contracts::DeviceConnectionState::Connected) {
        return requestedDevice.compare(connectedDeviceId_, Qt::CaseInsensitive) == 0;
    }
    if (connectionState_ != contracts::DeviceConnectionState::Disconnected
        || requestedDevice.isEmpty()) {
        reportError(
            QStringLiteral("NIDAQMX_CONNECT_STATE"),
            QStringLiteral("NI 采集设备当前不能连接。"),
            QStringLiteral("connection state or device id is invalid"),
            false);
        return false;
    }

    setConnectionState(contracts::DeviceConnectionState::Connecting);
    QString diagnostic;
    if (!driver_ || !driver_->load(&diagnostic)) {
        setConnectionState(contracts::DeviceConnectionState::Faulted);
        reportError(
            QStringLiteral("NIDAQMX_DRIVER_UNAVAILABLE"),
            QStringLiteral("未安装或无法加载 NI-DAQmx 运行库。"),
            diagnostic,
            false);
        return false;
    }

    QString productType;
    const NidaqmxStatus status = driver_->deviceProductType(requestedDevice, &productType);
    if (!succeeded(status)) {
        setConnectionState(contracts::DeviceConnectionState::Faulted);
        reportError(
            QStringLiteral("NIDAQMX_DEVICE_NOT_FOUND"),
            QStringLiteral("未找到指定的 NI 采集设备。"),
            driverDiagnostic(QStringLiteral("DAQmxGetDevProductType"), status),
            false);
        return false;
    }

    connectedDeviceId_ = requestedDevice;
    connectedProductType_ = productType;
    setConnectionState(contracts::DeviceConnectionState::Connected);
    return true;
}

bool NidaqmxAcquisitionDevice::disconnectDevice()
{
    if (connectionState_ == contracts::DeviceConnectionState::Disconnected) {
        return true;
    }

    const bool stopped = stop();
    if (!stopped && (aiTask_ || aoTask_)) {
        setConnectionState(contracts::DeviceConnectionState::Faulted);
        return false;
    }
    setConnectionState(contracts::DeviceConnectionState::Disconnecting);
    connectedDeviceId_.clear();
    connectedProductType_.clear();
    parameters_ = {};
    runId_ = {};
    configured_ = false;
    actualAiSampleRateHz_ = 0.0;
    setConnectionState(contracts::DeviceConnectionState::Disconnected);
    return stopped;
}

bool NidaqmxAcquisitionDevice::configure(const contracts::ParameterSnapshot &snapshot)
{
    if (connectionState_ != contracts::DeviceConnectionState::Connected
        || acquisitionState_ != contracts::AcquisitionState::Idle) {
        reportError(
            QStringLiteral("NIDAQMX_CONFIGURE_STATE"),
            QStringLiteral("NI 采集设备当前不能配置。"),
            QStringLiteral("device is not connected and idle"),
            false);
        return false;
    }

    QString diagnostic;
    const bool dimensionsFitDriver = snapshot.readSamplesPerBlock > 0
        && snapshot.readSamplesPerBlock <= std::numeric_limits<qint32>::max()
        && snapshot.aiChannelIds.size() > 0
        && snapshot.aiChannelIds.size()
            <= std::numeric_limits<quint32>::max() / static_cast<quint32>(snapshot.readSamplesPerBlock);
    if (!snapshot.isValid(&diagnostic)
        || snapshot.deviceId.compare(connectedDeviceId_, Qt::CaseInsensitive) != 0
        || !dimensionsFitDriver) {
        reportError(
            QStringLiteral("NIDAQMX_CONFIGURE_INVALID"),
            QStringLiteral("NI 采集参数无效。"),
            diagnostic.isEmpty() ? QStringLiteral("snapshot does not match the connected device or driver limits") : diagnostic,
            false);
        return false;
    }
    for (const QString &channelId : snapshot.aiChannelIds) {
        if (!channelBelongsToConnectedDevice(channelId)) {
            reportError(
                QStringLiteral("NIDAQMX_CONFIGURE_INVALID"),
                QStringLiteral("NI 采集通道与已连接设备不匹配。"),
                channelId,
                false);
            return false;
        }
    }
    if (snapshot.aoEnabled && !channelBelongsToConnectedDevice(snapshot.aoChannelId)) {
        reportError(
            QStringLiteral("NIDAQMX_CONFIGURE_INVALID"),
            QStringLiteral("NI 输出通道与已连接设备不匹配。"),
            snapshot.aoChannelId,
            false);
        return false;
    }

    if (!releaseTasks(false, &diagnostic)) {
        setAcquisitionState(contracts::AcquisitionState::Faulted);
        reportError(
            QStringLiteral("NIDAQMX_RESOURCE_RELEASE_FAILED"),
            QStringLiteral("NI 采集资源释放失败。"),
            diagnostic,
            false);
        return false;
    }
    setAcquisitionState(contracts::AcquisitionState::Configuring);
    parameters_ = snapshot;
    actualAiSampleRateHz_ = 0.0;
    if (!configureAiTask(snapshot) || !configureAoTask(snapshot)) {
        parameters_ = {};
        actualAiSampleRateHz_ = 0.0;
        configured_ = false;
        return false;
    }

    configured_ = true;
    setAcquisitionState(contracts::AcquisitionState::Idle);
    return true;
}

bool NidaqmxAcquisitionDevice::start(const contracts::RunId &runId)
{
    if (acquisitionState_ == contracts::AcquisitionState::Running) {
        return runId == runId_;
    }
    if (connectionState_ != contracts::DeviceConnectionState::Connected
        || acquisitionState_ != contracts::AcquisitionState::Idle
        || !configured_ || !aiTask_ || !runId.isValid()) {
        reportError(
            QStringLiteral("NIDAQMX_START_STATE"),
            QStringLiteral("NI 采集无法启动。"),
            QStringLiteral("device is not configured and idle"),
            false);
        return false;
    }

    if (aoTask_) {
        const NidaqmxStatus status = driver_->startTask(aoTask_);
        if (!succeeded(status)) {
            enterRuntimeFault(
                QStringLiteral("NIDAQMX_START_FAILED"),
                QStringLiteral("NI 模拟输出无法启动。"),
                QStringLiteral("DAQmxStartTask(AO)"), status, false);
            return false;
        }
        aoStarted_ = true;
    }
    const NidaqmxStatus status = driver_->startTask(aiTask_);
    if (!succeeded(status)) {
        enterRuntimeFault(
            QStringLiteral("NIDAQMX_START_FAILED"),
            QStringLiteral("NI 模拟输入无法启动。"),
            QStringLiteral("DAQmxStartTask(AI)"), status, false);
        return false;
    }
    aiStarted_ = true;

    runId_ = runId;
    sequence_ = 0;
    emittedSamplesPerChannel_ = 0;
    runStartedUtc_ = QDateTime::currentDateTimeUtc();
    lastSampleTimer_.start();
    setAcquisitionState(contracts::AcquisitionState::Running);
    pollTimer_.start();
    QTimer::singleShot(0, this, &NidaqmxAcquisitionDevice::pollAvailableData);
    return true;
}

bool NidaqmxAcquisitionDevice::stop()
{
    pollTimer_.stop();
    if (acquisitionState_ != contracts::AcquisitionState::Idle
        && acquisitionState_ != contracts::AcquisitionState::Faulted
        && acquisitionState_ != contracts::AcquisitionState::Running
        && acquisitionState_ != contracts::AcquisitionState::Stopping) {
        return false;
    }
    if (acquisitionState_ != contracts::AcquisitionState::Idle
        && acquisitionState_ != contracts::AcquisitionState::Faulted) {
        setAcquisitionState(contracts::AcquisitionState::Stopping);
    }

    QString diagnostic;
    const bool released = releaseTasks(true, &diagnostic);
    configured_ = false;
    parameters_ = {};
    actualAiSampleRateHz_ = 0.0;
    runId_ = {};
    if (!released) {
        setAcquisitionState(contracts::AcquisitionState::Faulted);
        reportError(
            QStringLiteral("NIDAQMX_RESOURCE_RELEASE_FAILED"),
            QStringLiteral("NI 采集任务停止或释放失败。"),
            diagnostic,
            false);
        return false;
    }
    setAcquisitionState(contracts::AcquisitionState::Idle);
    return true;
}

bool NidaqmxAcquisitionDevice::configureAiTask(const contracts::ParameterSnapshot &snapshot)
{
    NidaqmxStatus status = driver_->createTask(&aiTask_);
    if (!succeeded(status)) {
        return failConfiguration(QStringLiteral("DAQmxCreateTask(AI)"), status);
    }
    for (const QString &channelId : snapshot.aiChannelIds) {
        status = driver_->createAiVoltageChannel(
            aiTask_, channelId, snapshot.inputRangeMinV, snapshot.inputRangeMaxV);
        if (!succeeded(status)) {
            return failConfiguration(
                QStringLiteral("DAQmxCreateAIVoltageChan(%1)").arg(channelId), status);
        }
    }
    const quint64 bufferSamples = static_cast<quint64>(snapshot.readSamplesPerBlock)
        * static_cast<quint64>(options_.driverBufferBlocks);
    status = driver_->configureContinuousSampleClock(aiTask_, snapshot.sampleRateHz, bufferSamples);
    if (!succeeded(status)) {
        return failConfiguration(QStringLiteral("DAQmxCfgSampClkTiming(AI)"), status);
    }
    status = driver_->sampleClockRate(aiTask_, &actualAiSampleRateHz_);
    if (!succeeded(status)) {
        return failConfiguration(QStringLiteral("DAQmxGetSampClkRate(AI)"), status);
    }
    if (!std::isfinite(actualAiSampleRateHz_) || actualAiSampleRateHz_ <= 0.0) {
        return failConfiguration(
            QStringLiteral("DAQmxGetSampClkRate(AI) returned an invalid rate"), -1);
    }
    return true;
}

bool NidaqmxAcquisitionDevice::configureAoTask(const contracts::ParameterSnapshot &snapshot)
{
    if (!snapshot.aoEnabled) {
        return true;
    }
    QString diagnostic;
    const QVector<double> waveform = createAoWaveform(snapshot, &diagnostic);
    if (waveform.isEmpty()) {
        QString ignored;
        (void)releaseTasks(false, &ignored);
        setAcquisitionState(contracts::AcquisitionState::Faulted);
        reportError(
            QStringLiteral("NIDAQMX_AO_WAVEFORM_INVALID"),
            QStringLiteral("NI 模拟输出波形参数无效。"),
            diagnostic,
            false);
        return false;
    }

    NidaqmxStatus status = driver_->createTask(&aoTask_);
    if (!succeeded(status)) {
        return failConfiguration(QStringLiteral("DAQmxCreateTask(AO)"), status);
    }
    status = driver_->createAoVoltageChannel(
        aoTask_, snapshot.aoChannelId, -10.0, 10.0);
    if (!succeeded(status)) {
        return failConfiguration(QStringLiteral("DAQmxCreateAOVoltageChan"), status);
    }
    status = driver_->configureContinuousSampleClock(
        aoTask_, snapshot.outputSampleRateHz, static_cast<quint64>(waveform.size()));
    if (!succeeded(status)) {
        return failConfiguration(QStringLiteral("DAQmxCfgSampClkTiming(AO)"), status);
    }
    double actualAoSampleRateHz = 0.0;
    status = driver_->sampleClockRate(aoTask_, &actualAoSampleRateHz);
    if (!succeeded(status)) {
        return failConfiguration(QStringLiteral("DAQmxGetSampClkRate(AO)"), status);
    }
    if (!std::isfinite(actualAoSampleRateHz) || actualAoSampleRateHz <= 0.0) {
        return failConfiguration(
            QStringLiteral("DAQmxGetSampClkRate(AO) returned an invalid rate"), -1);
    }
    const double actualOutputFrequencyHz = actualAoSampleRateHz
        / static_cast<double>(waveform.size());
    const double frequencyToleranceHz = qMax(
        1.0e-9,
        std::abs(snapshot.outputFrequencyHz) * 1.0e-9);
    if (std::abs(actualOutputFrequencyHz - snapshot.outputFrequencyHz) > frequencyToleranceHz) {
        QString ignored;
        (void)releaseTasks(false, &ignored);
        actualAiSampleRateHz_ = 0.0;
        setAcquisitionState(contracts::AcquisitionState::Faulted);
        reportError(
            QStringLiteral("NIDAQMX_AO_RATE_COERCED"),
            QStringLiteral("NI 设备不能精确生成请求的模拟输出频率。"),
            QStringLiteral("requested=%1 Hz; actual=%2 Hz; actual sample rate=%3 Hz")
                .arg(snapshot.outputFrequencyHz, 0, 'g', 17)
                .arg(actualOutputFrequencyHz, 0, 'g', 17)
                .arg(actualAoSampleRateHz, 0, 'g', 17),
            false);
        return false;
    }
    qint32 samplesWritten = 0;
    status = driver_->writeAnalogF64(
        aoTask_, waveform, static_cast<qint32>(waveform.size()), &samplesWritten);
    if (!succeeded(status)) {
        return failConfiguration(QStringLiteral("DAQmxWriteAnalogF64(AO)"), status);
    }
    if (samplesWritten != waveform.size()) {
        return failConfiguration(
            QStringLiteral("DAQmxWriteAnalogF64(AO) wrote %1 of %2 samples")
                .arg(samplesWritten)
                .arg(waveform.size()),
            -1);
    }
    return true;
}

QVector<double> NidaqmxAcquisitionDevice::createAoWaveform(
    const contracts::ParameterSnapshot &snapshot,
    QString *diagnostic) const
{
    const double exactSamples = snapshot.outputSampleRateHz / snapshot.outputFrequencyHz;
    const qint64 sampleCount = qRound64(exactSamples);
    if (!std::isfinite(exactSamples) || sampleCount < 2
        || std::abs(exactSamples - static_cast<double>(sampleCount)) > 1.0e-9
        || sampleCount > options_.maxAoWaveformSamples
        || sampleCount > std::numeric_limits<qint32>::max()) {
        if (diagnostic) {
            *diagnostic = QStringLiteral(
                "AO sample rate divided by frequency must be an integer within configured limits");
        }
        return {};
    }

    QVector<double> waveform;
    waveform.reserve(sampleCount);
    for (qint64 index = 0; index < sampleCount; ++index) {
        const double phase = static_cast<double>(index) / static_cast<double>(sampleCount);
        double normalized = 0.0;
        switch (snapshot.waveform) {
        case contracts::Waveform::Sine:
            normalized = std::sin(2.0 * kPi * phase);
            break;
        case contracts::Waveform::Square:
            normalized = phase < 0.5 ? 1.0 : -1.0;
            break;
        case contracts::Waveform::Sawtooth:
            normalized = -1.0 + 2.0 * phase;
            break;
        case contracts::Waveform::Triangle:
            normalized = 1.0 - 4.0 * std::abs(phase - 0.5);
            break;
        }
        waveform.push_back(
            snapshot.outputOffsetV + snapshot.outputAmplitudePeakV * normalized);
    }
    return waveform;
}

void NidaqmxAcquisitionDevice::pollAvailableData()
{
    if (acquisitionState_ != contracts::AcquisitionState::Running || !aiTask_) {
        return;
    }

    for (int delivered = 0; delivered < options_.maxBlocksPerPoll; ++delivered) {
        quint32 availableSamples = 0;
        const NidaqmxStatus availableStatus = driver_->availableSamplesPerChannel(
            aiTask_, &availableSamples);
        if (!succeeded(availableStatus)) {
            enterRuntimeFault(
                QStringLiteral("NIDAQMX_DEVICE_DISCONNECTED"),
                QStringLiteral("NI 采集设备读取失败或已断开。"),
                QStringLiteral("DAQmxGetReadAvailSampPerChan"),
                availableStatus,
                true);
            return;
        }
        if (availableSamples < static_cast<quint32>(parameters_.readSamplesPerBlock)) {
            if (lastSampleTimer_.isValid()
                && lastSampleTimer_.elapsed() >= options_.acquisitionTimeoutMilliseconds) {
                enterTimeoutFault();
            }
            return;
        }

        const qsizetype channelCount = parameters_.aiChannelIds.size();
        const qsizetype requestedPerChannel = parameters_.readSamplesPerBlock;
        QVector<double> samples(channelCount * requestedPerChannel);
        qint32 samplesRead = 0;
        const NidaqmxStatus readStatus = driver_->readAnalogF64(
            aiTask_, static_cast<qint32>(requestedPerChannel), &samples, &samplesRead);
        if (!succeeded(readStatus)) {
            enterRuntimeFault(
                QStringLiteral("NIDAQMX_READ_FAILED"),
                QStringLiteral("NI 采集数据读取失败。"),
                QStringLiteral("DAQmxReadAnalogF64"), readStatus, true);
            return;
        }
        if (samplesRead != requestedPerChannel) {
            enterRuntimeFault(
                QStringLiteral("NIDAQMX_SHORT_READ"),
                QStringLiteral("NI 采集返回的数据块不完整。"),
                QStringLiteral("DAQmxReadAnalogF64 returned %1 of %2 samples per channel")
                    .arg(samplesRead).arg(requestedPerChannel),
                -1,
                false);
            return;
        }

        contracts::RawDataBlock block;
        block.runId = runId_;
        block.streamId = QStringLiteral("%1:ai").arg(connectedDeviceId_);
        block.sequence = ++sequence_;
        const double elapsedMilliseconds = 1000.0
            * static_cast<double>(emittedSamplesPerChannel_) / actualAiSampleRateHz_;
        block.sampleStart.utc = runStartedUtc_.addMSecs(qRound64(elapsedMilliseconds));
        block.sampleStart.monotonicNanoseconds = qRound64(elapsedMilliseconds * 1000000.0);
        block.sampleRateHz = actualAiSampleRateHz_;
        block.sampleCountPerChannel = requestedPerChannel;
        block.validity = contracts::DataValidity::Valid;
        block.diagnostic = QStringLiteral("NI-DAQmx product=%1; sample-clock timestamp inferred")
            .arg(connectedProductType_);

        for (qsizetype channelIndex = 0; channelIndex < channelCount; ++channelIndex) {
            contracts::ChannelSamples channel;
            channel.channelId = parameters_.aiChannelIds.at(channelIndex);
            channel.samplesV.reserve(requestedPerChannel);
            const qsizetype channelOffset = channelIndex * requestedPerChannel;
            for (qsizetype sampleIndex = 0; sampleIndex < requestedPerChannel; ++sampleIndex) {
                const double value = samples.at(channelOffset + sampleIndex);
                if (!std::isfinite(value)) {
                    block.validity = contracts::DataValidity::Invalid;
                    block.diagnostic = QStringLiteral("NI-DAQmx returned NaN or Inf");
                }
                channel.samplesV.push_back(value);
            }
            block.channels.push_back(std::move(channel));
        }
        emittedSamplesPerChannel_ += static_cast<quint64>(requestedPerChannel);
        lastSampleTimer_.restart();
        emit rawDataReady(block);
        if (acquisitionState_ != contracts::AcquisitionState::Running) {
            return;
        }
    }
}

bool NidaqmxAcquisitionDevice::releaseTasks(bool stopBeforeClear, QString *diagnostic)
{
    bool success = true;
    QStringList failures;
    const auto releaseOne = [&](NidaqmxTaskHandle &task, bool &started, const QString &name) {
        if (!task) {
            started = false;
            return;
        }
        if (stopBeforeClear && started) {
            const NidaqmxStatus status = driver_->stopTask(task);
            if (!succeeded(status)) {
                success = false;
                failures.push_back(driverDiagnostic(QStringLiteral("DAQmxStopTask(%1)").arg(name), status));
            }
        }
        const NidaqmxStatus clearStatus = driver_->clearTask(task);
        if (!succeeded(clearStatus)) {
            success = false;
            failures.push_back(driverDiagnostic(QStringLiteral("DAQmxClearTask(%1)").arg(name), clearStatus));
        } else {
            task = nullptr;
        }
        started = false;
    };
    releaseOne(aiTask_, aiStarted_, QStringLiteral("AI"));
    releaseOne(aoTask_, aoStarted_, QStringLiteral("AO"));
    if (diagnostic) {
        *diagnostic = failures.join(QStringLiteral("; "));
    }
    return success;
}

bool NidaqmxAcquisitionDevice::failConfiguration(
    const QString &operation,
    NidaqmxStatus status)
{
    const QString failure = driverDiagnostic(operation, status);
    QString cleanupDiagnostic;
    (void)releaseTasks(false, &cleanupDiagnostic);
    setAcquisitionState(contracts::AcquisitionState::Faulted);
    reportError(
        QStringLiteral("NIDAQMX_CONFIGURE_FAILED"),
        QStringLiteral("NI 采集任务配置失败。"),
        cleanupDiagnostic.isEmpty()
            ? failure
            : QStringLiteral("%1; cleanup=%2").arg(failure, cleanupDiagnostic),
        false);
    return false;
}

void NidaqmxAcquisitionDevice::enterRuntimeFault(
    const QString &code,
    const QString &userMessage,
    const QString &operation,
    NidaqmxStatus status,
    bool connectionLost)
{
    pollTimer_.stop();
    const QString failure = status == -1 && operation.startsWith(QStringLiteral("DAQmxReadAnalogF64 returned"))
        ? operation
        : driverDiagnostic(operation, status);
    QString cleanupDiagnostic;
    (void)releaseTasks(true, &cleanupDiagnostic);
    configured_ = false;
    actualAiSampleRateHz_ = 0.0;
    setAcquisitionState(contracts::AcquisitionState::Faulted);
    if (connectionLost) {
        setConnectionState(contracts::DeviceConnectionState::Faulted);
    }
    reportError(
        code,
        userMessage,
        cleanupDiagnostic.isEmpty()
            ? failure
            : QStringLiteral("%1; cleanup=%2").arg(failure, cleanupDiagnostic),
        true);
}

void NidaqmxAcquisitionDevice::enterTimeoutFault()
{
    pollTimer_.stop();
    QString cleanupDiagnostic;
    (void)releaseTasks(true, &cleanupDiagnostic);
    configured_ = false;
    actualAiSampleRateHz_ = 0.0;
    setAcquisitionState(contracts::AcquisitionState::Faulted);
    QString diagnostic = QStringLiteral("no complete block received within %1 ms")
        .arg(options_.acquisitionTimeoutMilliseconds);
    if (!cleanupDiagnostic.isEmpty()) {
        diagnostic += QStringLiteral("; cleanup=%1").arg(cleanupDiagnostic);
    }
    reportError(
        QStringLiteral("NIDAQMX_READ_TIMEOUT"),
        QStringLiteral("NI 采集等待数据超时。"),
        diagnostic,
        true);
}

void NidaqmxAcquisitionDevice::setConnectionState(contracts::DeviceConnectionState state)
{
    if (state == connectionState_) {
        return;
    }
    connectionState_ = state;
    emit connectionStateChanged(state);
}

void NidaqmxAcquisitionDevice::setAcquisitionState(contracts::AcquisitionState state)
{
    if (state == acquisitionState_) {
        return;
    }
    acquisitionState_ = state;
    emit acquisitionStateChanged(state);
}

void NidaqmxAcquisitionDevice::reportError(
    const QString &code,
    const QString &userMessage,
    const QString &diagnostic,
    bool requiresStop)
{
    contracts::ModuleError error;
    error.code = code;
    error.category = QStringLiteral("acquisition.nidaqmx");
    error.severity = requiresStop
        ? contracts::ErrorSeverity::Recoverable
        : contracts::ErrorSeverity::Warning;
    error.userMessage = userMessage;
    error.diagnostic = diagnostic;
    error.timestamp.utc = QDateTime::currentDateTimeUtc();
    error.retryable = true;
    error.requiresStop = requiresStop;
    if (runId_.isValid()) {
        error.runId = runId_;
    }
    emit errorOccurred(error);
}

QString NidaqmxAcquisitionDevice::driverDiagnostic(
    const QString &operation,
    NidaqmxStatus status) const
{
    return QStringLiteral("%1 failed: status=%2; %3")
        .arg(operation)
        .arg(status)
        .arg(driver_ ? driver_->errorText(status) : QStringLiteral("driver unavailable"));
}

bool NidaqmxAcquisitionDevice::channelBelongsToConnectedDevice(const QString &channelId) const
{
    const QString prefix = connectedDeviceId_ + QLatin1Char('/');
    return channelId.trimmed().startsWith(prefix, Qt::CaseInsensitive);
}

} // namespace tdlas::acquisition
