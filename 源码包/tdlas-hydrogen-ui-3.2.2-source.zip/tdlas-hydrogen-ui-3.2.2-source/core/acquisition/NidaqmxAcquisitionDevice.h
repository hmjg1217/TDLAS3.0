#pragma once

#include "acquisition/IAcquisitionDevice.h"
#include "acquisition/INidaqmxDriver.h"

#include <QElapsedTimer>
#include <QTimer>

#include <memory>

namespace tdlas::acquisition {

struct NidaqmxAcquisitionOptions {
    int pollIntervalMilliseconds = 2;
    int acquisitionTimeoutMilliseconds = 2000;
    int driverBufferBlocks = 8;
    int maxBlocksPerPoll = 8;
    qsizetype maxAoWaveformSamples = 1000000;
};

class NidaqmxAcquisitionDevice final : public IAcquisitionDevice
{
    Q_OBJECT

public:
    explicit NidaqmxAcquisitionDevice(QObject *parent = nullptr);
    NidaqmxAcquisitionDevice(
        std::unique_ptr<INidaqmxDriver> driver,
        const NidaqmxAcquisitionOptions &options = {},
        QObject *parent = nullptr);
    ~NidaqmxAcquisitionDevice() override;

    [[nodiscard]] contracts::DeviceConnectionState connectionState() const override;
    [[nodiscard]] contracts::AcquisitionState acquisitionState() const override;
    [[nodiscard]] bool connectDevice(const QString &deviceId) override;
    [[nodiscard]] bool disconnectDevice() override;
    [[nodiscard]] bool configure(const contracts::ParameterSnapshot &snapshot) override;
    [[nodiscard]] bool start(const contracts::RunId &runId) override;
    [[nodiscard]] bool stop() override;

private:
    void pollAvailableData();
    [[nodiscard]] bool configureAiTask(const contracts::ParameterSnapshot &snapshot);
    [[nodiscard]] bool configureAoTask(const contracts::ParameterSnapshot &snapshot);
    [[nodiscard]] QVector<double> createAoWaveform(
        const contracts::ParameterSnapshot &snapshot,
        QString *diagnostic) const;
    [[nodiscard]] bool releaseTasks(bool stopBeforeClear, QString *diagnostic = nullptr);
    [[nodiscard]] bool failConfiguration(
        const QString &operation,
        NidaqmxStatus status);
    void enterRuntimeFault(
        const QString &code,
        const QString &userMessage,
        const QString &operation,
        NidaqmxStatus status,
        bool connectionLost);
    void enterTimeoutFault();
    void setConnectionState(contracts::DeviceConnectionState state);
    void setAcquisitionState(contracts::AcquisitionState state);
    void reportError(
        const QString &code,
        const QString &userMessage,
        const QString &diagnostic,
        bool requiresStop);
    [[nodiscard]] QString driverDiagnostic(
        const QString &operation,
        NidaqmxStatus status) const;
    [[nodiscard]] bool channelBelongsToConnectedDevice(const QString &channelId) const;

    std::unique_ptr<INidaqmxDriver> driver_;
    NidaqmxAcquisitionOptions options_;
    QTimer pollTimer_;
    QElapsedTimer lastSampleTimer_;
    NidaqmxTaskHandle aiTask_ = nullptr;
    NidaqmxTaskHandle aoTask_ = nullptr;
    bool aiStarted_ = false;
    bool aoStarted_ = false;
    bool configured_ = false;
    contracts::DeviceConnectionState connectionState_ = contracts::DeviceConnectionState::Disconnected;
    contracts::AcquisitionState acquisitionState_ = contracts::AcquisitionState::Idle;
    QString connectedDeviceId_;
    QString connectedProductType_;
    contracts::ParameterSnapshot parameters_;
    double actualAiSampleRateHz_ = 0.0;
    contracts::RunId runId_;
    contracts::Sequence sequence_ = 0;
    quint64 emittedSamplesPerChannel_ = 0;
    QDateTime runStartedUtc_;
};

} // namespace tdlas::acquisition
