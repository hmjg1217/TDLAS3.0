#include "acquisition/RawDataBuffer.h"

#include <utility>

namespace tdlas::acquisition {

RawDataBuffer::RawDataBuffer(qsizetype capacity)
    : capacity_(qMax<qsizetype>(1, capacity))
{
}

void RawDataBuffer::push(contracts::RawDataBlock block)
{
    quint64 droppedForBlock = 0;
    while (blocks_.size() >= capacity_) {
        blocks_.dequeue();
        ++droppedForBlock;
        ++droppedBlockCount_;
    }
    if (droppedForBlock > 0) {
        contracts::RawDataBlock &firstDelivered = blocks_.isEmpty() ? block : blocks_.head();
        firstDelivered.overrun = true;
        firstDelivered.droppedBefore += droppedForBlock;
        firstDelivered.diagnostic = firstDelivered.diagnostic.isEmpty()
            ? QStringLiteral("raw buffer dropped %1 oldest block(s)").arg(droppedForBlock)
            : QStringLiteral("%1; raw buffer dropped %2 oldest block(s)")
                  .arg(firstDelivered.diagnostic)
                  .arg(droppedForBlock);
    }
    blocks_.enqueue(std::move(block));
}

std::optional<contracts::RawDataBlock> RawDataBuffer::takeOldest()
{
    if (blocks_.isEmpty()) {
        return std::nullopt;
    }
    return blocks_.dequeue();
}

void RawDataBuffer::clear()
{
    blocks_.clear();
}

qsizetype RawDataBuffer::capacity() const
{
    return capacity_;
}

qsizetype RawDataBuffer::size() const
{
    return blocks_.size();
}

quint64 RawDataBuffer::droppedBlockCount() const
{
    return droppedBlockCount_;
}

} // namespace tdlas::acquisition
