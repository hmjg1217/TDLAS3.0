#pragma once

#include "contracts/MeasurementTypes.h"

#include <QQueue>

#include <optional>

namespace tdlas::acquisition {

class RawDataBuffer final
{
public:
    explicit RawDataBuffer(qsizetype capacity = 8);

    void push(contracts::RawDataBlock block);
    [[nodiscard]] std::optional<contracts::RawDataBlock> takeOldest();
    void clear();

    [[nodiscard]] qsizetype capacity() const;
    [[nodiscard]] qsizetype size() const;
    [[nodiscard]] quint64 droppedBlockCount() const;

private:
    qsizetype capacity_;
    QQueue<contracts::RawDataBlock> blocks_;
    quint64 droppedBlockCount_ = 0;
};

} // namespace tdlas::acquisition
