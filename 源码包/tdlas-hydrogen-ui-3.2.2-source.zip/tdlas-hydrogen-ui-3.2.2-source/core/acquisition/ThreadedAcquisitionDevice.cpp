#include "acquisition/ThreadedAcquisitionDevice.h"

#include <QMetaObject>

namespace tdlas::acquisition {

AcquisitionDeviceWorker::AcquisitionDeviceWorker(AcquisitionBackendPolicy policy, QObject *parent)
    : QObject(parent)
    , policy_(policy)
{
}

void AcquisitionDeviceWorker::initialize()
{
    if (device_) return;
    device_ = std::make_unique<HybridAcquisitionDevice>(policy_);
    connect(device_.get(), &IAcquisitionDevice::connectionStateChanged,
        this, &AcquisitionDeviceWorker::connectionStateChanged);
    connect(device_.get(), &IAcquisitionDevice::acquisitionStateChanged,
        this, &AcquisitionDeviceWorker::acquisitionStateChanged);
    connect(device_.get(), &IAcquisitionDevice::rawDataReady,
        this, &AcquisitionDeviceWorker::rawDataReady);
    connect(device_.get(), &IAcquisitionDevice::errorOccurred,
        this, &AcquisitionDeviceWorker::errorOccurred);
}

bool AcquisitionDeviceWorker::connectDeviceCommand(const QString &deviceId)
{
    return device_ && device_->connectDevice(deviceId);
}

bool AcquisitionDeviceWorker::disconnectDeviceCommand()
{
    return !device_ || device_->disconnectDevice();
}

bool AcquisitionDeviceWorker::configureCommand(const contracts::ParameterSnapshot &snapshot)
{
    return device_ && device_->configure(snapshot);
}

bool AcquisitionDeviceWorker::startCommand(const contracts::RunId &runId)
{
    return device_ && device_->start(runId);
}

bool AcquisitionDeviceWorker::stopCommand()
{
    return !device_ || device_->stop();
}

void AcquisitionDeviceWorker::shutdown()
{
    if (device_) {
        (void)device_->stop();
        (void)device_->disconnectDevice();
        device_.reset();
    }
}

ThreadedAcquisitionDevice::ThreadedAcquisitionDevice(
    AcquisitionBackendPolicy policy,
    QObject *parent)
    : IAcquisitionDevice(parent)
    , worker_(new AcquisitionDeviceWorker(policy))
    , policy_(policy)
{
    qRegisterMetaType<contracts::RawDataBlock>();
    qRegisterMetaType<contracts::ModuleError>();
    qRegisterMetaType<contracts::DeviceConnectionState>();
    qRegisterMetaType<contracts::AcquisitionState>();

    worker_->moveToThread(&workerThread_);
    connect(&workerThread_, &QThread::finished, worker_, &QObject::deleteLater);
    connect(worker_, &AcquisitionDeviceWorker::connectionStateChanged,
        this, &ThreadedAcquisitionDevice::mirrorConnectionState, Qt::QueuedConnection);
    connect(worker_, &AcquisitionDeviceWorker::acquisitionStateChanged,
        this, &ThreadedAcquisitionDevice::mirrorAcquisitionState, Qt::QueuedConnection);
    connect(worker_, &AcquisitionDeviceWorker::rawDataReady,
        this, &IAcquisitionDevice::rawDataReady, Qt::QueuedConnection);
    connect(worker_, &AcquisitionDeviceWorker::errorOccurred,
        this, &IAcquisitionDevice::errorOccurred, Qt::QueuedConnection);
    workerThread_.setObjectName(QStringLiteral("tdlas-acquisition-worker"));
    workerThread_.start();
    QMetaObject::invokeMethod(worker_, &AcquisitionDeviceWorker::initialize, Qt::QueuedConnection);
}

ThreadedAcquisitionDevice::~ThreadedAcquisitionDevice()
{
    if (workerThread_.isRunning()) {
        QMetaObject::invokeMethod(worker_, &AcquisitionDeviceWorker::shutdown, Qt::BlockingQueuedConnection);
        workerThread_.quit();
        workerThread_.wait();
    }
}

contracts::DeviceConnectionState ThreadedAcquisitionDevice::connectionState() const
{
    return static_cast<contracts::DeviceConnectionState>(connectionState_.load(std::memory_order_acquire));
}

contracts::AcquisitionState ThreadedAcquisitionDevice::acquisitionState() const
{
    return static_cast<contracts::AcquisitionState>(acquisitionState_.load(std::memory_order_acquire));
}

bool ThreadedAcquisitionDevice::connectDevice(const QString &deviceId)
{
    if (!workerThread_.isRunning() || deviceId.trimmed().isEmpty()) return false;
    return QMetaObject::invokeMethod(worker_, [worker = worker_, deviceId]() {
        (void)worker->connectDeviceCommand(deviceId);
    }, Qt::QueuedConnection);
}

bool ThreadedAcquisitionDevice::disconnectDevice()
{
    if (!workerThread_.isRunning()) return true;
    return QMetaObject::invokeMethod(worker_, [worker = worker_]() {
        (void)worker->disconnectDeviceCommand();
    }, Qt::QueuedConnection);
}

bool ThreadedAcquisitionDevice::configure(const contracts::ParameterSnapshot &snapshot)
{
    QString diagnostic;
    if (!workerThread_.isRunning() || !snapshot.isValid(&diagnostic)) return false;
    return QMetaObject::invokeMethod(worker_, [worker = worker_, snapshot]() {
        (void)worker->configureCommand(snapshot);
    }, Qt::QueuedConnection);
}

bool ThreadedAcquisitionDevice::start(const contracts::RunId &runId)
{
    if (!workerThread_.isRunning() || !runId.isValid()) return false;
    return QMetaObject::invokeMethod(worker_, [worker = worker_, runId]() {
        (void)worker->startCommand(runId);
    }, Qt::QueuedConnection);
}

bool ThreadedAcquisitionDevice::stop()
{
    if (!workerThread_.isRunning()) return true;
    return QMetaObject::invokeMethod(worker_, [worker = worker_]() {
        (void)worker->stopCommand();
    }, Qt::QueuedConnection);
}

void ThreadedAcquisitionDevice::mirrorConnectionState(contracts::DeviceConnectionState state)
{
    connectionState_.store(static_cast<int>(state), std::memory_order_release);
    emit connectionStateChanged(state);
}

void ThreadedAcquisitionDevice::mirrorAcquisitionState(contracts::AcquisitionState state)
{
    acquisitionState_.store(static_cast<int>(state), std::memory_order_release);
    emit acquisitionStateChanged(state);
}

} // namespace tdlas::acquisition
