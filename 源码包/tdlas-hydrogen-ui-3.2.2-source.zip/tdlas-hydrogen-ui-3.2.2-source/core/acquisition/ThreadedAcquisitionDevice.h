#pragma once

#include "acquisition/HybridAcquisitionDevice.h"

#include <QThread>

#include <atomic>
#include <memory>

namespace tdlas::acquisition {

class AcquisitionDeviceWorker final : public QObject
{
    Q_OBJECT

public:
    explicit AcquisitionDeviceWorker(AcquisitionBackendPolicy policy, QObject *parent = nullptr);

public slots:
    void initialize();
    bool connectDeviceCommand(const QString &deviceId);
    bool disconnectDeviceCommand();
    bool configureCommand(const contracts::ParameterSnapshot &snapshot);
    bool startCommand(const contracts::RunId &runId);
    bool stopCommand();
    void shutdown();

signals:
    void connectionStateChanged(tdlas::contracts::DeviceConnectionState state);
    void acquisitionStateChanged(tdlas::contracts::AcquisitionState state);
    void rawDataReady(const tdlas::contracts::RawDataBlock &block);
    void errorOccurred(const tdlas::contracts::ModuleError &error);

private:
    AcquisitionBackendPolicy policy_;
    std::unique_ptr<HybridAcquisitionDevice> device_;
};

// UI-facing asynchronous facade. The concrete adapter, its timers and all DAQmx
// handles are created, used and destroyed on the dedicated acquisition thread.
class ThreadedAcquisitionDevice final : public IAcquisitionDevice
{
    Q_OBJECT

public:
    explicit ThreadedAcquisitionDevice(
        AcquisitionBackendPolicy policy,
        QObject *parent = nullptr);
    ~ThreadedAcquisitionDevice() override;

    [[nodiscard]] contracts::DeviceConnectionState connectionState() const override;
    [[nodiscard]] contracts::AcquisitionState acquisitionState() const override;
    [[nodiscard]] bool connectDevice(const QString &deviceId) override;
    [[nodiscard]] bool disconnectDevice() override;
    [[nodiscard]] bool configure(const contracts::ParameterSnapshot &snapshot) override;
    [[nodiscard]] bool start(const contracts::RunId &runId) override;
    [[nodiscard]] bool stop() override;
    [[nodiscard]] AcquisitionBackendPolicy policy() const { return policy_; }

private slots:
    void mirrorConnectionState(tdlas::contracts::DeviceConnectionState state);
    void mirrorAcquisitionState(tdlas::contracts::AcquisitionState state);

private:
    QThread workerThread_;
    AcquisitionDeviceWorker *worker_ = nullptr;
    AcquisitionBackendPolicy policy_ = AcquisitionBackendPolicy::Auto;
    std::atomic<int> connectionState_{static_cast<int>(contracts::DeviceConnectionState::Disconnected)};
    std::atomic<int> acquisitionState_{static_cast<int>(contracts::AcquisitionState::Idle)};
};

} // namespace tdlas::acquisition
