#pragma once

#include "contracts/MeasurementTypes.h"

namespace tdlas::algorithm {

class IAlgorithmProcessor
{
public:
    virtual ~IAlgorithmProcessor() = default;

    [[nodiscard]] virtual contracts::ProcessingResult process(
        const contracts::RawDataBlock &block,
        const contracts::ParameterSnapshot &parameters) const = 0;
};

} // namespace tdlas::algorithm
