#include "algorithm/MockAlgorithmProcessor.h"

#include <QDateTime>

#include <algorithm>
#include <cmath>
#include <numeric>

namespace tdlas::algorithm {

namespace {

contracts::ProcessingResult invalidResult(
    const contracts::RawDataBlock &block,
    const contracts::ParameterSnapshot &parameters,
    const QString &diagnostic)
{
    contracts::ProcessingResult result;
    result.runId = block.runId;
    result.sourceSequence = block.sequence;
    result.timestamp = block.sampleStart;
    if (!result.timestamp.utc.isValid()) {
        result.timestamp.utc = QDateTime::currentDateTimeUtc();
    }
    result.parameterSnapshotId = parameters.id;
    result.algorithmVersion = QStringLiteral("mock-algorithm-v1");
    result.validity = contracts::DataValidity::Invalid;
    result.diagnostic = diagnostic;
    return result;
}

QVector<double> movingAverage(const QVector<double> &values)
{
    QVector<double> smoothed;
    smoothed.reserve(values.size());
    for (qsizetype index = 0; index < values.size(); ++index) {
        const qsizetype begin = qMax<qsizetype>(0, index - 2);
        const qsizetype end = qMin<qsizetype>(values.size() - 1, index + 2);
        double sum = 0.0;
        for (qsizetype cursor = begin; cursor <= end; ++cursor) {
            sum += values.at(cursor);
        }
        smoothed.push_back(sum / static_cast<double>(end - begin + 1));
    }
    return smoothed;
}

} // namespace

contracts::ProcessingResult MockAlgorithmProcessor::process(
    const contracts::RawDataBlock &block,
    const contracts::ParameterSnapshot &parameters) const
{
    if (!block.runId.isValid() || block.sequence == 0
        || block.validity != contracts::DataValidity::Valid || block.channels.isEmpty()) {
        return invalidResult(block, parameters, QStringLiteral("raw block is incomplete or invalid"));
    }
    const QVector<double> &samples = block.channels.constFirst().samplesV;
    if (samples.isEmpty() || samples.size() != block.sampleCountPerChannel) {
        return invalidResult(block, parameters, QStringLiteral("raw block sample count mismatch"));
    }
    if (std::any_of(samples.cbegin(), samples.cend(), [](double value) { return !std::isfinite(value); })) {
        return invalidResult(block, parameters, QStringLiteral("raw block contains a non-finite sample"));
    }

    contracts::ProcessingResult result;
    result.runId = block.runId;
    result.sourceSequence = block.sequence;
    result.timestamp.utc = QDateTime::currentDateTimeUtc();
    result.timestamp.monotonicNanoseconds = block.sampleStart.monotonicNanoseconds;
    result.parameterSnapshotId = parameters.id;
    result.algorithmVersion = QStringLiteral("mock-algorithm-v1");
    result.voltageV = samples;
    if (std::isfinite(block.sampleRateHz) && block.sampleRateHz > 0.0) {
        for (qsizetype index = 0; index < samples.size(); ++index) {
            result.timeSeconds.push_back(static_cast<double>(index) / block.sampleRateHz);
        }
    }
    result.fittedVoltageV = movingAverage(samples);
    result.baselineV.fill(1.0, samples.size());
    result.absorbance.reserve(samples.size());
    result.fittedAbsorbance.reserve(samples.size());

    for (qsizetype index = 0; index < samples.size(); ++index) {
        result.absorbance.push_back(qBound(0.0, (1.0 - samples.at(index)) * 0.16, 1.0));
        result.fittedAbsorbance.push_back(qBound(0.0, (1.0 - result.fittedVoltageV.at(index)) * 0.16, 1.0));
    }

    result.peakAbsorbance = *std::max_element(result.fittedAbsorbance.cbegin(), result.fittedAbsorbance.cend());
    const double voltageMean = std::accumulate(samples.cbegin(), samples.cend(), 0.0)
        / static_cast<double>(samples.size());
    result.lightPercent = qBound(0.0, voltageMean * 100.0, 100.0);
    result.concentration.reset();
    result.concentrationUnit.clear();
    result.validity = contracts::DataValidity::Uncalibrated;
    result.diagnostic = QStringLiteral("deterministic mock transform; concentration calibration is not configured");
    return result;
}

} // namespace tdlas::algorithm
