#pragma once

#include "algorithm/IAlgorithmProcessor.h"

namespace tdlas::algorithm {

class MockAlgorithmProcessor final : public IAlgorithmProcessor
{
public:
    [[nodiscard]] contracts::ProcessingResult process(
        const contracts::RawDataBlock &block,
        const contracts::ParameterSnapshot &parameters) const override;
};

} // namespace tdlas::algorithm
