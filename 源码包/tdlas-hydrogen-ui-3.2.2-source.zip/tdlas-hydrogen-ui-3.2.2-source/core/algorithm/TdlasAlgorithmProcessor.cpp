#include "algorithm/TdlasAlgorithmProcessor.h"

#include <QDateTime>
#include <QElapsedTimer>

#include <algorithm>
#include <array>
#include <cmath>
#include <limits>
#include <numeric>
#include <utility>

namespace tdlas::algorithm {

namespace {

constexpr double kPi = 3.14159265358979323846;
constexpr double kLogFloor = 1.0e-12;

bool finiteVector(const QVector<double> &values)
{
    return std::all_of(values.cbegin(), values.cend(), [](double value) {
        return std::isfinite(value);
    });
}

struct Biquad {
    double b0 = 0.0;
    double b1 = 0.0;
    double b2 = 0.0;
    double a1 = 0.0;
    double a2 = 0.0;
};

Biquad butterworthSection(double normalizedCutoff, double qualityFactor)
{
    const double omega = kPi * normalizedCutoff;
    const double cosine = std::cos(omega);
    const double alpha = std::sin(omega) / (2.0 * qualityFactor);
    const double a0 = 1.0 + alpha;
    Biquad section;
    section.b0 = ((1.0 - cosine) * 0.5) / a0;
    section.b1 = (1.0 - cosine) / a0;
    section.b2 = section.b0;
    section.a1 = (-2.0 * cosine) / a0;
    section.a2 = (1.0 - alpha) / a0;
    return section;
}

void filterSectionInPlace(QVector<double> &values, const Biquad &section)
{
    if (values.isEmpty()) {
        return;
    }
    const double steady = values.constFirst();
    double state1 = (1.0 - section.b0) * steady;
    double state2 = (section.b2 - section.a2) * steady;
    for (double &value : values) {
        const double output = section.b0 * value + state1;
        state1 = section.b1 * value - section.a1 * output + state2;
        state2 = section.b2 * value - section.a2 * output;
        value = output;
    }
}

QVector<double> zeroPhaseLowPass(
    const QVector<double> &input,
    double normalizedCutoff)
{
    QVector<double> output = input;
    const std::array<Biquad, 2> sections{
        butterworthSection(normalizedCutoff, 0.541196100146197),
        butterworthSection(normalizedCutoff, 1.306562964876377)};
    for (const Biquad &section : sections) {
        filterSectionInPlace(output, section);
    }
    std::reverse(output.begin(), output.end());
    for (const Biquad &section : sections) {
        filterSectionInPlace(output, section);
    }
    std::reverse(output.begin(), output.end());
    return output;
}

bool solveFiveByFive(
    std::array<std::array<double, 5>, 5> matrix,
    std::array<double, 5> right,
    std::array<double, 5> *solution)
{
    for (int column = 0; column < 5; ++column) {
        int pivot = column;
        for (int row = column + 1; row < 5; ++row) {
            if (std::abs(matrix.at(row).at(column)) > std::abs(matrix.at(pivot).at(column))) {
                pivot = row;
            }
        }
        if (std::abs(matrix.at(pivot).at(column)) < 1.0e-14) {
            return false;
        }
        if (pivot != column) {
            std::swap(matrix.at(pivot), matrix.at(column));
            std::swap(right.at(pivot), right.at(column));
        }
        const double divisor = matrix.at(column).at(column);
        for (int cursor = column; cursor < 5; ++cursor) {
            matrix.at(column).at(cursor) /= divisor;
        }
        right.at(column) /= divisor;
        for (int row = 0; row < 5; ++row) {
            if (row == column) {
                continue;
            }
            const double factor = matrix.at(row).at(column);
            for (int cursor = column; cursor < 5; ++cursor) {
                matrix.at(row).at(cursor) -= factor * matrix.at(column).at(cursor);
            }
            right.at(row) -= factor * right.at(column);
        }
    }
    *solution = right;
    return true;
}

bool polynomialBaseline(
    const QVector<double> &voltage,
    double leadingFraction,
    double trailingFraction,
    QVector<double> *baseline)
{
    const qsizetype count = voltage.size();
    if (count < 9) {
        return false;
    }
    const qsizetype leadingCount = qMax<qsizetype>(5, static_cast<qsizetype>(std::floor(leadingFraction * count)));
    const qsizetype trailingCount = qMax<qsizetype>(5, static_cast<qsizetype>(std::floor(trailingFraction * count)));
    const qsizetype trailingStart = qMax<qsizetype>(
        leadingCount,
        count - trailingCount - 1);

    std::array<std::array<double, 5>, 5> normal{};
    std::array<double, 5> right{};
    const auto addPoint = [&](qsizetype index) {
        const double coordinate = count == 1
            ? 0.0
            : (2.0 * static_cast<double>(index) / static_cast<double>(count - 1)) - 1.0;
        std::array<double, 9> powers{};
        powers.at(0) = 1.0;
        for (int power = 1; power < 9; ++power) {
            powers.at(power) = powers.at(power - 1) * coordinate;
        }
        for (int row = 0; row < 5; ++row) {
            right.at(row) += powers.at(row) * voltage.at(index);
            for (int column = 0; column < 5; ++column) {
                normal.at(row).at(column) += powers.at(row + column);
            }
        }
    };
    for (qsizetype index = 0; index < leadingCount && index < count; ++index) {
        addPoint(index);
    }
    for (qsizetype index = trailingStart; index < count; ++index) {
        addPoint(index);
    }

    std::array<double, 5> coefficients{};
    if (!solveFiveByFive(normal, right, &coefficients)) {
        return false;
    }
    baseline->clear();
    baseline->reserve(count);
    for (qsizetype index = 0; index < count; ++index) {
        const double coordinate = count == 1
            ? 0.0
            : (2.0 * static_cast<double>(index) / static_cast<double>(count - 1)) - 1.0;
        double value = coefficients.at(4);
        for (int coefficient = 3; coefficient >= 0; --coefficient) {
            value = value * coordinate + coefficients.at(coefficient);
        }
        baseline->push_back(value);
    }
    return finiteVector(*baseline);
}

struct VoigtEvaluator {
    static constexpr std::array<double, 4> a{-1.2150, -1.3509, -1.2150, -1.3509};
    static constexpr std::array<double, 4> b{1.2359, 0.3786, -1.2359, -0.3786};
    static constexpr std::array<double, 4> c{-0.3085, 0.5906, -0.3085, 0.5906};
    static constexpr std::array<double, 4> d{0.0210, -1.1858, -0.0210, 1.1858};

    double center = 0.0;
    double amplitude = 0.0;
    double gaussianWidth = 0.0;
    double lorentzianWidth = 0.0;
    double rootLogTwo = 0.0;
    double phiGaussian = 0.0;
    double widthRatio = 0.0;
    bool valid = false;

    explicit VoigtEvaluator(const VoigtParameters &parameters)
        : center(parameters.centerCm1)
        , amplitude(parameters.amplitude)
        , gaussianWidth(parameters.gaussianFwhmCm1)
        , lorentzianWidth(parameters.lorentzianFwhmCm1)
    {
        valid = std::isfinite(center)
            && std::isfinite(amplitude)
            && std::isfinite(gaussianWidth)
            && std::isfinite(lorentzianWidth)
            && gaussianWidth > 0.0
            && lorentzianWidth >= 0.0;
        if (valid) {
            rootLogTwo = std::sqrt(std::log(2.0));
            phiGaussian = (2.0 / gaussianWidth) * std::sqrt(std::log(2.0) / kPi);
            widthRatio = (lorentzianWidth / gaussianWidth) * rootLogTwo;
        }
    }

    [[nodiscard]] double value(double frequencyCm1) const
    {
        if (!valid || !std::isfinite(frequencyCm1)) {
            return std::numeric_limits<double>::quiet_NaN();
        }
        const double offset = 2.0 * rootLogTwo * (frequencyCm1 - center);
        double profile = 0.0;
        for (int term = 0; term < 4; ++term) {
            const double real = widthRatio - a.at(term);
            const double imaginary = offset / gaussianWidth - b.at(term);
            profile += phiGaussian
                * (c.at(term) * real + d.at(term) * imaginary)
                / (real * real + imaginary * imaginary);
        }
        return profile * amplitude;
    }
};

double residualSumSquares(
    const VoigtParameters &parameters,
    const QVector<double> &frequencyCm1,
    const QVector<double> &absorbance)
{
    const VoigtEvaluator evaluator(parameters);
    double residual = 0.0;
    for (qsizetype index = 0; index < frequencyCm1.size(); ++index) {
        const double fitted = evaluator.value(frequencyCm1.at(index));
        if (!std::isfinite(fitted)) {
            return std::numeric_limits<double>::infinity();
        }
        const double difference = absorbance.at(index) - fitted;
        residual += difference * difference;
    }
    return residual;
}

contracts::ProcessingResult baseResult(
    const contracts::RawDataBlock &block,
    const contracts::ParameterSnapshot &parameters,
    const TdlasAlgorithmConfig &config)
{
    contracts::ProcessingResult result;
    result.runId = block.runId;
    result.sourceSequence = block.sequence;
    result.timestamp = block.sampleStart;
    if (!result.timestamp.utc.isValid()) {
        result.timestamp.utc = QDateTime::currentDateTimeUtc();
    }
    result.parameterSnapshotId = parameters.id;
    result.algorithmVersion = config.algorithmVersion;
    result.calibrationVersion = config.frequencyCalibrationVersion;
    return result;
}

contracts::ProcessingResult invalidResult(
    const contracts::RawDataBlock &block,
    const contracts::ParameterSnapshot &parameters,
    const TdlasAlgorithmConfig &config,
    const QString &diagnostic)
{
    contracts::ProcessingResult result = baseResult(block, parameters, config);
    result.validity = contracts::DataValidity::Invalid;
    result.diagnostic = diagnostic;
    return result;
}

} // namespace

TdlasAlgorithmConfig referenceAlgorithmConfig()
{
    return {};
}

TdlasAlgorithmConfig uiAlgorithmConfig()
{
    TdlasAlgorithmConfig config;
    config.parameterSetId = QStringLiteral("tdlas-v1.6-ui");
    config.samplesPerCycle = 0;
    config.algorithmVersion = QStringLiteral("tdlas-v1.8-20-cycle-average-cpp");
    config.averagedCyclesPerSpectrum = 20;
    config.averagedSpectra = 1;
    config.windowSamples = 0;
    config.samplesPerCycleFromBlock = true;
    config.alignAtMaximum = false;
    config.useMeasuredVoigtSeed = true;
    return config;
}

bool isValidConfig(const TdlasAlgorithmConfig &config, QString *diagnostic)
{
    QString reason;
    const bool dynamic = config.samplesPerCycleFromBlock;
    if (config.parameterSetId.trimmed().isEmpty() || config.algorithmVersion.trimmed().isEmpty()
        || config.frequencyCalibrationVersion.trimmed().isEmpty()) {
        reason = QStringLiteral("algorithm or calibration version is empty");
    } else if ((!dynamic && config.samplesPerCycle < 16)
        || config.averagedCyclesPerSpectrum <= 0 || config.averagedSpectra <= 0) {
        reason = QStringLiteral("cycle and averaging counts are invalid");
    } else if ((!dynamic && config.windowSamples
                   < config.samplesPerCycle * config.averagedCyclesPerSpectrum * config.averagedSpectra)
        || (dynamic && (config.samplesPerCycle != 0 || config.windowSamples != 0))) {
        reason = QStringLiteral("algorithm window is smaller than the required averaging window");
    } else if (!std::isfinite(config.lowPassNormalizedCutoff)
        || config.lowPassNormalizedCutoff <= 0.0 || config.lowPassNormalizedCutoff >= 1.0) {
        reason = QStringLiteral("low-pass cutoff must be between zero and one");
    } else if (!std::isfinite(config.voltageOffsetV)
        || config.cropStartFraction <= 0.0 || config.cropStartFraction >= config.cropEndFraction
        || config.cropEndFraction > 1.0 || config.baselineLeadingFraction <= 0.0
        || config.baselineTrailingFraction <= 0.0
        || config.baselineLeadingFraction + config.baselineTrailingFraction >= 1.0
        || !std::isfinite(config.frequencyScale) || config.frequencyScale == 0.0) {
        reason = QStringLiteral("preprocessing or frequency calibration settings are invalid");
    }
    if (diagnostic) {
        *diagnostic = reason;
    }
    return reason.isEmpty();
}

QVector<double> evaluateVoigt(
    const VoigtParameters &parameters,
    const QVector<double> &frequencyCm1)
{
    const VoigtEvaluator evaluator(parameters);
    QVector<double> values;
    values.reserve(frequencyCm1.size());
    for (double frequency : frequencyCm1) {
        values.push_back(evaluator.value(frequency));
    }
    return values;
}

VoigtParameters fitVoigt(
    const QVector<double> &frequencyCm1,
    const QVector<double> &absorbance,
    bool initializeFromData)
{
    VoigtParameters result;
    if (frequencyCm1.isEmpty() || frequencyCm1.size() != absorbance.size()
        || !finiteVector(frequencyCm1) || !finiteVector(absorbance)) {
        result.diagnostic = QStringLiteral("Voigt inputs must be finite, non-empty, and equal in length");
        return result;
    }

    constexpr std::array<double, 4> lower{-0.5, 0.0, 0.001, 0.001};
    constexpr std::array<double, 4> upper{0.5, 0.2, 0.5, 0.5};
    std::array<double, 4> values{0.0, 0.004, 0.05, 0.05};
    std::array<double, 4> steps{0.25, 0.05, 0.12475, 0.12475};
    const auto makeParameters = [](const std::array<double, 4> &candidate) {
        VoigtParameters parameters;
        parameters.centerCm1 = candidate.at(0);
        parameters.amplitude = candidate.at(1);
        parameters.gaussianFwhmCm1 = candidate.at(2);
        parameters.lorentzianFwhmCm1 = candidate.at(3);
        return parameters;
    };

    if (initializeFromData && frequencyCm1.size() > 1) {
        const qsizetype peak = std::distance(absorbance.cbegin(),
            std::max_element(absorbance.cbegin(), absorbance.cend()));
        qsizetype left = peak, right = peak;
        const double halfPeak = qMax(0.0, absorbance.at(peak)) * 0.5;
        while (left > 0 && absorbance.at(left) > halfPeak) --left;
        while (right + 1 < absorbance.size() && absorbance.at(right) > halfPeak) ++right;
        const double width = qBound(0.002, std::abs(frequencyCm1.at(right) - frequencyCm1.at(left)), 0.5);
        values = {qBound(-0.5, frequencyCm1.at(peak), 0.5), 0.004,
            qBound(0.001, width * 0.8, 0.5), qBound(0.001, width * 0.2, 0.5)};
        steps = {width * 0.25, 0.0, width * 0.25, width * 0.25};
    }
    const auto candidateResidual = [&](std::array<double, 4> &candidate) {
        if (initializeFromData) {
            // Amplitude is linear: solve its bounded least-squares value at
            // each center/width candidate instead of trapping all four
            // coordinates in the broad, almost-flat legacy local minimum.
            auto unit = makeParameters(candidate);
            unit.amplitude = 1.0;
            const VoigtEvaluator evaluator(unit);
            double numerator = 0.0, denominator = 0.0;
            for (qsizetype i = 0; i < frequencyCm1.size(); ++i) {
                const double profile = evaluator.value(frequencyCm1.at(i));
                numerator += profile * absorbance.at(i);
                denominator += profile * profile;
            }
            candidate[1] = denominator > 0.0 ? qBound(0.0, numerator / denominator, 0.2) : 0.0;
        }
        return residualSumSquares(makeParameters(candidate), frequencyCm1, absorbance);
    };

    double bestResidual = candidateResidual(values);
    for (int iteration = 0; iteration < 1000; ++iteration) {
        bool improved = false;
        for (int parameter = 0; parameter < 4; ++parameter) {
            if (initializeFromData && parameter == 1) continue;
            for (double direction : {-1.0, 1.0}) {
                std::array<double, 4> candidate = values;
                candidate.at(parameter) = qBound(
                    lower.at(parameter),
                    candidate.at(parameter) + direction * steps.at(parameter),
                    upper.at(parameter));
                const double residual = candidateResidual(candidate);
                if (residual + 1.0e-18 < bestResidual) {
                    values = candidate;
                    bestResidual = residual;
                    improved = true;
                }
            }
        }
        if (!improved) {
            for (double &step : steps) {
                step *= 0.5;
            }
            if (*std::max_element(steps.cbegin(), steps.cend()) < 1.0e-8) {
                break;
            }
        }
    }

    result = makeParameters(values);
    result.residualSumSquares = bestResidual;
    result.valid = std::isfinite(bestResidual);
    result.diagnostic = result.valid
        ? (initializeFromData ? QStringLiteral("single-cycle Voigt fit with measured-width seed and projected amplitude")
                              : QStringLiteral("bounded coordinate-search Voigt fit"))
        : QStringLiteral("Voigt optimizer did not produce a finite residual");
    return result;
}

TdlasSpectrumResult processTdlasWindow(
    const QVector<double> &voltageSamplesV,
    const TdlasAlgorithmConfig &config,
    TdlasStageTimings *timings)
{
    QElapsedTimer totalTimer;
    if (timings) {
        *timings = {};
        totalTimer.start();
    }
    TdlasSpectrumResult result;
    QString configDiagnostic;
    if (!isValidConfig(config, &configDiagnostic) || config.samplesPerCycleFromBlock) {
        result.diagnostic = config.samplesPerCycleFromBlock
            ? QStringLiteral("dynamic UI algorithm config must be resolved before window processing")
            : configDiagnostic;
        return result;
    }
    const qsizetype requiredSamples = config.samplesPerCycle
        * config.averagedCyclesPerSpectrum * config.averagedSpectra;
    if (voltageSamplesV.size() < config.windowSamples || config.windowSamples < requiredSamples) {
        result.diagnostic = QStringLiteral("algorithm window is incomplete: %1/%2 samples")
            .arg(voltageSamplesV.size()).arg(config.windowSamples);
        return result;
    }
    if (!finiteVector(voltageSamplesV)) {
        result.diagnostic = QStringLiteral("algorithm window contains a non-finite voltage sample");
        return result;
    }

    const qsizetype sourceStart = voltageSamplesV.size() - requiredSamples;
    const QVector<double> source = voltageSamplesV.mid(sourceStart, requiredSamples);
    QElapsedTimer stageTimer;
    if (timings) stageTimer.start();
    const QVector<double> filtered = zeroPhaseLowPass(source, config.lowPassNormalizedCutoff);
    if (timings) {
        timings->filterNs = stageTimer.nsecsElapsed();
        stageTimer.restart();
    }
    const qsizetype cropStart = qBound<qsizetype>(
        0,
        static_cast<qsizetype>(std::floor(config.cropStartFraction * config.samplesPerCycle)) - 1,
        config.samplesPerCycle - 1);
    const qsizetype cropEnd = qBound<qsizetype>(
        cropStart,
        static_cast<qsizetype>(std::floor(config.cropEndFraction * config.samplesPerCycle)) - 1,
        config.samplesPerCycle - 1);
    const qsizetype croppedCount = cropEnd - cropStart + 1;
    result.voltageV.fill(0.0, croppedCount);
    result.baselineV.fill(0.0, croppedCount);
    result.absorbance.fill(0.0, croppedCount);

    for (qsizetype spectrum = 0; spectrum < config.averagedSpectra; ++spectrum) {
        QVector<double> averagedCycle(config.samplesPerCycle, 0.0);
        for (qsizetype cycle = 0; cycle < config.averagedCyclesPerSpectrum; ++cycle) {
            const qsizetype cycleStart = (spectrum * config.averagedCyclesPerSpectrum + cycle)
                * config.samplesPerCycle;
            for (qsizetype sample = 0; sample < config.samplesPerCycle; ++sample) {
                averagedCycle[sample] += filtered.at(cycleStart + sample);
            }
        }
        for (double &value : averagedCycle) {
            value /= static_cast<double>(config.averagedCyclesPerSpectrum);
        }
        const auto maximum = std::max_element(averagedCycle.cbegin(), averagedCycle.cend());
        const qsizetype maximumIndex = config.alignAtMaximum
            ? std::distance(averagedCycle.cbegin(), maximum) : 0;
        QVector<double> alignedCycle;
        alignedCycle.reserve(config.samplesPerCycle);
        for (qsizetype sample = 0; sample < config.samplesPerCycle; ++sample) {
            alignedCycle.push_back(
                averagedCycle.at((maximumIndex + sample) % config.samplesPerCycle)
                + config.voltageOffsetV);
        }
        if (spectrum == 0) {
            const qsizetype lightReference = qMin<qsizetype>(49, alignedCycle.size() - 1);
            result.lightPercent = (alignedCycle.constLast() - alignedCycle.at(lightReference)) * 50.0;
        }

        const QVector<double> cropped = alignedCycle.mid(cropStart, croppedCount);
        QVector<double> baseline;
        QElapsedTimer baselineTimer;
        if (timings) baselineTimer.start();
        if (!polynomialBaseline(
                cropped,
                config.baselineLeadingFraction,
                config.baselineTrailingFraction,
                &baseline)) {
            result.diagnostic = QStringLiteral("fourth-order baseline fit is singular or non-finite");
            return result;
        }
        if (timings) timings->baselineFitNs += baselineTimer.nsecsElapsed();
        for (qsizetype sample = 0; sample < croppedCount; ++sample) {
            const double voltage = cropped.at(sample);
            const double baselineVoltage = baseline.at(sample);
            const double absorbance = std::log(
                qMax(kLogFloor, baselineVoltage) / qMax(kLogFloor, voltage));
            if (!std::isfinite(absorbance)) {
                result.diagnostic = QStringLiteral("absorbance calculation produced a non-finite value");
                return result;
            }
            result.voltageV[sample] += voltage;
            result.baselineV[sample] += baselineVoltage;
            result.absorbance[sample] += absorbance;
        }
    }
    const double spectra = static_cast<double>(config.averagedSpectra);
    for (qsizetype sample = 0; sample < croppedCount; ++sample) {
        result.voltageV[sample] /= spectra;
        result.baselineV[sample] /= spectra;
        result.absorbance[sample] /= spectra;
    }

    const qsizetype peakIndex = std::distance(
        result.absorbance.cbegin(),
        std::max_element(result.absorbance.cbegin(), result.absorbance.cend()));
    QVector<double> mappedFrequency;
    mappedFrequency.reserve(croppedCount);
    for (qsizetype sample = 0; sample < croppedCount; ++sample) {
        const double x = static_cast<double>(sample + 1);
        const auto &coefficient = config.frequencyPolynomial;
        mappedFrequency.push_back(
            ((coefficient.at(0) * x + coefficient.at(1)) * x + coefficient.at(2)) * x
            + coefficient.at(3));
    }
    const double peakFrequency = mappedFrequency.at(peakIndex);
    result.relativeFrequencyCm1.reserve(croppedCount);
    for (double frequency : mappedFrequency) {
        result.relativeFrequencyCm1.push_back((frequency - peakFrequency) * config.frequencyScale);
    }

    if (timings) {
        timings->preprocessingNs = stageTimer.nsecsElapsed() - timings->baselineFitNs;
        stageTimer.restart();
    }
    result.voigt = fitVoigt(result.relativeFrequencyCm1, result.absorbance, config.useMeasuredVoigtSeed);
    if (timings) {
        timings->voigtFitNs = stageTimer.nsecsElapsed();
        stageTimer.restart();
    }
    if (!result.voigt.valid) {
        result.diagnostic = result.voigt.diagnostic;
        return result;
    }
    result.fittedAbsorbance = evaluateVoigt(result.voigt, result.relativeFrequencyCm1);
    result.fittedVoltageV.reserve(croppedCount);
    for (qsizetype sample = 0; sample < croppedCount; ++sample) {
        result.fittedVoltageV.push_back(
            result.baselineV.at(sample) * std::exp(-result.fittedAbsorbance.at(sample)));
    }
    if (!finiteVector(result.fittedAbsorbance) || !finiteVector(result.fittedVoltageV)) {
        result.diagnostic = QStringLiteral("fitted curve contains a non-finite value");
        return result;
    }
    result.peakAbsorbance = *std::max_element(
        result.fittedAbsorbance.cbegin(), result.fittedAbsorbance.cend());
    result.sampleOffset = cropStart;
    result.cycleSamples = config.samplesPerCycle;
    result.valid = true;
    result.diagnostic = QStringLiteral(
        "v1.6 spectral processing succeeded; hydrogen concentration calibration is unavailable");
    if (timings) {
        timings->resultAssemblyNs = stageTimer.nsecsElapsed();
        timings->totalNs = totalTimer.nsecsElapsed();
    }
    return result;
}

TdlasAlgorithmProcessor::TdlasAlgorithmProcessor(TdlasAlgorithmConfig config)
    : config_(std::move(config))
{
}

TdlasAlgorithmConfig TdlasAlgorithmProcessor::resolvedConfig(
    const contracts::RawDataBlock &block,
    const contracts::ParameterSnapshot &parameters) const
{
    TdlasAlgorithmConfig resolved = config_;
    if (resolved.samplesPerCycleFromBlock) {
        // This is a nominal period used only to validate detected reset edges.
        // The acquisition read size is not a physical period.
        const double nominal = parameters.aoEnabled && parameters.outputFrequencyHz > 0.0
            ? block.sampleRateHz / parameters.outputFrequencyHz : 0.0;
        resolved.samplesPerCycle = nominal >= 16.0 && nominal <= 1000000.0
            ? static_cast<qsizetype>(std::llround(nominal)) : 16;
        resolved.windowSamples = resolved.samplesPerCycle
            * resolved.averagedCyclesPerSpectrum * resolved.averagedSpectra;
        resolved.samplesPerCycleFromBlock = false;
    }
    return resolved;
}

void TdlasAlgorithmProcessor::resetStream(
    const contracts::RunId &runId,
    const QString &parameterSnapshotId) const
{
    bufferedRunId_ = runId;
    bufferedParameterSnapshotId_ = parameterSnapshotId;
    lastSequence_ = 0;
    sampleBufferV_.clear();
    bufferedResetPolarity_ = 0;
    bufferedSampleRateHz_ = 0.0;
}

contracts::ProcessingResult TdlasAlgorithmProcessor::process(
    const contracts::RawDataBlock &block,
    const contracts::ParameterSnapshot &parameters) const
{
    TdlasAlgorithmConfig resolved = resolvedConfig(block, parameters);
    QString configDiagnostic;
    if (!isValidConfig(resolved, &configDiagnostic)) {
        return invalidResult(block, parameters, resolved, configDiagnostic);
    }
    if (!block.runId.isValid() || block.sequence == 0
        || block.validity != contracts::DataValidity::Valid || block.channels.isEmpty()
        || block.sampleCountPerChannel != parameters.readSamplesPerBlock
        || !std::isfinite(block.sampleRateHz) || block.sampleRateHz <= 0.0) {
        return invalidResult(block, parameters, resolved, QStringLiteral("raw block is incomplete or invalid"));
    }
    if (parameters.algorithmParameterSetId != config_.parameterSetId) {
        return invalidResult(
            block,
            parameters,
            resolved,
            QStringLiteral("algorithm parameter set mismatch: expected %1, received %2")
                .arg(config_.parameterSetId, parameters.algorithmParameterSetId));
    }
    const QString expectedChannel = parameters.aiChannelIds.isEmpty()
        ? QString()
        : parameters.aiChannelIds.constFirst();
    const auto channel = std::find_if(
        block.channels.cbegin(), block.channels.cend(), [&](const contracts::ChannelSamples &candidate) {
            return candidate.channelId == expectedChannel;
        });
    if (channel == block.channels.cend() || channel->samplesV.isEmpty()
        || channel->samplesV.size() != block.sampleCountPerChannel
        || !finiteVector(channel->samplesV)) {
        return invalidResult(
            block, parameters, resolved, QStringLiteral("selected AI channel is missing or contains invalid samples"));
    }

    if (block.runId != bufferedRunId_ || parameters.id != bufferedParameterSnapshotId_) {
        resetStream(block.runId, parameters.id);
    }
    const bool discontinuity = lastSequence_ > 0 && block.sequence != lastSequence_ + 1;
    if (discontinuity || block.overrun || block.droppedBefore > 0
        || bufferedSampleRateHz_ != block.sampleRateHz) {
        sampleBufferV_.clear();
        bufferedResetPolarity_ = 0;
    }
    bufferedSampleRateHz_ = block.sampleRateHz;
    lastSequence_ = block.sequence;
    sampleBufferV_ += channel->samplesV;

    contracts::ProcessingResult result = baseResult(block, parameters, resolved);
    if (!config_.samplesPerCycleFromBlock && sampleBufferV_.size() < resolved.windowSamples) {
        result.validity = contracts::DataValidity::Incomplete;
        result.diagnostic = QStringLiteral("assembling aligned algorithm window: %1/%2 samples")
            .arg(sampleBufferV_.size()).arg(resolved.windowSamples);
        if (discontinuity || block.overrun || block.droppedBefore > 0) {
            result.diagnostic.prepend(QStringLiteral("stream discontinuity reset; "));
        }
        return result;
    }

    QVector<double> window;
    QVector<double> sourceCycle;
    double cycleSampleIntervalSeconds = 1.0 / block.sampleRateHz;
    if (config_.samplesPerCycleFromBlock) {
        // Assemble disjoint groups of complete physical cycles, independent of
        // read boundaries. Fit only once, after averaging the same source shown
        // in the voltage chart. Both plots then travel in one ProcessingResult.
        const qsizetype cycleCount = config_.averagedCyclesPerSpectrum * config_.averagedSpectra;
        const double nominal = parameters.aoEnabled && parameters.outputFrequencyHz > 0.0
            ? block.sampleRateHz / parameters.outputFrequencyHz : 0.0;
        const qsizetype capacity = nominal >= 16.0 && nominal <= 1000000.0
            ? static_cast<qsizetype>(std::ceil(nominal * (cycleCount + 2) * 1.2))
                + block.sampleCountPerChannel + 64
            : qMax<qsizetype>(1000000, block.sampleCountPerChannel);
        if (sampleBufferV_.size() > capacity) {
            sampleBufferV_.remove(0, sampleBufferV_.size() - capacity);
            bufferedResetPolarity_ = 0;
        }
        const auto range = std::minmax_element(sampleBufferV_.cbegin(), sampleBufferV_.cend());
        const double span = *range.second - *range.first;
        const qsizetype lag = nominal >= 16.0
            ? qBound(qsizetype(1), static_cast<qsizetype>(std::ceil(nominal * 0.03)), qsizetype(64))
            : qBound(qsizetype(1), sampleBufferV_.size() / 100, qsizetype(32));
        const qsizetype minimumPeriod = nominal >= 16.0
            ? qMax<qsizetype>(16, static_cast<qsizetype>(nominal * 0.8)) : 16;
        QVector<qsizetype> selectedEdges;
        int selectedPolarity = 0;
        for (int polarity : {-1, 1}) {
            QVector<qsizetype> edges;
            if (bufferedResetPolarity_ == polarity) edges.push_back(0);
            for (qsizetype i = 0; span > 1.0e-9 && i + lag < sampleBufferV_.size(); ++i) {
                if (polarity * (sampleBufferV_.at(i + lag) - sampleBufferV_.at(i)) < span * 0.5) continue;
                // Locate the end of a reset even when it spans several AI samples.
                qsizetype edge = i + 1;
                for (qsizetype j = i + 2; j <= i + lag; ++j) {
                    if (polarity * sampleBufferV_.at(j) > polarity * sampleBufferV_.at(edge)) edge = j;
                }
                if (edges.isEmpty() || edge - edges.constLast() >= minimumPeriod) {
                    if (!edges.isEmpty() && nominal >= 16.0 && edge - edges.constLast() > nominal * 1.2) {
                        edges.clear(); // A missing reset breaks the consecutive group.
                    }
                    edges.push_back(edge);
                    if (edges.size() == cycleCount + 1) {
                        if (selectedEdges.isEmpty() || edge > selectedEdges.constLast()) {
                            selectedEdges = edges;
                            selectedPolarity = polarity;
                        }
                        // The result interface publishes at most one snapshot
                        // per read. If a read spans several groups, use the last
                        // completed group and retain the unfinished next group.
                        edges = {edge};
                    }
                }
                i = edge;
            }
        }
        if (selectedEdges.isEmpty()) {
            result.validity = contracts::DataValidity::Incomplete;
            result.diagnostic = QStringLiteral("waiting for %1 consecutive complete sawtooth cycles").arg(cycleCount);
            return result;
        }
        const qsizetype cycleStart = selectedEdges.constFirst();
        const qsizetype cycleEnd = selectedEdges.constLast();
        const qsizetype samplesPerCycle = selectedEdges.at(1) - cycleStart;
        sourceCycle.fill(0.0, samplesPerCycle + 1);
        for (qsizetype cycle = 0; cycle < cycleCount; ++cycle) {
            const qsizetype start = selectedEdges.at(cycle);
            const qsizetype length = selectedEdges.at(cycle + 1) - start;
            // Align reset-to-reset phase when AI sampling yields a one-sample
            // period variation. Retain the return endpoint for the full plot.
            for (qsizetype sample = 0; sample <= samplesPerCycle; ++sample) {
                const double position = static_cast<double>(sample) * length / samplesPerCycle;
                const qsizetype left = static_cast<qsizetype>(position);
                const qsizetype right = qMin(left + 1, length);
                const double fraction = position - left;
                sourceCycle[sample] += (sampleBufferV_.at(start + left) * (1.0 - fraction)
                    + sampleBufferV_.at(start + right) * fraction) / static_cast<double>(cycleCount);
            }
        }
        window = sourceCycle.mid(0, samplesPerCycle);
        cycleSampleIntervalSeconds = static_cast<double>(cycleEnd - cycleStart)
            / (static_cast<double>(cycleCount) * samplesPerCycle * block.sampleRateHz);
        const double startOffsetSeconds = static_cast<double>(
            cycleStart - (sampleBufferV_.size() - block.sampleCountPerChannel)) / block.sampleRateHz;
        result.timestamp.utc = block.sampleStart.utc.addMSecs(qRound64(startOffsetSeconds * 1000.0));
        result.timestamp.monotonicNanoseconds += qRound64(startOffsetSeconds * 1.0e9);
        sampleBufferV_.remove(0, cycleEnd);
        bufferedResetPolarity_ = selectedPolarity;
        resolved.samplesPerCycle = window.size();
        resolved.windowSamples = window.size();
        resolved.averagedCyclesPerSpectrum = 1;
        resolved.averagedSpectra = 1;
    } else {
        window = sampleBufferV_.mid(sampleBufferV_.size() - resolved.windowSamples, resolved.windowSamples);
        sampleBufferV_.clear();
    }
    const TdlasSpectrumResult spectrum = processTdlasWindow(window, resolved);
    if (!spectrum.valid) {
        return invalidResult(block, parameters, resolved, spectrum.diagnostic);
    }

    result.relativeFrequencyCm1 = spectrum.relativeFrequencyCm1;
    result.cycleVoltageV = sourceCycle;
    result.cycleTimeSeconds.reserve(sourceCycle.size());
    for (qsizetype index = 0; index < sourceCycle.size(); ++index) {
        result.cycleTimeSeconds.push_back(static_cast<double>(index) * cycleSampleIntervalSeconds);
    }
    result.displayVoltageOffsetV = sourceCycle.isEmpty() ? 0.0 : resolved.voltageOffsetV;
    result.timeSeconds.reserve(spectrum.voltageV.size());
    for (qsizetype index = 0; index < spectrum.voltageV.size(); ++index) {
        result.timeSeconds.push_back(static_cast<double>(spectrum.sampleOffset + index) * cycleSampleIntervalSeconds);
    }
    result.voltageV = spectrum.voltageV;
    result.baselineV = spectrum.baselineV;
    result.fittedVoltageV = spectrum.fittedVoltageV;
    result.absorbance = spectrum.absorbance;
    result.fittedAbsorbance = spectrum.fittedAbsorbance;
    result.peakAbsorbance = spectrum.peakAbsorbance;
    result.lightPercent = spectrum.lightPercent;
    result.voigtCenterCm1 = spectrum.voigt.centerCm1;
    result.voigtAmplitude = spectrum.voigt.amplitude;
    result.voigtGaussianFwhmCm1 = spectrum.voigt.gaussianFwhmCm1;
    result.voigtLorentzianFwhmCm1 = spectrum.voigt.lorentzianFwhmCm1;
    result.voigtResidualSumSquares = spectrum.voigt.residualSumSquares;
    result.concentration.reset();
    result.concentrationUnit.clear();
    result.validity = contracts::DataValidity::Uncalibrated;
    result.diagnostic = spectrum.diagnostic;
    return result;
}

} // namespace tdlas::algorithm
