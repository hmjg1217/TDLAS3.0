#pragma once

#include "algorithm/IAlgorithmProcessor.h"

#include <array>

namespace tdlas::algorithm {

struct TdlasAlgorithmConfig {
    QString parameterSetId = QStringLiteral("tdlas-v1.6-reference");
    QString algorithmVersion = QStringLiteral("tdlas-v1.6-cpp");
    QString frequencyCalibrationVersion = QStringLiteral("relative-frequency-20260901");
    qsizetype samplesPerCycle = 500;
    qsizetype averagedCyclesPerSpectrum = 10;
    qsizetype averagedSpectra = 20;
    qsizetype windowSamples = 100000;
    // Legacy name retained for callers: UI mode now detects sawtooth cycles in the stream.
    bool samplesPerCycleFromBlock = false;
    bool alignAtMaximum = true;
    bool useMeasuredVoigtSeed = false;
    double lowPassNormalizedCutoff = 0.1;
    double voltageOffsetV = 4.2;
    double cropStartFraction = 0.3;
    double cropEndFraction = 0.9;
    double baselineLeadingFraction = 0.35;
    double baselineTrailingFraction = 0.4;
    std::array<double, 4> frequencyPolynomial{
        -3.02716372873655e-09,
        5.82968569053455e-06,
        0.0241628513601265,
        0.609383083614659};
    double frequencyScale = 0.8761 / 30.0;
};

struct VoigtParameters {
    double centerCm1 = 0.0;
    double amplitude = 0.0;
    double gaussianFwhmCm1 = 0.0;
    double lorentzianFwhmCm1 = 0.0;
    double residualSumSquares = 0.0;
    bool valid = false;
    QString diagnostic;
};

struct TdlasSpectrumResult {
    QVector<double> relativeFrequencyCm1;
    QVector<double> voltageV;
    QVector<double> baselineV;
    QVector<double> fittedVoltageV;
    QVector<double> absorbance;
    QVector<double> fittedAbsorbance;
    VoigtParameters voigt;
    double peakAbsorbance = 0.0;
    double lightPercent = 0.0;
    qsizetype sampleOffset = 0;
    qsizetype cycleSamples = 0;
    bool valid = false;
    QString diagnostic;
};

// Optional measurements for the repeatable performance baseline; ignored by normal processing.
struct TdlasStageTimings {
    qint64 filterNs = 0;
    qint64 baselineFitNs = 0;
    qint64 preprocessingNs = 0;
    qint64 voigtFitNs = 0;
    qint64 resultAssemblyNs = 0;
    qint64 totalNs = 0;
};

[[nodiscard]] TdlasAlgorithmConfig referenceAlgorithmConfig();
[[nodiscard]] TdlasAlgorithmConfig uiAlgorithmConfig();
[[nodiscard]] bool isValidConfig(const TdlasAlgorithmConfig &config, QString *diagnostic = nullptr);
[[nodiscard]] QVector<double> evaluateVoigt(
    const VoigtParameters &parameters,
    const QVector<double> &frequencyCm1);
[[nodiscard]] VoigtParameters fitVoigt(
    const QVector<double> &frequencyCm1,
    const QVector<double> &absorbance,
    bool initializeFromData = false);
[[nodiscard]] TdlasSpectrumResult processTdlasWindow(
    const QVector<double> &voltageSamplesV,
    const TdlasAlgorithmConfig &config,
    TdlasStageTimings *timings = nullptr);

class TdlasAlgorithmProcessor final : public IAlgorithmProcessor
{
public:
    explicit TdlasAlgorithmProcessor(TdlasAlgorithmConfig config = uiAlgorithmConfig());

    [[nodiscard]] contracts::ProcessingResult process(
        const contracts::RawDataBlock &block,
        const contracts::ParameterSnapshot &parameters) const override;

private:
    [[nodiscard]] TdlasAlgorithmConfig resolvedConfig(
        const contracts::RawDataBlock &block,
        const contracts::ParameterSnapshot &parameters) const;
    void resetStream(const contracts::RunId &runId, const QString &parameterSnapshotId) const;

    TdlasAlgorithmConfig config_;
    mutable contracts::RunId bufferedRunId_;
    mutable QString bufferedParameterSnapshotId_;
    mutable contracts::Sequence lastSequence_ = 0;
    mutable QVector<double> sampleBufferV_;
    mutable int bufferedResetPolarity_ = 0;
    mutable double bufferedSampleRateHz_ = 0.0;
};

} // namespace tdlas::algorithm
