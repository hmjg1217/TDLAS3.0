#include "application/AlgorithmWorker.h"

namespace tdlas::application {

AlgorithmWorker::AlgorithmWorker(const algorithm::IAlgorithmProcessor &algorithm)
    : algorithm_(algorithm)
{
}

void AlgorithmWorker::process(
    const contracts::RawDataBlock &block,
    const contracts::ParameterSnapshot &parameters)
{
    emit resultReady(algorithm_.process(block, parameters));
}

} // namespace tdlas::application
