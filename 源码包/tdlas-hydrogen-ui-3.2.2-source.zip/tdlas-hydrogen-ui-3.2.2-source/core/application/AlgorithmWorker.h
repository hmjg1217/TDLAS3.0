#pragma once

#include "algorithm/IAlgorithmProcessor.h"

#include <QObject>

namespace tdlas::application {

class AlgorithmWorker final : public QObject
{
    Q_OBJECT

public:
    explicit AlgorithmWorker(const algorithm::IAlgorithmProcessor &algorithm);

public slots:
    void process(
        const tdlas::contracts::RawDataBlock &block,
        const tdlas::contracts::ParameterSnapshot &parameters);

signals:
    void resultReady(const tdlas::contracts::ProcessingResult &result);

private:
    const algorithm::IAlgorithmProcessor &algorithm_;
};

} // namespace tdlas::application
