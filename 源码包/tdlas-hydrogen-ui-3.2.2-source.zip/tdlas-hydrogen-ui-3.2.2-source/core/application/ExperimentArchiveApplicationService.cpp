#include "application/ExperimentArchiveApplicationService.h"

namespace tdlas::application {

ExperimentArchiveApplicationService::ExperimentArchiveApplicationService(
    const system::IAuthorizationService &authorization,
    system::IAuditSink &audit)
    : authorization_(authorization)
    , audit_(audit)
{
}

storage::StorageOperationResult ExperimentArchiveApplicationService::authorize(
    const system::SessionContext &session,
    system::ProtectedOperation operation,
    const QString &action,
    const QDateTime &nowUtc)
{
    const system::AuthorizationDecision decision = authorization_.authorize(
        session, operation, nowUtc);
    if (decision.allowed) {
        return storage::StorageOperationResult::succeeded();
    }
    audit(session, action, QStringLiteral("denied"), nowUtc, {}, {}, decision.diagnostic);
    return storage::StorageOperationResult::failed(
        decision.code,
        QStringLiteral("当前会话无权执行实验数据操作。"),
        decision.diagnostic);
}

void ExperimentArchiveApplicationService::audit(
    const system::SessionContext &session,
    const QString &action,
    const QString &outcome,
    const QDateTime &nowUtc,
    const QString &experimentId,
    const QString &runId,
    const QString &diagnostic)
{
    (void)audit_.record({
        nowUtc.toUTC(), session.principalId, session.sessionId,
        QStringLiteral("experiment-archive"), action, outcome,
        experimentId, runId, diagnostic});
}

storage::StorageOperationResult ExperimentArchiveApplicationService::inspect(
    const system::SessionContext &session,
    const QString &experimentDirectory,
    storage::ExperimentArchiveSummary *summary,
    const QDateTime &nowUtc)
{
    storage::StorageOperationResult result = authorize(
        session, system::ProtectedOperation::ViewMeasurements,
        QStringLiteral("inspect"), nowUtc);
    if (!result.success) {
        return result;
    }
    result = storage::ExperimentArchiveService::inspect(experimentDirectory, summary);
    audit(session, QStringLiteral("inspect"), result.success ? QStringLiteral("success")
        : QStringLiteral("failed"), nowUtc,
        result.success ? summary->experimentId.value : QString(),
        result.success ? summary->runId.value : QString(), result.diagnostic);
    return result;
}

storage::StorageOperationResult ExperimentArchiveApplicationService::replayRawData(
    const system::SessionContext &session,
    const QString &experimentDirectory,
    const storage::ExperimentArchiveService::RawBlockConsumer &consumer,
    quint64 *replayedBlockCount,
    const QDateTime &nowUtc)
{
    storage::StorageOperationResult result = authorize(
        session, system::ProtectedOperation::ViewMeasurements,
        QStringLiteral("replay-raw-data"), nowUtc);
    if (!result.success) {
        return result;
    }
    result = storage::ExperimentArchiveService::replayRawData(
        experimentDirectory, consumer, replayedBlockCount);
    audit(session, QStringLiteral("replay-raw-data"),
        result.success ? QStringLiteral("success") : QStringLiteral("failed"),
        nowUtc, {}, {}, result.diagnostic);
    return result;
}

storage::StorageOperationResult ExperimentArchiveApplicationService::exportProcessingResultsCsv(
    const system::SessionContext &session,
    const QString &experimentDirectory,
    const QString &outputFilePath,
    quint64 *exportedRowCount,
    const QDateTime &nowUtc)
{
    storage::StorageOperationResult result = authorize(
        session, system::ProtectedOperation::SaveExperiment,
        QStringLiteral("export-processing-results"), nowUtc);
    if (!result.success) {
        return result;
    }
    result = storage::ExperimentArchiveService::exportProcessingResultsCsv(
        experimentDirectory, outputFilePath, exportedRowCount);
    audit(session, QStringLiteral("export-processing-results"),
        result.success ? QStringLiteral("success") : QStringLiteral("failed"),
        nowUtc, {}, {}, result.diagnostic);
    return result;
}

storage::StorageOperationResult ExperimentArchiveApplicationService::recoverInterruptedExperiment(
    const system::SessionContext &session,
    const QString &experimentDirectory,
    const QDateTime &recoveredAtUtc,
    const QString &diagnostic,
    const QDateTime &nowUtc)
{
    storage::StorageOperationResult result = authorize(
        session, system::ProtectedOperation::ConfigureStorage,
        QStringLiteral("recover-interrupted-experiment"), nowUtc);
    if (!result.success) {
        return result;
    }
    result = storage::ExperimentArchiveService::recoverInterruptedExperiment(
        experimentDirectory, recoveredAtUtc, diagnostic);
    audit(session, QStringLiteral("recover-interrupted-experiment"),
        result.success ? QStringLiteral("success") : QStringLiteral("failed"),
        nowUtc, {}, {}, result.diagnostic);
    return result;
}

} // namespace tdlas::application
