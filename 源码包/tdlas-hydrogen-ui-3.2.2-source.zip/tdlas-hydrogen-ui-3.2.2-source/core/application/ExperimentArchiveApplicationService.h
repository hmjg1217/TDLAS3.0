#pragma once

#include "storage/ExperimentArchiveService.h"
#include "system/IAuditSink.h"
#include "system/IAuthorizationService.h"

namespace tdlas::application {

class ExperimentArchiveApplicationService final
{
public:
    ExperimentArchiveApplicationService(
        const system::IAuthorizationService &authorization,
        system::IAuditSink &audit);

    [[nodiscard]] storage::StorageOperationResult inspect(
        const system::SessionContext &session,
        const QString &experimentDirectory,
        storage::ExperimentArchiveSummary *summary,
        const QDateTime &nowUtc = QDateTime::currentDateTimeUtc());
    [[nodiscard]] storage::StorageOperationResult replayRawData(
        const system::SessionContext &session,
        const QString &experimentDirectory,
        const storage::ExperimentArchiveService::RawBlockConsumer &consumer,
        quint64 *replayedBlockCount = nullptr,
        const QDateTime &nowUtc = QDateTime::currentDateTimeUtc());
    [[nodiscard]] storage::StorageOperationResult exportProcessingResultsCsv(
        const system::SessionContext &session,
        const QString &experimentDirectory,
        const QString &outputFilePath,
        quint64 *exportedRowCount = nullptr,
        const QDateTime &nowUtc = QDateTime::currentDateTimeUtc());
    [[nodiscard]] storage::StorageOperationResult recoverInterruptedExperiment(
        const system::SessionContext &session,
        const QString &experimentDirectory,
        const QDateTime &recoveredAtUtc,
        const QString &diagnostic,
        const QDateTime &nowUtc = QDateTime::currentDateTimeUtc());

private:
    [[nodiscard]] storage::StorageOperationResult authorize(
        const system::SessionContext &session,
        system::ProtectedOperation operation,
        const QString &action,
        const QDateTime &nowUtc);
    void audit(
        const system::SessionContext &session,
        const QString &action,
        const QString &outcome,
        const QDateTime &nowUtc,
        const QString &experimentId,
        const QString &runId,
        const QString &diagnostic);

    const system::IAuthorizationService &authorization_;
    system::IAuditSink &audit_;
};

} // namespace tdlas::application
