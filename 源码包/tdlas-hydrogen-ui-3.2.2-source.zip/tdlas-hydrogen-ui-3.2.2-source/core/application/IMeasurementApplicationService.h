#pragma once

#include "contracts/MeasurementTypes.h"

namespace tdlas::application {

class IMeasurementApplicationService
{
public:
    virtual ~IMeasurementApplicationService() = default;

    [[nodiscard]] virtual bool start(const contracts::StartMeasurementRequest &request) = 0;
    [[nodiscard]] virtual bool stop(const contracts::RunId &runId) = 0;
    [[nodiscard]] virtual bool resetFault() = 0;
    [[nodiscard]] virtual contracts::MeasurementState state() const = 0;
    [[nodiscard]] virtual contracts::RunId currentRunId() const = 0;
    [[nodiscard]] virtual contracts::ExperimentId currentExperimentId() const = 0;
};

} // namespace tdlas::application
