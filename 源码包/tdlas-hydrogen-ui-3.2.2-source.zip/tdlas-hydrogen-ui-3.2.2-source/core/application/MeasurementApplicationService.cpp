#include "application/MeasurementApplicationService.h"

#include "application/AlgorithmWorker.h"
#include "application/PeakRecordBuilder.h"
#include "application/StorageWorker.h"

#include <QDateTime>
#include <QMetaObject>
#include <QUuid>

#include <algorithm>
#include <cmath>

namespace tdlas::application {

namespace {

QString acquisitionLabel(contracts::DataSourceKind sourceKind)
{
    return sourceKind == contracts::DataSourceKind::RealDevice
        ? QStringLiteral("真实设备采集")
        : QStringLiteral("模拟采集");
}

QVector<double> timeAxis(qsizetype count, double durationSeconds)
{
    QVector<double> times;
    times.reserve(count);
    for (qsizetype index = 0; index < count; ++index) {
        times.push_back(durationSeconds * static_cast<double>(index) / static_cast<double>(count));
    }
    return times;
}

contracts::DataSourceKind sourceKindForDevice(
    const QString &deviceId,
    contracts::DataSourceKind configuredKind)
{
    const QString normalizedId = deviceId.trimmed();
    const bool isSimulation = normalizedId.startsWith(
            QStringLiteral("mock-"), Qt::CaseInsensitive)
        || normalizedId.startsWith(QStringLiteral("sim/"), Qt::CaseInsensitive);
    return isSimulation
        ? contracts::DataSourceKind::Simulation
        : configuredKind;
}

} // namespace

MeasurementApplicationService::MeasurementApplicationService(
    acquisition::IAcquisitionDevice &device,
    const algorithm::IAlgorithmProcessor &algorithm,
    QObject *parent)
    : MeasurementApplicationService(device, algorithm, MeasurementApplicationOptions{}, parent)
{
}

MeasurementApplicationService::MeasurementApplicationService(
    acquisition::IAcquisitionDevice &device,
    const algorithm::IAlgorithmProcessor &algorithm,
    const MeasurementApplicationOptions &options,
    QObject *parent)
    : QObject(parent)
    , device_(device)
    , algorithm_(algorithm)
    , options_(options)
{
    initialize();
}

MeasurementApplicationService::MeasurementApplicationService(
    acquisition::IAcquisitionDevice &device,
    const algorithm::IAlgorithmProcessor &algorithm,
    storage::IStorageRepository &storageRepository,
    QObject *parent)
    : MeasurementApplicationService(
        device, algorithm, storageRepository, MeasurementApplicationOptions{}, parent)
{
}

MeasurementApplicationService::MeasurementApplicationService(
    acquisition::IAcquisitionDevice &device,
    const algorithm::IAlgorithmProcessor &algorithm,
    storage::IStorageRepository &storageRepository,
    const MeasurementApplicationOptions &options,
    QObject *parent)
    : QObject(parent)
    , device_(device)
    , algorithm_(algorithm)
    , storageRepository_(&storageRepository)
    , options_(options)
{
    initialize();
}

void MeasurementApplicationService::initialize()
{
    qRegisterMetaType<contracts::RunId>();
    qRegisterMetaType<contracts::ExperimentId>();
    qRegisterMetaType<contracts::ParameterSnapshot>();
    qRegisterMetaType<contracts::RawDataBlock>();
    qRegisterMetaType<contracts::ProcessingResult>();
    qRegisterMetaType<contracts::ModuleError>();
    qRegisterMetaType<contracts::DeviceConnectionState>();
    qRegisterMetaType<contracts::AcquisitionState>();
    qRegisterMetaType<contracts::MeasurementState>();
    qRegisterMetaType<contracts::ExperimentStorageState>();
    qRegisterMetaType<contracts::MeasurementDisplayModel>();
    qRegisterMetaType<contracts::ParameterDraft>();

    options_.displayRefreshIntervalMilliseconds = qMax(1, options_.displayRefreshIntervalMilliseconds);
    options_.peakHistoryCapacity = qMax<qsizetype>(1, options_.peakHistoryCapacity);
    activeSourceKind_ = options_.sourceKind;
    displayRefreshTimer_.setInterval(options_.displayRefreshIntervalMilliseconds);
    displayRefreshTimer_.setTimerType(Qt::PreciseTimer);
    connect(&displayRefreshTimer_, &QTimer::timeout, this, [this]() {
        if (!displayRefreshPending_ || stateMachine_.state() != contracts::MeasurementState::Running) {
            return;
        }
        displayRefreshPending_ = false;
        publishDisplayModel();
    });

    displayModel_.sourceKind = options_.sourceKind;
    displayModel_.connectionState = device_.connectionState();
    displayModel_.statusMessage = QStringLiteral("%1就绪").arg(acquisitionLabel(options_.sourceKind));

    algorithmWorker_ = new AlgorithmWorker(algorithm_);
    algorithmWorker_->moveToThread(&algorithmThread_);
    connect(&algorithmThread_, &QThread::finished, algorithmWorker_, &QObject::deleteLater);
    connect(this, &MeasurementApplicationService::algorithmProcessingRequested,
        algorithmWorker_, &AlgorithmWorker::process, Qt::QueuedConnection);
    connect(algorithmWorker_, &AlgorithmWorker::resultReady,
        this, &MeasurementApplicationService::handleProcessingResult, Qt::QueuedConnection);
    algorithmThread_.setObjectName(QStringLiteral("tdlas-algorithm-worker"));
    algorithmThread_.start();

    if (storageRepository_) {
        storageWorker_ = new StorageWorker(*storageRepository_);
        storageWorker_->moveToThread(&storageThread_);
        connect(&storageThread_, &QThread::finished, storageWorker_, &QObject::deleteLater);
        connect(this, &MeasurementApplicationService::storageRawDataRequested,
            storageWorker_, &StorageWorker::appendRawData, Qt::QueuedConnection);
        connect(this, &MeasurementApplicationService::storageResultRequested,
            storageWorker_, &StorageWorker::appendProcessingResult, Qt::QueuedConnection);
        connect(storageWorker_, &StorageWorker::errorOccurred,
            this, &MeasurementApplicationService::handleStorageError, Qt::QueuedConnection);
        connect(storageWorker_, &StorageWorker::experimentFinished,
            this, &MeasurementApplicationService::handleStorageFinished, Qt::QueuedConnection);
        storageThread_.setObjectName(QStringLiteral("tdlas-storage-worker"));
        storageThread_.start();
    }

    connect(&device_, &acquisition::IAcquisitionDevice::connectionStateChanged,
        this, &MeasurementApplicationService::handleConnectionState);
    connect(&device_, &acquisition::IAcquisitionDevice::acquisitionStateChanged,
        this, &MeasurementApplicationService::handleAcquisitionState);
    connect(&device_, &acquisition::IAcquisitionDevice::rawDataReady,
        this, &MeasurementApplicationService::handleRawData);
    connect(&device_, &acquisition::IAcquisitionDevice::errorOccurred,
        this, &MeasurementApplicationService::handleError);
}

MeasurementApplicationService::~MeasurementApplicationService()
{
    displayRefreshTimer_.stop();
    if (device_.acquisitionState() == contracts::AcquisitionState::Running
        || device_.acquisitionState() == contracts::AcquisitionState::Stopping) {
        (void)device_.stop();
    }
    (void)device_.disconnectDevice();
    if (storageExperimentActive_ && !storageFinishPending_) {
        (void)finishStorage(
            storage::ExperimentCompletionStatus::Aborted,
            QStringLiteral("application service destroyed before normal completion"));
    }
    algorithmThread_.quit();
    algorithmThread_.wait();
    if (storageFinishPending_ && storageWorker_) {
        QMetaObject::invokeMethod(storageWorker_, []() {}, Qt::BlockingQueuedConnection);
    }
    if (storageWorker_) {
        storageThread_.quit();
        storageThread_.wait();
    }
}

bool MeasurementApplicationService::start(const contracts::StartMeasurementRequest &request)
{
    if (stateMachine_.state() == contracts::MeasurementState::Stopping) {
        QString diagnostic;
        if (!request.parameters.isValid(&diagnostic)) {
            return false;
        }
        pendingStartRequest_ = request;
        displayModel_.statusMessage = QStringLiteral("停止完成后自动重新开始采集");
        publishDisplayModel();
        return true;
    }

    activeSourceKind_ = sourceKindForDevice(request.parameters.deviceId, options_.sourceKind);
    QString diagnostic;
    if (!request.parameters.isValid(&diagnostic)) {
        enterFault(
            QStringLiteral("PARAMETER_INVALID"),
            QStringLiteral("%1参数无效。").arg(acquisitionLabel(activeSourceKind_)),
            diagnostic);
        return false;
    }

    if (!request.experimentId.value.isEmpty() && !request.experimentId.isValid()) {
        enterFault(
            QStringLiteral("EXPERIMENT_ID_INVALID"),
            QStringLiteral("实验 ID 无效。"),
            request.experimentId.value);
        return false;
    }

    const QDateTime startedAtUtc = QDateTime::currentDateTimeUtc();
    const contracts::RunId runId{
        QUuid::createUuid().toString(QUuid::WithoutBraces)};
    if (!stateMachine_.begin(runId)) {
        return false;
    }

    parameters_ = request.parameters;
    experimentId_ = request.experimentId.isValid()
        ? request.experimentId
        : contracts::createExperimentId(startedAtUtc);
    storageState_ = contracts::ExperimentStorageState::NotStarted;
    displayRefreshTimer_.stop();
    displayRefreshPending_ = false;
    acquisitionStopped_ = false;
    algorithmRequestsInFlight_ = 0;
    lastPresentedSequence_ = 0;
    newestPeakAtUtc_ = {};
    peakTrendChronological_ = true;
    displayModel_ = {};
    displayModel_.state = stateMachine_.state();
    displayModel_.connectionState = device_.connectionState();
    displayModel_.sourceKind = activeSourceKind_;
    displayModel_.runId = runId;
    displayModel_.experimentId = experimentId_;
    displayModel_.runStartedAtUtc = startedAtUtc;
    displayModel_.peakRecords = peakRecords_;
    peakRecordsDirty_ = false;
    displayModel_.peakTrendSeries.xUnit = QStringLiteral("HH:mm:ss");
    displayModel_.peakTrendSeries.yUnit = QStringLiteral("1");
    displayModel_.peakTrendSeries.validity = contracts::DataValidity::Valid;
    displayModel_.storageState = storageState_;
    displayModel_.validity = contracts::DataValidity::Incomplete;
    publishState(QStringLiteral("正在准备%1… · %2")
        .arg(acquisitionLabel(activeSourceKind_), experimentId_.value));

    if (storageWorker_) {
        storage::ExperimentContext context;
        context.experimentId = experimentId_;
        context.runId = runId;
        context.parameters = parameters_;
        context.startedAt.utc = startedAtUtc;
        context.sourceKind = activeSourceKind_;
        context.operatorId = request.operatorId.trimmed();
        const storage::StorageOperationResult storageResult = beginStorage(context);
        if (!storageResult.success) {
            storageState_ = contracts::ExperimentStorageState::Failed;
            displayModel_.storageState = storageState_;
            enterFault(
                storageResult.code,
                storageResult.userMessage.isEmpty()
                    ? QStringLiteral("无法创建实验数据目录。")
                    : storageResult.userMessage,
                QStringLiteral("%1; path=%2").arg(storageResult.diagnostic, storageResult.path));
            return false;
        }
        storageExperimentActive_ = true;
        storageState_ = contracts::ExperimentStorageState::Saving;
        displayModel_.storageState = storageState_;
    }

    if (!device_.connectDevice(parameters_.deviceId)
        || !device_.configure(parameters_)
        || !device_.start(runId)) {
        if (stateMachine_.state() != contracts::MeasurementState::Faulted) {
            if (storageExperimentActive_) {
                (void)finishStorage(
                    storage::ExperimentCompletionStatus::Faulted,
                    QStringLiteral("acquisition start sequence failed"));
            }
            enterFault(
                QStringLiteral("ACQUISITION_START_FAILED"),
                QStringLiteral("%1启动失败。").arg(acquisitionLabel(activeSourceKind_)),
                QStringLiteral("acquisition port rejected start sequence"));
        }
        return false;
    }
    return true;
}

bool MeasurementApplicationService::stop(const contracts::RunId &runId)
{
    if (stateMachine_.state() == contracts::MeasurementState::Idle) {
        return true;
    }
    if (!runId.isValid() || runId != stateMachine_.activeRunId()) {
        return false;
    }
    if (stateMachine_.state() == contracts::MeasurementState::Stopping) {
        return true;
    }
    if (stateMachine_.state() != contracts::MeasurementState::Preparing
        && stateMachine_.state() != contracts::MeasurementState::Running) {
        return false;
    }
    if (!stateMachine_.transitionTo(contracts::MeasurementState::Stopping)) {
        return false;
    }
    displayRefreshTimer_.stop();
    displayRefreshPending_ = false;
    publishState(QStringLiteral("正在停止%1…").arg(acquisitionLabel(activeSourceKind_)));
    if (!device_.stop()) {
        pendingStartRequest_.reset();
        enterFault(
            QStringLiteral("ACQUISITION_STOP_FAILED"),
            QStringLiteral("%1停止失败。").arg(acquisitionLabel(activeSourceKind_)),
            QStringLiteral("acquisition port rejected stop"));
        return false;
    }
    return true;
}

bool MeasurementApplicationService::resetFault()
{
    displayRefreshTimer_.stop();
    displayRefreshPending_ = false;
    if (device_.acquisitionState() == contracts::AcquisitionState::Running) {
        (void)device_.stop();
    }
    if (!stateMachine_.resetFault()) {
        return false;
    }
    displayModel_ = {};
    displayModel_.sourceKind = activeSourceKind_;
    displayModel_.connectionState = device_.connectionState();
    displayModel_.experimentId = experimentId_;
    displayModel_.storageState = storageState_;
    publishState(QStringLiteral("%1故障已复位").arg(acquisitionLabel(activeSourceKind_)));
    return true;
}

contracts::MeasurementState MeasurementApplicationService::state() const
{
    return stateMachine_.state();
}

contracts::RunId MeasurementApplicationService::currentRunId() const
{
    return stateMachine_.activeRunId();
}

contracts::ExperimentId MeasurementApplicationService::currentExperimentId() const
{
    return experimentId_;
}

contracts::MeasurementDisplayModel MeasurementApplicationService::displayModel() const
{
    auto snapshot = displayModel_;
    if (peakRecordsDirty_) snapshot.peakRecords = peakRecords_;
    return snapshot;
}

void MeasurementApplicationService::handleConnectionState(contracts::DeviceConnectionState state)
{
    displayModel_.connectionState = state;
    displayModel_.lastUpdatedUtc = QDateTime::currentDateTimeUtc();
    publishDisplayModel();
}

void MeasurementApplicationService::handleAcquisitionState(contracts::AcquisitionState state)
{
    if (state == contracts::AcquisitionState::Running
        && stateMachine_.state() == contracts::MeasurementState::Preparing) {
        if (stateMachine_.transitionTo(contracts::MeasurementState::Running)) {
            publishState(QStringLiteral("%1中 · %2")
                .arg(acquisitionLabel(activeSourceKind_), experimentId_.value));
            displayRefreshTimer_.start();
        }
        return;
    }
    if (state == contracts::AcquisitionState::Idle
        && stateMachine_.state() == contracts::MeasurementState::Stopping) {
        displayRefreshTimer_.stop();
        displayRefreshPending_ = false;
        acquisitionStopped_ = true;
        finishStopWhenDrained();
        return;
    }
    if (state == contracts::AcquisitionState::Faulted) {
        displayRefreshTimer_.stop();
        displayRefreshPending_ = false;
    }
}

void MeasurementApplicationService::handleStorageFinished(
    bool success,
    const QString &code,
    const QString &userMessage,
    const QString &diagnostic,
    const QString &path)
{
    if (!storageFinishPending_) return;
    storageFinishPending_ = false;
    storageExperimentActive_ = false;
    storageState_ = success
        ? contracts::ExperimentStorageState::Saved
        : contracts::ExperimentStorageState::Failed;
    displayModel_.storageState = storageState_;
    if (!success && stateMachine_.state() != contracts::MeasurementState::Faulted) {
        pendingStartRequest_.reset();
        enterFault(code.isEmpty() ? QStringLiteral("STORAGE_FINISH_FAILED") : code,
            userMessage.isEmpty() ? QStringLiteral("实验结束信息保存失败。") : userMessage,
            QStringLiteral("%1; path=%2").arg(diagnostic, path));
        return;
    }
    if (stateMachine_.state() == contracts::MeasurementState::Stopping
        && stateMachine_.transitionTo(contracts::MeasurementState::Idle)) {
        publishState(QStringLiteral("%1已停止 · %2")
            .arg(acquisitionLabel(activeSourceKind_), experimentId_.value));
        startPendingRequest();
    }
}

void MeasurementApplicationService::handleRawData(const contracts::RawDataBlock &block)
{
    if (!stateMachine_.acceptData(block.runId, block.sequence)) {
        return;
    }

    if (storageExperimentActive_) emit storageRawDataRequested(experimentId_, block);

    const QString selectedChannel = parameters_.aiChannelIds.isEmpty()
        ? QString()
        : parameters_.aiChannelIds.constFirst();
    const auto channel = std::find_if(
        block.channels.cbegin(), block.channels.cend(), [&](const contracts::ChannelSamples &candidate) {
            return candidate.channelId == selectedChannel;
        });
    if (block.validity == contracts::DataValidity::Valid && block.sampleCountPerChannel > 0
        && channel != block.channels.cend()
        && channel->samplesV.size() == block.sampleCountPerChannel
        && std::all_of(channel->samplesV.cbegin(), channel->samplesV.cend(), [](double value) { return std::isfinite(value); })
        && std::isfinite(block.sampleRateHz) && block.sampleRateHz > 0.0) {
        const bool firstRawBlock = displayModel_.rawSeries.x.isEmpty();
        displayModel_.sequence = block.sequence;
        displayModel_.lastUpdatedUtc = block.sampleStart.utc;
        if (displayModel_.processedVoltageSeries.x.isEmpty()) {
            displayModel_.waveformDurationSeconds = static_cast<double>(block.sampleCountPerChannel) / block.sampleRateHz;
        }
        displayModel_.rawVoltageV = channel->samplesV;
        displayModel_.rawSeries = {
            timeAxis(block.sampleCountPerChannel,
                     static_cast<double>(block.sampleCountPerChannel) / block.sampleRateHz),
            channel->samplesV,
            QStringLiteral("s"),
            QStringLiteral("V"),
            block.validity};
        if (firstRawBlock) {
            // Show the first waveform as soon as it arrives. Later blocks remain
            // coalesced by the display timer so high-rate acquisition cannot
            // force a chart repaint for every device block.
            displayRefreshPending_ = false;
            publishDisplayModel();
        } else {
            displayRefreshPending_ = true;
        }
    }
    ++algorithmRequestsInFlight_;
    emit algorithmProcessingRequested(block, parameters_);
}

void MeasurementApplicationService::handleProcessingResult(const contracts::ProcessingResult &result)
{
    if (result.runId != stateMachine_.activeRunId() || result.sourceSequence == 0) {
        return;
    }
    if (algorithmRequestsInFlight_ > 0) --algorithmRequestsInFlight_;
    const auto state = stateMachine_.state();
    if (state == contracts::MeasurementState::Running
        || (state == contracts::MeasurementState::Stopping && storageExperimentActive_)) {
        processAcceptedResult(result);
    }
    finishStopWhenDrained();
}

void MeasurementApplicationService::processAcceptedResult(const contracts::ProcessingResult &result)
{
    if (result.validity == contracts::DataValidity::Incomplete) {
        return;
    }
    const contracts::PeakRecord record = buildPeakRecord(
        result, parameters_, experimentId_, activeSourceKind_, displayModel_.runStartedAtUtc);
    const bool appendInOrder = peakRecords_.isEmpty()
        || (peakRecords_.constLast().runId != result.runId && !newestPeakAtUtc_.isValid())
        || (peakRecords_.constLast().runId == result.runId
            && record.sequence > peakRecords_.constLast().sequence
            && (!newestPeakAtUtc_.isValid() || !record.acquiredAtUtc.isValid()
                || record.acquiredAtUtc >= newestPeakAtUtc_));
    const bool evictsFirst = peakRecords_.size() >= options_.peakHistoryCapacity;
    const auto evictedRunId = evictsFirst ? peakRecords_.constFirst().runId : contracts::RunId{};
    const auto evictedTimestamp = evictsFirst ? peakRecords_.constFirst().acquiredAtUtc : QDateTime{};
    const bool evictedTrendPoint = evictsFirst && peakRecords_.constFirst().peakValue
        && peakRecords_.constFirst().validity == contracts::DataValidity::Valid;
    if (!insertPeakRecord(peakRecords_, record, options_.peakHistoryCapacity)) return;
    peakRecordsDirty_ = true;
    if (!appendInOrder) peakTrendChronological_ = false;
    if (!appendInOrder || !peakTrendChronological_) {
        rebuildPeakTrend(result.runId);
    } else {
        if (record.acquiredAtUtc.isValid()
            && (!newestPeakAtUtc_.isValid() || record.acquiredAtUtc > newestPeakAtUtc_)) {
            newestPeakAtUtc_ = record.acquiredAtUtc;
        }
        auto &trend = displayModel_.peakTrendSeries;
        if (evictedTrendPoint && evictedRunId == result.runId && !trend.x.isEmpty()
            && trend.x.constFirst() == static_cast<double>(evictedTimestamp.toMSecsSinceEpoch()) / 1000.0) {
            trend.x.removeFirst();
            trend.y.removeFirst();
            displayModel_.peakHistory.removeFirst();
        }
        const QDateTime cutoff = newestPeakAtUtc_.addSecs(-3600);
        qsizetype expired = 0;
        const double cutoffSeconds = static_cast<double>(cutoff.toMSecsSinceEpoch()) / 1000.0;
        while (expired < trend.x.size() && trend.x.at(expired) < cutoffSeconds) ++expired;
        if (expired > 0) {
            trend.x.remove(0, expired);
            trend.y.remove(0, expired);
            displayModel_.peakHistory.remove(0, expired);
        }
        if (record.peakValue && record.acquiredAtUtc.isValid()
            && record.validity == contracts::DataValidity::Valid
            && record.acquiredAtUtc >= cutoff) {
            const double value = *record.peakValue;
            displayModel_.peakHistory.push_back(value);
            trend.x.push_back(static_cast<double>(record.acquiredAtUtc.toMSecsSinceEpoch()) / 1000.0);
            trend.y.push_back(value);
        }
    }
    if (storageExperimentActive_) emit storageResultRequested(experimentId_, result);
    if (result.sourceSequence <= lastPresentedSequence_) {
        // Preserve the latest live result while filling an earlier record in the table/trend.
        displayRefreshPending_ = true;
        return;
    }
    displayModel_.peakAbsorbance = record.peakValue;
    if (result.validity == contracts::DataValidity::Invalid) {
        enterFault(QStringLiteral("ALGORITHM_INVALID"), QStringLiteral("算法无法处理采集数据。"), result.diagnostic);
        return;
    }
    lastPresentedSequence_ = result.sourceSequence;

    displayModel_.state = stateMachine_.state();
    displayModel_.runId = result.runId;
    displayModel_.experimentId = experimentId_;
    displayModel_.storageState = storageState_;
    displayModel_.sequence = qMax(displayModel_.sequence, result.sourceSequence);
    displayModel_.fittedVoltageV = result.fittedVoltageV;
    displayModel_.absorbance = result.absorbance;
    displayModel_.fittedAbsorbance = result.fittedAbsorbance;
    displayModel_.peakAbsorbance = record.peakValue;
    displayModel_.lightPercent = result.lightPercent;
    displayModel_.concentration = result.concentration;
    displayModel_.concentrationUnit = result.concentrationUnit;
    displayModel_.validity = result.validity;
    displayModel_.diagnostic = result.diagnostic;
    displayModel_.statusMessage = result.algorithmVersion.startsWith(QStringLiteral("mock-"))
        ? QStringLiteral("%1中 · mock 算法 · #%2 · %3")
              .arg(acquisitionLabel(activeSourceKind_))
              .arg(result.sourceSequence)
              .arg(experimentId_.value)
        : QStringLiteral("%1中 · %2 · #%3 · %4")
              .arg(acquisitionLabel(activeSourceKind_), result.cycleTimeSeconds.isEmpty()
                  ? QStringLiteral("TDLAS") : QStringLiteral("20 周期平均拟合"))
              .arg(result.sourceSequence)
              .arg(experimentId_.value);
    displayModel_.processedVoltageSeries = {
        result.cycleTimeSeconds.isEmpty() ? result.timeSeconds : result.cycleTimeSeconds,
        result.cycleVoltageV.isEmpty() ? result.voltageV : result.cycleVoltageV,
        QStringLiteral("s"),
        QStringLiteral("V"),
        result.validity};
    displayModel_.fittedVoltageSeries = {
        result.timeSeconds,
        result.fittedVoltageV,
        QStringLiteral("s"),
        QStringLiteral("V"),
        result.validity};
    for (double &value : displayModel_.fittedVoltageSeries.y) value -= result.displayVoltageOffsetV;
    if (!result.cycleTimeSeconds.isEmpty()) {
        displayModel_.waveformDurationSeconds = result.cycleTimeSeconds.constLast();
    } else if (!result.timeSeconds.isEmpty()) {
        displayModel_.waveformDurationSeconds = result.timeSeconds.constLast();
    }
    const bool hasFrequency = result.relativeFrequencyCm1.size() == result.absorbance.size()
        && !result.relativeFrequencyCm1.isEmpty();
    const QVector<double> spectrumAxis = hasFrequency ? result.relativeFrequencyCm1
        : timeAxis(result.absorbance.size(), static_cast<double>(result.absorbance.size()));
    const QString spectrumUnit = hasFrequency ? QStringLiteral("cm⁻¹") : QStringLiteral("sample");
    displayModel_.absorbanceSeries = {
        spectrumAxis,
        result.absorbance,
        spectrumUnit,
        QStringLiteral("1"),
        result.validity};
    displayModel_.fittedAbsorbanceSeries = {
        spectrumAxis,
        result.fittedAbsorbance,
        spectrumUnit,
        QStringLiteral("1"),
        result.validity};
    displayRefreshPending_ = true;
}

void MeasurementApplicationService::finishStopWhenDrained()
{
    if (!acquisitionStopped_ || stateMachine_.state() != contracts::MeasurementState::Stopping)
        return;
    // The repository must receive every completed algorithm result before its
    // finish marker.  Qt's worker queue preserves the order of raw requests.
    if (storageExperimentActive_) {
        if (algorithmRequestsInFlight_ > 0 || storageFinishPending_) return;
        storageFinishPending_ = true;
        const auto experimentId = experimentId_;
        const auto completedAt = QDateTime::currentDateTimeUtc();
        QMetaObject::invokeMethod(storageWorker_, [worker = storageWorker_, experimentId, completedAt]() {
            worker->finishExperimentAsync(experimentId,
                storage::ExperimentCompletionStatus::Completed, completedAt, {});
        }, Qt::QueuedConnection);
        return;
    }
    if (stateMachine_.transitionTo(contracts::MeasurementState::Idle)) {
        publishState(QStringLiteral("%1已停止 · %2")
            .arg(acquisitionLabel(activeSourceKind_), experimentId_.value));
        startPendingRequest();
    }
}

void MeasurementApplicationService::handleError(const contracts::ModuleError &error)
{
    pendingStartRequest_.reset();
    emit errorOccurred(error);
    displayRefreshTimer_.stop();
    displayRefreshPending_ = false;
    if (storageExperimentActive_ && !storageFinishPending_) {
        storageFinishPending_ = true;
        pendingStorageStatus_ = storage::ExperimentCompletionStatus::Faulted;
        pendingStorageDiagnostic_ = QStringLiteral("%1: %2").arg(error.code, error.diagnostic);
        const auto experimentId = experimentId_;
        const auto completedAt = QDateTime::currentDateTimeUtc();
        const QString diagnostic = pendingStorageDiagnostic_;
        QMetaObject::invokeMethod(storageWorker_, [worker = storageWorker_, experimentId,
            completedAt, diagnostic]() {
            worker->finishExperimentAsync(experimentId,
                storage::ExperimentCompletionStatus::Faulted, completedAt, diagnostic);
        }, Qt::QueuedConnection);
    }
    stateMachine_.fault();
    displayModel_.state = contracts::MeasurementState::Faulted;
    displayModel_.validity = contracts::DataValidity::Invalid;
    displayModel_.statusMessage = error.userMessage;
    displayModel_.diagnostic = error.diagnostic;
    displayModel_.lastUpdatedUtc = QDateTime::currentDateTimeUtc();
    if (device_.acquisitionState() != contracts::AcquisitionState::Idle) {
        (void)device_.stop();
    }
    (void)device_.disconnectDevice();
    emit measurementStateChanged(displayModel_.state);
    publishDisplayModel();
}

void MeasurementApplicationService::handleStorageError(const contracts::ModuleError &error)
{
    if (stateMachine_.state() != contracts::MeasurementState::Preparing
        && stateMachine_.state() != contracts::MeasurementState::Running
        && stateMachine_.state() != contracts::MeasurementState::Stopping) {
        return;
    }
    storageState_ = contracts::ExperimentStorageState::Failed;
    displayModel_.storageState = storageState_;
    handleError(error);
}

void MeasurementApplicationService::publishState(const QString &statusMessage)
{
    displayModel_.state = stateMachine_.state();
    displayModel_.connectionState = device_.connectionState();
    displayModel_.experimentId = experimentId_;
    displayModel_.storageState = storageState_;
    displayModel_.statusMessage = statusMessage;
    displayModel_.lastUpdatedUtc = QDateTime::currentDateTimeUtc();
    emit measurementStateChanged(displayModel_.state);
    publishDisplayModel();
}

void MeasurementApplicationService::publishDisplayModel()
{
    if (peakRecordsDirty_) {
        displayModel_.peakRecords = peakRecords_;
        peakRecordsDirty_ = false;
    }
    emit displayModelChanged(displayModel_);
}

void MeasurementApplicationService::rebuildPeakTrend(const contracts::RunId &runId)
{
    auto &trend = displayModel_.peakTrendSeries;
    displayModel_.peakHistory.clear();
    trend = {};
    trend.xUnit = QStringLiteral("HH:mm:ss");
    trend.yUnit = QStringLiteral("1");
    trend.validity = contracts::DataValidity::Valid;
    newestPeakAtUtc_ = {};
    // Out-of-order timestamps stay on the exact scan path for the rest of the run.
    for (const auto &sample : peakRecords_) {
        if (sample.runId == runId && sample.acquiredAtUtc > newestPeakAtUtc_)
            newestPeakAtUtc_ = sample.acquiredAtUtc;
    }
    const QDateTime cutoff = newestPeakAtUtc_.addSecs(-3600);
    for (const auto &sample : peakRecords_) {
        if (sample.runId != runId || !sample.peakValue || !sample.acquiredAtUtc.isValid()
            || sample.validity != contracts::DataValidity::Valid || sample.acquiredAtUtc < cutoff) continue;
        displayModel_.peakHistory.push_back(*sample.peakValue);
        trend.x.push_back(static_cast<double>(sample.acquiredAtUtc.toMSecsSinceEpoch()) / 1000.0);
        trend.y.push_back(*sample.peakValue);
    }
}

void MeasurementApplicationService::startPendingRequest()
{
    if (!pendingStartRequest_) return;
    const contracts::StartMeasurementRequest request = *pendingStartRequest_;
    pendingStartRequest_.reset();
    (void)start(request);
}

void MeasurementApplicationService::enterFault(
    const QString &code,
    const QString &userMessage,
    const QString &diagnostic)
{
    contracts::ModuleError error;
    error.code = code;
    error.category = QStringLiteral("application");
    error.userMessage = userMessage;
    error.diagnostic = diagnostic;
    error.timestamp.utc = QDateTime::currentDateTimeUtc();
    error.retryable = true;
    error.requiresStop = true;
    if (stateMachine_.activeRunId().isValid()) {
        error.runId = stateMachine_.activeRunId();
    }
    handleError(error);
}

storage::StorageOperationResult MeasurementApplicationService::beginStorage(
    const storage::ExperimentContext &context)
{
    if (!storageWorker_) {
        return storage::StorageOperationResult::succeeded();
    }
    storage::StorageOperationResult result = storage::StorageOperationResult::failed(
        QStringLiteral("STORAGE_WORKER_UNAVAILABLE"),
        QStringLiteral("存储服务不可用。"),
        QStringLiteral("storage worker invocation did not run"));
    const bool invoked = QMetaObject::invokeMethod(
        storageWorker_,
        [this, &result, context]() {
            result = storageWorker_->beginExperiment(context);
        },
        Qt::BlockingQueuedConnection);
    if (!invoked) {
        return storage::StorageOperationResult::failed(
            QStringLiteral("STORAGE_WORKER_UNAVAILABLE"),
            QStringLiteral("存储服务不可用。"),
            QStringLiteral("failed to invoke storage worker"));
    }
    return result;
}

storage::StorageOperationResult MeasurementApplicationService::finishStorage(
    storage::ExperimentCompletionStatus status,
    const QString &diagnostic)
{
    if (!storageWorker_ || !storageExperimentActive_) {
        return storage::StorageOperationResult::succeeded();
    }
    storage::StorageOperationResult result = storage::StorageOperationResult::failed(
        QStringLiteral("STORAGE_WORKER_UNAVAILABLE"),
        QStringLiteral("存储服务不可用。"),
        QStringLiteral("storage worker invocation did not run"));
    const contracts::ExperimentId experimentId = experimentId_;
    const QDateTime completedAtUtc = QDateTime::currentDateTimeUtc();
    const bool invoked = QMetaObject::invokeMethod(
        storageWorker_,
        [this, &result, experimentId, status, completedAtUtc, diagnostic]() {
            result = storageWorker_->finishExperiment(
                experimentId, status, completedAtUtc, diagnostic);
        },
        Qt::BlockingQueuedConnection);
    if (!invoked) {
        return storage::StorageOperationResult::failed(
            QStringLiteral("STORAGE_WORKER_UNAVAILABLE"),
            QStringLiteral("存储服务不可用。"),
            QStringLiteral("failed to invoke storage worker"));
    }
    storageExperimentActive_ = false;
    storageState_ = result.success
        ? contracts::ExperimentStorageState::Saved
        : contracts::ExperimentStorageState::Failed;
    displayModel_.storageState = storageState_;
    return result;
}

} // namespace tdlas::application
