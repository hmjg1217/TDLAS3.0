#pragma once

#include "acquisition/IAcquisitionDevice.h"
#include "algorithm/IAlgorithmProcessor.h"
#include "application/IMeasurementApplicationService.h"
#include "application/MeasurementStateMachine.h"
#include "storage/IStorageRepository.h"

#include <QObject>
#include <QThread>
#include <QTimer>

#include <optional>

namespace tdlas::application {

class AlgorithmWorker;
class StorageWorker;

struct MeasurementApplicationOptions {
    int displayRefreshIntervalMilliseconds = 33;
    qsizetype peakHistoryCapacity = 60000;
    contracts::DataSourceKind sourceKind = contracts::DataSourceKind::Simulation;
};

class MeasurementApplicationService final : public QObject, public IMeasurementApplicationService
{
    Q_OBJECT

public:
    MeasurementApplicationService(
        acquisition::IAcquisitionDevice &device,
        const algorithm::IAlgorithmProcessor &algorithm,
        QObject *parent = nullptr);
    MeasurementApplicationService(
        acquisition::IAcquisitionDevice &device,
        const algorithm::IAlgorithmProcessor &algorithm,
        const MeasurementApplicationOptions &options,
        QObject *parent = nullptr);
    MeasurementApplicationService(
        acquisition::IAcquisitionDevice &device,
        const algorithm::IAlgorithmProcessor &algorithm,
        storage::IStorageRepository &storageRepository,
        QObject *parent = nullptr);
    MeasurementApplicationService(
        acquisition::IAcquisitionDevice &device,
        const algorithm::IAlgorithmProcessor &algorithm,
        storage::IStorageRepository &storageRepository,
        const MeasurementApplicationOptions &options,
        QObject *parent = nullptr);
    ~MeasurementApplicationService() override;

    [[nodiscard]] bool start(const contracts::StartMeasurementRequest &request) override;
    [[nodiscard]] bool stop(const contracts::RunId &runId) override;
    [[nodiscard]] bool resetFault() override;
    [[nodiscard]] contracts::MeasurementState state() const override;
    [[nodiscard]] contracts::RunId currentRunId() const override;
    [[nodiscard]] contracts::ExperimentId currentExperimentId() const override;
    [[nodiscard]] contracts::MeasurementDisplayModel displayModel() const;

signals:
    void algorithmProcessingRequested(
        const tdlas::contracts::RawDataBlock &block,
        const tdlas::contracts::ParameterSnapshot &parameters);
    void storageRawDataRequested(
        const tdlas::contracts::ExperimentId &experimentId,
        const tdlas::contracts::RawDataBlock &block);
    void storageResultRequested(
        const tdlas::contracts::ExperimentId &experimentId,
        const tdlas::contracts::ProcessingResult &result);
    void measurementStateChanged(tdlas::contracts::MeasurementState state);
    void displayModelChanged(const tdlas::contracts::MeasurementDisplayModel &model);
    void errorOccurred(const tdlas::contracts::ModuleError &error);

private:
    void handleConnectionState(contracts::DeviceConnectionState state);
    void handleAcquisitionState(contracts::AcquisitionState state);
    void handleRawData(const contracts::RawDataBlock &block);
    void handleProcessingResult(const contracts::ProcessingResult &result);
    void processAcceptedResult(const contracts::ProcessingResult &result);
    void finishStopWhenDrained();
    void handleError(const contracts::ModuleError &error);
    void handleStorageError(const contracts::ModuleError &error);
    void handleStorageFinished(bool success, const QString &code,
        const QString &userMessage, const QString &diagnostic, const QString &path);
    void publishState(const QString &statusMessage);
    void publishDisplayModel();
    void rebuildPeakTrend(const contracts::RunId &runId);
    void startPendingRequest();
    void enterFault(const QString &code, const QString &userMessage, const QString &diagnostic);
    void initialize();
    [[nodiscard]] storage::StorageOperationResult beginStorage(
        const storage::ExperimentContext &context);
    [[nodiscard]] storage::StorageOperationResult finishStorage(
        storage::ExperimentCompletionStatus status,
        const QString &diagnostic = {});

    acquisition::IAcquisitionDevice &device_;
    const algorithm::IAlgorithmProcessor &algorithm_;
    QThread algorithmThread_;
    AlgorithmWorker *algorithmWorker_ = nullptr;
    storage::IStorageRepository *storageRepository_ = nullptr;
    QThread storageThread_;
    StorageWorker *storageWorker_ = nullptr;
    bool storageExperimentActive_ = false;
    bool storageFinishPending_ = false;
    storage::ExperimentCompletionStatus pendingStorageStatus_ = storage::ExperimentCompletionStatus::Completed;
    QString pendingStorageDiagnostic_;
    contracts::ExperimentId experimentId_;
    contracts::ExperimentStorageState storageState_ = contracts::ExperimentStorageState::NotStarted;
    MeasurementStateMachine stateMachine_;
    MeasurementApplicationOptions options_;
    contracts::DataSourceKind activeSourceKind_ = contracts::DataSourceKind::Simulation;
    QTimer displayRefreshTimer_;
    bool displayRefreshPending_ = false;
    bool acquisitionStopped_ = false;
    quint64 algorithmRequestsInFlight_ = 0;
    contracts::Sequence lastPresentedSequence_ = 0;
    contracts::ParameterSnapshot parameters_;
    std::optional<contracts::StartMeasurementRequest> pendingStartRequest_;
    contracts::MeasurementDisplayModel displayModel_;
    QVector<contracts::PeakRecord> peakRecords_;
    bool peakRecordsDirty_ = false;
    QDateTime newestPeakAtUtc_;
    bool peakTrendChronological_ = true;
};

} // namespace tdlas::application
