#include "application/MeasurementStateMachine.h"

namespace tdlas::application {

contracts::MeasurementState MeasurementStateMachine::state() const
{
    return state_;
}

contracts::RunId MeasurementStateMachine::activeRunId() const
{
    return activeRunId_;
}

contracts::Sequence MeasurementStateMachine::lastAcceptedSequence() const
{
    return lastAcceptedSequence_;
}

bool MeasurementStateMachine::begin(const contracts::RunId &runId)
{
    if (state_ != contracts::MeasurementState::Idle || !runId.isValid()) {
        return false;
    }
    activeRunId_ = runId;
    lastAcceptedSequence_ = 0;
    state_ = contracts::MeasurementState::Preparing;
    return true;
}

bool MeasurementStateMachine::transitionTo(contracts::MeasurementState target)
{
    if (target == state_) {
        return true;
    }

    bool allowed = false;
    switch (state_) {
    case contracts::MeasurementState::Idle:
        allowed = target == contracts::MeasurementState::Preparing;
        break;
    case contracts::MeasurementState::Preparing:
        allowed = target == contracts::MeasurementState::Running
            || target == contracts::MeasurementState::Stopping;
        break;
    case contracts::MeasurementState::Running:
        allowed = target == contracts::MeasurementState::Stopping;
        break;
    case contracts::MeasurementState::Stopping:
        allowed = target == contracts::MeasurementState::Idle;
        break;
    case contracts::MeasurementState::Faulted:
        allowed = false;
        break;
    }
    if (!allowed) {
        return false;
    }
    state_ = target;
    if (state_ == contracts::MeasurementState::Idle) {
        activeRunId_ = {};
        lastAcceptedSequence_ = 0;
    }
    return true;
}

bool MeasurementStateMachine::acceptData(const contracts::RunId &runId, contracts::Sequence sequence)
{
    if (state_ != contracts::MeasurementState::Running || runId != activeRunId_
        || sequence == 0 || sequence <= lastAcceptedSequence_) {
        return false;
    }
    lastAcceptedSequence_ = sequence;
    return true;
}

void MeasurementStateMachine::fault()
{
    state_ = contracts::MeasurementState::Faulted;
}

bool MeasurementStateMachine::resetFault()
{
    if (state_ != contracts::MeasurementState::Faulted) {
        return false;
    }
    state_ = contracts::MeasurementState::Idle;
    activeRunId_ = {};
    lastAcceptedSequence_ = 0;
    return true;
}

} // namespace tdlas::application
