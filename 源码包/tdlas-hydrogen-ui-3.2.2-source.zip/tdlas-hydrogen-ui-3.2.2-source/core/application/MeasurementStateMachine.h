#pragma once

#include "contracts/MeasurementTypes.h"

namespace tdlas::application {

class MeasurementStateMachine final
{
public:
    [[nodiscard]] contracts::MeasurementState state() const;
    [[nodiscard]] contracts::RunId activeRunId() const;
    [[nodiscard]] contracts::Sequence lastAcceptedSequence() const;

    [[nodiscard]] bool begin(const contracts::RunId &runId);
    [[nodiscard]] bool transitionTo(contracts::MeasurementState target);
    [[nodiscard]] bool acceptData(const contracts::RunId &runId, contracts::Sequence sequence);
    void fault();
    [[nodiscard]] bool resetFault();

private:
    contracts::MeasurementState state_ = contracts::MeasurementState::Idle;
    contracts::RunId activeRunId_;
    contracts::Sequence lastAcceptedSequence_ = 0;
};

} // namespace tdlas::application
