#include "application/PeakRecordBuilder.h"

#include <cmath>
#include <algorithm>

namespace tdlas::application {

contracts::PeakRecord buildPeakRecord(
    const contracts::ProcessingResult &result,
    const contracts::ParameterSnapshot &parameters,
    const contracts::ExperimentId &experimentId,
    contracts::DataSourceKind sourceKind,
    const QDateTime &runStartedAtUtc)
{
    contracts::PeakRecord record;
    record.sequence = result.sourceSequence;
    record.acquiredAtUtc = result.timestamp.utc.toUTC();
    record.runId = result.runId;
    record.experimentId = experimentId;
    record.sourceKind = sourceKind;
    record.parameters = parameters;
    record.algorithmVersion = result.algorithmVersion;
    record.calibrationVersion = result.calibrationVersion;
    record.validity = result.validity;
    record.reason = result.diagnostic;
    if (!record.acquiredAtUtc.isValid() || !runStartedAtUtc.isValid()) {
        record.validity = contracts::DataValidity::Invalid;
        record.reason = QStringLiteral("采集时间缺失，无法建立可追溯峰值记录");
        return record;
    }
    record.elapsedSeconds = result.timestamp.monotonicNanoseconds >= 0
        ? static_cast<double>(result.timestamp.monotonicNanoseconds) / 1000000000.0
        : static_cast<double>(runStartedAtUtc.msecsTo(record.acquiredAtUtc)) / 1000.0;
    if (result.validity != contracts::DataValidity::Valid
        && result.validity != contracts::DataValidity::Uncalibrated) {
        if (record.reason.isEmpty()) {
            record.reason = QStringLiteral("FV 曲线质量无效");
        }
        return record;
    }

    const auto &curve = result.fittedAbsorbance.isEmpty()
        ? result.absorbance : result.fittedAbsorbance;
    const bool hasFrequency = result.relativeFrequencyCm1.size() == curve.size()
        && !curve.isEmpty();
    record.peakXUnit = hasFrequency ? QStringLiteral("cm⁻¹")
                                  : QStringLiteral("sample");
    for (qsizetype index = 0; index < curve.size(); ++index) {
        const double value = curve.at(index);
        const double position = hasFrequency
            ? result.relativeFrequencyCm1.at(index)
            : static_cast<double>(index);
        if (!std::isfinite(value) || !std::isfinite(position)) {
            continue;
        }
        if (!record.peakValue.has_value() || value > *record.peakValue) {
            record.peakValue = value;
            record.peakX = position;
        }
    }
    if (!record.peakValue.has_value()) {
        record.validity = contracts::DataValidity::Invalid;
        record.reason = curve.isEmpty() ? QStringLiteral("FV 曲线为空")
                                       : QStringLiteral("FV 曲线无有限数值");
    } else {
        // Uncalibrated concentration does not invalidate an absorbance peak.
        record.validity = contracts::DataValidity::Valid;
    }
    return record;
}

bool insertPeakRecord(QVector<contracts::PeakRecord> &records,
    const contracts::PeakRecord &record, qsizetype capacity)
{
    if (!record.runId.isValid() || record.sequence == 0 || capacity < 1) return false;
    const auto first = std::find_if(records.cbegin(), records.cend(), [&](const auto &r) { return r.runId == record.runId; });
    const auto last = std::find_if(first, records.cend(), [&](const auto &r) { return r.runId != record.runId; });
    const auto position = std::lower_bound(first, last, record.sequence,
        [](const auto &r, contracts::Sequence sequence) { return r.sequence < sequence; });
    if (position != last && position->sequence == record.sequence) return false;
    const qsizetype offset = position - records.cbegin();
    records.insert(offset, record);
    const qsizetype excess = records.size() - capacity;
    if (excess > 0) records.remove(0, excess);
    return excess <= offset;
}

} // namespace tdlas::application
