#pragma once

#include "contracts/MeasurementTypes.h"

namespace tdlas::application {

// One extraction point for peak charts, record details and CSV provenance.
[[nodiscard]] contracts::PeakRecord buildPeakRecord(
    const contracts::ProcessingResult &result,
    const contracts::ParameterSnapshot &parameters,
    const contracts::ExperimentId &experimentId,
    contracts::DataSourceKind sourceKind,
    const QDateTime &runStartedAtUtc);

// Run + source sequence is the acquisition identity. Late results fill their sequence position.
[[nodiscard]] bool insertPeakRecord(QVector<contracts::PeakRecord> &records,
    const contracts::PeakRecord &record, qsizetype capacity);

} // namespace tdlas::application
