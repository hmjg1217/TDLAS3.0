#include "application/StorageWorker.h"

namespace tdlas::application {

StorageWorker::StorageWorker(storage::IStorageRepository &repository, QObject *parent)
    : QObject(parent)
    , repository_(repository)
{
}

storage::StorageOperationResult StorageWorker::beginExperiment(
    const storage::ExperimentContext &context)
{
    failureReported_ = false;
    lastFailure_.reset();
    return repository_.beginExperiment(context);
}

storage::StorageOperationResult StorageWorker::finishExperiment(
    const contracts::ExperimentId &experimentId,
    storage::ExperimentCompletionStatus status,
    const QDateTime &completedAtUtc,
    const QString &diagnostic)
{
    const storage::ExperimentCompletionStatus finalStatus = lastFailure_.has_value()
        ? storage::ExperimentCompletionStatus::Faulted
        : status;
    const QString finalDiagnostic = lastFailure_.has_value()
        ? QStringLiteral("%1; %2").arg(lastFailure_->diagnostic, diagnostic)
        : diagnostic;
    const storage::StorageOperationResult finishResult = repository_.finishExperiment(
        experimentId, finalStatus, completedAtUtc, finalDiagnostic);
    if (!finishResult.success) {
        return finishResult;
    }
    if (lastFailure_.has_value()) {
        return *lastFailure_;
    }
    return finishResult;
}

void StorageWorker::appendRawData(
    const contracts::ExperimentId &experimentId,
    const contracts::RawDataBlock &block)
{
    const storage::StorageOperationResult result = repository_.appendRawData(experimentId, block);
    if (!result.success) {
        reportFailure(result, block.runId, block.sequence);
    }
}

void StorageWorker::appendProcessingResult(
    const contracts::ExperimentId &experimentId,
    const contracts::ProcessingResult &resultValue)
{
    const storage::StorageOperationResult result = repository_.appendProcessingResult(experimentId, resultValue);
    if (!result.success) {
        reportFailure(result, resultValue.runId, resultValue.sourceSequence);
    }
}

void StorageWorker::finishExperimentAsync(
    const contracts::ExperimentId &experimentId,
    storage::ExperimentCompletionStatus status,
    const QDateTime &completedAtUtc,
    const QString &diagnostic)
{
    const storage::StorageOperationResult result = finishExperiment(
        experimentId, status, completedAtUtc, diagnostic);
    emit experimentFinished(
        result.success, result.code, result.userMessage, result.diagnostic, result.path);
}

void StorageWorker::reportFailure(
    const storage::StorageOperationResult &result,
    const contracts::RunId &runId,
    std::optional<contracts::Sequence> sequence)
{
    if (failureReported_) {
        return;
    }
    failureReported_ = true;
    lastFailure_ = result;
    contracts::ModuleError error;
    error.code = result.code.isEmpty() ? QStringLiteral("STORAGE_WRITE_FAILED") : result.code;
    error.category = QStringLiteral("storage");
    error.severity = contracts::ErrorSeverity::Fatal;
    error.userMessage = result.userMessage.isEmpty()
        ? QStringLiteral("实验数据保存失败，采集已安全停止。")
        : result.userMessage;
    error.diagnostic = result.path.isEmpty()
        ? result.diagnostic
        : QStringLiteral("%1; path=%2").arg(result.diagnostic, result.path);
    error.timestamp.utc = QDateTime::currentDateTimeUtc();
    error.retryable = true;
    error.requiresStop = true;
    error.runId = runId;
    error.sequence = sequence;
    emit errorOccurred(error);
}

} // namespace tdlas::application

