#pragma once

#include "storage/IStorageRepository.h"

#include <QObject>

namespace tdlas::application {

class StorageWorker final : public QObject
{
    Q_OBJECT

public:
    explicit StorageWorker(storage::IStorageRepository &repository, QObject *parent = nullptr);

    [[nodiscard]] storage::StorageOperationResult beginExperiment(
        const storage::ExperimentContext &context);
    [[nodiscard]] storage::StorageOperationResult finishExperiment(
        const contracts::ExperimentId &experimentId,
        storage::ExperimentCompletionStatus status,
        const QDateTime &completedAtUtc,
        const QString &diagnostic);

public slots:
    void appendRawData(
        const tdlas::contracts::ExperimentId &experimentId,
        const tdlas::contracts::RawDataBlock &block);
    void appendProcessingResult(
        const tdlas::contracts::ExperimentId &experimentId,
        const tdlas::contracts::ProcessingResult &result);
    void finishExperimentAsync(
        const tdlas::contracts::ExperimentId &experimentId,
        tdlas::storage::ExperimentCompletionStatus status,
        const QDateTime &completedAtUtc,
        const QString &diagnostic);

signals:
    void errorOccurred(const tdlas::contracts::ModuleError &error);
    void experimentFinished(bool success, const QString &code,
        const QString &userMessage, const QString &diagnostic, const QString &path);

private:
    void reportFailure(
        const storage::StorageOperationResult &result,
        const contracts::RunId &runId,
        std::optional<contracts::Sequence> sequence = std::nullopt);

    storage::IStorageRepository &repository_;
    bool failureReported_ = false;
    std::optional<storage::StorageOperationResult> lastFailure_;
};

} // namespace tdlas::application

