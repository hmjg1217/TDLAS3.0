#include "camera/CameraApplicationService.h"

#include <QMetaObject>

namespace tdlas::camera {

CameraApplicationService::CameraApplicationService(
    std::unique_ptr<ICameraDevice> device,
    const QString &storageRoot,
    QObject *parent)
    : QObject(parent)
{
    qRegisterMetaType<CameraFormat>();
    qRegisterMetaType<CameraFrame>();
    qRegisterMetaType<CameraDisplayModel>();
    qRegisterMetaType<MediaResult>();
    qRegisterMetaType<CameraViewState>();
    qRegisterMetaType<CameraViewOperation>();
    qRegisterMetaType<CameraControlState>();
    qRegisterMetaType<contracts::ExperimentId>();
    qRegisterMetaType<contracts::ModuleError>();

    auto *worker = new CameraWorker(std::move(device), storageRoot);
    worker_ = worker;
    worker->moveToThread(&workerThread_);
    connect(&workerThread_, &QThread::finished, worker, &QObject::deleteLater);
    connect(worker, &CameraWorker::displayModelChanged,
        this, [this](const CameraDisplayModel &model) {
            if (shutdownComplete_ && model.state != CameraSessionState::Idle) return;
            const bool reset = model.sessionId != displayModel_.sessionId
                || model.state == CameraSessionState::Idle
                || model.state == CameraSessionState::Faulted;
            displayModel_ = model;
            if (reset) { resetView(); clearCameraControls(); }
            emit displayModelChanged(displayModel_);
            if (previewRequested_ && model.latestFrame.has_value() && model.latestFrame->isValid()
                && controlState_.sessionId.isEmpty()) refreshCameraControls();
        });
    connect(worker, &CameraWorker::cameraControlsChanged, this, [this](const CameraControlState &state) {
        if (shutdownComplete_ || !previewRequested_ || state.sessionId != displayModel_.sessionId.value) return;
        controlInFlight_ = false;
        controlState_ = state;
        emit cameraControlsChanged(controlState_);
        if (pendingControl_.has_value()) controlTimer_.start();
    });
    controlTimer_.setSingleShot(true);
    controlTimer_.setInterval(100);
    connect(&controlTimer_, &QTimer::timeout, this, &CameraApplicationService::dispatchCameraControl);
    controlPollTimer_.setInterval(1000);
    connect(&controlPollTimer_, &QTimer::timeout, this, &CameraApplicationService::refreshCameraControls);
    controlPollTimer_.start();
    connect(worker, &CameraWorker::mediaCompleted,
        this, &CameraApplicationService::mediaCompleted);
    connect(worker, &CameraWorker::errorOccurred,
        this, &CameraApplicationService::errorOccurred);
    workerThread_.setObjectName(QStringLiteral("tdlas-camera-worker"));
    workerThread_.start();
}

CameraApplicationService::~CameraApplicationService()
{
    shutdown();
}

void CameraApplicationService::refreshDevices()
{
    invokeWorker([](CameraWorker &worker) { worker.refreshDevices(); });
}

void CameraApplicationService::startPreview(const QString &cameraId, const CameraFormat &format)
{
    if (shutdownComplete_) return;
    previewRequested_ = true;
    clearCameraControls();
    resetView();
    invokeWorker([cameraId, format](CameraWorker &worker) { worker.startPreview(cameraId, format); });
}

void CameraApplicationService::stopPreview()
{
    previewRequested_ = false;
    clearCameraControls();
    resetView();
    invokeWorker([](CameraWorker &worker) { worker.stopPreview(); });
}

void CameraApplicationService::capturePhoto(const contracts::ExperimentId &experimentId)
{
    invokeWorker([experimentId](CameraWorker &worker) { worker.capturePhoto(experimentId); });
}

void CameraApplicationService::startRecording(const contracts::ExperimentId &experimentId)
{
    invokeWorker([experimentId](CameraWorker &worker) { worker.startRecording(experimentId); });
}

void CameraApplicationService::stopRecording()
{
    invokeWorker([](CameraWorker &worker) { worker.stopRecording(); });
}

void CameraApplicationService::setStorageRoot(const QString &storageRoot)
{
    invokeWorker([storageRoot](CameraWorker &worker) { worker.setStorageRoot(storageRoot); });
}

void CameraApplicationService::operateView(CameraViewOperation operation)
{
    if (shutdownComplete_ || !previewRequested_
        || (displayModel_.state != CameraSessionState::Previewing
            && displayModel_.state != CameraSessionState::Recording)
        || !displayModel_.latestFrame.has_value()
        || !displayModel_.latestFrame->isValid()
        || displayModel_.latestFrame->sessionId != displayModel_.sessionId) return;
    if (operation == CameraViewOperation::RotateClockwise) {
        // Rotation is a display feature; direction/zoom always go to the device.
        viewState_.quarterTurns = (viewState_.quarterTurns + 1) % 4;
        emit viewStateChanged(viewState_);
    } else {
        if (operation == CameraViewOperation::Reset) resetView();
        pendingControl_ = operation; // One latest intent, never an unbounded queue.
        if (!controlInFlight_ && !controlTimer_.isActive()) controlTimer_.start();
    }
}

void CameraApplicationService::clearCameraControls()
{
    pendingControl_.reset();
    controlTimer_.stop();
    controlInFlight_ = false;
    controlState_ = {};
    emit cameraControlsChanged(controlState_);
}

void CameraApplicationService::refreshCameraControls()
{
    if (shutdownComplete_ || !previewRequested_ || controlInFlight_ || pendingControl_.has_value()
        || !displayModel_.latestFrame.has_value() || !displayModel_.latestFrame->isValid()) return;
    controlInFlight_ = true;
    const auto session = displayModel_.sessionId.value;
    invokeWorker([session](CameraWorker &worker) { worker.readCameraControls(session); });
}

void CameraApplicationService::dispatchCameraControl()
{
    if (shutdownComplete_ || !previewRequested_ || controlInFlight_ || !pendingControl_.has_value()) return;
    const auto operation = *pendingControl_;
    pendingControl_.reset();
    controlInFlight_ = true;
    const auto session = displayModel_.sessionId.value;
    invokeWorker([session, operation](CameraWorker &worker) { worker.operateCameraControls(session, operation); });
}

const CameraViewState &CameraApplicationService::viewState() const
{
    return viewState_;
}

void CameraApplicationService::resetView()
{
    viewState_ = {};
    emit viewStateChanged(viewState_);
}

void CameraApplicationService::shutdown()
{
    if (shutdownComplete_) {
        return;
    }
    shutdownComplete_ = true;
    controlPollTimer_.stop();
    clearCameraControls();
    resetView();
    if (worker_ && workerThread_.isRunning()) {
        QMetaObject::invokeMethod(
            worker_,
            [worker = worker_]() {
                if (worker) {
                    worker->shutdown();
                }
            },
            Qt::BlockingQueuedConnection);
    }
    workerThread_.quit();
    workerThread_.wait();
}

const CameraDisplayModel &CameraApplicationService::displayModel() const
{
    return displayModel_;
}

bool CameraApplicationService::workerThreadRunning() const
{
    return workerThread_.isRunning();
}

template<typename Function>
void CameraApplicationService::invokeWorker(Function &&function)
{
    if (shutdownComplete_ || !worker_ || !workerThread_.isRunning()) {
        return;
    }
    QMetaObject::invokeMethod(
        worker_,
        [worker = worker_, function = std::forward<Function>(function)]() mutable {
            if (worker) {
                function(*worker);
            }
        },
        Qt::QueuedConnection);
}

} // namespace tdlas::camera
