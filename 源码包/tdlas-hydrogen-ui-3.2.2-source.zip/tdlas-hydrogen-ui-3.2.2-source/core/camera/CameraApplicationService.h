#pragma once

#include "camera/CameraWorker.h"
#include "camera/CameraViewState.h"

#include <QPointer>
#include <QThread>
#include <QTimer>

#include <memory>

namespace tdlas::camera {

class CameraApplicationService final : public QObject
{
    Q_OBJECT

public:
    CameraApplicationService(
        std::unique_ptr<ICameraDevice> device,
        const QString &storageRoot,
        QObject *parent = nullptr);
    ~CameraApplicationService() override;

    void refreshDevices();
    void startPreview(const QString &cameraId, const CameraFormat &format = {});
    void stopPreview();
    void capturePhoto(const contracts::ExperimentId &experimentId);
    void startRecording(const contracts::ExperimentId &experimentId);
    void stopRecording();
    void operateView(CameraViewOperation operation);
    [[nodiscard]] const CameraViewState &viewState() const;
    [[nodiscard]] const CameraControlState &cameraControls() const { return controlState_; }
    void refreshCameraControls();
    void setStorageRoot(const QString &storageRoot);
    void shutdown();

    [[nodiscard]] const CameraDisplayModel &displayModel() const;
    [[nodiscard]] bool workerThreadRunning() const;

signals:
    void cameraControlsChanged(const tdlas::camera::CameraControlState &state);
    void viewStateChanged(const tdlas::camera::CameraViewState &state);
    void displayModelChanged(const tdlas::camera::CameraDisplayModel &model);
    void mediaCompleted(const tdlas::camera::MediaResult &result);
    void errorOccurred(const tdlas::contracts::ModuleError &error);

private:
    void resetView();
    void clearCameraControls();
    void dispatchCameraControl();
    template<typename Function>
    void invokeWorker(Function &&function);

    QThread workerThread_;
    QPointer<CameraWorker> worker_;
    CameraDisplayModel displayModel_;
    CameraViewState viewState_;
    CameraControlState controlState_;
    QTimer controlTimer_, controlPollTimer_;
    std::optional<CameraViewOperation> pendingControl_;
    bool controlInFlight_ = false;
    bool previewRequested_ = false;
    bool shutdownComplete_ = false;
};

} // namespace tdlas::camera
