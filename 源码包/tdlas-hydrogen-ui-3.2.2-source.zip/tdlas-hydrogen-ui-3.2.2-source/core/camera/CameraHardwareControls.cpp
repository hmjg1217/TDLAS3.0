#include "camera/CameraHardwareControls.h"
#include <algorithm>
#include <QtGlobal>

namespace tdlas::camera {
CameraControlRange &cameraControlRange(CameraControlState &state, CameraControlAxis axis)
{
    if (axis == CameraControlAxis::Pan) return state.pan;
    if (axis == CameraControlAxis::Tilt) return state.tilt;
    return state.zoom;
}

bool cameraHardwareOperationEnabled(const CameraControlState &state, CameraViewOperation operation)
{
    using O = CameraViewOperation;
    const CameraControlRange *range = nullptr;
    bool increase = false;
    switch (operation) {
    case O::MoveLeft: range = &state.pan; break;
    case O::MoveRight: range = &state.pan; increase = true; break;
    case O::MoveDown: range = &state.tilt; break;
    case O::MoveUp: range = &state.tilt; increase = true; break;
    case O::ZoomOut: range = &state.zoom; break;
    case O::ZoomIn: range = &state.zoom; increase = true; break;
    case O::Reset: return state.pan.writable || state.tilt.writable || state.zoom.writable;
    default: return false;
    }
    return range->readable && range->writable && range->step > 0
        && (increase ? range->value < range->maximum : range->value > range->minimum);
}

bool applyCameraHardwareOperation(CameraControlState &state, CameraViewOperation operation, const CameraControlWriter &write)
{
    using O = CameraViewOperation;
    state.success = false;
    const auto set = [&](CameraControlAxis axis, qint64 target) {
        auto &range = cameraControlRange(state, axis);
        if (!range.readable || !range.writable || range.step <= 0 || range.minimum > range.maximum) {
            state.message = QStringLiteral("所选相机不支持此设备控制，未进行软件替代。");
            return false;
        }
        target = std::clamp(target, qint64(range.minimum), qint64(range.maximum));
        target = range.minimum + ((target - range.minimum) / range.step) * range.step;
        if (target == range.value) { state.message = QStringLiteral("已到达设备控制边界。"); return true; }
        QString error;
        if (!write(axis, static_cast<int>(target), error)) {
            state.message = QStringLiteral("设备控制失败：%1").arg(error);
            return false;
        }
        // The caller replaces this optimistic value with a fresh driver readback.
        range.value = static_cast<int>(target);
        state.message = QStringLiteral("设备控制已写入，正在回读确认。");
        return true;
    };
    switch (operation) {
    case O::MoveLeft: state.success = set(CameraControlAxis::Pan, qint64(state.pan.value) - state.pan.step); break;
    case O::MoveRight: state.success = set(CameraControlAxis::Pan, qint64(state.pan.value) + state.pan.step); break;
    case O::MoveDown: state.success = set(CameraControlAxis::Tilt, qint64(state.tilt.value) - state.tilt.step); break;
    case O::MoveUp: state.success = set(CameraControlAxis::Tilt, qint64(state.tilt.value) + state.tilt.step); break;
    case O::ZoomOut: state.success = set(CameraControlAxis::Zoom, qint64(state.zoom.value) - state.zoom.step); break;
    case O::ZoomIn: state.success = set(CameraControlAxis::Zoom, qint64(state.zoom.value) + state.zoom.step); break;
    case O::Reset: {
        bool any = false, passed = true;
        QString failures;
        for (auto axis : {CameraControlAxis::Pan, CameraControlAxis::Tilt, CameraControlAxis::Zoom}) {
            auto &range = cameraControlRange(state, axis);
            if (!range.readable || !range.writable) continue;
            any = true;
            if (!set(axis, range.defaultValue)) { passed = false; failures += state.message + QLatin1Char(' '); }
        }
        state.success = any && passed;
        state.message = !any ? QStringLiteral("此相机未提供可复位的 PTZ 控制。")
            : passed ? QStringLiteral("PTZ 已恢复驱动默认值；曝光和对焦保持原设置。") : failures;
        break;
    }
    default: state.message = QStringLiteral("此操作不属于设备 PTZ 控制。"); break;
    }
    return state.success;
}
}
