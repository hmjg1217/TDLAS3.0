#pragma once

#include "camera/CameraViewState.h"
#include <QString>
#include <QMetaType>
#include <functional>

namespace tdlas::camera {
enum class CameraControlAxis { Pan, Tilt, Zoom };

struct CameraControlRange {
    bool readable = false;
    bool writable = false;
    int minimum = 0;
    int maximum = 0;
    int step = 1;
    int defaultValue = 0;
    int value = 0;
};

struct CameraControlState {
    QString sessionId;
    QString cameraId;
    CameraControlRange pan, tilt, zoom;
    bool simulated = false;
    bool success = true;
    QString message;
};

using CameraControlWriter = std::function<bool(CameraControlAxis, int, QString &)>;
[[nodiscard]] CameraControlRange &cameraControlRange(CameraControlState &state, CameraControlAxis axis);
// Reads and writes belong to the device's owning worker. Values are driver units.
[[nodiscard]] bool applyCameraHardwareOperation(
    CameraControlState &state, CameraViewOperation operation, const CameraControlWriter &write);
[[nodiscard]] bool cameraHardwareOperationEnabled(const CameraControlState &state, CameraViewOperation operation);
}

Q_DECLARE_METATYPE(tdlas::camera::CameraControlState)
