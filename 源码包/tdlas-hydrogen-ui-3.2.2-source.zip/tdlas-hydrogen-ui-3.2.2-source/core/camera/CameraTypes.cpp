#include "camera/CameraTypes.h"

#include <cmath>

namespace tdlas::camera {

bool CameraFormat::isValid() const
{
    return frameSize.width() > 0
        && frameSize.height() > 0
        && std::isfinite(minimumFrameRate)
        && std::isfinite(maximumFrameRate)
        && minimumFrameRate > 0.0
        && maximumFrameRate >= minimumFrameRate
        && !pixelFormat.trimmed().isEmpty();
}

QString CameraFormat::displayName() const
{
    if (!isValid()) {
        return {};
    }
    const double frameRate = maximumFrameRate;
    return QStringLiteral("%1 × %2 · %3 FPS · %4")
        .arg(frameSize.width())
        .arg(frameSize.height())
        .arg(frameRate, 0, 'f', std::abs(frameRate - std::round(frameRate)) < 0.001 ? 0 : 2)
        .arg(pixelFormat);
}

bool CameraDeviceDescriptor::isValid() const
{
    if (id.trimmed().isEmpty() || displayName.trimmed().isEmpty() || formats.isEmpty()) {
        return false;
    }
    for (const CameraFormat &format : formats) {
        if (!format.isValid()) {
            return false;
        }
    }
    return true;
}

bool CameraFrame::isValid() const
{
    return sessionId.isValid()
        && !cameraId.trimmed().isEmpty()
        && sequence > 0
        && timestamp.utc.isValid()
        && !pixelFormat.trimmed().isEmpty()
        && !image.isNull()
        && validity == contracts::DataValidity::Valid;
}

QString cameraSessionStateName(CameraSessionState state)
{
    switch (state) {
    case CameraSessionState::Idle:
        return QStringLiteral("Idle");
    case CameraSessionState::Previewing:
        return QStringLiteral("Previewing");
    case CameraSessionState::Recording:
        return QStringLiteral("Recording");
    case CameraSessionState::Faulted:
        return QStringLiteral("Faulted");
    }
    return QStringLiteral("Unknown");
}

QString mediaTypeName(MediaType mediaType)
{
    return mediaType == MediaType::Photo
        ? QStringLiteral("photo")
        : QStringLiteral("video");
}

} // namespace tdlas::camera
