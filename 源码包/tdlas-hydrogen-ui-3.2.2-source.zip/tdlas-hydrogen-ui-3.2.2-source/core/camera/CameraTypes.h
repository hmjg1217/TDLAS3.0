#pragma once

#include "contracts/MeasurementTypes.h"

#include <QImage>
#include <QMetaType>
#include <QSize>
#include <QString>
#include <QVector>

#include <optional>

namespace tdlas::camera {

struct CameraSessionId {
    QString value;

    [[nodiscard]] bool isValid() const { return !value.trimmed().isEmpty(); }
};

inline bool operator==(const CameraSessionId &left, const CameraSessionId &right)
{
    return left.value == right.value;
}

inline bool operator!=(const CameraSessionId &left, const CameraSessionId &right)
{
    return !(left == right);
}

struct CameraFormat {
    QSize frameSize;
    double minimumFrameRate = 0.0;
    double maximumFrameRate = 0.0;
    QString pixelFormat;

    [[nodiscard]] bool isValid() const;
    [[nodiscard]] QString displayName() const;
};

struct CameraDeviceDescriptor {
    QString id;
    QString displayName;
    QVector<CameraFormat> formats;
    contracts::DataSourceKind sourceKind = contracts::DataSourceKind::Simulation;
    bool isDefault = false;

    [[nodiscard]] bool isValid() const;
};

enum class CameraDeviceState {
    Disconnected,
    Connecting,
    Connected,
    Previewing,
    Faulted
};

enum class CameraSessionState {
    Idle,
    Previewing,
    Recording,
    Faulted
};

struct CameraFrame {
    CameraSessionId sessionId;
    QString cameraId;
    contracts::Sequence sequence = 0;
    contracts::Timestamp timestamp;
    QString pixelFormat;
    QImage image;
    contracts::DataValidity validity = contracts::DataValidity::Invalid;
    QString diagnostic;

    [[nodiscard]] bool isValid() const;
};

enum class MediaType {
    Photo,
    Video
};

struct MediaResult {
    CameraSessionId sessionId;
    contracts::ExperimentId experimentId;
    QString cameraId;
    MediaType mediaType = MediaType::Photo;
    QDateTime startedAtUtc;
    QDateTime completedAtUtc;
    QString path;
    quint64 frameCount = 0;
    bool success = false;
    QString errorCode;
    QString diagnostic;
};

struct CameraDisplayModel {
    QVector<CameraDeviceDescriptor> devices;
    CameraSessionState state = CameraSessionState::Idle;
    CameraSessionId sessionId;
    QString selectedCameraId;
    CameraFormat activeFormat;
    contracts::DataSourceKind sourceKind = contracts::DataSourceKind::Simulation;
    std::optional<CameraFrame> latestFrame;
    std::optional<MediaResult> lastMediaResult;
    qint64 recordingDurationMilliseconds = 0;
    QString statusMessage;
    QString diagnostic;
};

[[nodiscard]] QString cameraSessionStateName(CameraSessionState state);
[[nodiscard]] QString mediaTypeName(MediaType mediaType);

} // namespace tdlas::camera

Q_DECLARE_METATYPE(tdlas::camera::CameraSessionId)
Q_DECLARE_METATYPE(tdlas::camera::CameraFormat)
Q_DECLARE_METATYPE(tdlas::camera::CameraDeviceDescriptor)
Q_DECLARE_METATYPE(QVector<tdlas::camera::CameraDeviceDescriptor>)
Q_DECLARE_METATYPE(tdlas::camera::CameraDeviceState)
Q_DECLARE_METATYPE(tdlas::camera::CameraSessionState)
Q_DECLARE_METATYPE(tdlas::camera::CameraFrame)
Q_DECLARE_METATYPE(tdlas::camera::MediaResult)
Q_DECLARE_METATYPE(tdlas::camera::CameraDisplayModel)
