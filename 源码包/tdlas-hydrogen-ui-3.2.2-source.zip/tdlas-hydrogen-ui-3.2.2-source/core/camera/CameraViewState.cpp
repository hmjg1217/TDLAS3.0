#include "camera/CameraViewState.h"

#include <algorithm>
#include <cmath>

namespace tdlas::camera {

CameraViewState normalizedCameraView(const CameraViewState &state)
{
    CameraViewState result = state;
    result.zoom = std::isfinite(state.zoom)
        ? std::clamp(state.zoom, CameraViewState::minimumZoom, CameraViewState::maximumZoom) : 1.0;
    const auto offset = [](double value) {
        return std::isfinite(value)
            ? std::clamp(value, -CameraViewState::maximumOffset, CameraViewState::maximumOffset) : 0.0;
    };
    result.offset = QPointF(offset(state.offset.x()), offset(state.offset.y()));
    result.quarterTurns = ((state.quarterTurns % 4) + 4) % 4;
    return result;
}

CameraViewState applyCameraViewOperation(const CameraViewState &state, CameraViewOperation operation)
{
    auto result = normalizedCameraView(state);
    switch (operation) {
    case CameraViewOperation::MoveUp: result.offset.ry() -= CameraViewState::movementStep; break;
    case CameraViewOperation::MoveDown: result.offset.ry() += CameraViewState::movementStep; break;
    case CameraViewOperation::MoveLeft: result.offset.rx() -= CameraViewState::movementStep; break;
    case CameraViewOperation::MoveRight: result.offset.rx() += CameraViewState::movementStep; break;
    case CameraViewOperation::ZoomIn:
    case CameraViewOperation::ZoomOut: {
        const double zoom = std::clamp(
            result.zoom * (operation == CameraViewOperation::ZoomIn
                ? CameraViewState::zoomStep : 1.0 / CameraViewState::zoomStep),
            CameraViewState::minimumZoom, CameraViewState::maximumZoom);
        // Scale the translation too, so zoom is anchored at the viewport centre.
        result.offset *= zoom / result.zoom;
        result.zoom = zoom;
        break;
    }
    case CameraViewOperation::RotateClockwise: ++result.quarterTurns; break;
    case CameraViewOperation::Reset: return {};
    }
    return normalizedCameraView(result);
}

QTransform cameraImageTransform(
    const CameraViewState &state, const QSizeF &imageSize, const QRectF &viewport)
{
    if (imageSize.isEmpty() || viewport.isEmpty()) return {};
    const auto view = normalizedCameraView(state);
    const QSizeF rotatedSize = view.quarterTurns % 2
        ? QSizeF(imageSize.height(), imageSize.width()) : imageSize;
    // Retain the existing centre-fill view at zoom 1, including after rotation.
    const double scale = std::max(viewport.width() / rotatedSize.width(),
        viewport.height() / rotatedSize.height()) * view.zoom;
    QTransform transform;
    transform.translate(viewport.center().x() + view.offset.x() * viewport.width(),
        viewport.center().y() + view.offset.y() * viewport.height());
    transform.rotate(90.0 * view.quarterTurns);
    transform.scale(scale, scale);
    transform.translate(-imageSize.width() / 2.0, -imageSize.height() / 2.0);
    return transform;
}

} // namespace tdlas::camera
