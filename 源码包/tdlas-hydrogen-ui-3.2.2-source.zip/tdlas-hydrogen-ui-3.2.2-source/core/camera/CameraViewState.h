#pragma once

#include <QMetaType>
#include <QPointF>
#include <QRectF>
#include <QSizeF>
#include <QTransform>

namespace tdlas::camera {

enum class CameraViewOperation {
    MoveUp, MoveDown, MoveLeft, MoveRight,
    ZoomIn, ZoomOut, RotateClockwise, Reset
};

// Preview-only state. Source frames, photos and videos are never transformed.
struct CameraViewState {
    static constexpr double minimumZoom = 0.25;
    static constexpr double maximumZoom = 8.0;
    static constexpr double zoomStep = 1.2;
    static constexpr double movementStep = 0.05;
    static constexpr double maximumOffset = 0.45;
    static constexpr int repeatDelayMilliseconds = 400;
    static constexpr int repeatIntervalMilliseconds = 80;

    double zoom = 1.0;
    QPointF offset; // Fractions of the viewport; positive x/y means right/down.
    int quarterTurns = 0;
};

[[nodiscard]] CameraViewState normalizedCameraView(const CameraViewState &state);
[[nodiscard]] CameraViewState applyCameraViewOperation(
    const CameraViewState &state, CameraViewOperation operation);
[[nodiscard]] QTransform cameraImageTransform(
    const CameraViewState &state, const QSizeF &imageSize, const QRectF &viewport);

} // namespace tdlas::camera

Q_DECLARE_METATYPE(tdlas::camera::CameraViewState)
Q_DECLARE_METATYPE(tdlas::camera::CameraViewOperation)
