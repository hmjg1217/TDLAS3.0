#include "camera/CameraWorker.h"

#include <QBuffer>
#include <QDate>
#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QJsonDocument>
#include <QJsonObject>
#include <QSaveFile>
#include <QUuid>

#include <algorithm>

namespace tdlas::camera {

namespace {

QString utcFileStamp(const QDateTime &utc)
{
    return utc.toUTC().toString(QStringLiteral("yyyyMMdd'T'HHmmsszzz'Z'"));
}

QString randomSuffix()
{
    return QUuid::createUuid().toString(QUuid::WithoutBraces).left(8).toLower();
}

MediaResult failedMediaResult(
    MediaType type,
    const CameraSessionId &sessionId,
    const contracts::ExperimentId &experimentId,
    const QString &cameraId,
    const QString &code,
    const QString &diagnostic)
{
    MediaResult result;
    result.sessionId = sessionId;
    result.experimentId = experimentId;
    result.cameraId = cameraId;
    result.mediaType = type;
    result.completedAtUtc = QDateTime::currentDateTimeUtc();
    result.errorCode = code;
    result.diagnostic = diagnostic;
    return result;
}

} // namespace

class FileMediaStore final
{
public:
    explicit FileMediaStore(QString storageRoot)
        : storageRoot_(QDir::cleanPath(std::move(storageRoot)))
    {
    }

    MediaResult capturePhoto(
        const CameraFrame &frame,
        const contracts::ExperimentId &experimentId)
    {
        const QString mediaDirectory = ensureMediaDirectory(experimentId);
        if (mediaDirectory.isEmpty()) {
            return failedMediaResult(
                MediaType::Photo, frame.sessionId, experimentId, frame.cameraId,
                QStringLiteral("MEDIA_EXPERIMENT_DIRECTORY_MISSING"),
                QStringLiteral("experiment directory does not exist"));
        }
        const QDateTime completedAtUtc = QDateTime::currentDateTimeUtc();
        const QString fileName = QStringLiteral("photo-%1-%2.png")
                                     .arg(utcFileStamp(completedAtUtc), randomSuffix());
        const QString path = QDir(mediaDirectory).filePath(fileName);
        QSaveFile file(path);
        if (!file.open(QIODevice::WriteOnly)) {
            return failedMediaResult(
                MediaType::Photo, frame.sessionId, experimentId, frame.cameraId,
                QStringLiteral("MEDIA_PHOTO_OPEN_FAILED"), file.errorString());
        }
        if (!frame.image.save(&file, "PNG") || !file.commit()) {
            return failedMediaResult(
                MediaType::Photo, frame.sessionId, experimentId, frame.cameraId,
                QStringLiteral("MEDIA_PHOTO_WRITE_FAILED"), file.errorString());
        }

        MediaResult result;
        result.sessionId = frame.sessionId;
        result.experimentId = experimentId;
        result.cameraId = frame.cameraId;
        result.mediaType = MediaType::Photo;
        result.startedAtUtc = frame.timestamp.utc;
        result.completedAtUtc = completedAtUtc;
        result.path = path;
        result.frameCount = 1;
        result.success = true;
        const QString indexError = appendIndex(result, frame.image.size(), frame.pixelFormat);
        if (!indexError.isEmpty()) {
            result.success = false;
            result.errorCode = QStringLiteral("MEDIA_INDEX_WRITE_FAILED");
            result.diagnostic = indexError;
        }
        return result;
    }

    MediaResult beginVideo(
        const CameraFrame &frame,
        const contracts::ExperimentId &experimentId)
    {
        if (videoFile_) {
            return failedMediaResult(
                MediaType::Video, frame.sessionId, experimentId, frame.cameraId,
                QStringLiteral("MEDIA_VIDEO_ALREADY_RECORDING"),
                QStringLiteral("a recording is already open"));
        }
        const QString mediaDirectory = ensureMediaDirectory(experimentId);
        if (mediaDirectory.isEmpty()) {
            return failedMediaResult(
                MediaType::Video, frame.sessionId, experimentId, frame.cameraId,
                QStringLiteral("MEDIA_EXPERIMENT_DIRECTORY_MISSING"),
                QStringLiteral("experiment directory does not exist"));
        }
        const QDateTime startedAtUtc = QDateTime::currentDateTimeUtc();
        const QString fileName = QStringLiteral("video-%1-%2.mjpeg")
                                     .arg(utcFileStamp(startedAtUtc), randomSuffix());
        const QString path = QDir(mediaDirectory).filePath(fileName);
        auto videoFile = std::make_unique<QSaveFile>(path);
        if (!videoFile->open(QIODevice::WriteOnly)) {
            return failedMediaResult(
                MediaType::Video, frame.sessionId, experimentId, frame.cameraId,
                QStringLiteral("MEDIA_VIDEO_OPEN_FAILED"), videoFile->errorString());
        }
        videoFile_ = std::move(videoFile);
        videoResult_ = {};
        videoResult_.sessionId = frame.sessionId;
        videoResult_.experimentId = experimentId;
        videoResult_.cameraId = frame.cameraId;
        videoResult_.mediaType = MediaType::Video;
        videoResult_.startedAtUtc = startedAtUtc;
        videoResult_.path = path;
        videoFrameSize_ = frame.image.size();
        videoPixelFormat_ = frame.pixelFormat;
        return videoResult_;
    }

    QString appendVideoFrame(const CameraFrame &frame)
    {
        if (!videoFile_ || frame.sessionId != videoResult_.sessionId) {
            return QStringLiteral("no matching recording is open");
        }
        QByteArray jpeg;
        QBuffer buffer(&jpeg);
        if (!buffer.open(QIODevice::WriteOnly) || !frame.image.save(&buffer, "JPG", 85)) {
            return QStringLiteral("JPEG encoding failed");
        }
        if (videoFile_->write(jpeg) != jpeg.size()) {
            return videoFile_->errorString();
        }
        ++videoResult_.frameCount;
        return {};
    }

    MediaResult finishVideo()
    {
        if (!videoFile_) {
            return failedMediaResult(
                MediaType::Video, {}, {}, {},
                QStringLiteral("MEDIA_VIDEO_NOT_RECORDING"),
                QStringLiteral("no recording is open"));
        }
        MediaResult result = videoResult_;
        result.completedAtUtc = QDateTime::currentDateTimeUtc();
        if (result.frameCount == 0) {
            videoFile_->cancelWriting();
            result.errorCode = QStringLiteral("MEDIA_VIDEO_EMPTY");
            result.diagnostic = QStringLiteral("recording contains no complete frames");
            videoFile_.reset();
            videoResult_ = {};
            return result;
        }
        if (!videoFile_->commit()) {
            result.errorCode = QStringLiteral("MEDIA_VIDEO_COMMIT_FAILED");
            result.diagnostic = videoFile_->errorString();
            videoFile_.reset();
            videoResult_ = {};
            return result;
        }
        videoFile_.reset();
        result.success = true;
        const QString indexError = appendIndex(result, videoFrameSize_, videoPixelFormat_);
        if (!indexError.isEmpty()) {
            result.success = false;
            result.errorCode = QStringLiteral("MEDIA_INDEX_WRITE_FAILED");
            result.diagnostic = indexError;
        }
        videoResult_ = {};
        return result;
    }

    MediaResult abortVideo(const QString &code, const QString &diagnostic)
    {
        MediaResult result = videoResult_;
        result.completedAtUtc = QDateTime::currentDateTimeUtc();
        result.errorCode = code;
        result.diagnostic = diagnostic;
        if (videoFile_) {
            videoFile_->cancelWriting();
        }
        videoFile_.reset();
        videoResult_ = {};
        return result;
    }

    [[nodiscard]] bool isRecording() const { return videoFile_ != nullptr; }

private:
    QString experimentDirectory(const contracts::ExperimentId &experimentId) const
    {
        if (!experimentId.isValid()) {
            return {};
        }
        const QDate date = QDate::fromString(experimentId.value.mid(4, 8), QStringLiteral("yyyyMMdd"));
        if (!date.isValid()) {
            return {};
        }
        return QDir(storageRoot_).filePath(
            QStringLiteral("%1/%2/%3/%4")
                .arg(date.toString(QStringLiteral("yyyy")),
                    date.toString(QStringLiteral("MM")),
                    date.toString(QStringLiteral("dd")),
                    experimentId.value));
    }

    QString ensureMediaDirectory(const contracts::ExperimentId &experimentId) const
    {
        if (!experimentId.isValid() || storageRoot_.isEmpty()) {
            return {};
        }
        // Keep camera output in the operator-selected root's dedicated folder.
        // This makes the sidebar data-root choice control photos and videos
        // without requiring the measurement archive to exist first.
        const QString media = QDir(storageRoot_).filePath(QStringLiteral("拍照摄像"));
        if (!QDir().mkpath(media)) {
            return {};
        }
        return media;
    }

    QString appendIndex(
        const MediaResult &result,
        const QSize &frameSize,
        const QString &pixelFormat) const
    {
        const QString media = QFileInfo(result.path).absolutePath();
        QFile index(QDir(media).filePath(QStringLiteral("index.jsonl")));
        if (!index.open(QIODevice::WriteOnly | QIODevice::Append | QIODevice::Text)) {
            return index.errorString();
        }
        QJsonObject object{
            {QStringLiteral("contractVersion"), QStringLiteral("%1.%2")
                .arg(contracts::kContractMajorVersion)
                .arg(contracts::kContractMinorVersion)},
            {QStringLiteral("experimentId"), result.experimentId.value},
            {QStringLiteral("cameraSessionId"), result.sessionId.value},
            {QStringLiteral("cameraId"), result.cameraId},
            {QStringLiteral("mediaType"), mediaTypeName(result.mediaType)},
            {QStringLiteral("startedAtUtc"), result.startedAtUtc.toUTC().toString(Qt::ISODateWithMs)},
            {QStringLiteral("completedAtUtc"), result.completedAtUtc.toUTC().toString(Qt::ISODateWithMs)},
            {QStringLiteral("fileName"), QFileInfo(result.path).fileName()},
            {QStringLiteral("frameCount"), static_cast<qint64>(result.frameCount)},
            {QStringLiteral("width"), frameSize.width()},
            {QStringLiteral("height"), frameSize.height()},
            {QStringLiteral("pixelFormat"), pixelFormat}};
        const QByteArray line = QJsonDocument(object).toJson(QJsonDocument::Compact) + '\n';
        if (index.write(line) != line.size() || !index.flush()) {
            return index.errorString();
        }
        return {};
    }

    QString storageRoot_;
    std::unique_ptr<QSaveFile> videoFile_;
    MediaResult videoResult_;
    QSize videoFrameSize_;
    QString videoPixelFormat_;
};

CameraWorker::CameraWorker(
    std::unique_ptr<ICameraDevice> device,
    const QString &storageRoot,
    QObject *parent)
    : QObject(parent)
    , device_(device.release())
    , mediaStore_(std::make_unique<FileMediaStore>(storageRoot))
{
    Q_ASSERT(device_);
    device_->setParent(this);
    connect(device_, &ICameraDevice::frameReady,
        this, &CameraWorker::handleFrame);
    connect(device_, &ICameraDevice::errorOccurred,
        this, &CameraWorker::handleDeviceError);
    connect(device_, &ICameraDevice::devicesChanged,
        this, [this](const QVector<CameraDeviceDescriptor> &devices) {
            model_.devices = devices;
            publishModel(true);
        });
}

CameraWorker::~CameraWorker() = default;

void CameraWorker::refreshDevices()
{
    if (shuttingDown_) {
        return;
    }
    model_.devices = device_->enumerateDevices();
    if (model_.devices.isEmpty()) {
        model_.statusMessage = QStringLiteral("未发现可用摄像头。");
    } else if (model_.state == CameraSessionState::Idle) {
        model_.statusMessage = QStringLiteral("已发现 %1 个摄像头，等待选择。").arg(model_.devices.size());
    }
    publishModel(true);
}

void CameraWorker::startPreview(const QString &cameraId, const CameraFormat &format)
{
    if (shuttingDown_) {
        return;
    }
    if (model_.devices.isEmpty()) {
        refreshDevices();
    }
    const CameraDeviceDescriptor *descriptor = findDevice(cameraId);
    if (!descriptor) {
        publishOperationError(
            QStringLiteral("CAMERA_NOT_FOUND"),
            QStringLiteral("未找到所选摄像头。"),
            cameraId);
        return;
    }
    const CameraFormat selectedFormat = selectFormat(*descriptor, format);
    if (!selectedFormat.isValid()) {
        publishOperationError(
            QStringLiteral("CAMERA_FORMAT_NOT_FOUND"),
            QStringLiteral("所选摄像头没有可用视频格式。"),
            cameraId);
        return;
    }
    if (model_.state == CameraSessionState::Recording) {
        stopRecording();
    }
    if (device_->state() != CameraDeviceState::Disconnected) {
        (void)device_->stopPreview();
        (void)device_->disconnectDevice();
    }

    model_.sessionId = {QUuid::createUuid().toString(QUuid::WithoutBraces)};
    controlMessage_.clear();
    controlSuccess_ = true;
    model_.selectedCameraId = descriptor->id;
    model_.activeFormat = selectedFormat;
    model_.sourceKind = descriptor->sourceKind;
    model_.latestFrame.reset();
    latestSourceFrame_.reset();
    model_.lastMediaResult.reset();
    model_.diagnostic.clear();
    lastAcceptedSequence_ = 0;
    if (!device_->connectDevice(descriptor->id, selectedFormat)
        || !device_->startPreview(model_.sessionId)) {
        model_.state = CameraSessionState::Faulted;
        model_.statusMessage = QStringLiteral("摄像头预览启动失败。");
        publishModel(true);
        return;
    }
    previewPublishTimer_.restart();
    model_.state = CameraSessionState::Previewing;
    model_.statusMessage = descriptor->sourceKind == contracts::DataSourceKind::Simulation
        ? QStringLiteral("模拟摄像头预览中。")
        : QStringLiteral("摄像头预览中。");
    publishModel(true);
}

void CameraWorker::stopPreview()
{
    if (model_.state == CameraSessionState::Recording) {
        stopRecording();
    }
    (void)device_->stopPreview();
    (void)device_->disconnectDevice();
    model_.state = CameraSessionState::Idle;
    model_.sessionId = {};
    model_.selectedCameraId.clear();
    model_.activeFormat = {};
    model_.latestFrame.reset();
    latestSourceFrame_.reset();
    model_.recordingDurationMilliseconds = 0;
    model_.statusMessage = QStringLiteral("摄像头已释放。");
    lastAcceptedSequence_ = 0;
    publishModel(true);
}

void CameraWorker::readCameraControls(const QString &sessionId)
{
    if (sessionId != model_.sessionId.value || shuttingDown_) return;
    auto state = device_->readCameraControls();
    state.sessionId = sessionId;
    state.cameraId = model_.selectedCameraId;
    if (!controlMessage_.isEmpty()) state.message = controlMessage_;
    state.success = controlSuccess_;
    emit cameraControlsChanged(state);
}

void CameraWorker::operateCameraControls(const QString &sessionId, CameraViewOperation operation)
{
    if (shuttingDown_ || sessionId != model_.sessionId.value
        || (model_.state != CameraSessionState::Previewing && model_.state != CameraSessionState::Recording)) return;
    auto state = device_->readCameraControls();
    const auto before = state;
    controlSuccess_ = applyCameraHardwareOperation(state, operation,
        [this](CameraControlAxis axis, int value, QString &error) { return device_->setCameraControl(axis, value, error); });
    if (controlSuccess_) {
        auto readback = device_->readCameraControls();
        auto original = before;
        for (auto axis : {CameraControlAxis::Pan, CameraControlAxis::Tilt, CameraControlAxis::Zoom}) {
            const auto wanted = cameraControlRange(state, axis);
            const auto previous = cameraControlRange(original, axis);
            const auto actual = cameraControlRange(readback, axis);
            if (wanted.value != previous.value && (!actual.readable || actual.value != wanted.value)) {
                controlSuccess_ = false;
                state.message = QStringLiteral("设备回读未确认本次操作，请重试或检查相机。");
            }
        }
    }
    controlMessage_ = controlSuccess_ ? QStringLiteral("设备控制已完成并回读。") : state.message;
    readCameraControls(sessionId);
}

void CameraWorker::capturePhoto(const contracts::ExperimentId &experimentId)
{
    if ((model_.state != CameraSessionState::Previewing
            && model_.state != CameraSessionState::Recording)
        || !latestSourceFrame_.has_value()) {
        publishOperationError(
            QStringLiteral("CAMERA_PHOTO_NOT_READY"),
            QStringLiteral("摄像预览尚未就绪，无法拍照。"),
            QStringLiteral("no valid preview frame"));
        return;
    }
    const MediaResult result = mediaStore_->capturePhoto(*latestSourceFrame_, experimentId);
    model_.lastMediaResult = result;
    model_.statusMessage = result.success
        ? QStringLiteral("照片已保存并关联实验 %1。").arg(experimentId.value)
        : QStringLiteral("照片保存失败。");
    model_.diagnostic = result.diagnostic;
    emit mediaCompleted(result);
    if (!result.success) {
        publishOperationError(
            result.errorCode,
            QStringLiteral("照片保存失败。"),
            result.diagnostic);
    }
    publishModel(true);
}

void CameraWorker::startRecording(const contracts::ExperimentId &experimentId)
{
    if (model_.state == CameraSessionState::Recording) {
        return;
    }
    if (model_.state != CameraSessionState::Previewing || !latestSourceFrame_.has_value()) {
        publishOperationError(
            QStringLiteral("CAMERA_VIDEO_NOT_READY"),
            QStringLiteral("摄像预览尚未就绪，无法录像。"),
            QStringLiteral("no valid preview frame"));
        return;
    }
    const MediaResult begin = mediaStore_->beginVideo(*latestSourceFrame_, experimentId);
    if (!begin.errorCode.isEmpty()) {
        model_.lastMediaResult = begin;
        emit mediaCompleted(begin);
        publishOperationError(
            begin.errorCode,
            QStringLiteral("录像文件创建失败。"),
            begin.diagnostic);
        return;
    }
    recordingTimer_.restart();
    model_.state = CameraSessionState::Recording;
    model_.recordingDurationMilliseconds = 0;
    model_.statusMessage = QStringLiteral("正在录像 · 实验 %1").arg(experimentId.value);
    publishModel(true);
}

void CameraWorker::stopRecording()
{
    if (model_.state != CameraSessionState::Recording || !mediaStore_->isRecording()) {
        return;
    }
    const MediaResult result = mediaStore_->finishVideo();
    model_.lastMediaResult = result;
    model_.state = CameraSessionState::Previewing;
    model_.recordingDurationMilliseconds = 0;
    model_.statusMessage = result.success
        ? QStringLiteral("录像已保存并关联实验 %1。").arg(result.experimentId.value)
        : QStringLiteral("录像保存失败。");
    model_.diagnostic = result.diagnostic;
    emit mediaCompleted(result);
    if (!result.success) {
        publishOperationError(
            result.errorCode,
            QStringLiteral("录像保存失败。"),
            result.diagnostic);
    }
    publishModel(true);
}

void CameraWorker::setStorageRoot(const QString &storageRoot)
{
    if (model_.state == CameraSessionState::Recording) {
        stopRecording();
    }
    mediaStore_ = std::make_unique<FileMediaStore>(storageRoot);
}

void CameraWorker::shutdown()
{
    if (shuttingDown_) {
        return;
    }
    shuttingDown_ = true;
    if (model_.state == CameraSessionState::Recording) {
        stopRecording();
    }
    (void)device_->stopPreview();
    (void)device_->disconnectDevice();
    model_.state = CameraSessionState::Idle;
    model_.sessionId = {};
    model_.selectedCameraId.clear();
    model_.latestFrame.reset();
    latestSourceFrame_.reset();
    model_.recordingDurationMilliseconds = 0;
    model_.statusMessage = QStringLiteral("摄像会话已关闭并释放设备。");
    publishModel(true);
}

void CameraWorker::handleFrame(const CameraFrame &frame)
{
    if (!frame.isValid()
        || frame.sessionId != model_.sessionId
        || frame.sequence <= lastAcceptedSequence_
        || (model_.state != CameraSessionState::Previewing
            && model_.state != CameraSessionState::Recording)) {
        return;
    }
    lastAcceptedSequence_ = frame.sequence;
    if (model_.state == CameraSessionState::Recording) {
        const QString writeError = mediaStore_->appendVideoFrame(frame);
        if (!writeError.isEmpty()) {
            const MediaResult result = mediaStore_->abortVideo(
                QStringLiteral("MEDIA_VIDEO_WRITE_FAILED"), writeError);
            model_.lastMediaResult = result;
            model_.state = CameraSessionState::Previewing;
            model_.recordingDurationMilliseconds = 0;
            emit mediaCompleted(result);
            publishOperationError(
                result.errorCode,
                QStringLiteral("录像写入失败。"),
                result.diagnostic);
        } else {
            model_.recordingDurationMilliseconds = recordingTimer_.elapsed();
        }
    }
    latestSourceFrame_ = frame;
    CameraFrame displayFrame = frame;
    if (displayFrame.image.width() > 1280 || displayFrame.image.height() > 720) {
        displayFrame.image = displayFrame.image.scaled(
            QSize(1280, 720), Qt::KeepAspectRatio, Qt::SmoothTransformation);
    }
    model_.latestFrame = std::move(displayFrame);
    if (!previewPublishTimer_.isValid() || previewPublishTimer_.elapsed() >= 66) {
        previewPublishTimer_.restart();
        publishModel();
    }
}

void CameraWorker::handleDeviceError(const contracts::ModuleError &error)
{
    if (mediaStore_->isRecording()) {
        const MediaResult result = mediaStore_->abortVideo(error.code, error.diagnostic);
        model_.lastMediaResult = result;
        emit mediaCompleted(result);
    }
    if (error.requiresStop) {
        (void)device_->stopPreview();
        (void)device_->disconnectDevice();
    }
    model_.state = CameraSessionState::Faulted;
    model_.latestFrame.reset();
    latestSourceFrame_.reset();
    model_.recordingDurationMilliseconds = 0;
    model_.statusMessage = error.userMessage;
    model_.diagnostic = error.diagnostic;
    emit errorOccurred(error);
    publishModel(true);
}

void CameraWorker::publishModel(bool force)
{
    Q_UNUSED(force)
    emit displayModelChanged(model_);
}

void CameraWorker::publishOperationError(
    const QString &code,
    const QString &userMessage,
    const QString &diagnostic,
    bool requiresStop)
{
    contracts::ModuleError error;
    error.code = code;
    error.category = QStringLiteral("camera");
    error.severity = contracts::ErrorSeverity::Recoverable;
    error.userMessage = userMessage;
    error.diagnostic = diagnostic;
    error.timestamp.utc = QDateTime::currentDateTimeUtc();
    error.retryable = true;
    error.requiresStop = requiresStop;
    model_.statusMessage = userMessage;
    model_.diagnostic = diagnostic;
    emit errorOccurred(error);
}

const CameraDeviceDescriptor *CameraWorker::findDevice(const QString &cameraId) const
{
    for (const CameraDeviceDescriptor &device : model_.devices) {
        if (device.id == cameraId) {
            return &device;
        }
    }
    return nullptr;
}

CameraFormat CameraWorker::selectFormat(
    const CameraDeviceDescriptor &device,
    const CameraFormat &requested) const
{
    if (requested.isValid()) {
        for (const CameraFormat &candidate : device.formats) {
            if (candidate.frameSize == requested.frameSize
                && candidate.pixelFormat == requested.pixelFormat
                && std::abs(candidate.maximumFrameRate - requested.maximumFrameRate) < 0.01) {
                return candidate;
            }
        }
        return {};
    }
    return device.formats.isEmpty() ? CameraFormat{} : device.formats.first();
}

} // namespace tdlas::camera
