#pragma once

#include "camera/ICameraDevice.h"

#include <QElapsedTimer>
#include <QObject>

#include <memory>
#include <optional>

namespace tdlas::camera {

class FileMediaStore;

class CameraWorker final : public QObject
{
    Q_OBJECT

public:
    CameraWorker(
        std::unique_ptr<ICameraDevice> device,
        const QString &storageRoot,
        QObject *parent = nullptr);
    ~CameraWorker() override;

public slots:
    void refreshDevices();
    void startPreview(const QString &cameraId, const tdlas::camera::CameraFormat &format = {});
    void stopPreview();
    void capturePhoto(const tdlas::contracts::ExperimentId &experimentId);
    void startRecording(const tdlas::contracts::ExperimentId &experimentId);
    void stopRecording();
    void setStorageRoot(const QString &storageRoot);
    void shutdown();
    void readCameraControls(const QString &sessionId);
    void operateCameraControls(const QString &sessionId, tdlas::camera::CameraViewOperation operation);

signals:
    void cameraControlsChanged(const tdlas::camera::CameraControlState &state);
    void displayModelChanged(const tdlas::camera::CameraDisplayModel &model);
    void mediaCompleted(const tdlas::camera::MediaResult &result);
    void errorOccurred(const tdlas::contracts::ModuleError &error);

private:
    void handleFrame(const tdlas::camera::CameraFrame &frame);
    void handleDeviceError(const tdlas::contracts::ModuleError &error);
    void publishModel(bool force = false);
    void publishOperationError(
        const QString &code,
        const QString &userMessage,
        const QString &diagnostic,
        bool requiresStop = false);
    [[nodiscard]] const CameraDeviceDescriptor *findDevice(const QString &cameraId) const;
    [[nodiscard]] CameraFormat selectFormat(
        const CameraDeviceDescriptor &device,
        const CameraFormat &requested) const;

    ICameraDevice *device_ = nullptr;
    std::unique_ptr<FileMediaStore> mediaStore_;
    CameraDisplayModel model_;
    std::optional<CameraFrame> latestSourceFrame_;
    QElapsedTimer previewPublishTimer_;
    QElapsedTimer recordingTimer_;
    contracts::Sequence lastAcceptedSequence_ = 0;
    bool shuttingDown_ = false;
    QString controlMessage_;
    bool controlSuccess_ = true;
};

} // namespace tdlas::camera
