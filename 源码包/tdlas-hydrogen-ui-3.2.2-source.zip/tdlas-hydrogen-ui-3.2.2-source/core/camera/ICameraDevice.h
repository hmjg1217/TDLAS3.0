#pragma once

#include "camera/CameraTypes.h"
#include "camera/CameraHardwareControls.h"

#include <QObject>

namespace tdlas::camera {

class ICameraDevice : public QObject
{
    Q_OBJECT

public:
    explicit ICameraDevice(QObject *parent = nullptr)
        : QObject(parent)
    {
    }
    ~ICameraDevice() override = default;

    [[nodiscard]] virtual QVector<CameraDeviceDescriptor> enumerateDevices() = 0;
    [[nodiscard]] virtual CameraDeviceState state() const = 0;
    [[nodiscard]] virtual bool connectDevice(
        const QString &cameraId,
        const CameraFormat &format) = 0;
    [[nodiscard]] virtual bool disconnectDevice() = 0;
    [[nodiscard]] virtual bool startPreview(const CameraSessionId &sessionId) = 0;
    [[nodiscard]] virtual bool stopPreview() = 0;
    [[nodiscard]] virtual CameraControlState readCameraControls() { return {}; }
    virtual bool setCameraControl(CameraControlAxis, int, QString &error) {
        error = QStringLiteral("此设备未实现 PTZ 控制。"); return false;
    }

signals:
    void devicesChanged(const QVector<tdlas::camera::CameraDeviceDescriptor> &devices);
    void stateChanged(tdlas::camera::CameraDeviceState state);
    void frameReady(const tdlas::camera::CameraFrame &frame);
    void errorOccurred(const tdlas::contracts::ModuleError &error);
};

} // namespace tdlas::camera
