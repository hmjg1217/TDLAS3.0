#include "camera/MockCameraDevice.h"

#include <QDateTime>
#include <QLinearGradient>
#include <QPainter>

namespace tdlas::camera {

namespace {

CameraFormat mockFormat(const QSize &size, int intervalMilliseconds)
{
    CameraFormat format;
    format.frameSize = size;
    format.minimumFrameRate = 1000.0 / static_cast<double>(qMax(1, intervalMilliseconds));
    format.maximumFrameRate = format.minimumFrameRate;
    format.pixelFormat = QStringLiteral("RGB32");
    return format;
}

} // namespace

MockCameraDevice::MockCameraDevice(QObject *parent)
    : MockCameraDevice(MockCameraOptions{}, parent)
{
}

MockCameraDevice::MockCameraDevice(const MockCameraOptions &options, QObject *parent)
    : ICameraDevice(parent)
    , options_(options)
    , frameTimer_(new QTimer(this))
{
    frameTimer_->setInterval(qMax(1, options_.frameIntervalMilliseconds));
    frameTimer_->setTimerType(Qt::PreciseTimer);
    connect(frameTimer_, &QTimer::timeout, this, &MockCameraDevice::generateFrame);
}

CameraControlState MockCameraDevice::readCameraControls()
{
    if (!controls_.simulated) {
        controls_.simulated = true;
        controls_.pan = {true, true, -180, 180, 1, 0, 0};
        controls_.tilt = controls_.pan;
        controls_.zoom = {true, true, 0, 260, 1, 0, 0};
    }
    return controls_;
}

bool MockCameraDevice::setCameraControl(CameraControlAxis axis, int value, QString &error)
{
    (void)readCameraControls();
    auto &range = cameraControlRange(controls_, axis);
    if (state_ != CameraDeviceState::Previewing || value < range.minimum || value > range.maximum) {
        error = QStringLiteral("模拟设备状态或范围无效。"); return false;
    }
    range.value = value;
    return true;
}

QVector<CameraDeviceDescriptor> MockCameraDevice::enumerateDevices()
{
    CameraDeviceDescriptor descriptor;
    descriptor.id = QStringLiteral("mock-camera-0");
    descriptor.displayName = QStringLiteral("模拟摄像头 (mock-camera-0)");
    descriptor.formats = {mockFormat(options_.frameSize, options_.frameIntervalMilliseconds)};
    descriptor.sourceKind = contracts::DataSourceKind::Simulation;
    descriptor.isDefault = true;
    const QVector<CameraDeviceDescriptor> devices{descriptor};
    emit devicesChanged(devices);
    return devices;
}

CameraDeviceState MockCameraDevice::state() const
{
    return state_;
}

bool MockCameraDevice::connectDevice(const QString &cameraId, const CameraFormat &format)
{
    if (state_ == CameraDeviceState::Connected || state_ == CameraDeviceState::Previewing) {
        return cameraId_ == cameraId && activeFormat_.frameSize == format.frameSize;
    }
    if (cameraId != QStringLiteral("mock-camera-0") || !format.isValid()
        || format.frameSize != options_.frameSize) {
        setState(CameraDeviceState::Faulted);
        reportError(
            QStringLiteral("MOCK_CAMERA_NOT_FOUND"),
            QStringLiteral("未找到模拟摄像头或请求格式无效。"),
            QStringLiteral("camera=%1 format=%2").arg(cameraId, format.displayName()),
            false);
        return false;
    }
    setState(CameraDeviceState::Connecting);
    cameraId_ = cameraId;
    activeFormat_ = format;
    setState(CameraDeviceState::Connected);
    return true;
}

bool MockCameraDevice::disconnectDevice()
{
    if (state_ == CameraDeviceState::Disconnected) {
        return true;
    }
    (void)stopPreview();
    cameraId_.clear();
    activeFormat_ = {};
    sessionId_ = {};
    sequence_ = 0;
    setState(CameraDeviceState::Disconnected);
    return true;
}

bool MockCameraDevice::startPreview(const CameraSessionId &sessionId)
{
    if (state_ == CameraDeviceState::Previewing) {
        return sessionId_ == sessionId;
    }
    if (state_ != CameraDeviceState::Connected || !sessionId.isValid()) {
        reportError(
            QStringLiteral("MOCK_CAMERA_START_STATE"),
            QStringLiteral("模拟摄像头当前无法开始预览。"),
            QStringLiteral("camera is not connected or session id is invalid"),
            false);
        return false;
    }
    sessionId_ = sessionId;
    sequence_ = 0;
    monotonicClock_.start();
    setState(CameraDeviceState::Previewing);
    frameTimer_->start();
    QTimer::singleShot(0, this, &MockCameraDevice::generateFrame);
    return true;
}

bool MockCameraDevice::stopPreview()
{
    frameTimer_->stop();
    sessionId_ = {};
    sequence_ = 0;
    if (state_ == CameraDeviceState::Previewing || state_ == CameraDeviceState::Faulted) {
        setState(cameraId_.isEmpty() ? CameraDeviceState::Disconnected : CameraDeviceState::Connected);
    }
    return true;
}

void MockCameraDevice::generateFrame()
{
    if (state_ != CameraDeviceState::Previewing) {
        return;
    }
    if (options_.disconnectAfterFrames > 0 && sequence_ >= options_.disconnectAfterFrames) {
        frameTimer_->stop();
        setState(CameraDeviceState::Faulted);
        reportError(
            QStringLiteral("MOCK_CAMERA_DISCONNECTED"),
            QStringLiteral("模拟摄像头连接已断开。"),
            QStringLiteral("injected disconnect after %1 frames").arg(options_.disconnectAfterFrames),
            true);
        return;
    }

    QImage image(activeFormat_.frameSize, QImage::Format_RGB32);
    image.fill(QColor(QStringLiteral("#0b1722")));
    QPainter painter(&image);
    painter.setRenderHint(QPainter::Antialiasing);
    QLinearGradient background(0, 0, 0, image.height());
    background.setColorAt(0.0, QColor(QStringLiteral("#263b4c")));
    background.setColorAt(0.65, QColor(QStringLiteral("#101b26")));
    background.setColorAt(1.0, QColor(QStringLiteral("#07111c")));
    painter.fillRect(image.rect(), background);

    const qreal centerY = image.height() * 0.5;
    const qreal left = image.width() * 0.18;
    const qreal right = image.width() * 0.82;
    const qreal tubeHeight = image.height() * 0.28;
    painter.setPen(QPen(QColor(215, 235, 245, 180), 2.0));
    painter.setBrush(QColor(140, 195, 220, 85));
    painter.drawRoundedRect(
        QRectF(left, centerY - tubeHeight / 2.0, right - left, tubeHeight),
        tubeHeight / 3.0,
        tubeHeight / 3.0);
    const qreal pulse = static_cast<qreal>((sequence_ * 7U) % 100U) / 100.0;
    painter.setPen(QPen(QColor(255, 48, 79, 85), 10.0, Qt::SolidLine, Qt::RoundCap));
    painter.drawLine(QPointF(image.width() * 0.08, centerY), QPointF(image.width() * 0.92, centerY));
    painter.setPen(QPen(QColor(255, 89 + static_cast<int>(80 * pulse), 109), 3.0, Qt::SolidLine, Qt::RoundCap));
    painter.drawLine(QPointF(image.width() * 0.08, centerY), QPointF(image.width() * 0.92, centerY));
    painter.end();

    CameraFrame frame;
    frame.sessionId = sessionId_;
    frame.cameraId = cameraId_;
    frame.sequence = ++sequence_;
    frame.timestamp.utc = QDateTime::currentDateTimeUtc();
    frame.timestamp.monotonicNanoseconds = monotonicClock_.nsecsElapsed();
    frame.pixelFormat = QStringLiteral("RGB32");
    frame.image = std::move(image);
    frame.validity = contracts::DataValidity::Valid;
    frame.diagnostic = QStringLiteral("deterministic mock camera frame");
    emit frameReady(frame);
}

void MockCameraDevice::setState(CameraDeviceState state)
{
    if (state_ == state) {
        return;
    }
    state_ = state;
    emit stateChanged(state_);
}

void MockCameraDevice::reportError(
    const QString &code,
    const QString &userMessage,
    const QString &diagnostic,
    bool requiresStop)
{
    contracts::ModuleError error;
    error.code = code;
    error.category = QStringLiteral("camera");
    error.severity = contracts::ErrorSeverity::Recoverable;
    error.userMessage = userMessage;
    error.diagnostic = diagnostic;
    error.timestamp.utc = QDateTime::currentDateTimeUtc();
    error.retryable = true;
    error.requiresStop = requiresStop;
    emit errorOccurred(error);
}

} // namespace tdlas::camera
