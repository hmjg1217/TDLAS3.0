#pragma once

#include "camera/ICameraDevice.h"

#include <QElapsedTimer>
#include <QTimer>

namespace tdlas::camera {

struct MockCameraOptions {
    int frameIntervalMilliseconds = 50;
    QSize frameSize = QSize(640, 360);
    quint64 disconnectAfterFrames = 0;
};

class MockCameraDevice final : public ICameraDevice
{
    Q_OBJECT

public:
    explicit MockCameraDevice(QObject *parent = nullptr);
    explicit MockCameraDevice(const MockCameraOptions &options, QObject *parent = nullptr);

    [[nodiscard]] QVector<CameraDeviceDescriptor> enumerateDevices() override;
    [[nodiscard]] CameraDeviceState state() const override;
    [[nodiscard]] bool connectDevice(
        const QString &cameraId,
        const CameraFormat &format) override;
    [[nodiscard]] bool disconnectDevice() override;
    [[nodiscard]] bool startPreview(const CameraSessionId &sessionId) override;
    [[nodiscard]] bool stopPreview() override;
    CameraControlState readCameraControls() override;
    bool setCameraControl(CameraControlAxis axis, int value, QString &error) override;

private:
    void generateFrame();
    void setState(CameraDeviceState state);
    void reportError(
        const QString &code,
        const QString &userMessage,
        const QString &diagnostic,
        bool requiresStop);

    MockCameraOptions options_;
    QTimer *frameTimer_ = nullptr;
    QElapsedTimer monotonicClock_;
    CameraDeviceState state_ = CameraDeviceState::Disconnected;
    CameraFormat activeFormat_;
    CameraSessionId sessionId_;
    QString cameraId_;
    contracts::Sequence sequence_ = 0;
    CameraControlState controls_;
};

} // namespace tdlas::camera
