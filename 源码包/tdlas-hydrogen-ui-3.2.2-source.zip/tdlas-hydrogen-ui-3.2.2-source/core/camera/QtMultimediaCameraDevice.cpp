#include "camera/QtMultimediaCameraDevice.h"

#include <QCamera>
#include <QCameraDevice>
#include <QCameraFormat>
#include <QDateTime>
#include <QMediaCaptureSession>
#include <QMediaDevices>
#include <QVideoFrame>
#include <QVideoFrameFormat>
#include <QVideoSink>

#include <cmath>

namespace tdlas::camera {

namespace {

QString stableCameraId(const QCameraDevice &device)
{
    return QString::fromLatin1(device.id().toHex());
}

QString pixelFormatName(QVideoFrameFormat::PixelFormat format)
{
    const QString name = QVideoFrameFormat::pixelFormatToString(format);
    return name.isEmpty() ? QStringLiteral("Unknown") : name;
}

CameraFormat toContractFormat(const QCameraFormat &format)
{
    CameraFormat result;
    result.frameSize = format.resolution();
    result.minimumFrameRate = static_cast<double>(format.minFrameRate());
    result.maximumFrameRate = static_cast<double>(format.maxFrameRate());
    result.pixelFormat = pixelFormatName(format.pixelFormat());
    return result;
}

bool formatMatches(const QCameraFormat &candidate, const CameraFormat &requested)
{
    return candidate.resolution() == requested.frameSize
        && std::abs(static_cast<double>(candidate.minFrameRate()) - requested.minimumFrameRate) < 0.01
        && std::abs(static_cast<double>(candidate.maxFrameRate()) - requested.maximumFrameRate) < 0.01
        && pixelFormatName(candidate.pixelFormat()) == requested.pixelFormat;
}

} // namespace

QtMultimediaCameraDevice::QtMultimediaCameraDevice(QObject *parent)
    : ICameraDevice(parent)
    , deviceWatchTimer_(new QTimer(this))
{
    deviceWatchTimer_->setInterval(1000);
    connect(deviceWatchTimer_, &QTimer::timeout,
        this, &QtMultimediaCameraDevice::verifySelectedDeviceStillPresent);
}

QtMultimediaCameraDevice::~QtMultimediaCameraDevice()
{
    (void)disconnectDevice();
}

QVector<CameraDeviceDescriptor> QtMultimediaCameraDevice::enumerateDevices()
{
    QVector<CameraDeviceDescriptor> result;
    const QList<QCameraDevice> inputs = QMediaDevices::videoInputs();
    const QCameraDevice defaultInput = QMediaDevices::defaultVideoInput();
    result.reserve(inputs.size());
    for (const QCameraDevice &input : inputs) {
        CameraDeviceDescriptor descriptor;
        descriptor.id = stableCameraId(input);
        descriptor.displayName = input.description();
        descriptor.sourceKind = contracts::DataSourceKind::RealDevice;
        descriptor.isDefault = !defaultInput.isNull() && input.id() == defaultInput.id();
        const QList<QCameraFormat> formats = input.videoFormats();
        descriptor.formats.reserve(formats.size());
        for (const QCameraFormat &format : formats) {
            const CameraFormat contractFormat = toContractFormat(format);
            if (contractFormat.isValid()) {
                descriptor.formats.push_back(contractFormat);
            }
        }
        if (descriptor.isValid()) {
            result.push_back(descriptor);
        }
    }
    emit devicesChanged(result);
    return result;
}

CameraDeviceState QtMultimediaCameraDevice::state() const
{
    return state_;
}

bool QtMultimediaCameraDevice::connectDevice(
    const QString &cameraId,
    const CameraFormat &format)
{
    if (state_ == CameraDeviceState::Connected || state_ == CameraDeviceState::Previewing) {
        return cameraId_ == cameraId
            && activeFormat_.frameSize == format.frameSize
            && activeFormat_.pixelFormat == format.pixelFormat;
    }
    if (cameraId.trimmed().isEmpty() || !format.isValid()) {
        reportError(
            QStringLiteral("CAMERA_CONNECT_INVALID"),
            QStringLiteral("摄像头或视频格式无效。"),
            QStringLiteral("empty camera id or invalid format"),
            false);
        return false;
    }

    QCameraDevice selected;
    QCameraFormat selectedFormat;
    for (const QCameraDevice &input : QMediaDevices::videoInputs()) {
        if (stableCameraId(input) != cameraId) {
            continue;
        }
        selected = input;
        for (const QCameraFormat &candidate : input.videoFormats()) {
            if (formatMatches(candidate, format)) {
                selectedFormat = candidate;
                break;
            }
        }
        break;
    }
    if (selected.isNull() || selectedFormat.isNull()) {
        setState(CameraDeviceState::Faulted);
        reportError(
            QStringLiteral("CAMERA_DEVICE_OR_FORMAT_NOT_FOUND"),
            QStringLiteral("未找到所选摄像头或视频格式。"),
            QStringLiteral("camera=%1 format=%2").arg(cameraId, format.displayName()),
            false);
        return false;
    }

    setState(CameraDeviceState::Connecting);
    captureSession_ = new QMediaCaptureSession(this);
    videoSink_ = new QVideoSink(this);
    camera_ = new QCamera(selected, this);
    (void)controls_.open(selected.id());
    camera_->setCameraFormat(selectedFormat);
    captureSession_->setCamera(camera_);
    captureSession_->setVideoSink(videoSink_);
    connect(videoSink_, &QVideoSink::videoFrameChanged,
        this, &QtMultimediaCameraDevice::handleVideoFrame);
    connect(camera_, &QCamera::errorOccurred,
        this, [this](QCamera::Error, const QString &) { handleCameraError(); });
    cameraId_ = cameraId;
    activeFormat_ = format;
    deviceWatchTimer_->start();
    setState(CameraDeviceState::Connected);
    return true;
}

bool QtMultimediaCameraDevice::disconnectDevice()
{
    controls_.close();
    deviceWatchTimer_->stop();
    (void)stopPreview();
    if (captureSession_) {
        captureSession_->setCamera(nullptr);
        captureSession_->setVideoSink(nullptr);
    }
    delete camera_;
    delete videoSink_;
    delete captureSession_;
    camera_ = nullptr;
    videoSink_ = nullptr;
    captureSession_ = nullptr;
    cameraId_.clear();
    activeFormat_ = {};
    sessionId_ = {};
    sequence_ = 0;
    setState(CameraDeviceState::Disconnected);
    return true;
}

CameraControlState QtMultimediaCameraDevice::readCameraControls()
{
    return controls_.read();
}

bool QtMultimediaCameraDevice::setCameraControl(CameraControlAxis axis, int value, QString &error)
{
    return controls_.write(axis, value, error);
}

bool QtMultimediaCameraDevice::startPreview(const CameraSessionId &sessionId)
{
    if (state_ == CameraDeviceState::Previewing) {
        return sessionId_ == sessionId;
    }
    if (state_ != CameraDeviceState::Connected || !camera_ || !sessionId.isValid()) {
        reportError(
            QStringLiteral("CAMERA_START_STATE"),
            QStringLiteral("摄像头当前无法开始预览。"),
            QStringLiteral("camera is not connected or session id is invalid"),
            false);
        return false;
    }
    sessionId_ = sessionId;
    sequence_ = 0;
    monotonicClock_.start();
    camera_->start();
    setState(CameraDeviceState::Previewing);
    return true;
}

bool QtMultimediaCameraDevice::stopPreview()
{
    if (camera_) {
        camera_->stop();
    }
    sessionId_ = {};
    sequence_ = 0;
    if (state_ == CameraDeviceState::Previewing || state_ == CameraDeviceState::Faulted) {
        setState(camera_ ? CameraDeviceState::Connected : CameraDeviceState::Disconnected);
    }
    return true;
}

void QtMultimediaCameraDevice::handleVideoFrame(const QVideoFrame &videoFrame)
{
    if (state_ != CameraDeviceState::Previewing || !sessionId_.isValid()) {
        return;
    }
    const QImage image = videoFrame.toImage();
    if (image.isNull()) {
        reportError(
            QStringLiteral("CAMERA_FRAME_CONVERSION_FAILED"),
            QStringLiteral("摄像画面格式无法转换。"),
            QStringLiteral("QVideoFrame::toImage returned an empty image"),
            false);
        return;
    }
    CameraFrame frame;
    frame.sessionId = sessionId_;
    frame.cameraId = cameraId_;
    frame.sequence = ++sequence_;
    frame.timestamp.utc = QDateTime::currentDateTimeUtc();
    frame.timestamp.monotonicNanoseconds = monotonicClock_.nsecsElapsed();
    frame.pixelFormat = QVideoFrameFormat::pixelFormatToString(videoFrame.pixelFormat());
    if (frame.pixelFormat.isEmpty()) {
        frame.pixelFormat = QStringLiteral("QImage");
    }
    frame.image = image.copy();
    frame.validity = contracts::DataValidity::Valid;
    emit frameReady(frame);
}

void QtMultimediaCameraDevice::handleCameraError()
{
    const QString diagnostic = camera_ ? camera_->errorString() : QStringLiteral("camera object missing");
    setState(CameraDeviceState::Faulted);
    reportError(
        QStringLiteral("CAMERA_RUNTIME_ERROR"),
        QStringLiteral("摄像头运行失败或连接已断开。"),
        diagnostic,
        true);
}

void QtMultimediaCameraDevice::verifySelectedDeviceStillPresent()
{
    if (cameraId_.isEmpty()) {
        return;
    }
    for (const QCameraDevice &input : QMediaDevices::videoInputs()) {
        if (stableCameraId(input) == cameraId_) {
            return;
        }
    }
    setState(CameraDeviceState::Faulted);
    reportError(
        QStringLiteral("CAMERA_DISCONNECTED"),
        QStringLiteral("摄像头连接已断开。"),
        QStringLiteral("selected camera no longer appears in QMediaDevices::videoInputs"),
        true);
}

void QtMultimediaCameraDevice::setState(CameraDeviceState state)
{
    if (state_ == state) {
        return;
    }
    state_ = state;
    emit stateChanged(state_);
}

void QtMultimediaCameraDevice::reportError(
    const QString &code,
    const QString &userMessage,
    const QString &diagnostic,
    bool requiresStop)
{
    contracts::ModuleError error;
    error.code = code;
    error.category = QStringLiteral("camera");
    error.severity = contracts::ErrorSeverity::Recoverable;
    error.userMessage = userMessage;
    error.diagnostic = diagnostic;
    error.timestamp.utc = QDateTime::currentDateTimeUtc();
    error.retryable = true;
    error.requiresStop = requiresStop;
    emit errorOccurred(error);
}

} // namespace tdlas::camera
