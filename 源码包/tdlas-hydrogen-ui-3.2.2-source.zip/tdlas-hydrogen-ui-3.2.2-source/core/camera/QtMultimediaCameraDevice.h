#pragma once

#include "camera/ICameraDevice.h"
#include "camera/WindowsCameraControls.h"

#include <QElapsedTimer>
#include <QTimer>

class QCamera;
class QMediaCaptureSession;
class QVideoFrame;
class QVideoSink;

namespace tdlas::camera {

class QtMultimediaCameraDevice final : public ICameraDevice
{
    Q_OBJECT

public:
    explicit QtMultimediaCameraDevice(QObject *parent = nullptr);
    ~QtMultimediaCameraDevice() override;

    [[nodiscard]] QVector<CameraDeviceDescriptor> enumerateDevices() override;
    [[nodiscard]] CameraDeviceState state() const override;
    [[nodiscard]] bool connectDevice(
        const QString &cameraId,
        const CameraFormat &format) override;
    [[nodiscard]] bool disconnectDevice() override;
    [[nodiscard]] bool startPreview(const CameraSessionId &sessionId) override;
    [[nodiscard]] bool stopPreview() override;
    CameraControlState readCameraControls() override;
    bool setCameraControl(CameraControlAxis axis, int value, QString &error) override;

private:
    void handleVideoFrame(const QVideoFrame &videoFrame);
    void handleCameraError();
    void verifySelectedDeviceStillPresent();
    void setState(CameraDeviceState state);
    void reportError(
        const QString &code,
        const QString &userMessage,
        const QString &diagnostic,
        bool requiresStop);

    QMediaCaptureSession *captureSession_ = nullptr;
    QCamera *camera_ = nullptr;
    QVideoSink *videoSink_ = nullptr;
    QTimer *deviceWatchTimer_ = nullptr;
    QElapsedTimer monotonicClock_;
    CameraDeviceState state_ = CameraDeviceState::Disconnected;
    CameraSessionId sessionId_;
    QString cameraId_;
    CameraFormat activeFormat_;
    contracts::Sequence sequence_ = 0;
    WindowsCameraControls controls_;
};

} // namespace tdlas::camera
