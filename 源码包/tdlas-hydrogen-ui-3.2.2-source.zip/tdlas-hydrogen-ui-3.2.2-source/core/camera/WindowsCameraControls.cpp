#include "camera/WindowsCameraControls.h"
#ifdef Q_OS_WIN
#define NOMINMAX
#include <windows.h>
#include <dshow.h>
#include <wrl/client.h>
#endif

namespace tdlas::camera {
struct WindowsCameraControls::Impl {
    QString error;
#ifdef Q_OS_WIN
    Microsoft::WRL::ComPtr<IBaseFilter> filter;
    Microsoft::WRL::ComPtr<IAMCameraControl> control;
    bool uninitialize = false;
#endif
};

WindowsCameraControls::WindowsCameraControls() : impl_(std::make_unique<Impl>()) {}
WindowsCameraControls::~WindowsCameraControls() { close(); }

void WindowsCameraControls::close()
{
#ifdef Q_OS_WIN
    impl_->control.Reset();
    impl_->filter.Reset();
    if (impl_->uninitialize) CoUninitialize();
    impl_->uninitialize = false;
#endif
    impl_->error.clear();
}

bool WindowsCameraControls::open(const QByteArray &devicePath)
{
    close();
#ifdef Q_OS_WIN
    using Microsoft::WRL::ComPtr;
    const auto hr = CoInitializeEx(nullptr, COINIT_MULTITHREADED);
    if (FAILED(hr) && hr != RPC_E_CHANGED_MODE) {
        impl_->error = QStringLiteral("COM 初始化失败：0x%1").arg(quint32(hr), 8, 16, QLatin1Char('0')); return false;
    }
    impl_->uninitialize = SUCCEEDED(hr);
    const auto canonical = [](QString path) {
        path = path.toLower();
        const auto category = path.indexOf(QStringLiteral("#{"));
        if (category >= 0) path.truncate(category);
        return path;
    };
    const auto requested = canonical(QString::fromUtf8(devicePath));
    if (requested.isEmpty()) { impl_->error = QStringLiteral("设备标识为空，未选择其他相机替代。"); return false; }
    ComPtr<ICreateDevEnum> enumerator;
    auto status = CoCreateInstance(CLSID_SystemDeviceEnum, nullptr, CLSCTX_INPROC_SERVER, IID_PPV_ARGS(enumerator.GetAddressOf()));
    ComPtr<IEnumMoniker> items;
    if (SUCCEEDED(status)) status = enumerator->CreateClassEnumerator(CLSID_VideoInputDeviceCategory, items.GetAddressOf(), 0);
    if (status == S_OK && items) {
        ComPtr<IMoniker> moniker;
        while (items->Next(1, moniker.ReleaseAndGetAddressOf(), nullptr) == S_OK) {
            ComPtr<IPropertyBag> bag;
            if (FAILED(moniker->BindToStorage(nullptr, nullptr, IID_PPV_ARGS(bag.GetAddressOf())))) continue;
            VARIANT value; VariantInit(&value);
            const auto read = bag->Read(L"DevicePath", &value, nullptr);
            const auto path = SUCCEEDED(read) && value.vt == VT_BSTR ? QString::fromWCharArray(value.bstrVal) : QString();
            VariantClear(&value);
            if (canonical(path) != requested) continue;
            status = moniker->BindToObject(nullptr, nullptr, IID_PPV_ARGS(impl_->filter.GetAddressOf()));
            if (SUCCEEDED(status)) status = impl_->filter.As(&impl_->control);
            if (SUCCEEDED(status)) return true;
            impl_->error = QStringLiteral("相机控制接口不可用：0x%1").arg(quint32(status), 8, 16, QLatin1Char('0'));
            return false;
        }
    }
    impl_->error = QStringLiteral("未匹配当前相机的 Windows 设备控制接口。");
#else
    Q_UNUSED(devicePath)
    impl_->error = QStringLiteral("此系统未提供 Windows 相机控制适配器。");
#endif
    return false;
}

CameraControlState WindowsCameraControls::read()
{
    CameraControlState state;
    state.message = impl_->error;
#ifdef Q_OS_WIN
    if (impl_->control) {
        const long properties[] = {CameraControl_Pan, CameraControl_Tilt, CameraControl_Zoom};
        for (int i = 0; i < 3; ++i) {
            auto &range = cameraControlRange(state, static_cast<CameraControlAxis>(i));
            long minimum = 0, maximum = 0, step = 0, def = 0, caps = 0, value = 0, flags = 0;
            const auto a = impl_->control->GetRange(properties[i], &minimum, &maximum, &step, &def, &caps);
            const auto b = impl_->control->Get(properties[i], &value, &flags);
            range.readable = SUCCEEDED(a) && SUCCEEDED(b) && minimum <= maximum && step > 0;
            range.writable = range.readable && (caps & CameraControl_Flags_Manual);
            if (range.readable) range = {true, range.writable, int(minimum), int(maximum), int(step), int(def), int(value)};
        }
        if (!state.pan.readable && !state.tilt.readable && !state.zoom.readable)
            state.message = QStringLiteral("驱动未提供可读取的 PTZ 控制，或设备已断开。");
    }
#endif
    return state;
}

bool WindowsCameraControls::write(CameraControlAxis axis, int value, QString &error)
{
#ifdef Q_OS_WIN
    const auto state = read();
    auto copy = state;
    const auto &range = cameraControlRange(copy, axis);
    if (!impl_->control || !range.writable || value < range.minimum || value > range.maximum
        || (qint64(value) - range.minimum) % range.step != 0) {
        error = QStringLiteral("设备不支持此写入，或值不符合驱动范围／步长。"); return false;
    }
    const long properties[] = {CameraControl_Pan, CameraControl_Tilt, CameraControl_Zoom};
    const auto hr = impl_->control->Set(properties[static_cast<int>(axis)], value, CameraControl_Flags_Manual);
    if (FAILED(hr)) {
        error = QStringLiteral("驱动写入失败：0x%1").arg(quint32(hr), 8, 16, QLatin1Char('0')); return false;
    }
    long actual = 0, flags = 0;
    const auto got = impl_->control->Get(properties[static_cast<int>(axis)], &actual, &flags);
    if (FAILED(got) || actual != value) {
        error = QStringLiteral("写入后回读不一致：期望 %1，回读 %2（0x%3）。")
            .arg(value).arg(actual).arg(quint32(got), 8, 16, QLatin1Char('0')); return false;
    }
    return true;
#else
    Q_UNUSED(axis) Q_UNUSED(value)
    error = impl_->error; return false;
#endif
}
}
