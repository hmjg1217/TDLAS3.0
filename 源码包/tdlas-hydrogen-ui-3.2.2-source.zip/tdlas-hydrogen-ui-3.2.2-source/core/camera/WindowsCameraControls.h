#pragma once
#include "camera/CameraHardwareControls.h"
#include <QByteArray>
#include <memory>

namespace tdlas::camera {
// COM objects are created, used and destroyed on the same camera worker thread.
class WindowsCameraControls final {
public:
    WindowsCameraControls();
    ~WindowsCameraControls();
    bool open(const QByteArray &devicePath);
    void close();
    CameraControlState read();
    bool write(CameraControlAxis axis, int value, QString &error);
private:
    struct Impl;
    std::unique_ptr<Impl> impl_;
};
}
