#include "contracts/MeasurementTypes.h"

#include <QCryptographicHash>
#include <QRegularExpression>
#include <QUuid>

#include <cmath>

namespace tdlas::contracts {

namespace {

bool finite(double value)
{
    return std::isfinite(value);
}

} // namespace

bool ExperimentId::isValid() const
{
    static const QRegularExpression pattern(
        QStringLiteral("^EXP-[0-9]{8}T[0-9]{9}Z-[0-9a-f]{8}$"));
    return pattern.match(value).hasMatch();
}

bool ParameterSnapshot::isValid(QString *diagnostic) const
{
    QString reason;
    QStringList uniqueChannels;
    for (const QString &channelId : aiChannelIds) {
        const QString trimmed = channelId.trimmed();
        if (trimmed.isEmpty()) {
            reason = QStringLiteral("AI channel id is empty");
            break;
        }
        if (uniqueChannels.contains(trimmed)) {
            reason = QStringLiteral("AI channel id is duplicated");
            break;
        }
        uniqueChannels.push_back(trimmed);
    }
    if (!reason.isEmpty()) {
        // Keep the channel-specific reason found above.
    } else if (id.trimmed().isEmpty()) {
        reason = QStringLiteral("parameter snapshot id is empty");
    } else if (deviceId.trimmed().isEmpty()) {
        reason = QStringLiteral("device id is empty");
    } else if (aiChannelIds.isEmpty()) {
        reason = QStringLiteral("no AI channel selected");
    } else if (!finite(sampleRateHz) || sampleRateHz <= 0.0) {
        reason = QStringLiteral("sample rate must be positive and finite");
    } else if (readSamplesPerBlock <= 0) {
        reason = QStringLiteral("samples per block must be positive");
    } else if (!finite(inputRangeMinV) || !finite(inputRangeMaxV) || inputRangeMinV >= inputRangeMaxV) {
        reason = QStringLiteral("input range is invalid");
    } else if (algorithmParameterSetId.trimmed().isEmpty()) {
        reason = QStringLiteral("algorithm parameter set id is empty");
    } else if (revision == 0 || !createdAtUtc.isValid() || hash.trimmed().isEmpty()) {
        reason = QStringLiteral("parameter snapshot metadata is invalid");
    } else if (aoEnabled && (aoChannelId.trimmed().isEmpty()
                   || !finite(outputFrequencyHz) || outputFrequencyHz <= 0.0
                   || !finite(outputAmplitudePeakV) || outputAmplitudePeakV < 0.0
                   || !finite(outputOffsetV)
                   || !finite(outputSampleRateHz)
                   || outputSampleRateHz < outputFrequencyHz * 10.0)) {
        reason = QStringLiteral("AO configuration is invalid");
    } else if (aoEnabled && (outputOffsetV - outputAmplitudePeakV < -10.0
               || outputOffsetV + outputAmplitudePeakV > 10.0)) {
        reason = QStringLiteral("AO waveform exceeds the software voltage boundary");
    }

    if (diagnostic) {
        *diagnostic = reason;
    }
    return reason.isEmpty();
}

ParameterDraft ParameterDraft::mockDefaults()
{
    ParameterDraft draft;
    draft.deviceId = QStringLiteral("mock-acquisition-0");
    draft.aiChannelIds = {QStringLiteral("sim/ai0")};
    draft.sampleRateHz = 5120.0;
    draft.readSamplesPerBlock = 256;
    draft.inputRangeMinV = -10.0;
    draft.inputRangeMaxV = 10.0;
    draft.aoEnabled = false;
    draft.waveform = Waveform::Sine;
    draft.algorithmParameterSetId = QStringLiteral("tdlas-v1.6-ui");
    return draft;
}

ParameterSnapshot ParameterSnapshot::mockDefaults()
{
    ParameterSnapshot snapshot;
    snapshot.id = QStringLiteral("mock-parameter-set-v1");
    snapshot.deviceId = QStringLiteral("mock-acquisition-0");
    snapshot.aiChannelIds = {QStringLiteral("sim/ai0")};
    snapshot.sampleRateHz = 5120.0;
    snapshot.readSamplesPerBlock = 256;
    snapshot.inputRangeMinV = -10.0;
    snapshot.inputRangeMaxV = 10.0;
    snapshot.aoEnabled = false;
    snapshot.waveform = Waveform::Sine;
    snapshot.algorithmParameterSetId = QStringLiteral("tdlas-v1.6-ui");
    snapshot.revision = 1;
    snapshot.createdAtUtc = QDateTime::currentDateTimeUtc();
    const QByteArray stableFields = QByteArrayLiteral("mock-acquisition-0|sim/ai0|5120|256|tdlas-v1.6-ui|1");
    snapshot.hash = QString::fromLatin1(QCryptographicHash::hash(stableFields, QCryptographicHash::Sha256).toHex());
    return snapshot;
}

bool ChartSeriesData::isConsistent() const
{
    if (x.isEmpty() || x.size() != y.size()) {
        return false;
    }
    for (qsizetype index = 0; index < x.size(); ++index) {
        if (!finite(x.at(index)) || !finite(y.at(index))) {
            return false;
        }
    }
    return true;
}

QString measurementStateName(MeasurementState state)
{
    switch (state) {
    case MeasurementState::Idle:
        return QStringLiteral("Idle");
    case MeasurementState::Preparing:
        return QStringLiteral("Preparing");
    case MeasurementState::Running:
        return QStringLiteral("Running");
    case MeasurementState::Stopping:
        return QStringLiteral("Stopping");
    case MeasurementState::Faulted:
        return QStringLiteral("Faulted");
    }
    return QStringLiteral("Unknown");
}

ExperimentId createExperimentId(const QDateTime &startedAtUtc)
{
    const QDateTime utc = startedAtUtc.toUTC();
    const QString suffix = QUuid::createUuid().toString(QUuid::WithoutBraces).left(8).toLower();
    return {QStringLiteral("EXP-%1Z-%2")
                .arg(utc.toString(QStringLiteral("yyyyMMdd'T'HHmmsszzz")), suffix)};
}

} // namespace tdlas::contracts
