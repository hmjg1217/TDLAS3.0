#pragma once

#include <QDateTime>
#include <QMetaType>
#include <QString>
#include <QStringList>
#include <QVector>

#include <optional>

namespace tdlas::contracts {

inline constexpr int kContractMajorVersion = 1;
inline constexpr int kContractMinorVersion = 7;

struct ContractVersion {
    int major = kContractMajorVersion;
    int minor = kContractMinorVersion;
};

struct RunId {
    QString value;

    [[nodiscard]] bool isValid() const { return !value.trimmed().isEmpty(); }
};

struct ExperimentId {
    QString value;

    [[nodiscard]] bool isValid() const;
};

inline bool operator==(const ExperimentId &left, const ExperimentId &right)
{
    return left.value == right.value;
}

inline bool operator!=(const ExperimentId &left, const ExperimentId &right)
{
    return !(left == right);
}

inline bool operator==(const RunId &left, const RunId &right)
{
    return left.value == right.value;
}

inline bool operator!=(const RunId &left, const RunId &right)
{
    return !(left == right);
}

using Sequence = quint64;

struct Timestamp {
    QDateTime utc;
    qint64 monotonicNanoseconds = -1;
};

enum class DataValidity {
    Valid,
    Invalid,
    Incomplete,
    Stale,
    Uncalibrated
};

enum class ErrorSeverity {
    Info,
    Warning,
    Recoverable,
    Fatal
};

struct ModuleError {
    QString code;
    QString category;
    ErrorSeverity severity = ErrorSeverity::Recoverable;
    QString userMessage;
    QString diagnostic;
    Timestamp timestamp;
    bool retryable = false;
    bool requiresStop = false;
    std::optional<RunId> runId;
    std::optional<Sequence> sequence;
};

enum class Waveform {
    Sine,
    Square,
    Sawtooth,
    Triangle
};

struct ParameterDraft {
    QString deviceId;
    QStringList aiChannelIds;
    double sampleRateHz = 0.0;
    qsizetype readSamplesPerBlock = 0;
    double inputRangeMinV = -10.0;
    double inputRangeMaxV = 10.0;
    bool aoEnabled = false;
    QString aoChannelId;
    Waveform waveform = Waveform::Sine;
    double outputFrequencyHz = 0.0;
    double outputAmplitudePeakV = 0.0;
    double outputOffsetV = 0.0;
    double outputSampleRateHz = 0.0;
    QString algorithmParameterSetId;

    [[nodiscard]] static ParameterDraft mockDefaults();
};

struct ParameterSnapshot {
    QString id;
    QString deviceId;
    QStringList aiChannelIds;
    double sampleRateHz = 0.0;
    qsizetype readSamplesPerBlock = 0;
    double inputRangeMinV = -10.0;
    double inputRangeMaxV = 10.0;
    bool aoEnabled = false;
    QString aoChannelId;
    Waveform waveform = Waveform::Sine;
    double outputFrequencyHz = 0.0;
    double outputAmplitudePeakV = 0.0;
    double outputOffsetV = 0.0;
    double outputSampleRateHz = 0.0;
    QString algorithmParameterSetId;
    quint64 revision = 0;
    QDateTime createdAtUtc;
    QString hash;

    [[nodiscard]] bool isValid(QString *diagnostic = nullptr) const;
    [[nodiscard]] static ParameterSnapshot mockDefaults();
};

struct ParameterValidationError {
    QString field;
    QString code;
    QString message;
};

struct ParameterValidationResult {
    QVector<ParameterValidationError> errors;

    [[nodiscard]] bool isValid() const { return errors.isEmpty(); }
};

struct ParameterCommitResult {
    std::optional<ParameterSnapshot> snapshot;
    ParameterValidationResult validation;

    [[nodiscard]] bool isSuccess() const { return snapshot.has_value() && validation.isValid(); }
};

struct StartMeasurementRequest {
    ParameterSnapshot parameters;
    ExperimentId experimentId;
    QString operatorId;
};

enum class DeviceConnectionState {
    Disconnected,
    Connecting,
    Connected,
    Disconnecting,
    Faulted
};

enum class AcquisitionState {
    Idle,
    Configuring,
    Running,
    Stopping,
    Faulted
};

enum class MeasurementState {
    Idle,
    Preparing,
    Running,
    Stopping,
    Faulted
};

enum class DataSourceKind {
    Simulation,
    RealDevice
};

enum class ExperimentStorageState {
    NotStarted,
    Saving,
    Saved,
    Failed
};

struct ChannelSamples {
    QString channelId;
    QVector<double> samplesV;
};

struct RawDataBlock {
    RunId runId;
    QString streamId;
    Sequence sequence = 0;
    Timestamp sampleStart;
    double sampleRateHz = 0.0;
    QVector<ChannelSamples> channels;
    qsizetype sampleCountPerChannel = 0;
    bool overrun = false;
    quint64 droppedBefore = 0;
    DataValidity validity = DataValidity::Invalid;
    QString diagnostic;
};

struct ProcessingResult {
    RunId runId;
    Sequence sourceSequence = 0;
    Timestamp timestamp;
    QString parameterSnapshotId;
    QString algorithmVersion;
    QString calibrationVersion;
    QVector<double> timeSeconds; // Cropped positions on the same phase/time grid as cycleTimeSeconds.
    QVector<double> cycleTimeSeconds; // Complete averaged cycle, including the return edge for display.
    QVector<double> cycleVoltageV; // UI v1.8: unfiltered phase-aligned mean of 20 complete AI cycles.
    double displayVoltageOffsetV = 0.0; // Subtract from processed/fitted voltages to overlay on raw AI.
    QVector<double> relativeFrequencyCm1;
    QVector<double> voltageV;
    QVector<double> baselineV;
    QVector<double> fittedVoltageV;
    QVector<double> absorbance;
    QVector<double> fittedAbsorbance;
    std::optional<double> voigtCenterCm1;
    std::optional<double> voigtAmplitude;
    std::optional<double> voigtGaussianFwhmCm1;
    std::optional<double> voigtLorentzianFwhmCm1;
    std::optional<double> voigtResidualSumSquares;
    std::optional<double> peakAbsorbance;
    std::optional<double> lightPercent;
    std::optional<double> concentration;
    QString concentrationUnit;
    DataValidity validity = DataValidity::Invalid;
    QString diagnostic;
};

struct ChartSeriesData {
    QVector<double> x;
    QVector<double> y;
    QString xUnit;
    QString yUnit;
    DataValidity validity = DataValidity::Invalid;

    [[nodiscard]] bool isConsistent() const;
};

struct PeakRecord {
    Sequence sequence = 0;
    QDateTime acquiredAtUtc;
    double elapsedSeconds = 0.0;
    std::optional<double> peakValue;
    std::optional<double> peakX;
    QString unit = QStringLiteral("1");
    DataValidity validity = DataValidity::Incomplete;
    QString reason;
    RunId runId;
    ExperimentId experimentId;
    QString peakXUnit;
    DataSourceKind sourceKind = DataSourceKind::Simulation;
    ParameterSnapshot parameters;
    QString algorithmVersion;
    QString calibrationVersion;
};

struct MeasurementDisplayModel {
    MeasurementState state = MeasurementState::Idle;
    DeviceConnectionState connectionState = DeviceConnectionState::Disconnected;
    DataSourceKind sourceKind = DataSourceKind::Simulation;
    ExperimentStorageState storageState = ExperimentStorageState::NotStarted;
    RunId runId;
    ExperimentId experimentId;
    QDateTime runStartedAtUtc;
    Sequence sequence = 0;
    QDateTime lastUpdatedUtc;
    QVector<double> rawVoltageV;
    QVector<double> fittedVoltageV;
    QVector<double> absorbance;
    QVector<double> fittedAbsorbance;
    QVector<double> peakHistory;
    double waveformDurationSeconds = 1.0;
    ChartSeriesData rawSeries;
    ChartSeriesData processedVoltageSeries;
    ChartSeriesData fittedVoltageSeries;
    ChartSeriesData absorbanceSeries;
    ChartSeriesData fittedAbsorbanceSeries;
    ChartSeriesData peakTrendSeries;
    QVector<PeakRecord> peakRecords;
    std::optional<double> peakAbsorbance;
    std::optional<double> lightPercent;
    std::optional<double> concentration;
    QString concentrationUnit;
    DataValidity validity = DataValidity::Incomplete;
    QString statusMessage;
    QString diagnostic;
};

[[nodiscard]] QString measurementStateName(MeasurementState state);
[[nodiscard]] ExperimentId createExperimentId(const QDateTime &startedAtUtc = QDateTime::currentDateTimeUtc());

} // namespace tdlas::contracts

Q_DECLARE_METATYPE(tdlas::contracts::RunId)
Q_DECLARE_METATYPE(tdlas::contracts::ExperimentId)
Q_DECLARE_METATYPE(tdlas::contracts::ParameterDraft)
Q_DECLARE_METATYPE(tdlas::contracts::ParameterSnapshot)
Q_DECLARE_METATYPE(tdlas::contracts::RawDataBlock)
Q_DECLARE_METATYPE(tdlas::contracts::ProcessingResult)
Q_DECLARE_METATYPE(tdlas::contracts::ModuleError)
Q_DECLARE_METATYPE(tdlas::contracts::DeviceConnectionState)
Q_DECLARE_METATYPE(tdlas::contracts::AcquisitionState)
Q_DECLARE_METATYPE(tdlas::contracts::MeasurementState)
Q_DECLARE_METATYPE(tdlas::contracts::ExperimentStorageState)
Q_DECLARE_METATYPE(tdlas::contracts::MeasurementDisplayModel)
