#pragma once

#include "contracts/MeasurementTypes.h"

#include <optional>

namespace tdlas::parameter {

class IParameterService
{
public:
    virtual ~IParameterService() = default;

    [[nodiscard]] virtual contracts::ParameterValidationResult validate(
        const contracts::ParameterDraft &draft) const = 0;
    [[nodiscard]] virtual contracts::ParameterCommitResult commit(
        const contracts::ParameterDraft &draft) = 0;
    [[nodiscard]] virtual std::optional<contracts::ParameterSnapshot> currentSnapshot() const = 0;
};

} // namespace tdlas::parameter
