#include "parameter/ParameterService.h"

#include <QCryptographicHash>
#include <QDateTime>

#include <cmath>

namespace tdlas::parameter {

namespace {

bool finite(double value)
{
    return std::isfinite(value);
}

void addError(
    contracts::ParameterValidationResult &result,
    const QString &field,
    const QString &code,
    const QString &message)
{
    result.errors.push_back({field, code, message});
}

QByteArray canonicalBytes(const contracts::ParameterDraft &draft, quint64 revision)
{
    QByteArray bytes;
    auto append = [&bytes](const QString &value) {
        bytes.append(value.toUtf8());
        bytes.append('|');
    };
    append(draft.deviceId.trimmed());
    append(draft.aiChannelIds.join(QLatin1Char(',')));
    append(QString::number(draft.sampleRateHz, 'g', 17));
    append(QString::number(draft.readSamplesPerBlock));
    append(QString::number(draft.inputRangeMinV, 'g', 17));
    append(QString::number(draft.inputRangeMaxV, 'g', 17));
    append(draft.aoEnabled ? QStringLiteral("1") : QStringLiteral("0"));
    append(draft.aoChannelId.trimmed());
    append(QString::number(static_cast<int>(draft.waveform)));
    append(QString::number(draft.outputFrequencyHz, 'g', 17));
    append(QString::number(draft.outputAmplitudePeakV, 'g', 17));
    append(QString::number(draft.outputOffsetV, 'g', 17));
    append(QString::number(draft.outputSampleRateHz, 'g', 17));
    append(draft.algorithmParameterSetId.trimmed());
    append(QString::number(revision));
    return bytes;
}

} // namespace

contracts::ParameterValidationResult ParameterService::validate(
    const contracts::ParameterDraft &draft) const
{
    contracts::ParameterValidationResult result;
    if (draft.deviceId.trimmed().isEmpty()) {
        addError(result, QStringLiteral("deviceId"), QStringLiteral("REQUIRED"), QStringLiteral("请选择采集设备。"));
    }
    if (draft.aiChannelIds.isEmpty()) {
        addError(result, QStringLiteral("aiChannelIds"), QStringLiteral("REQUIRED"), QStringLiteral("至少选择一个采集通道。"));
    } else {
        QStringList uniqueChannels;
        for (const QString &channelId : draft.aiChannelIds) {
            const QString trimmed = channelId.trimmed();
            if (trimmed.isEmpty()) {
                addError(result, QStringLiteral("aiChannelIds"), QStringLiteral("EMPTY_CHANNEL"), QStringLiteral("采集通道标识不能为空。"));
                break;
            }
            if (uniqueChannels.contains(trimmed)) {
                addError(result, QStringLiteral("aiChannelIds"), QStringLiteral("DUPLICATE_CHANNEL"), QStringLiteral("采集通道不能重复。"));
                break;
            }
            uniqueChannels.push_back(trimmed);
        }
    }
    if (!finite(draft.sampleRateHz) || draft.sampleRateHz <= 0.0) {
        addError(result, QStringLiteral("sampleRateHz"), QStringLiteral("POSITIVE_FINITE"), QStringLiteral("采样率必须是大于 0 的有限数。"));
    }
    if (draft.readSamplesPerBlock <= 0) {
        addError(result, QStringLiteral("readSamplesPerBlock"), QStringLiteral("POSITIVE"), QStringLiteral("每块读取点数必须大于 0。"));
    }
    if (!finite(draft.inputRangeMinV) || !finite(draft.inputRangeMaxV)
        || draft.inputRangeMinV >= draft.inputRangeMaxV) {
        addError(result, QStringLiteral("inputRangeV"), QStringLiteral("ORDER"), QStringLiteral("输入量程下限必须小于上限。"));
    }
    if (draft.algorithmParameterSetId.trimmed().isEmpty()) {
        addError(result, QStringLiteral("algorithmParameterSetId"), QStringLiteral("REQUIRED"), QStringLiteral("算法参数集不能为空。"));
    }

    if (draft.aoEnabled) {
        if (draft.aoChannelId.trimmed().isEmpty()) {
            addError(result, QStringLiteral("aoChannelId"), QStringLiteral("REQUIRED"), QStringLiteral("启用输出时必须选择输出通道。"));
        }
        if (!finite(draft.outputFrequencyHz) || draft.outputFrequencyHz <= 0.0) {
            addError(result, QStringLiteral("outputFrequencyHz"), QStringLiteral("POSITIVE_FINITE"), QStringLiteral("输出频率必须是大于 0 的有限数。"));
        }
        if (!finite(draft.outputAmplitudePeakV) || draft.outputAmplitudePeakV < 0.0) {
            addError(result, QStringLiteral("outputAmplitudePeakV"), QStringLiteral("NON_NEGATIVE_FINITE"), QStringLiteral("输出峰值幅值必须是非负有限数。"));
        }
        if (!finite(draft.outputOffsetV)) {
            addError(result, QStringLiteral("outputOffsetV"), QStringLiteral("FINITE"), QStringLiteral("输出偏移必须是有限数。"));
        }
        if (!finite(draft.outputSampleRateHz)
            || draft.outputSampleRateHz < draft.outputFrequencyHz * 10.0) {
            addError(result, QStringLiteral("outputSampleRateHz"), QStringLiteral("NYQUIST_MARGIN"), QStringLiteral("输出采样率至少应为输出频率的 10 倍。"));
        }
        if (finite(draft.outputOffsetV) && finite(draft.outputAmplitudePeakV)
            && (draft.outputOffsetV - draft.outputAmplitudePeakV < -10.0
                || draft.outputOffsetV + draft.outputAmplitudePeakV > 10.0)) {
            addError(result, QStringLiteral("outputVoltageV"), QStringLiteral("SOFTWARE_BOUNDARY"), QStringLiteral("输出波形必须保持在 -10 V 至 +10 V 软件边界内。"));
        }
    }
    return result;
}

contracts::ParameterCommitResult ParameterService::commit(
    const contracts::ParameterDraft &draft)
{
    contracts::ParameterCommitResult result;
    result.validation = validate(draft);
    if (!result.validation.isValid()) {
        return result;
    }

    contracts::ParameterSnapshot snapshot;
    snapshot.deviceId = draft.deviceId.trimmed();
    for (const QString &channelId : draft.aiChannelIds) {
        snapshot.aiChannelIds.push_back(channelId.trimmed());
    }
    snapshot.sampleRateHz = draft.sampleRateHz;
    snapshot.readSamplesPerBlock = draft.readSamplesPerBlock;
    snapshot.inputRangeMinV = draft.inputRangeMinV;
    snapshot.inputRangeMaxV = draft.inputRangeMaxV;
    snapshot.aoEnabled = draft.aoEnabled;
    snapshot.aoChannelId = draft.aoChannelId.trimmed();
    snapshot.waveform = draft.waveform;
    snapshot.outputFrequencyHz = draft.outputFrequencyHz;
    snapshot.outputAmplitudePeakV = draft.outputAmplitudePeakV;
    snapshot.outputOffsetV = draft.outputOffsetV;
    snapshot.outputSampleRateHz = draft.outputSampleRateHz;
    snapshot.algorithmParameterSetId = draft.algorithmParameterSetId.trimmed();
    snapshot.revision = nextRevision_++;
    snapshot.createdAtUtc = QDateTime::currentDateTimeUtc();
    snapshot.hash = QString::fromLatin1(
        QCryptographicHash::hash(canonicalBytes(draft, snapshot.revision), QCryptographicHash::Sha256).toHex());
    snapshot.id = QStringLiteral("parameter-%1-%2")
                      .arg(snapshot.revision)
                      .arg(snapshot.hash.left(12));
    currentSnapshot_ = snapshot;
    result.snapshot = snapshot;
    return result;
}

std::optional<contracts::ParameterSnapshot> ParameterService::currentSnapshot() const
{
    return currentSnapshot_;
}

} // namespace tdlas::parameter
