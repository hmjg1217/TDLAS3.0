#pragma once

#include "parameter/IParameterService.h"

namespace tdlas::parameter {

class ParameterService final : public IParameterService
{
public:
    [[nodiscard]] contracts::ParameterValidationResult validate(
        const contracts::ParameterDraft &draft) const override;
    [[nodiscard]] contracts::ParameterCommitResult commit(
        const contracts::ParameterDraft &draft) override;
    [[nodiscard]] std::optional<contracts::ParameterSnapshot> currentSnapshot() const override;

private:
    quint64 nextRevision_ = 1;
    std::optional<contracts::ParameterSnapshot> currentSnapshot_;
};

} // namespace tdlas::parameter
