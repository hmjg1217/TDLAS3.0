#include "storage/ExperimentArchiveService.h"

#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QSaveFile>
#include <QTextStream>
#if QT_VERSION >= QT_VERSION_CHECK(6, 0, 0)
#include <QStringConverter>
#endif

#include <cmath>
#include <algorithm>

namespace tdlas::storage {

namespace {

StorageOperationResult archiveFailure(
    const QString &code,
    const QString &message,
    const QString &diagnostic,
    const QString &path = {})
{
    return StorageOperationResult::failed(code, message, diagnostic, path);
}

QDateTime parseUtc(const QString &text)
{
    QDateTime value = QDateTime::fromString(text, Qt::ISODateWithMs);
    if (!value.isValid()) {
        value = QDateTime::fromString(text, Qt::ISODate);
    }
    return value.isValid() ? value.toUTC() : QDateTime{};
}

bool parseUnsigned(const QString &text, quint64 *value)
{
    bool ok = false;
    const quint64 parsed = text.toULongLong(&ok);
    if (ok && value != nullptr) {
        *value = parsed;
    }
    return ok;
}

bool parseDouble(const QString &text, double *value)
{
    bool ok = false;
    const double parsed = text.toDouble(&ok);
    if (ok && std::isfinite(parsed) && value != nullptr) {
        *value = parsed;
    }
    return ok && std::isfinite(parsed);
}

bool parseValidity(const QString &text, contracts::DataValidity *validity)
{
    if (text == QStringLiteral("valid")) {
        *validity = contracts::DataValidity::Valid;
    } else if (text == QStringLiteral("invalid")) {
        *validity = contracts::DataValidity::Invalid;
    } else if (text == QStringLiteral("incomplete")) {
        *validity = contracts::DataValidity::Incomplete;
    } else if (text == QStringLiteral("stale")) {
        *validity = contracts::DataValidity::Stale;
    } else if (text == QStringLiteral("uncalibrated")) {
        *validity = contracts::DataValidity::Uncalibrated;
    } else {
        return false;
    }
    return true;
}

QString csvField(const QString &value)
{
    QString escaped = value;
    escaped.replace(QLatin1Char('"'), QStringLiteral("\"\""));
    if (escaped.contains(QLatin1Char(',')) || escaped.contains(QLatin1Char('"'))
        || escaped.contains(QLatin1Char('\n')) || escaped.contains(QLatin1Char('\r'))) {
        return QLatin1Char('"') + escaped + QLatin1Char('"');
    }
    return escaped;
}

QString jsonNumber(const QJsonValue &value)
{
    return value.isDouble() && std::isfinite(value.toDouble())
        ? QString::number(value.toDouble(), 'g', 17)
        : QString();
}

StorageOperationResult readJsonObject(const QString &path, QJsonObject *object)
{
    QFile file(path);
    if (!file.open(QIODevice::ReadOnly)) {
        return archiveFailure(
            QStringLiteral("ARCHIVE_OPEN_FAILED"),
            QStringLiteral("无法读取实验归档。"), file.errorString(), path);
    }
    QJsonParseError parseError;
    const QJsonDocument document = QJsonDocument::fromJson(file.readAll(), &parseError);
    if (parseError.error != QJsonParseError::NoError || !document.isObject()) {
        return archiveFailure(
            QStringLiteral("ARCHIVE_JSON_INVALID"),
            QStringLiteral("实验归档 JSON 无效。"), parseError.errorString(), path);
    }
    *object = document.object();
    return StorageOperationResult::succeeded(path);
}

StorageOperationResult validateManifest(
    const QString &experimentDirectory,
    QJsonObject *manifest,
    ExperimentArchiveSummary *summary,
    QStringList *rawFiles,
    QStringList *resultFiles)
{
    const QFileInfo directoryInfo(experimentDirectory);
    if (!directoryInfo.exists() || !directoryInfo.isDir()) {
        return archiveFailure(
            QStringLiteral("ARCHIVE_DIRECTORY_INVALID"),
            QStringLiteral("实验归档目录不存在。"), experimentDirectory, experimentDirectory);
    }
    const QString cleanDirectory = QDir::cleanPath(directoryInfo.absoluteFilePath());
    const QString manifestPath = QDir(cleanDirectory).filePath(QStringLiteral("manifest.json"));
    StorageOperationResult readResult = readJsonObject(manifestPath, manifest);
    if (!readResult.success) {
        return readResult;
    }

    ExperimentArchiveSummary parsed;
    parsed.directory = cleanDirectory;
    parsed.experimentId = {manifest->value(QStringLiteral("experimentId")).toString()};
    parsed.runId = {manifest->value(QStringLiteral("runId")).toString()};
    parsed.status = manifest->value(QStringLiteral("status")).toString();
    parsed.startedAtUtc = parseUtc(manifest->value(QStringLiteral("startedAtUtc")).toString());
    parsed.completedAtUtc = parseUtc(manifest->value(QStringLiteral("completedAtUtc")).toString());
    parsed.sourceKind = manifest->value(QStringLiteral("sourceKind")).toString()
            == QStringLiteral("real-device")
        ? contracts::DataSourceKind::RealDevice
        : contracts::DataSourceKind::Simulation;
    parsed.operatorId = manifest->value(QStringLiteral("operatorId")).toString();
    parsed.parameterSnapshotId = manifest->value(QStringLiteral("parameterSnapshotId")).toString();
    parsed.algorithmParameterSetId = manifest->value(
        QStringLiteral("algorithmParameterSetId")).toString();
    const qint64 rawCount = manifest->value(QStringLiteral("rawBlockCount")).toInteger(-1);
    const qint64 resultCount = manifest->value(QStringLiteral("resultCount")).toInteger(-1);
    const QStringList allowedStatuses{
        QStringLiteral("running"), QStringLiteral("completed"),
        QStringLiteral("aborted"), QStringLiteral("faulted")};
    if (!parsed.experimentId.isValid() || !parsed.runId.isValid()
        || !parsed.startedAtUtc.isValid() || !allowedStatuses.contains(parsed.status)
        || rawCount < 0 || resultCount < 0
        || QFileInfo(cleanDirectory).fileName() != parsed.experimentId.value) {
        return archiveFailure(
            QStringLiteral("ARCHIVE_MANIFEST_INVALID"),
            QStringLiteral("实验归档清单字段无效。"), manifestPath, manifestPath);
    }
    parsed.rawBlockCount = static_cast<quint64>(rawCount);
    parsed.resultCount = static_cast<quint64>(resultCount);

    QDir rawDirectory(QDir(cleanDirectory).filePath(QStringLiteral("raw")));
    QDir resultDirectory(QDir(cleanDirectory).filePath(QStringLiteral("results")));
    *rawFiles = rawDirectory.entryList(
        QStringList{QStringLiteral("raw-*.csv")}, QDir::Files, QDir::Name);
    *resultFiles = resultDirectory.entryList(
        QStringList{QStringLiteral("result-*.json")}, QDir::Files, QDir::Name);
    if (parsed.status != QStringLiteral("running")
        && (static_cast<quint64>(rawFiles->size()) != parsed.rawBlockCount
            || static_cast<quint64>(resultFiles->size()) != parsed.resultCount)) {
        return archiveFailure(
            QStringLiteral("ARCHIVE_COUNT_MISMATCH"),
            QStringLiteral("实验归档文件数量与清单不一致。"),
            QStringLiteral("manifest raw/result=%1/%2, files=%3/%4")
                .arg(parsed.rawBlockCount).arg(parsed.resultCount)
                .arg(rawFiles->size()).arg(resultFiles->size()), cleanDirectory);
    }
    *summary = parsed;
    return StorageOperationResult::succeeded(cleanDirectory);
}

StorageOperationResult parseRawBlock(
    const ExperimentArchiveSummary &summary,
    const QString &path,
    contracts::RawDataBlock *block)
{
    QFile file(path);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        return archiveFailure(
            QStringLiteral("ARCHIVE_RAW_OPEN_FAILED"),
            QStringLiteral("无法读取原始数据文件。"), file.errorString(), path);
    }
    QTextStream stream(&file);
#if QT_VERSION >= QT_VERSION_CHECK(6, 0, 0)
    stream.setEncoding(QStringConverter::Utf8);
#else
    stream.setCodec("UTF-8");
#endif
    const QString expectedHeader = QStringLiteral(
        "experiment_id,run_id,stream_id,sequence,sample_start_utc,sample_rate_hz,channel_id,sample_index,voltage_v,validity,overrun,dropped_before");
    if (stream.readLine() != expectedHeader) {
        return archiveFailure(
            QStringLiteral("ARCHIVE_RAW_HEADER_INVALID"),
            QStringLiteral("原始数据表头无效。"), path, path);
    }

    contracts::RawDataBlock parsed;
    QHash<QString, qsizetype> channelIndexes;
    bool firstRow = true;
    qsizetype rowNumber = 1;
    while (!stream.atEnd()) {
        ++rowNumber;
        const QString line = stream.readLine();
        if (line.isEmpty()) {
            continue;
        }
        const QStringList fields = line.split(QLatin1Char(','), Qt::KeepEmptyParts);
        if (fields.size() != 12) {
            return archiveFailure(
                QStringLiteral("ARCHIVE_RAW_ROW_INVALID"),
                QStringLiteral("原始数据行字段数量无效。"),
                QStringLiteral("%1:%2").arg(path).arg(rowNumber), path);
        }
        quint64 sequence = 0;
        quint64 sampleIndex = 0;
        quint64 droppedBefore = 0;
        double sampleRate = 0.0;
        double voltage = 0.0;
        contracts::DataValidity validity = contracts::DataValidity::Invalid;
        const QDateTime sampleStart = parseUtc(fields.at(4));
        if (fields.at(0) != summary.experimentId.value || fields.at(1) != summary.runId.value
            || !parseUnsigned(fields.at(3), &sequence) || sequence == 0
            || !sampleStart.isValid() || !parseDouble(fields.at(5), &sampleRate) || sampleRate <= 0.0
            || fields.at(6).trimmed().isEmpty() || !parseUnsigned(fields.at(7), &sampleIndex)
            || !parseDouble(fields.at(8), &voltage) || !parseValidity(fields.at(9), &validity)
            || (fields.at(10) != QStringLiteral("0") && fields.at(10) != QStringLiteral("1"))
            || !parseUnsigned(fields.at(11), &droppedBefore)) {
            return archiveFailure(
                QStringLiteral("ARCHIVE_RAW_ROW_INVALID"),
                QStringLiteral("原始数据行内容无效。"),
                QStringLiteral("%1:%2").arg(path).arg(rowNumber), path);
        }
        if (firstRow) {
            parsed.runId = summary.runId;
            parsed.streamId = fields.at(2);
            parsed.sequence = sequence;
            parsed.sampleStart.utc = sampleStart;
            parsed.sampleRateHz = sampleRate;
            parsed.validity = validity;
            parsed.overrun = fields.at(10) == QStringLiteral("1");
            parsed.droppedBefore = droppedBefore;
            firstRow = false;
        } else if (parsed.streamId != fields.at(2) || parsed.sequence != sequence
            || parsed.sampleStart.utc != sampleStart || parsed.sampleRateHz != sampleRate
            || parsed.validity != validity || parsed.overrun != (fields.at(10) == QStringLiteral("1"))
            || parsed.droppedBefore != droppedBefore) {
            return archiveFailure(
                QStringLiteral("ARCHIVE_RAW_BLOCK_MISMATCH"),
                QStringLiteral("原始数据块内元数据不一致。"),
                QStringLiteral("%1:%2").arg(path).arg(rowNumber), path);
        }

        const QString channelId = fields.at(6);
        qsizetype channelIndex = channelIndexes.value(channelId, -1);
        if (channelIndex < 0) {
            channelIndex = parsed.channels.size();
            channelIndexes.insert(channelId, channelIndex);
            parsed.channels.append({channelId, {}});
        }
        auto &samples = parsed.channels[channelIndex].samplesV;
        if (sampleIndex != static_cast<quint64>(samples.size())) {
            return archiveFailure(
                QStringLiteral("ARCHIVE_RAW_SEQUENCE_INVALID"),
                QStringLiteral("原始数据样本序号不连续。"),
                QStringLiteral("%1:%2").arg(path).arg(rowNumber), path);
        }
        samples.append(voltage);
    }
    if (firstRow || parsed.channels.isEmpty()) {
        return archiveFailure(
            QStringLiteral("ARCHIVE_RAW_EMPTY"),
            QStringLiteral("原始数据文件为空。"), path, path);
    }
    const qsizetype sampleCount = parsed.channels.first().samplesV.size();
    for (const auto &channel : parsed.channels) {
        if (channel.samplesV.size() != sampleCount) {
            return archiveFailure(
                QStringLiteral("ARCHIVE_RAW_CHANNEL_MISMATCH"),
                QStringLiteral("原始数据通道长度不一致。"), path, path);
        }
    }
    parsed.sampleCountPerChannel = sampleCount;
    *block = parsed;
    return StorageOperationResult::succeeded(path);
}

} // namespace

StorageOperationResult ExperimentArchiveService::inspect(
    const QString &experimentDirectory,
    ExperimentArchiveSummary *summary)
{
    if (summary == nullptr) {
        return archiveFailure(
            QStringLiteral("ARCHIVE_ARGUMENT_INVALID"),
            QStringLiteral("实验归档检查参数无效。"), QStringLiteral("summary is null"));
    }
    QJsonObject manifest;
    QStringList rawFiles;
    QStringList resultFiles;
    return validateManifest(
        experimentDirectory, &manifest, summary, &rawFiles, &resultFiles);
}

StorageOperationResult ExperimentArchiveService::replayRawData(
    const QString &experimentDirectory,
    const RawBlockConsumer &consumer,
    quint64 *replayedBlockCount)
{
    if (!consumer) {
        return archiveFailure(
            QStringLiteral("ARCHIVE_ARGUMENT_INVALID"),
            QStringLiteral("实验回放参数无效。"), QStringLiteral("consumer is empty"));
    }
    ExperimentArchiveSummary summary;
    QJsonObject manifest;
    QStringList rawFiles;
    QStringList resultFiles;
    StorageOperationResult result = validateManifest(
        experimentDirectory, &manifest, &summary, &rawFiles, &resultFiles);
    if (!result.success) {
        return result;
    }
    quint64 replayed = 0;
    contracts::Sequence previousSequence = 0;
    const QDir rawDirectory(QDir(summary.directory).filePath(QStringLiteral("raw")));
    for (const QString &fileName : rawFiles) {
        contracts::RawDataBlock block;
        result = parseRawBlock(summary, rawDirectory.filePath(fileName), &block);
        if (!result.success) {
            return result;
        }
        if (block.sequence <= previousSequence) {
            return archiveFailure(
                QStringLiteral("ARCHIVE_RAW_SEQUENCE_INVALID"),
                QStringLiteral("实验回放块序号未严格递增。"), fileName, result.path);
        }
        if (!consumer(block)) {
            if (replayedBlockCount != nullptr) {
                *replayedBlockCount = replayed;
            }
            return archiveFailure(
                QStringLiteral("ARCHIVE_REPLAY_CANCELLED"),
                QStringLiteral("实验回放已取消。"), QString::number(block.sequence), result.path);
        }
        previousSequence = block.sequence;
        ++replayed;
    }
    if (replayedBlockCount != nullptr) {
        *replayedBlockCount = replayed;
    }
    return StorageOperationResult::succeeded(summary.directory);
}

StorageOperationResult ExperimentArchiveService::exportProcessingResultsCsv(
    const QString &experimentDirectory,
    const QString &outputFilePath,
    quint64 *exportedRowCount)
{
    if (outputFilePath.trimmed().isEmpty() || QFileInfo::exists(outputFilePath)) {
        return archiveFailure(
            QStringLiteral("ARCHIVE_EXPORT_TARGET_INVALID"),
            QStringLiteral("导出目标无效或已存在，未覆盖文件。"), outputFilePath, outputFilePath);
    }
    ExperimentArchiveSummary summary;
    QJsonObject manifest;
    QStringList rawFiles;
    QStringList resultFiles;
    StorageOperationResult result = validateManifest(
        experimentDirectory, &manifest, &summary, &rawFiles, &resultFiles);
    if (!result.success) {
        return result;
    }
    const QFileInfo outputInfo(outputFilePath);
    if (!QDir().mkpath(outputInfo.absolutePath())) {
        return archiveFailure(
            QStringLiteral("ARCHIVE_EXPORT_DIRECTORY_FAILED"),
            QStringLiteral("无法创建导出目录。"), outputInfo.absolutePath(), outputFilePath);
    }
    QSaveFile output(outputInfo.absoluteFilePath());
    if (!output.open(QIODevice::WriteOnly | QIODevice::Truncate | QIODevice::Text)) {
        return archiveFailure(
            QStringLiteral("ARCHIVE_EXPORT_OPEN_FAILED"),
            QStringLiteral("无法创建导出文件。"), output.errorString(), outputFilePath);
    }
    QTextStream stream(&output);
#if QT_VERSION >= QT_VERSION_CHECK(6, 0, 0)
    stream.setEncoding(QStringConverter::Utf8);
#else
    stream.setCodec("UTF-8");
#endif
    stream << "experiment_id,run_id,source_sequence,timestamp_utc,point_index,relative_frequency_cm1,voltage_v,baseline_v,fitted_voltage_v,absorbance,fitted_absorbance,peak_absorbance,light_percent,concentration,concentration_unit,validity,algorithm_version,calibration_version,time_seconds\n";
    quint64 rows = 0;
    const QDir resultsDirectory(QDir(summary.directory).filePath(QStringLiteral("results")));
    for (const QString &fileName : resultFiles) {
        QJsonObject object;
        result = readJsonObject(resultsDirectory.filePath(fileName), &object);
        if (!result.success) {
            return result;
        }
        const QJsonArray frequencies = object.value(QStringLiteral("relativeFrequencyCm1")).toArray();
        const QJsonArray times = object.value(QStringLiteral("timeSeconds")).toArray();
        const QJsonArray voltage = object.value(QStringLiteral("voltageV")).toArray();
        const QJsonArray baseline = object.value(QStringLiteral("baselineV")).toArray();
        const QJsonArray fittedVoltage = object.value(QStringLiteral("fittedVoltageV")).toArray();
        const QJsonArray absorbance = object.value(QStringLiteral("absorbance")).toArray();
        const QJsonArray fittedAbsorbance = object.value(QStringLiteral("fittedAbsorbance")).toArray();
        const qsizetype pointCount = std::max({
            frequencies.size(), voltage.size(), baseline.size(), fittedVoltage.size(),
            absorbance.size(), fittedAbsorbance.size()});
        const auto curveLengthValid = [pointCount](const QJsonArray &values) {
            return values.isEmpty() || values.size() == pointCount;
        };
        if (object.value(QStringLiteral("experimentId")).toString() != summary.experimentId.value
            || object.value(QStringLiteral("runId")).toString() != summary.runId.value
            || pointCount == 0 || !curveLengthValid(frequencies) || !curveLengthValid(times) || !curveLengthValid(voltage)
            || !curveLengthValid(baseline) || !curveLengthValid(fittedVoltage)
            || !curveLengthValid(absorbance) || !curveLengthValid(fittedAbsorbance)) {
            return archiveFailure(
                QStringLiteral("ARCHIVE_RESULT_INVALID"),
                QStringLiteral("处理结果归档字段或曲线长度无效。"), fileName, result.path);
        }
        const QStringList common{
            csvField(summary.experimentId.value),
            csvField(summary.runId.value),
            QString::number(object.value(QStringLiteral("sourceSequence")).toInteger()),
            csvField(object.value(QStringLiteral("timestampUtc")).toString())};
        const QStringList trailing{
            jsonNumber(object.value(QStringLiteral("peakAbsorbance"))),
            jsonNumber(object.value(QStringLiteral("lightPercent"))),
            jsonNumber(object.value(QStringLiteral("concentration"))),
            csvField(object.value(QStringLiteral("concentrationUnit")).toString()),
            csvField(object.value(QStringLiteral("validity")).toString()),
            csvField(object.value(QStringLiteral("algorithmVersion")).toString()),
            csvField(object.value(QStringLiteral("calibrationVersion")).toString())};
        for (qsizetype index = 0; index < pointCount; ++index) {
            QStringList row = common;
            const auto curveValue = [index](const QJsonArray &values) {
                return values.isEmpty() ? QString() : jsonNumber(values.at(index));
            };
            row << QString::number(index)
                << curveValue(frequencies)
                << curveValue(voltage)
                << curveValue(baseline)
                << curveValue(fittedVoltage)
                << curveValue(absorbance)
                << curveValue(fittedAbsorbance);
            row.append(trailing);
            row.append(curveValue(times));
            stream << row.join(QLatin1Char(',')) << '\n';
            ++rows;
        }
    }
    stream.flush();
    if (stream.status() != QTextStream::Ok || !output.commit()) {
        return archiveFailure(
            QStringLiteral("ARCHIVE_EXPORT_COMMIT_FAILED"),
            QStringLiteral("导出文件保存失败。"), output.errorString(), outputFilePath);
    }
    if (exportedRowCount != nullptr) {
        *exportedRowCount = rows;
    }
    return StorageOperationResult::succeeded(outputInfo.absoluteFilePath());
}

StorageOperationResult ExperimentArchiveService::recoverInterruptedExperiment(
    const QString &experimentDirectory,
    const QDateTime &recoveredAtUtc,
    const QString &diagnostic)
{
    if (!recoveredAtUtc.isValid()) {
        return archiveFailure(
            QStringLiteral("ARCHIVE_ARGUMENT_INVALID"),
            QStringLiteral("恢复时间无效。"), QStringLiteral("invalid recovery time"));
    }
    ExperimentArchiveSummary summary;
    QJsonObject manifest;
    QStringList rawFiles;
    QStringList resultFiles;
    StorageOperationResult result = validateManifest(
        experimentDirectory, &manifest, &summary, &rawFiles, &resultFiles);
    if (!result.success) {
        return result;
    }
    if (summary.status != QStringLiteral("running")) {
        return archiveFailure(
            QStringLiteral("ARCHIVE_NOT_INTERRUPTED"),
            QStringLiteral("实验归档不需要恢复。"), summary.status, summary.directory);
    }
    manifest.insert(QStringLiteral("status"), QStringLiteral("aborted"));
    manifest.insert(
        QStringLiteral("completedAtUtc"),
        recoveredAtUtc.toUTC().toString(Qt::ISODateWithMs));
    manifest.insert(QStringLiteral("rawBlockCount"), static_cast<qint64>(rawFiles.size()));
    manifest.insert(QStringLiteral("resultCount"), static_cast<qint64>(resultFiles.size()));
    manifest.insert(QStringLiteral("diagnostic"), diagnostic);
    const QString manifestPath = QDir(summary.directory).filePath(QStringLiteral("manifest.json"));
    QSaveFile manifestFile(manifestPath);
    if (!manifestFile.open(QIODevice::WriteOnly | QIODevice::Truncate)) {
        return archiveFailure(
            QStringLiteral("ARCHIVE_RECOVERY_OPEN_FAILED"),
            QStringLiteral("无法恢复中断实验。"), manifestFile.errorString(), manifestPath);
    }
    const QByteArray payload = QJsonDocument(manifest).toJson(QJsonDocument::Indented);
    if (manifestFile.write(payload) != payload.size() || !manifestFile.commit()) {
        return archiveFailure(
            QStringLiteral("ARCHIVE_RECOVERY_COMMIT_FAILED"),
            QStringLiteral("中断实验恢复提交失败。"), manifestFile.errorString(), manifestPath);
    }

    const QString logPath = QDir(summary.directory).filePath(QStringLiteral("logs/events.jsonl"));
    QFile log(logPath);
    if (!log.open(QIODevice::WriteOnly | QIODevice::Append | QIODevice::Text)) {
        return archiveFailure(
            QStringLiteral("ARCHIVE_RECOVERY_LOG_FAILED"),
            QStringLiteral("中断实验已恢复，但恢复事件写入失败。"), log.errorString(), logPath);
    }
    const QJsonObject event{
        {QStringLiteral("timestampUtc"), recoveredAtUtc.toUTC().toString(Qt::ISODateWithMs)},
        {QStringLiteral("experimentId"), summary.experimentId.value},
        {QStringLiteral("runId"), summary.runId.value},
        {QStringLiteral("event"), QStringLiteral("experiment-recovered")},
        {QStringLiteral("outcome"), QStringLiteral("aborted")},
        {QStringLiteral("diagnostic"), diagnostic}};
    const QByteArray line = QJsonDocument(event).toJson(QJsonDocument::Compact) + '\n';
    if (log.write(line) != line.size() || !log.flush()) {
        return archiveFailure(
            QStringLiteral("ARCHIVE_RECOVERY_LOG_FAILED"),
            QStringLiteral("中断实验已恢复，但恢复事件写入失败。"), log.errorString(), logPath);
    }
    return StorageOperationResult::succeeded(summary.directory);
}

} // namespace tdlas::storage
