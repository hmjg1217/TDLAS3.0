#pragma once

#include "storage/IStorageRepository.h"

#include <functional>

namespace tdlas::storage {

struct ExperimentArchiveSummary {
    contracts::ExperimentId experimentId;
    contracts::RunId runId;
    QString status;
    QDateTime startedAtUtc;
    QDateTime completedAtUtc;
    contracts::DataSourceKind sourceKind = contracts::DataSourceKind::Simulation;
    QString operatorId;
    QString parameterSnapshotId;
    QString algorithmParameterSetId;
    quint64 rawBlockCount = 0;
    quint64 resultCount = 0;
    QString directory;
};

class ExperimentArchiveService final
{
public:
    using RawBlockConsumer = std::function<bool(const contracts::RawDataBlock &)>;

    [[nodiscard]] static StorageOperationResult inspect(
        const QString &experimentDirectory,
        ExperimentArchiveSummary *summary);
    [[nodiscard]] static StorageOperationResult replayRawData(
        const QString &experimentDirectory,
        const RawBlockConsumer &consumer,
        quint64 *replayedBlockCount = nullptr);
    [[nodiscard]] static StorageOperationResult exportProcessingResultsCsv(
        const QString &experimentDirectory,
        const QString &outputFilePath,
        quint64 *exportedRowCount = nullptr);
    [[nodiscard]] static StorageOperationResult recoverInterruptedExperiment(
        const QString &experimentDirectory,
        const QDateTime &recoveredAtUtc,
        const QString &diagnostic = QStringLiteral("application restarted before experiment completion"));
};

} // namespace tdlas::storage
