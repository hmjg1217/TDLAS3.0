#include "storage/FileStorageRepository.h"

#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QSaveFile>

#include <cmath>

namespace tdlas::storage {

namespace {

QString isoUtc(const QDateTime &value)
{
    return value.isValid() ? value.toUTC().toString(Qt::ISODateWithMs) : QString();
}

QString waveformName(contracts::Waveform waveform)
{
    switch (waveform) {
    case contracts::Waveform::Sine:
        return QStringLiteral("sine");
    case contracts::Waveform::Square:
        return QStringLiteral("square");
    case contracts::Waveform::Sawtooth:
        return QStringLiteral("sawtooth");
    case contracts::Waveform::Triangle:
        return QStringLiteral("triangle");
    }
    return QStringLiteral("unknown");
}

QString validityName(contracts::DataValidity validity)
{
    switch (validity) {
    case contracts::DataValidity::Valid:
        return QStringLiteral("valid");
    case contracts::DataValidity::Invalid:
        return QStringLiteral("invalid");
    case contracts::DataValidity::Incomplete:
        return QStringLiteral("incomplete");
    case contracts::DataValidity::Stale:
        return QStringLiteral("stale");
    case contracts::DataValidity::Uncalibrated:
        return QStringLiteral("uncalibrated");
    }
    return QStringLiteral("unknown");
}

QString sourceName(contracts::DataSourceKind source)
{
    return source == contracts::DataSourceKind::RealDevice
        ? QStringLiteral("real-device")
        : QStringLiteral("simulation");
}

QString completionName(ExperimentCompletionStatus status)
{
    switch (status) {
    case ExperimentCompletionStatus::Completed:
        return QStringLiteral("completed");
    case ExperimentCompletionStatus::Aborted:
        return QStringLiteral("aborted");
    case ExperimentCompletionStatus::Faulted:
        return QStringLiteral("faulted");
    }
    return QStringLiteral("unknown");
}

QJsonArray doubles(const QVector<double> &values)
{
    QJsonArray array;
    for (double value : values) {
        array.append(value);
    }
    return array;
}

void addOptional(QJsonObject &object, const QString &name, const std::optional<double> &value)
{
    if (value.has_value() && std::isfinite(*value)) {
        object.insert(name, *value);
    } else {
        object.insert(name, QJsonValue::Null);
    }
}

QJsonObject parameterJson(const contracts::ParameterSnapshot &parameters)
{
    QJsonArray channels;
    for (const QString &channel : parameters.aiChannelIds) {
        channels.append(channel);
    }
    return {
        {QStringLiteral("id"), parameters.id},
        {QStringLiteral("revision"), static_cast<qint64>(parameters.revision)},
        {QStringLiteral("createdAtUtc"), isoUtc(parameters.createdAtUtc)},
        {QStringLiteral("hashSha256"), parameters.hash},
        {QStringLiteral("deviceId"), parameters.deviceId},
        {QStringLiteral("aiChannelIds"), channels},
        {QStringLiteral("sampleRateHz"), parameters.sampleRateHz},
        {QStringLiteral("readSamplesPerBlock"), static_cast<qint64>(parameters.readSamplesPerBlock)},
        {QStringLiteral("inputRangeMinV"), parameters.inputRangeMinV},
        {QStringLiteral("inputRangeMaxV"), parameters.inputRangeMaxV},
        {QStringLiteral("aoEnabled"), parameters.aoEnabled},
        {QStringLiteral("aoChannelId"), parameters.aoChannelId},
        {QStringLiteral("waveform"), waveformName(parameters.waveform)},
        {QStringLiteral("outputFrequencyHz"), parameters.outputFrequencyHz},
        {QStringLiteral("outputAmplitudePeakV"), parameters.outputAmplitudePeakV},
        {QStringLiteral("outputOffsetV"), parameters.outputOffsetV},
        {QStringLiteral("outputSampleRateHz"), parameters.outputSampleRateHz},
        {QStringLiteral("algorithmParameterSetId"), parameters.algorithmParameterSetId}
    };
}

StorageOperationResult writeJsonAtomically(const QString &path, const QJsonObject &object)
{
    QSaveFile file(path);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Truncate)) {
        return StorageOperationResult::failed(
            QStringLiteral("STORAGE_OPEN_FAILED"),
            QStringLiteral("无法创建实验数据文件。"),
            file.errorString(),
            path);
    }
    const QByteArray payload = QJsonDocument(object).toJson(QJsonDocument::Indented);
    if (file.write(payload) != payload.size() || !file.commit()) {
        return StorageOperationResult::failed(
            QStringLiteral("STORAGE_COMMIT_FAILED"),
            QStringLiteral("实验数据文件保存失败。"),
            file.errorString(),
            path);
    }
    return StorageOperationResult::succeeded(path);
}

} // namespace

bool StorageConfiguration::isValid(QString *diagnostic) const
{
    QString reason;
    const QFileInfo root(rootDirectory);
    if (rootDirectory.trimmed().isEmpty()) {
        reason = QStringLiteral("storage root directory is empty");
    } else if (!root.isAbsolute()) {
        reason = QStringLiteral("storage root directory must be absolute");
    } else if (schemaVersion != QStringLiteral("1.0")) {
        reason = QStringLiteral("unsupported storage schema version");
    } else if (!saveRawData && !saveProcessingResults) {
        reason = QStringLiteral("at least raw data or processing results must be enabled");
    }
    if (diagnostic) {
        *diagnostic = reason;
    }
    return reason.isEmpty();
}

StorageOperationResult StorageOperationResult::succeeded(const QString &path)
{
    StorageOperationResult result;
    result.success = true;
    result.path = path;
    return result;
}

StorageOperationResult StorageOperationResult::failed(
    const QString &code,
    const QString &userMessage,
    const QString &diagnostic,
    const QString &path)
{
    StorageOperationResult result;
    result.code = code;
    result.userMessage = userMessage;
    result.diagnostic = diagnostic;
    result.path = path;
    return result;
}

StorageOperationResult StorageConfigurationStore::save(
    const QString &filePath,
    const StorageConfiguration &configuration)
{
    QString diagnostic;
    if (!configuration.isValid(&diagnostic)) {
        return StorageOperationResult::failed(
            QStringLiteral("STORAGE_CONFIG_INVALID"),
            QStringLiteral("存储配置无效。"), diagnostic, filePath);
    }
    const QFileInfo info(filePath);
    if (!QDir().mkpath(info.absolutePath())) {
        return StorageOperationResult::failed(
            QStringLiteral("STORAGE_CONFIG_DIRECTORY_FAILED"),
            QStringLiteral("无法创建存储配置目录。"), info.absolutePath(), filePath);
    }
    return writeJsonAtomically(filePath, {
        {QStringLiteral("schemaVersion"), configuration.schemaVersion},
        {QStringLiteral("rootDirectory"), configuration.rootDirectory},
        {QStringLiteral("saveRawData"), configuration.saveRawData},
        {QStringLiteral("saveProcessingResults"), configuration.saveProcessingResults},
        {QStringLiteral("writeEventLog"), configuration.writeEventLog}
    });
}

StorageConfiguration StorageConfigurationStore::loadOrCreate(
    const QString &filePath,
    const StorageConfiguration &defaults,
    StorageOperationResult *operation)
{
    QFile file(filePath);
    if (!file.exists()) {
        const StorageOperationResult saveResult = save(filePath, defaults);
        if (operation) {
            *operation = saveResult;
        }
        return defaults;
    }
    if (!file.open(QIODevice::ReadOnly)) {
        if (operation) {
            *operation = StorageOperationResult::failed(
                QStringLiteral("STORAGE_CONFIG_OPEN_FAILED"),
                QStringLiteral("无法读取存储配置。"), file.errorString(), filePath);
        }
        return defaults;
    }
    QJsonParseError parseError;
    const QJsonDocument document = QJsonDocument::fromJson(file.readAll(), &parseError);
    if (parseError.error != QJsonParseError::NoError || !document.isObject()) {
        if (operation) {
            *operation = StorageOperationResult::failed(
                QStringLiteral("STORAGE_CONFIG_PARSE_FAILED"),
                QStringLiteral("存储配置格式错误。"), parseError.errorString(), filePath);
        }
        return defaults;
    }
    const QJsonObject object = document.object();
    StorageConfiguration loaded;
    loaded.schemaVersion = object.value(QStringLiteral("schemaVersion")).toString();
    loaded.rootDirectory = object.value(QStringLiteral("rootDirectory")).toString();
    loaded.saveRawData = object.value(QStringLiteral("saveRawData")).toBool(true);
    loaded.saveProcessingResults = object.value(QStringLiteral("saveProcessingResults")).toBool(true);
    loaded.writeEventLog = object.value(QStringLiteral("writeEventLog")).toBool(true);
    QString diagnostic;
    if (!loaded.isValid(&diagnostic)) {
        if (operation) {
            *operation = StorageOperationResult::failed(
                QStringLiteral("STORAGE_CONFIG_INVALID"),
                QStringLiteral("存储配置无效。"), diagnostic, filePath);
        }
        return defaults;
    }
    if (operation) {
        *operation = StorageOperationResult::succeeded(filePath);
    }
    return loaded;
}

FileStorageRepository::FileStorageRepository(StorageConfiguration configuration)
    : configuration_(std::move(configuration))
{
}

QString FileStorageRepository::directoryFor(const ExperimentContext &context) const
{
    const QString relative = QStringLiteral("%1/%2")
        .arg(context.startedAt.utc.toUTC().toString(QStringLiteral("yyyy/MM/dd")),
            context.experimentId.value);
    return QDir::cleanPath(QDir(configuration_.rootDirectory).absoluteFilePath(relative));
}

StorageOperationResult FileStorageRepository::beginExperiment(const ExperimentContext &context)
{
    QString configurationDiagnostic;
    QString parameterDiagnostic;
    if (!configuration_.isValid(&configurationDiagnostic)) {
        return StorageOperationResult::failed(
            QStringLiteral("STORAGE_CONFIG_INVALID"),
            QStringLiteral("存储配置无效，无法开始实验。"), configurationDiagnostic);
    }
    if (!context.experimentId.isValid() || !context.runId.isValid()
        || !context.startedAt.utc.isValid()
        || !context.parameters.isValid(&parameterDiagnostic)) {
        return StorageOperationResult::failed(
            QStringLiteral("STORAGE_CONTEXT_INVALID"),
            QStringLiteral("实验保存上下文无效。"),
            parameterDiagnostic.isEmpty() ? QStringLiteral("invalid experiment id, run id, or start time") : parameterDiagnostic);
    }
    if (activeExperiments_.contains(context.experimentId.value)
        || knownDirectories_.contains(context.experimentId.value)) {
        return StorageOperationResult::failed(
            QStringLiteral("STORAGE_EXPERIMENT_EXISTS"),
            QStringLiteral("实验 ID 已存在，未覆盖已有数据。"), context.experimentId.value);
    }

    const QString base = QDir::fromNativeSeparators(
        QDir::cleanPath(QFileInfo(configuration_.rootDirectory).absoluteFilePath()));
    const QString directory = QDir::fromNativeSeparators(directoryFor(context));
#ifdef Q_OS_WIN
    constexpr Qt::CaseSensitivity pathCase = Qt::CaseInsensitive;
#else
    constexpr Qt::CaseSensitivity pathCase = Qt::CaseSensitive;
#endif
    if (!directory.startsWith(base + QLatin1Char('/'), pathCase)) {
        return StorageOperationResult::failed(
            QStringLiteral("STORAGE_PATH_OUTSIDE_ROOT"),
            QStringLiteral("实验目录超出已配置的数据根目录。"), directory);
    }
    if (QFileInfo::exists(directory)) {
        return StorageOperationResult::failed(
            QStringLiteral("STORAGE_EXPERIMENT_EXISTS"),
            QStringLiteral("实验 ID 已存在，未覆盖已有数据。"), directory, directory);
    }
    const QStringList subdirectories = {
        directory,
        QDir(directory).filePath(QStringLiteral("parameters")),
        QDir(directory).filePath(QStringLiteral("raw")),
        QDir(directory).filePath(QStringLiteral("results")),
        QDir(directory).filePath(QStringLiteral("logs"))};
    for (const QString &path : subdirectories) {
        if (!QDir().mkpath(path)) {
            return StorageOperationResult::failed(
                QStringLiteral("STORAGE_DIRECTORY_FAILED"),
                QStringLiteral("无法创建实验数据目录。"), path, path);
        }
    }

    ActiveExperiment active{context, directory};
    StorageOperationResult result = writeManifest(active, QStringLiteral("running"));
    if (!result.success) {
        return result;
    }
    const QString parameterName = QStringLiteral("parameter-r%1-%2.json")
        .arg(context.parameters.revision)
        .arg(context.parameters.hash.left(12));
    result = writeJsonAtomically(
        QDir(directory).filePath(QStringLiteral("parameters/%1").arg(parameterName)),
        parameterJson(context.parameters));
    if (!result.success) {
        return result;
    }
    result = appendEvent(active, QStringLiteral("experiment-started"), QStringLiteral("success"));
    if (!result.success) {
        return result;
    }
    activeExperiments_.insert(context.experimentId.value, active);
    knownDirectories_.insert(context.experimentId.value, directory);
    return StorageOperationResult::succeeded(directory);
}

StorageOperationResult FileStorageRepository::appendRawData(
    const contracts::ExperimentId &experimentId,
    const contracts::RawDataBlock &block)
{
    auto iterator = activeExperiments_.find(experimentId.value);
    if (iterator == activeExperiments_.end()) {
        return StorageOperationResult::failed(
            QStringLiteral("STORAGE_EXPERIMENT_NOT_ACTIVE"),
            QStringLiteral("实验保存会话未处于活动状态。"), experimentId.value);
    }
    ActiveExperiment &active = iterator.value();
    if (block.runId != active.context.runId || block.sequence == 0) {
        return StorageOperationResult::failed(
            QStringLiteral("STORAGE_RAW_MISMATCH"),
            QStringLiteral("原始数据与当前实验不匹配。"),
            QStringLiteral("run or sequence mismatch"));
    }
    if (!configuration_.saveRawData) {
        return StorageOperationResult::succeeded(active.directory);
    }

    const QString path = QDir(active.directory).filePath(
        QStringLiteral("raw/raw-%1.csv").arg(block.sequence, 12, 10, QLatin1Char('0')));
    if (QFileInfo::exists(path)) {
        return StorageOperationResult::failed(
            QStringLiteral("STORAGE_SEQUENCE_EXISTS"),
            QStringLiteral("原始数据序号已存在，未覆盖已有文件。"),
            QString::number(block.sequence), path);
    }
    QSaveFile file(path);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Truncate | QIODevice::Text)) {
        return StorageOperationResult::failed(
            QStringLiteral("STORAGE_RAW_OPEN_FAILED"),
            QStringLiteral("原始数据保存失败，采集将安全停止。"), file.errorString(), path);
    }
    // Reuse a bounded UTF-8 staging buffer rather than formatting every scalar
    // through QTextStream or holding a whole high-sample-rate block in memory.
    // QSaveFile still commits only after every chunk has been written.
    constexpr qsizetype kChunkBytes = 64 * 1024;
    QByteArray payload;
    payload.reserve(kChunkBytes + 256);
    payload.append("experiment_id,run_id,stream_id,sequence,sample_start_utc,sample_rate_hz,channel_id,sample_index,voltage_v,validity,overrun,dropped_before\n");
    const QByteArray experimentIdBytes = experimentId.value.toUtf8();
    const QByteArray runIdBytes = block.runId.value.toUtf8();
    const QByteArray streamIdBytes = block.streamId.toUtf8();
    const QByteArray sampleStartBytes = isoUtc(block.sampleStart.utc).toUtf8();
    const QByteArray sampleRateBytes = QByteArray::number(block.sampleRateHz, 'g', 17);
    const QByteArray validityBytes = validityName(block.validity).toUtf8();
    const QByteArray overrunBytes = block.overrun ? QByteArrayLiteral("1") : QByteArrayLiteral("0");
    const QByteArray sequenceBytes = QByteArray::number(block.sequence);
    const QByteArray droppedBeforeBytes = QByteArray::number(block.droppedBefore);
    auto flushChunk = [&]() {
        if (payload.isEmpty()) return true;
        const bool written = file.write(payload) == payload.size();
        payload.clear();
        return written;
    };
    for (const contracts::ChannelSamples &channel : block.channels) {
        const QByteArray channelIdBytes = channel.channelId.toUtf8();
        QByteArray rowPrefix;
        rowPrefix.reserve(experimentIdBytes.size() + runIdBytes.size() + streamIdBytes.size()
            + sequenceBytes.size() + sampleStartBytes.size() + sampleRateBytes.size()
            + channelIdBytes.size() + 8);
        rowPrefix.append(experimentIdBytes).append(',')
            .append(runIdBytes).append(',')
            .append(streamIdBytes).append(',')
            .append(sequenceBytes).append(',')
            .append(sampleStartBytes).append(',')
            .append(sampleRateBytes).append(',')
            .append(channelIdBytes).append(',');
        QByteArray rowSuffix;
        rowSuffix.append(',').append(validityBytes).append(',')
            .append(overrunBytes).append(',').append(droppedBeforeBytes).append('\n');
        for (qsizetype index = 0; index < channel.samplesV.size(); ++index) {
            payload.append(rowPrefix)
                .append(QByteArray::number(index)).append(',')
                .append(QByteArray::number(channel.samplesV.at(index), 'g', 17))
                .append(rowSuffix);
            if (payload.size() >= kChunkBytes && !flushChunk()) {
                return StorageOperationResult::failed(
                    QStringLiteral("STORAGE_RAW_COMMIT_FAILED"),
                    QStringLiteral("原始数据保存失败，采集将安全停止。"), file.errorString(), path);
            }
        }
    }
    if (!flushChunk() || !file.commit()) {
        return StorageOperationResult::failed(
            QStringLiteral("STORAGE_RAW_COMMIT_FAILED"),
            QStringLiteral("原始数据保存失败，采集将安全停止。"), file.errorString(), path);
    }
    ++active.rawBlockCount;
    return StorageOperationResult::succeeded(path);
}

StorageOperationResult FileStorageRepository::appendProcessingResult(
    const contracts::ExperimentId &experimentId,
    const contracts::ProcessingResult &result)
{
    auto iterator = activeExperiments_.find(experimentId.value);
    if (iterator == activeExperiments_.end()) {
        return StorageOperationResult::failed(
            QStringLiteral("STORAGE_EXPERIMENT_NOT_ACTIVE"),
            QStringLiteral("实验保存会话未处于活动状态。"), experimentId.value);
    }
    ActiveExperiment &active = iterator.value();
    if (result.runId != active.context.runId || result.sourceSequence == 0) {
        return StorageOperationResult::failed(
            QStringLiteral("STORAGE_RESULT_MISMATCH"),
            QStringLiteral("处理结果与当前实验不匹配。"),
            QStringLiteral("run or source sequence mismatch"));
    }
    if (!configuration_.saveProcessingResults) {
        return StorageOperationResult::succeeded(active.directory);
    }

    QJsonObject object{
        {QStringLiteral("experimentId"), experimentId.value},
        {QStringLiteral("runId"), result.runId.value},
        {QStringLiteral("sourceSequence"), static_cast<qint64>(result.sourceSequence)},
        {QStringLiteral("timestampUtc"), isoUtc(result.timestamp.utc)},
        {QStringLiteral("parameterSnapshotId"), result.parameterSnapshotId},
        {QStringLiteral("algorithmVersion"), result.algorithmVersion},
        {QStringLiteral("calibrationVersion"), result.calibrationVersion},
        {QStringLiteral("validity"), validityName(result.validity)},
        {QStringLiteral("diagnostic"), result.diagnostic},
        {QStringLiteral("concentrationUnit"), result.concentrationUnit},
        {QStringLiteral("relativeFrequencyCm1"), doubles(result.relativeFrequencyCm1)},
        {QStringLiteral("timeSeconds"), doubles(result.timeSeconds)},
          {QStringLiteral("cycleTimeSeconds"), doubles(result.cycleTimeSeconds)},
          {QStringLiteral("cycleVoltageV"), doubles(result.cycleVoltageV)},
          {QStringLiteral("displayVoltageOffsetV"), result.displayVoltageOffsetV},
        {QStringLiteral("voltageV"), doubles(result.voltageV)},
        {QStringLiteral("baselineV"), doubles(result.baselineV)},
        {QStringLiteral("fittedVoltageV"), doubles(result.fittedVoltageV)},
        {QStringLiteral("absorbance"), doubles(result.absorbance)},
        {QStringLiteral("fittedAbsorbance"), doubles(result.fittedAbsorbance)}
    };
    addOptional(object, QStringLiteral("voigtCenterCm1"), result.voigtCenterCm1);
    addOptional(object, QStringLiteral("voigtAmplitude"), result.voigtAmplitude);
    addOptional(object, QStringLiteral("voigtGaussianFwhmCm1"), result.voigtGaussianFwhmCm1);
    addOptional(object, QStringLiteral("voigtLorentzianFwhmCm1"), result.voigtLorentzianFwhmCm1);
    addOptional(object, QStringLiteral("voigtResidualSumSquares"), result.voigtResidualSumSquares);
    addOptional(object, QStringLiteral("peakAbsorbance"), result.peakAbsorbance);
    addOptional(object, QStringLiteral("lightPercent"), result.lightPercent);
    addOptional(object, QStringLiteral("concentration"), result.concentration);

    const QString path = QDir(active.directory).filePath(
        QStringLiteral("results/result-%1.json").arg(result.sourceSequence, 12, 10, QLatin1Char('0')));
    if (QFileInfo::exists(path)) {
        return StorageOperationResult::failed(
            QStringLiteral("STORAGE_SEQUENCE_EXISTS"),
            QStringLiteral("处理结果序号已存在，未覆盖已有文件。"),
            QString::number(result.sourceSequence), path);
    }
    const StorageOperationResult saveResult = writeJsonAtomically(path, object);
    if (saveResult.success) {
        ++active.resultCount;
    }
    return saveResult;
}

StorageOperationResult FileStorageRepository::finishExperiment(
    const contracts::ExperimentId &experimentId,
    ExperimentCompletionStatus status,
    const QDateTime &completedAtUtc,
    const QString &diagnostic)
{
    auto iterator = activeExperiments_.find(experimentId.value);
    if (iterator == activeExperiments_.end()) {
        return StorageOperationResult::failed(
            QStringLiteral("STORAGE_EXPERIMENT_NOT_ACTIVE"),
            QStringLiteral("实验保存会话未处于活动状态。"), experimentId.value);
    }
    const ActiveExperiment active = iterator.value();
    StorageOperationResult result = writeManifest(
        active, completionName(status), completedAtUtc, diagnostic);
    if (result.success) {
        result = appendEvent(active, QStringLiteral("experiment-finished"), completionName(status), diagnostic);
    }
    if (result.success) {
        activeExperiments_.erase(iterator);
    }
    return result;
}

QString FileStorageRepository::experimentDirectory(
    const contracts::ExperimentId &experimentId) const
{
    return knownDirectories_.value(experimentId.value);
}

StorageOperationResult FileStorageRepository::writeManifest(
    const ActiveExperiment &active,
    const QString &status,
    const QDateTime &completedAtUtc,
    const QString &diagnostic) const
{
    const ExperimentContext &context = active.context;
    QJsonObject object{
        {QStringLiteral("schemaVersion"), configuration_.schemaVersion},
        {QStringLiteral("contractVersion"), QStringLiteral("%1.%2")
            .arg(contracts::kContractMajorVersion).arg(contracts::kContractMinorVersion)},
        {QStringLiteral("experimentId"), context.experimentId.value},
        {QStringLiteral("runId"), context.runId.value},
        {QStringLiteral("status"), status},
        {QStringLiteral("startedAtUtc"), isoUtc(context.startedAt.utc)},
        {QStringLiteral("completedAtUtc"), isoUtc(completedAtUtc)},
        {QStringLiteral("sourceKind"), sourceName(context.sourceKind)},
        {QStringLiteral("operatorId"), context.operatorId},
        {QStringLiteral("parameterSnapshotId"), context.parameters.id},
        {QStringLiteral("parameterHashSha256"), context.parameters.hash},
        {QStringLiteral("algorithmParameterSetId"), context.parameters.algorithmParameterSetId},
        {QStringLiteral("rawBlockCount"), static_cast<qint64>(active.rawBlockCount)},
        {QStringLiteral("resultCount"), static_cast<qint64>(active.resultCount)},
        {QStringLiteral("diagnostic"), diagnostic}
    };
    return writeJsonAtomically(QDir(active.directory).filePath(QStringLiteral("manifest.json")), object);
}

StorageOperationResult FileStorageRepository::appendEvent(
    const ActiveExperiment &active,
    const QString &event,
    const QString &outcome,
    const QString &diagnostic) const
{
    if (!configuration_.writeEventLog) {
        return StorageOperationResult::succeeded(active.directory);
    }
    const QString path = QDir(active.directory).filePath(QStringLiteral("logs/events.jsonl"));
    QFile file(path);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Append | QIODevice::Text)) {
        return StorageOperationResult::failed(
            QStringLiteral("STORAGE_LOG_OPEN_FAILED"),
            QStringLiteral("实验日志保存失败。"), file.errorString(), path);
    }
    const QJsonObject object{
        {QStringLiteral("timestampUtc"), isoUtc(QDateTime::currentDateTimeUtc())},
        {QStringLiteral("experimentId"), active.context.experimentId.value},
        {QStringLiteral("runId"), active.context.runId.value},
        {QStringLiteral("event"), event},
        {QStringLiteral("outcome"), outcome},
        {QStringLiteral("diagnostic"), diagnostic}
    };
    const QByteArray line = QJsonDocument(object).toJson(QJsonDocument::Compact) + '\n';
    if (file.write(line) != line.size() || !file.flush()) {
        return StorageOperationResult::failed(
            QStringLiteral("STORAGE_LOG_WRITE_FAILED"),
            QStringLiteral("实验日志保存失败。"), file.errorString(), path);
    }
    return StorageOperationResult::succeeded(path);
}

} // namespace tdlas::storage

