#pragma once

#include "storage/IStorageRepository.h"

#include <QHash>

namespace tdlas::storage {

class StorageConfigurationStore final
{
public:
    [[nodiscard]] static StorageOperationResult save(
        const QString &filePath,
        const StorageConfiguration &configuration);
    [[nodiscard]] static StorageConfiguration loadOrCreate(
        const QString &filePath,
        const StorageConfiguration &defaults,
        StorageOperationResult *operation = nullptr);
};

class FileStorageRepository final : public IStorageRepository
{
public:
    explicit FileStorageRepository(StorageConfiguration configuration);

    [[nodiscard]] StorageOperationResult beginExperiment(const ExperimentContext &context) override;
    [[nodiscard]] StorageOperationResult appendRawData(
        const contracts::ExperimentId &experimentId,
        const contracts::RawDataBlock &block) override;
    [[nodiscard]] StorageOperationResult appendProcessingResult(
        const contracts::ExperimentId &experimentId,
        const contracts::ProcessingResult &result) override;
    [[nodiscard]] StorageOperationResult finishExperiment(
        const contracts::ExperimentId &experimentId,
        ExperimentCompletionStatus status,
        const QDateTime &completedAtUtc,
        const QString &diagnostic = {}) override;
    [[nodiscard]] QString experimentDirectory(
        const contracts::ExperimentId &experimentId) const override;

private:
    struct ActiveExperiment {
        ExperimentContext context;
        QString directory;
        quint64 rawBlockCount = 0;
        quint64 resultCount = 0;
    };

    [[nodiscard]] StorageOperationResult writeManifest(
        const ActiveExperiment &active,
        const QString &status,
        const QDateTime &completedAtUtc = {},
        const QString &diagnostic = {}) const;
    [[nodiscard]] StorageOperationResult appendEvent(
        const ActiveExperiment &active,
        const QString &event,
        const QString &outcome,
        const QString &diagnostic = {}) const;
    [[nodiscard]] QString directoryFor(const ExperimentContext &context) const;

    StorageConfiguration configuration_;
    QHash<QString, ActiveExperiment> activeExperiments_;
    QHash<QString, QString> knownDirectories_;
};

} // namespace tdlas::storage

