#pragma once

#include "contracts/MeasurementTypes.h"

namespace tdlas::storage {

struct StorageConfiguration {
    QString rootDirectory;
    QString schemaVersion = QStringLiteral("1.0");
    bool saveRawData = true;
    bool saveProcessingResults = true;
    bool writeEventLog = true;

    [[nodiscard]] bool isValid(QString *diagnostic = nullptr) const;
};

enum class ExperimentCompletionStatus {
    Completed,
    Aborted,
    Faulted
};

struct ExperimentContext {
    contracts::ExperimentId experimentId;
    contracts::RunId runId;
    contracts::ParameterSnapshot parameters;
    contracts::Timestamp startedAt;
    contracts::DataSourceKind sourceKind = contracts::DataSourceKind::Simulation;
    QString operatorId;
};

struct StorageOperationResult {
    bool success = false;
    QString code;
    QString userMessage;
    QString diagnostic;
    QString path;

    [[nodiscard]] static StorageOperationResult succeeded(const QString &path = {});
    [[nodiscard]] static StorageOperationResult failed(
        const QString &code,
        const QString &userMessage,
        const QString &diagnostic,
        const QString &path = {});
};

class IStorageRepository
{
public:
    virtual ~IStorageRepository() = default;

    [[nodiscard]] virtual StorageOperationResult beginExperiment(const ExperimentContext &context) = 0;
    [[nodiscard]] virtual StorageOperationResult appendRawData(
        const contracts::ExperimentId &experimentId,
        const contracts::RawDataBlock &block) = 0;
    [[nodiscard]] virtual StorageOperationResult appendProcessingResult(
        const contracts::ExperimentId &experimentId,
        const contracts::ProcessingResult &result) = 0;
    [[nodiscard]] virtual StorageOperationResult finishExperiment(
        const contracts::ExperimentId &experimentId,
        ExperimentCompletionStatus status,
        const QDateTime &completedAtUtc,
        const QString &diagnostic = {}) = 0;
    [[nodiscard]] virtual QString experimentDirectory(
        const contracts::ExperimentId &experimentId) const = 0;
};

} // namespace tdlas::storage

