#include "storage/PeakRecordCsvExporter.h"
#include <QDir>
#include <QFileInfo>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QSaveFile>
#include <QTimeZone>
#include <cmath>

namespace tdlas::storage {
namespace {
QString quoted(QString text) {
    text.replace(QLatin1Char('"'), QStringLiteral("\"\""));
    return QLatin1Char('"') + text + QLatin1Char('"');
}
QString number(const std::optional<double> &value) {
    return value && std::isfinite(*value) ? QString::number(*value, 'g', 17) : QString();
}
QString quality(contracts::DataValidity value) {
    switch (value) {
    case contracts::DataValidity::Valid: return QStringLiteral("Valid");
    case contracts::DataValidity::Invalid: return QStringLiteral("Invalid");
    case contracts::DataValidity::Incomplete: return QStringLiteral("Incomplete");
    case contracts::DataValidity::Stale: return QStringLiteral("Stale");
    case contracts::DataValidity::Uncalibrated: return QStringLiteral("Uncalibrated");
    }
    return QStringLiteral("Invalid");
}
QString parametersJson(const contracts::ParameterSnapshot &p) {
    const QJsonObject object{
        {QStringLiteral("id"), p.id}, {QStringLiteral("revision"), static_cast<qint64>(p.revision)},
        {QStringLiteral("createdAtUtc"), p.createdAtUtc.toUTC().toString(Qt::ISODateWithMs)},
        {QStringLiteral("hashSha256"), p.hash}, {QStringLiteral("deviceId"), p.deviceId},
        {QStringLiteral("aiChannelIds"), QJsonArray::fromStringList(p.aiChannelIds)},
        {QStringLiteral("sampleRateHz"), p.sampleRateHz},
        {QStringLiteral("readSamplesPerBlock"), static_cast<qint64>(p.readSamplesPerBlock)},
        {QStringLiteral("inputRangeMinV"), p.inputRangeMinV}, {QStringLiteral("inputRangeMaxV"), p.inputRangeMaxV},
        {QStringLiteral("aoEnabled"), p.aoEnabled}, {QStringLiteral("aoChannelId"), p.aoChannelId},
        {QStringLiteral("waveform"), static_cast<int>(p.waveform)},
        {QStringLiteral("outputFrequencyHz"), p.outputFrequencyHz},
        {QStringLiteral("outputAmplitudePeakV"), p.outputAmplitudePeakV},
        {QStringLiteral("outputOffsetV"), p.outputOffsetV}, {QStringLiteral("outputSampleRateHz"), p.outputSampleRateHz},
        {QStringLiteral("algorithmParameterSetId"), p.algorithmParameterSetId}};
    return QString::fromUtf8(QJsonDocument(object).toJson(QJsonDocument::Compact));
}
}

StorageOperationResult exportPeakRecordsCsv(const QVector<contracts::PeakRecord> &records, const QString &path)
{
    if (records.isEmpty() || path.trimmed().isEmpty()) {
        return StorageOperationResult::failed(QStringLiteral("PEAK_CSV_EMPTY"), QStringLiteral("暂无峰值源记录可导出。"), {}, path);
    }
    const QFileInfo info(path);
    if (!QDir().mkpath(info.absolutePath())) {
        return StorageOperationResult::failed(QStringLiteral("PEAK_CSV_DIRECTORY"), QStringLiteral("无法创建 CSV 目录。"), info.absolutePath(), path);
    }
    QSaveFile file(info.absoluteFilePath());
    file.setDirectWriteFallback(false);
    if (!file.open(QIODevice::WriteOnly)) {
        return StorageOperationResult::failed(QStringLiteral("PEAK_CSV_OPEN"), QStringLiteral("无法打开 CSV 文件。"), file.errorString(), path);
    }
    auto write = [&file](const QStringList &fields) {
        QStringList escaped;
        for (const auto &field : fields) escaped.push_back(quoted(field));
        const QByteArray row = escaped.join(QLatin1Char(',')).toUtf8() + "\r\n";
        return file.write(row) == row.size();
    };
    const QByteArray bom = QByteArray::fromHex("efbbbf");
    bool success = file.write(bom) == bom.size() && write({
        QStringLiteral("sequence"), QStringLiteral("acquisition_time_local"), QStringLiteral("time_zone"),
        QStringLiteral("utc_offset_seconds"), QStringLiteral("acquisition_time_utc"), QStringLiteral("elapsed_seconds"),
        QStringLiteral("peak_value"), QStringLiteral("peak_x"), QStringLiteral("peak_unit"), QStringLiteral("peak_x_unit"),
        QStringLiteral("validity"), QStringLiteral("reason"), QStringLiteral("run_id"), QStringLiteral("experiment_id"),
        QStringLiteral("device_id"), QStringLiteral("parameter_snapshot_id"), QStringLiteral("parameters_json"),
        QStringLiteral("algorithm_version"), QStringLiteral("calibration_version"), QStringLiteral("is_simulation"), QStringLiteral("contract_version")});
    const QString zone = QString::fromUtf8(QTimeZone::systemTimeZoneId());
    for (const auto &record : records) {
        if (!success) break;
        const auto local = record.acquiredAtUtc.toLocalTime();
        success = write({QString::number(record.sequence), local.toString(Qt::ISODateWithMs), zone,
            local.isValid() ? QString::number(local.offsetFromUtc()) : QString(),
            record.acquiredAtUtc.toUTC().toString(Qt::ISODateWithMs), QString::number(record.elapsedSeconds, 'g', 17),
            number(record.peakValue), number(record.peakX), record.unit, record.peakXUnit,
            quality(record.validity), record.reason, record.runId.value, record.experimentId.value,
            record.parameters.deviceId, record.parameters.id, parametersJson(record.parameters),
            record.algorithmVersion, record.calibrationVersion,
            record.sourceKind == contracts::DataSourceKind::Simulation ? QStringLiteral("1") : QStringLiteral("0"),
            QStringLiteral("%1.%2").arg(contracts::kContractMajorVersion).arg(contracts::kContractMinorVersion)});
    }
    if (!success) {
        file.cancelWriting();
        return StorageOperationResult::failed(QStringLiteral("PEAK_CSV_WRITE"), QStringLiteral("CSV 写入失败。"), file.errorString(), path);
    }
    if (!file.commit()) {
        return StorageOperationResult::failed(QStringLiteral("PEAK_CSV_COMMIT"), QStringLiteral("CSV 文件提交失败。"), file.errorString(), path);
    }
    return StorageOperationResult::succeeded(info.absoluteFilePath());
}
} // namespace tdlas::storage
