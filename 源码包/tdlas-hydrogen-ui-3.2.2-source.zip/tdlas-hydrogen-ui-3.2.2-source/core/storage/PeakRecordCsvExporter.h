#pragma once
#include "storage/IStorageRepository.h"
namespace tdlas::storage {
// Synchronous file I/O; application callers must run this on a worker.
[[nodiscard]] StorageOperationResult exportPeakRecordsCsv(
    const QVector<contracts::PeakRecord> &records, const QString &path);
}
