#include "system/IAuditSink.h"

#include <QDir>
#include <QFile>
#include <QJsonDocument>
#include <QJsonObject>

namespace tdlas::system {

FileAuditSink::FileAuditSink(QString rootDirectory)
    : rootDirectory_(std::move(rootDirectory))
{
}

AuditWriteResult FileAuditSink::record(const AuditEvent &event)
{
    if (!event.timestampUtc.isValid() || event.category.trimmed().isEmpty()
        || event.action.trimmed().isEmpty() || event.outcome.trimmed().isEmpty()) {
        return {false, QStringLiteral("AUDIT_EVENT_INVALID"),
            QStringLiteral("audit event is missing required fields")};
    }
    if (rootDirectory_.trimmed().isEmpty() || !QFileInfo(rootDirectory_).isAbsolute()) {
        return {false, QStringLiteral("AUDIT_CONFIG_INVALID"),
            QStringLiteral("audit root directory must be absolute")};
    }
    if (!QDir().mkpath(rootDirectory_)) {
        return {false, QStringLiteral("AUDIT_DIRECTORY_FAILED"), rootDirectory_};
    }
    const QString path = QDir(rootDirectory_).filePath(
        QStringLiteral("audit-%1.jsonl").arg(event.timestampUtc.toUTC().toString(QStringLiteral("yyyy-MM"))));
    QFile file(path);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Append | QIODevice::Text)) {
        return {false, QStringLiteral("AUDIT_OPEN_FAILED"), file.errorString()};
    }
    const QJsonObject object{
        {QStringLiteral("timestampUtc"), event.timestampUtc.toUTC().toString(Qt::ISODateWithMs)},
        {QStringLiteral("principalId"), event.principalId},
        {QStringLiteral("sessionId"), event.sessionId},
        {QStringLiteral("category"), event.category},
        {QStringLiteral("action"), event.action},
        {QStringLiteral("outcome"), event.outcome},
        {QStringLiteral("experimentId"), event.experimentId},
        {QStringLiteral("runId"), event.runId},
        {QStringLiteral("diagnostic"), event.diagnostic}
    };
    const QByteArray line = QJsonDocument(object).toJson(QJsonDocument::Compact) + '\n';
    if (file.write(line) != line.size() || !file.flush()) {
        return {false, QStringLiteral("AUDIT_WRITE_FAILED"), file.errorString()};
    }
    return {true, {}, {}};
}

} // namespace tdlas::system

