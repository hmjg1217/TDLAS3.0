#pragma once

#include "system/IAuthorizationService.h"

namespace tdlas::system {

struct AuditEvent {
    QDateTime timestampUtc;
    QString principalId;
    QString sessionId;
    QString category;
    QString action;
    QString outcome;
    QString experimentId;
    QString runId;
    QString diagnostic;
};

struct AuditWriteResult {
    bool success = false;
    QString code;
    QString diagnostic;
};

class IAuditSink
{
public:
    virtual ~IAuditSink() = default;
    [[nodiscard]] virtual AuditWriteResult record(const AuditEvent &event) = 0;
};

class FileAuditSink final : public IAuditSink
{
public:
    explicit FileAuditSink(QString rootDirectory);
    [[nodiscard]] AuditWriteResult record(const AuditEvent &event) override;

private:
    QString rootDirectory_;
};

} // namespace tdlas::system

