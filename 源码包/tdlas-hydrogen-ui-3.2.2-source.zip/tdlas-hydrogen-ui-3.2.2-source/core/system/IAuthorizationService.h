#pragma once

#include <QDateTime>
#include <QString>

namespace tdlas::system {

enum class SystemRole {
    Invalid,
    Administrator,
    Client
};

enum class ProtectedOperation {
    ViewMeasurements,
    StartMeasurement,
    StopMeasurement,
    ResetMeasurement,
    ModifyParameters,
    SaveExperiment,
    UseCamera,
    ConfigureStorage,
    ViewAuditLog,
    ManageAuthorization
};

struct SessionContext {
    QString sessionId;
    QString principalId;
    SystemRole role = SystemRole::Invalid;
    QDateTime issuedAtUtc;
    QDateTime expiresAtUtc;
    QString authenticationAuthority;

    [[nodiscard]] bool isValidAt(const QDateTime &nowUtc) const;
};

struct AuthorizationDecision {
    bool allowed = false;
    QString code;
    QString diagnostic;
};

class IAuthorizationService
{
public:
    virtual ~IAuthorizationService() = default;

    [[nodiscard]] virtual AuthorizationDecision authorize(
        const SessionContext &session,
        ProtectedOperation operation,
        const QDateTime &nowUtc = QDateTime::currentDateTimeUtc()) const = 0;
};

[[nodiscard]] QString protectedOperationName(ProtectedOperation operation);

} // namespace tdlas::system

