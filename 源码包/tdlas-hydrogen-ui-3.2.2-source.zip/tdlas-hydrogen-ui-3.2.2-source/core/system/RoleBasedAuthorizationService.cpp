#include "system/RoleBasedAuthorizationService.h"

namespace tdlas::system {

bool SessionContext::isValidAt(const QDateTime &nowUtc) const
{
    const QDateTime now = nowUtc.toUTC();
    return !sessionId.trimmed().isEmpty()
        && !principalId.trimmed().isEmpty()
        && role != SystemRole::Invalid
        && issuedAtUtc.isValid()
        && expiresAtUtc.isValid()
        && issuedAtUtc.toUTC() <= now
        && now < expiresAtUtc.toUTC()
        && !authenticationAuthority.trimmed().isEmpty();
}

AuthorizationDecision RoleBasedAuthorizationService::authorize(
    const SessionContext &session,
    ProtectedOperation operation,
    const QDateTime &nowUtc) const
{
    if (!session.isValidAt(nowUtc)) {
        return {false, QStringLiteral("SESSION_INVALID"),
            QStringLiteral("missing, expired, or otherwise invalid session")};
    }
    if (session.role == SystemRole::Administrator) {
        return {true, QStringLiteral("AUTHORIZED"), {}};
    }
    if (session.role == SystemRole::Client) {
        switch (operation) {
        case ProtectedOperation::ViewMeasurements:
        case ProtectedOperation::StartMeasurement:
        case ProtectedOperation::StopMeasurement:
        case ProtectedOperation::ResetMeasurement:
        case ProtectedOperation::ModifyParameters:
        case ProtectedOperation::SaveExperiment:
        case ProtectedOperation::UseCamera:
            return {true, QStringLiteral("AUTHORIZED"), {}};
        case ProtectedOperation::ConfigureStorage:
        case ProtectedOperation::ViewAuditLog:
        case ProtectedOperation::ManageAuthorization:
            break;
        }
    }
    return {false, QStringLiteral("OPERATION_FORBIDDEN"),
        QStringLiteral("role does not grant operation %1").arg(protectedOperationName(operation))};
}

QString protectedOperationName(ProtectedOperation operation)
{
    switch (operation) {
    case ProtectedOperation::ViewMeasurements:
        return QStringLiteral("view-measurements");
    case ProtectedOperation::StartMeasurement:
        return QStringLiteral("start-measurement");
    case ProtectedOperation::StopMeasurement:
        return QStringLiteral("stop-measurement");
    case ProtectedOperation::ResetMeasurement:
        return QStringLiteral("reset-measurement");
    case ProtectedOperation::ModifyParameters:
        return QStringLiteral("modify-parameters");
    case ProtectedOperation::SaveExperiment:
        return QStringLiteral("save-experiment");
    case ProtectedOperation::UseCamera:
        return QStringLiteral("use-camera");
    case ProtectedOperation::ConfigureStorage:
        return QStringLiteral("configure-storage");
    case ProtectedOperation::ViewAuditLog:
        return QStringLiteral("view-audit-log");
    case ProtectedOperation::ManageAuthorization:
        return QStringLiteral("manage-authorization");
    }
    return QStringLiteral("unknown");
}

} // namespace tdlas::system

