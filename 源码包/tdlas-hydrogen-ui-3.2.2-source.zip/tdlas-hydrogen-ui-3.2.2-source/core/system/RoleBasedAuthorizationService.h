#pragma once

#include "system/IAuthorizationService.h"

namespace tdlas::system {

class RoleBasedAuthorizationService final : public IAuthorizationService
{
public:
    [[nodiscard]] AuthorizationDecision authorize(
        const SessionContext &session,
        ProtectedOperation operation,
        const QDateTime &nowUtc = QDateTime::currentDateTimeUtc()) const override;
};

} // namespace tdlas::system

