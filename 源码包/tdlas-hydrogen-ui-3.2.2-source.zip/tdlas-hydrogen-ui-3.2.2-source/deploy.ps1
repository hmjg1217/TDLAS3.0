param(
    [string]$QtRoot = $env:QTDIR,
    [ValidateSet('Debug', 'Release', 'RelWithDebInfo', 'MinSizeRel')]
    [string]$Configuration = 'Release',
    [string]$BuildDirectory = 'build',
    [string]$PackageDirectory = 'dist',
    [string]$ReleaseVersion = '3.2.2',
    [switch]$IncludePreviewTargets,
    [switch]$SkipSmokeTest,
    [switch]$NoArchive
)

$ErrorActionPreference = 'Stop'

$projectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
. (Join-Path $PSScriptRoot 'tools\resolve-environment.ps1')
$toolchain = Resolve-TdlasEnvironment -QtRoot $QtRoot
$QtRoot = $toolchain.QtRoot
$versionMatch = [regex]::Match((Get-Content -LiteralPath (Join-Path $PSScriptRoot 'CMakeLists.txt') -Raw), 'project\([^\r\n]*VERSION\s+([0-9.]+)')
if (-not $versionMatch.Success -or $ReleaseVersion -ne $versionMatch.Groups[1].Value) {
    throw 'ReleaseVersion must match CMakeLists.txt.'
}

$buildPath = if ([System.IO.Path]::IsPathRooted($BuildDirectory)) {
    [System.IO.Path]::GetFullPath($BuildDirectory)
} else {
    [System.IO.Path]::GetFullPath((Join-Path $projectRoot $BuildDirectory))
}
$outputRoot = if ([System.IO.Path]::IsPathRooted($PackageDirectory)) {
    [System.IO.Path]::GetFullPath($PackageDirectory)
} else {
    [System.IO.Path]::GetFullPath((Join-Path $projectRoot $PackageDirectory))
}
$safeVersion = $ReleaseVersion -replace '[^0-9A-Za-z._-]', '-'
$packageName = "tdlas-hydrogen-ui-$safeVersion-win64"
$packagePath = [System.IO.Path]::GetFullPath((Join-Path $outputRoot $packageName))
$stagingPath = [System.IO.Path]::GetFullPath((Join-Path $outputRoot ".$packageName.staging-$PID"))
$archivePath = [System.IO.Path]::GetFullPath((Join-Path $outputRoot "$packageName.zip"))
$outputPrefix = $outputRoot.TrimEnd([System.IO.Path]::DirectorySeparatorChar) + [System.IO.Path]::DirectorySeparatorChar
if (-not $packagePath.StartsWith($outputPrefix, [System.StringComparison]::OrdinalIgnoreCase) -or
    -not $stagingPath.StartsWith($outputPrefix, [System.StringComparison]::OrdinalIgnoreCase) -or
    -not $archivePath.StartsWith($outputPrefix, [System.StringComparison]::OrdinalIgnoreCase)) {
    throw '部署输出路径未保持在指定 PackageDirectory 内。'
}

$deployTool = Join-Path $QtRoot 'bin\windeployqt.exe'
$vswhere = if (${env:ProgramFiles(x86)}) {
    Join-Path ${env:ProgramFiles(x86)} 'Microsoft Visual Studio\Installer\vswhere.exe'
} else {
    $null
}
if ((-not $env:VCINSTALLDIR -or -not (Test-Path -LiteralPath (Join-Path $env:VCINSTALLDIR 'Redist\MSVC'))) -and $vswhere -and (Test-Path -LiteralPath $vswhere)) {
    $visualStudioRoots = @(& $vswhere -latest -products '*' -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath)
    if ($LASTEXITCODE -eq 0 -and $visualStudioRoots.Count -gt 0) {
        $visualStudioRoot = $visualStudioRoots[0].Trim()
        $candidateVcRoot = Join-Path $visualStudioRoot 'VC'
        if (Test-Path -LiteralPath (Join-Path $candidateVcRoot 'Redist\MSVC')) {
            $env:VSINSTALLDIR = $visualStudioRoot + [System.IO.Path]::DirectorySeparatorChar
            $env:VCINSTALLDIR = $candidateVcRoot + [System.IO.Path]::DirectorySeparatorChar
        }
    }
}
$previewExecutableNames = @(
    'tdlas_startup_codex_template.exe',
    'tdlas_admin_codex_template.exe',
    'tdlas_client_codex_template.exe'
)
$executableNames = @('tdlas_hydrogen_ui.exe')
if ($IncludePreviewTargets) {
    $executableNames += $previewExecutableNames
}

if (-not (Test-Path -LiteralPath $deployTool)) {
    throw "未找到 windeployqt.exe：$deployTool"
}

$sourceExecutables = foreach ($name in $executableNames) {
    $path = Join-Path $buildPath "bin\$Configuration\$name"
    if (-not (Test-Path -LiteralPath $path)) {
        throw "未找到构建产物：$path。请先运行 build.ps1。"
    }
    $path
}

New-Item -ItemType Directory -Path $outputRoot -Force | Out-Null
$staleStagingDirectories = Get-ChildItem -LiteralPath $outputRoot -Force -Directory |
    Where-Object { $_.Name -like ".$packageName.staging-*" }
foreach ($staleStagingDirectory in $staleStagingDirectories) {
    $stalePath = [System.IO.Path]::GetFullPath($staleStagingDirectory.FullName)
    if (-not $stalePath.StartsWith($outputPrefix, [System.StringComparison]::OrdinalIgnoreCase)) {
        throw "拒绝清理输出目录之外的 staging：$stalePath"
    }
    Remove-Item -LiteralPath $stalePath -Recurse -Force
}
if (Test-Path -LiteralPath $stagingPath) {
    Remove-Item -LiteralPath $stagingPath -Recurse -Force
}
New-Item -ItemType Directory -Path $stagingPath -Force | Out-Null

try {
    $deployMode = if ($Configuration -eq 'Debug') { '--debug' } else { '--release' }
    foreach ($sourceExecutable in $sourceExecutables) {
        $deployedExecutable = Join-Path $stagingPath (Split-Path -Leaf $sourceExecutable)
        Copy-Item -LiteralPath $sourceExecutable -Destination $deployedExecutable -Force
        & $deployTool $deployMode --compiler-runtime --no-translations --dir $stagingPath $deployedExecutable
        if ($LASTEXITCODE -ne 0) {
            throw "Qt 运行库部署失败，退出码 $LASTEXITCODE"
        }
    }

    $runtimeNames = @('msvcp140.dll', 'vcruntime140.dll', 'vcruntime140_1.dll')
    $missingRuntime = $runtimeNames | Where-Object {
        -not (Test-Path -LiteralPath (Join-Path $stagingPath $_))
    }
    if ($missingRuntime) {
        $redistRoot = if ($env:VCINSTALLDIR) {
            Join-Path $env:VCINSTALLDIR 'Redist\MSVC'
        } else {
            'C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Redist\MSVC'
        }
        $versionDirectories = if (Test-Path -LiteralPath $redistRoot) {
            Get-ChildItem -LiteralPath $redistRoot -Directory |
                Where-Object { $_.Name -match '^\d+(\.\d+)+$' } |
                Sort-Object { [version]$_.Name } -Descending
        }
        $crtDirectory = $versionDirectories |
            ForEach-Object { Join-Path $_.FullName 'x64\Microsoft.VC143.CRT' } |
            Where-Object { Test-Path -LiteralPath $_ } |
            Select-Object -First 1

        if ($crtDirectory) {
            Get-ChildItem -LiteralPath $crtDirectory -Filter '*.dll' -File | ForEach-Object {
                Copy-Item -LiteralPath $_.FullName -Destination (Join-Path $stagingPath $_.Name) -Force
            }
        }
    }

    $requiredFiles = @($executableNames | ForEach-Object { Join-Path $stagingPath $_ })
    $requiredFiles += Join-Path $stagingPath 'platforms\qwindows.dll'
    $requiredFiles += $runtimeNames | ForEach-Object { Join-Path $stagingPath $_ }
    $missingFiles = $requiredFiles | Where-Object { -not (Test-Path -LiteralPath $_) }
    if ($missingFiles) {
        throw "部署目录缺少必要文件：$($missingFiles -join ', ')"
    }

    $documentationDirectory = Join-Path $stagingPath 'docs'
    New-Item -ItemType Directory -Path $documentationDirectory -Force | Out-Null
    Copy-Item -LiteralPath (Join-Path $projectRoot 'docs\DEPLOYMENT.md') -Destination $documentationDirectory
    $releaseNotes = Join-Path $projectRoot "docs\RELEASE_NOTES_V$ReleaseVersion.md"
    if (-not (Test-Path -LiteralPath $releaseNotes)) {
        throw "未找到当前版本发布说明：$releaseNotes"
    }
    Copy-Item -LiteralPath $releaseNotes -Destination $documentationDirectory
    Copy-Item -LiteralPath (Join-Path $projectRoot 'docs\PACKAGE_README.md') -Destination (Join-Path $documentationDirectory 'README.md')
    Copy-Item -LiteralPath (Join-Path $projectRoot 'docs\OPEN_QUESTIONS.md') -Destination $documentationDirectory
    Copy-Item -LiteralPath (Join-Path $projectRoot 'docs\CAMERA_MANUAL_REVIEW.md') -Destination $documentationDirectory
    Copy-Item -LiteralPath (Join-Path $projectRoot 'tools\camera-manual-review.cmd') -Destination (Join-Path $stagingPath '相机人工复验.cmd')
    Copy-Item -LiteralPath (Join-Path $projectRoot 'tools\verify-package.ps1') -Destination $stagingPath

    Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'run-portable.ps1') -Destination $stagingPath
    Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'portable-config') -Destination $stagingPath -Recurse
    Copy-Item -LiteralPath (Join-Path $PSScriptRoot '启动便携版.cmd') -Destination $stagingPath
    @('[Paths]', 'Plugins=.', 'Libraries=.') | Set-Content -LiteralPath (Join-Path $stagingPath 'qt.conf') -Encoding ascii

    if (-not $SkipSmokeTest) {
        $smokeRoot = Join-Path $stagingPath '.smoke-data'
        $smokeConfig = Join-Path $stagingPath '.smoke-config\storage.json'
        $smokeCapture = Join-Path $stagingPath '.smoke-login.png'
        $savedStorageRoot = $env:TDLAS_STORAGE_ROOT
        $savedStorageConfig = $env:TDLAS_STORAGE_CONFIG
        $savedParameterConfig = $env:TDLAS_PARAMETER_CONFIG
        $savedAcquisitionBackend = $env:TDLAS_ACQUISITION_BACKEND
        $savedPath = $env:PATH
        $savedPluginPath = $env:QT_PLUGIN_PATH
        $savedPlatformPluginPath = $env:QT_QPA_PLATFORM_PLUGIN_PATH
        $savedCameraBackend = $env:TDLAS_CAMERA_BACKEND
        $savedCameraDevice = $env:TDLAS_CAMERA_DEVICE_ID
        $savedPlatform = $env:QT_QPA_PLATFORM
        try {
            $env:TDLAS_STORAGE_ROOT = $smokeRoot
            $env:TDLAS_STORAGE_CONFIG = $smokeConfig
            $env:TDLAS_PARAMETER_CONFIG = Join-Path $stagingPath '.smoke-config\parameters.ini'
            $env:TDLAS_ACQUISITION_BACKEND = 'mock'
            $env:PATH = "$env:SystemRoot\System32;$env:SystemRoot"
            Remove-Item Env:QT_PLUGIN_PATH -ErrorAction SilentlyContinue
            Remove-Item Env:QT_QPA_PLATFORM_PLUGIN_PATH -ErrorAction SilentlyContinue
            $env:TDLAS_CAMERA_BACKEND = 'mock'
            Remove-Item Env:TDLAS_CAMERA_DEVICE_ID -ErrorAction SilentlyContinue
            # Validate the same platform plugin that the Windows package ships.
            $env:QT_QPA_PLATFORM = 'windows'
            $smokeProcess = Start-Process `
                -FilePath (Join-Path $stagingPath 'tdlas_hydrogen_ui.exe') `
                -ArgumentList @('--capture', ('"' + $smokeCapture + '"')) `
                -WindowStyle Hidden `
                -PassThru
            if (-not $smokeProcess.WaitForExit(30000)) {
                $smokeProcess.Kill()
                throw 'Portable package startup timed out after 30 seconds.'
            }
            if ($smokeProcess.ExitCode -ne 0 -or -not (Test-Path -LiteralPath $smokeCapture) -or
                (Get-Item -LiteralPath $smokeCapture).Length -le 0) {
                throw "部署包离屏启动冒烟失败，退出码 $($smokeProcess.ExitCode)"
            }
        } finally {
            $env:TDLAS_STORAGE_ROOT = $savedStorageRoot
            $env:TDLAS_STORAGE_CONFIG = $savedStorageConfig
            $env:TDLAS_PARAMETER_CONFIG = $savedParameterConfig
            $env:TDLAS_ACQUISITION_BACKEND = $savedAcquisitionBackend
            $env:PATH = $savedPath
            $env:QT_PLUGIN_PATH = $savedPluginPath
            $env:QT_QPA_PLATFORM_PLUGIN_PATH = $savedPlatformPluginPath
            $env:TDLAS_CAMERA_BACKEND = $savedCameraBackend
            $env:TDLAS_CAMERA_DEVICE_ID = $savedCameraDevice
            $env:QT_QPA_PLATFORM = $savedPlatform
        }
        foreach ($smokeArtifact in @($smokeCapture, $smokeRoot, (Join-Path $stagingPath '.smoke-config'))) {
            if (Test-Path -LiteralPath $smokeArtifact) {
                Remove-Item -LiteralPath $smokeArtifact -Recurse -Force
            }
        }
    }

    $gitRevision = (& git -C $projectRoot rev-parse HEAD 2>$null)
    if ($LASTEXITCODE -ne 0) {
        $gitRevision = 'unavailable'
        # A source ZIP has no Git metadata; this is a successful deployment path.
        $global:LASTEXITCODE = 0
    }
    $payloadFiles = Get-ChildItem -LiteralPath $stagingPath -Recurse -File | Sort-Object FullName
    $manifestFiles = foreach ($file in $payloadFiles) {
        $relativePath = [System.IO.Path]::GetRelativePath($stagingPath, $file.FullName).Replace('\', '/')
        [ordered]@{
            path = $relativePath
            sizeBytes = $file.Length
            sha256 = (Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
        }
    }
    $manifest = [ordered]@{
        schemaVersion = '1.0'
        product = 'TDLAS Hydrogen UI Suite'
        version = $ReleaseVersion
        configuration = $Configuration
        architecture = 'win64'
        gitRevision = [string]$gitRevision
        generatedAtUtc = [DateTime]::UtcNow.ToString('o')
        hardwareBackendsEnabledByDefault = $true
        hardwareValidated = $false
        executable = 'tdlas_hydrogen_ui.exe'
        files = @($manifestFiles)
    }
    $manifestPath = Join-Path $stagingPath 'release-manifest.json'
    $manifest | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $manifestPath -Encoding utf8

    $checksumFiles = Get-ChildItem -LiteralPath $stagingPath -Recurse -File | Sort-Object FullName
    $checksumLines = foreach ($file in $checksumFiles) {
        $relativePath = [System.IO.Path]::GetRelativePath($stagingPath, $file.FullName).Replace('\', '/')
        $hash = (Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
        "$hash  $relativePath"
    }
    $checksumLines | Set-Content -LiteralPath (Join-Path $stagingPath 'SHA256SUMS.txt') -Encoding utf8

    if (Test-Path -LiteralPath $packagePath) {
        Remove-Item -LiteralPath $packagePath -Recurse -Force
    }
    Move-Item -LiteralPath $stagingPath -Destination $packagePath

    if (-not $NoArchive) {
        if (Test-Path -LiteralPath $archivePath) {
            Remove-Item -LiteralPath $archivePath -Force
        }
        Compress-Archive -Path (Join-Path $packagePath '*') -DestinationPath $archivePath -CompressionLevel Optimal
    }
} finally {
    if (Test-Path -LiteralPath $stagingPath) {
        Remove-Item -LiteralPath $stagingPath -Recurse -Force
    }
}

Write-Host "可运行部署目录：$packagePath"
if (-not $NoArchive) {
    Write-Host "发布压缩包：$archivePath"
}

