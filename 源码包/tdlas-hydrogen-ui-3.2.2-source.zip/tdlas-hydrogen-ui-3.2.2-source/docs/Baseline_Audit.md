# TDLAS Hydrogen UI Suite 基线与现状审计

## 1. 审计结论

- 审计日期：2026-11-04（Asia/Shanghai）。
- 范围：`TDLAS-Hydrogen-UI-Suite`、用户指定的 `dist/tdlas_hydrogen_ui.exe`、当前 Git 根目录及直接引用的项目资料。
- 结论：Qt Widgets UI 工程可全量构建，现有 2 项 CTest 全部通过，13 个标准页面/状态均可生成非空截图；用户指定的部署 EXE 可独立生成登录截图。
- 当前实质能力：已批准 UI、静态模拟图表/摄像画布、开发用临时账号路由、预览与截图入口。
- 当前不存在：参数服务、采集服务、算法库、真实/模拟采集适配器、摄像服务、存储服务、正式认证/授权、完整退出登录与运行生命周期。
- 本轮只修改文档、Git 基线和版本化截图，不修改 `.cpp`、`.h`、QSS、QRC、CMake 或脚本中的业务行为。

证据标记：`CONFIRMED` 为代码/命令/运行观察确认，`PROPOSED` 为后续设计，`TBD` 为待用户或实测关闭。

## 2. Git 与工程边界

| 项目 | 结果 | 证据 |
|---|---|---|
| Git 根目录 | `C:/Users/91463/Documents/ChatGPT/N.UI`，比 Suite 高一级 | `git rev-parse --show-toplevel`，CONFIRMED |
| 初始状态 | `master`、无提交，Suite 与上级技术资料均未跟踪 | `git status` / `git log`，CONFIRMED |
| 本轮基线 | 初始提交后创建提交与标签 `ui-baseline` | 本轮 Git 操作；最终状态以标签为准 |
| 忽略产物 | `build/`、`dist/`、临时 `artifacts/captures/` | `.gitignore`，CONFIRMED |
| 版本化 UI 证据 | `docs/ui/baseline/2026-11-04/` 13 张运行截图 | 本轮实际捕获，CONFIRMED |

现有 Git 根包含项目外的算法、技术参数、模块规范和摄像头 PDF；它们与工程规则互相引用，故本轮作为同一初始基线保留。是否把 Suite 拆成独立仓库列入 `OQ-GIT-001`。

## 3. 构建目标与页面清单

| Target | 定位 | 页面/状态 | 现状 |
|---|---|---|---|
| `tdlas_hydrogen_ui` | 唯一正式应用 | login → admin/client | 临时凭据路由可用 |
| `tdlas_startup_codex_template` | 开发预览 | splash、login | 可截图 |
| `tdlas_admin_codex_template` | 开发预览 | main、parameters、debug、peak、camera、camera-motion | 静态模拟 UI，可截图 |
| `tdlas_client_codex_template` | 开发预览 | main、parameters、camera、camera-motion | 静态模拟 UI，可截图 |
| `tdlas_authentication_test` | 单元级可执行测试 | 2 组有效凭据与无效输入 | CTest PASS |
| `tdlas_login_routing_test` | offscreen GUI 路由测试 | 错误、管理员、客户 | CTest PASS |

工程约束由根 `CMakeLists.txt` 确认：CMake 3.21+、C++17、Qt 5/6 Widgets；本机实际使用 CMake 3.30.5、Qt 6.8.3、Visual Studio 2022 x64、Windows SDK 10.0.26100.0、Git 2.53.0.windows.3。

## 4. 代码现状与耦合点

| 范围 | 已观察事实 | 风险/后续边界 |
|---|---|---|
| 应用路由 | `IntegratedApplicationController` 直接创建登录和角色窗口并切换应用级 QSS | 适合作为当前 shell；后续认证、会话和测量编排应进入应用服务 |
| 认证 | `TemporaryCredentialAuthenticator` 固定 `00/00` 与 `01/01` | 仅开发路由；没有账号存储、授权、会话失效或审计 |
| Admin UI | 单个窗口文件构造页面；部分按钮发出以显示文本为载荷的 `actionRequested(QString)` | 文本不是稳定业务命令；需要 typed intent/adapter，且不能破坏既有布局 |
| Client UI | 按钮主要连接到本地 lambda，只显示“未接入”提示 | 尚无向外的业务合同，是第一个纵向闭环的明确接入点 |
| 图表 | `ChartWidget` 在 `paintEvent` 中生成固定数学曲线并标记 `SIM` | 不是算法输出；未来只替换数据源，不重做图表页面 |
| 摄像画面 | `CameraPreviewWidget` 绘制模拟管道/激光画面 | 未枚举或打开任何摄像头 |
| 参数 | 参数控件由窗口即时创建，无参数模型、校验快照或持久化 | 需要参数服务，范围和默认值先确认 |
| 线程 | 当前没有采集、算法、摄像或存储工作线程 | 后续 I/O/算法必须脱离 UI 线程并有有界缓存 |
| 数据/存储 | UI 明确提示未写磁盘；仓库中无 CSV、数据库或记录存储实现 | 保存合同、格式、路径和追溯字段均待确认 |
| 算法/硬件 | Suite 中没有算法与 NI-DAQmx 实现 | 上级历史说明仅可作为设计参考，不能当作当前代码存在的证据 |

## 5. 实际验证记录

| ID | 命令/操作 | 结果 |
|---|---|---|
| VER-BASE-001 | `.\build.ps1 -QtRoot 'C:\Qt\6.8.3\msvc2022_64' -Target all` | PASS；4 个应用、2 个测试及 integrated core 生成 |
| VER-BASE-002 | `ctest --test-dir .\build -C Release --output-on-failure` | PASS；2/2；初次 0.35 s，提交前复验 0.38 s |
| VER-BASE-003 | `.\tools\capture-all.ps1 ... -OutputDirectory 'docs\ui\baseline\2026-11-04'` | PASS；13/13，exit 0，PNG 非空 |
| VER-BASE-004 | `dist\tdlas_hydrogen_ui.exe --capture <path>` | PASS；exit 0，1880×1055 登录截图 |
| VER-BASE-005 | SHA-256 比较 `build` 与 `dist` 主程序 | PASS；均为 `80D1FA61A8C8B5E01DCCC609B465B18F87572F9D06E9A211275AB296E4B2823F` |
| VER-BASE-006 | 目视检查 13 状态及既有联系表 | 结构级 PASS；未见缺页、主要裁切或模拟/未校准标记丢失 |

构建唯一提示是可选 Vulkan headers 未找到；该工程只链接 Qt Widgets，本轮未使用 Vulkan。未运行真实设备、真实摄像头、算法数值等价、数据落盘、长时间稳定性或目标生产环境测试。

## 6. 部署 EXE 审计

| 字段 | 值 |
|---|---|
| 路径 | `dist/tdlas_hydrogen_ui.exe` |
| 大小 | 5,270,528 bytes |
| 文件时间 | 2026-11-02 15:35:37 +08:00 |
| SHA-256 | `80D1FA61A8C8B5E01DCCC609B465B18F87572F9D06E9A211275AB296E4B2823F` |
| File/Product version resource | 未设置 |
| 与本轮 build 主程序 | 字节级相同 |
| app-local 截图 | 成功 |

同一 EXE 在 build 截图脚本环境与 app-local dist 环境中生成的登录图肉眼结构一致，但存在 1,657 / 1,983,400 像素（0.083543%）差异，包围框位于表单区域；Qt 核心 DLL 与 `qwindows.dll` 的 SDK/dist 哈希相同。根因尚未证明，可能与前台/焦点/样式状态有关，因此只登记为截图确定性问题，不作为 UI 功能失败。见 `UI-DIFF-008`。

## 7. 基线截图矩阵

| 角色 | 状态数 | 像素尺寸 | 证据 |
|---|---:|---|---|
| integrated | 1 | 1880×1055 | `docs/ui/baseline/2026-11-04/integrated-login.png` |
| startup | 2 | login 1880×1055；splash 1875×938 | 同目录 |
| admin | 6 | 1880×1055 | 同目录 |
| client | 4 | 1880×1055 | 同目录 |

完整 SHA-256 与捕获限制见 `docs/ui/baseline/2026-11-04/README.md`。这些是本机运行候选，不是原始生成参考图，也不证明真实 DPR、目标字体或生产显示器上的像素级一致性。

## 8. 审计判定

- 阶段 0（UI/Git 基线）：在本轮提交和标签创建后完成；构建、测试、版本化截图和保护规则具备。
- 阶段 1（架构准备）：文档草案已完成，仍需用户确认接口取舍与 P0 待确认项。
- 业务实现：未开始，符合本轮“不写业务代码”的范围。
- 下一安全步骤：确认 `docs/OPEN_QUESTIONS.md` 中阻塞阶段 2/3 的项目，再按 `docs/Module_Development_Plan.md` 建立最小合同与模拟采集纵向闭环。
