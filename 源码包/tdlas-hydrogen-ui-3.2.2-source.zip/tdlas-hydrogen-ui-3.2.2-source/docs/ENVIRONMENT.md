# V3.2.2 环境配置

## 运行电脑

Windows 10/11 x64；将 `发布包/tdlas-hydrogen-ui-3.2.2-win64` 整体解压至可写目录。已附带 Qt 6.8.3 Core/Gui/Widgets/Multimedia/Network/Svg、Windows 平台插件、图像/媒体插件、FFmpeg DLL、MSVC x64 运行库和 `qt.conf`。无需 Qt SDK、CMake、Visual Studio 或 Python。

默认启动 `启动便携版.cmd`，模拟演示使用 `启动便携版.cmd --mock`。直接双击 EXE 也会读取便携配置。设置和数据首次使用时创建于 `config/` 和 `data/`；复制文件夹后，便携环境从新 EXE 所在目录解析相对路径。用户指定的绝对路径与 `TDLAS_*` 环境变量优先。

配置文件为 `portable-config/runtime.ini`，提供 `dataDirectory`、`configurationDirectory`、`acquisition=auto|mock|nidaqmx` 和 `camera=system|mock`。`auto` 在有真实 NI 时优先使用 NI；模拟结果带有模拟标记。

NI-DAQmx 为系统驱动，需要现场为设备安装；便携包不安装或模拟此驱动。系统/UVC 摄像驱动由 Windows/设备厂商提供。摄像头仍须在 UI 中选择后连接。

## 源码开发电脑

- Visual Studio 2022 或 Build Tools：C++ 桌面开发、MSVC v143 x64 和 Windows SDK。
- Qt 6.8.3 `msvc2022_64`，包含 Qt Multimedia。
- CMake 3.21+；本版实测 3.30.5。
- PowerShell 7 用于部署与源码打包脚本。最终运行的 CMD/EXE 不依赖 PowerShell 7。

`tools/resolve-environment.ps1` 自动查找 `C:/Qt` 版本目录、PATH 与 Visual Studio Installer；非默认安装位置通过 `build.ps1 -QtRoot` 或 `QTDIR` 指定。开发工具链需要在新电脑安装，不把当前机器的 SDK/编译器缓存当作可移植运行库。

在正式源码目录执行 `./build.ps1 -RunTests`；新目录会重新生成 CMake 配置。用 `./deploy.ps1 -PackageDirectory ../../发布包` 生成运行包；用 `./tools/package-source.ps1` 生成干净源码包。

## 环境覆盖

`TDLAS_STORAGE_ROOT` 指定实验/审计目录；`TDLAS_STORAGE_CONFIG` 和 `TDLAS_PARAMETER_CONFIG` 分别指定存储 JSON 与参数 INI；`TDLAS_ACQUISITION_BACKEND`、`TDLAS_CAMERA_BACKEND` 指定后端；`TDLAS_CAMERA_DEVICE_ID` 可指定摄像设备。未设置环境变量时读取包内便携配置；环境变量无需写入系统或注册表。

