# TDLAS 公共接口定义

## 1. 状态与适用范围

- 版本：1.7（增加完整单周期原始数据及拟合图电压偏置信息），2026-11-09。
- M7 已在 `core/camera` 完成摄像端口、独立 worker、确定性 mock、Qt Multimedia/UVC adapter、照片/MJPEG 保存和实验媒体索引；正式组合现默认枚举 Qt Multimedia 摄像头但不自动打开未明确选择的设备。真实摄像头、NI 设备、浓度标定、生产身份提供方和长期存储运维仍不在实机验证范围。
- `IMPLEMENTED` 表示已由源码和自动化测试验证；`PROPOSED` 表示后续模块合同；`TBD-*` 对应尚未获得的设备、算法或产品依据。
- 所有数值必须同时携带单位/版本/有效性语义；`0` 不自动代表有效值。

## 2. 通用类型

| 类型 | 字段/取值 | 规则 |
|---|---|---|
| `RunId` | 无花括号、小写 UUID 字符串 | 一次开始到最终停止/故障清理的唯一关联键；每次成功开始生成新值 |
| `ExperimentId` | `EXP-yyyyMMddTHHmmsszzzZ-xxxxxxxx` | UTC 时间 + 8 位随机十六进制；一次实验目录、参数、原始数据、结果和日志的稳定关联键；既有目录禁止覆盖 |
| `Sequence` | `uint64` | 同一 run/stream 从 1 开始严格递增；新 run 重新从 1 开始 |
| `Timestamp` | UTC 时间 + 可选单调时钟纳秒偏移 | UTC 用于展示/追溯；单调时钟用于同进程内采集顺序 |
| `DataValidity` | `Valid / Invalid / Incomplete / Stale / Uncalibrated` | 无效值必须带诊断；不得用哨兵数字代替 |
| `ModuleError` | code、category、severity、userMessage、diagnostic、timestamp、retryable、requiresStop、runId?、sequence? | 用户文案与技术详情分离；厂商错误码放 diagnostic |
| `ContractVersion` | major/minor | 不兼容字段或语义变更升级 major；文档、调用方和测试同批更新 |

公共合同版本为 `1.7`，保留既有字段。1.5 增加裁剪曲线 `timeSeconds`，1.6 增加追溯完整的 `PeakRecord` 序列；1.7 在 `ProcessingResult` 增加 `cycleTimeSeconds`、`cycleVoltageV`、`displayVoltageOffsetV`，与处理结果 JSON 一同保存。`algorithmVersion=tdlas-v1.8-20-cycle-average-cpp` 时完整周期电压为连续 20 个周期相位对齐后的 AI 电压均值；旧 single-cycle 版本仍表示单周期来源。既有处理电压数组保留算法 4.2 V 偏置，UI 叠加时扣除 `displayVoltageOffsetV`。趋势绘制消费记录有效性以断线，峰值从有效/未标定拟合吸光度有限值中取最大值，空曲线保留 null 和原因；记录以 runId + sourceSequence 幂等排序。测量核心只依赖 Qt Core；摄像通过值语义 QImage 和独立 camera target 依赖 Qt Gui/Multimedia，不依赖 Qt Widgets。

## 3. 参数合同

### 3.1 `ParameterDraft` / `ParameterSnapshot`（M3 IMPLEMENTED）

| 字段 | 类型/单位 | 状态与规则 |
|---|---|---|
| deviceId | string | 运行时枚举值；禁止硬编码现场设备名 |
| aiChannelIds | list<string> | 多通道组织见 OQ-ACQ-002 |
| sampleRateHz | double / Hz | `> 0`；设备实际范围 TBD |
| readSamplesPerBlock | positive integer / samples | 与延迟、缓存和算法窗口协调，TBD |
| inputRangeMinV / inputRangeMaxV | double / V | min < max；设备能力内，实际范围 TBD |
| aoEnabled / aoChannelId | bool / string | AO 与 AI 是不同职责；关闭时不创建 AO task |
| waveform | Sine / Square / Sawtooth / Triangle | 来自现有资料，CONFIRMED |
| outputFrequencyHz | double / Hz | `> 0`，设备限制 TBD |
| outputAmplitudePeakV | double / V peak | 按峰值解释；与 offset 合成后保持在软件 `[-10,+10] V` 边界 |
| outputOffsetV | double / V | 同上 |
| outputSampleRateHz | double / Hz | 至少为输出频率 10 倍；设备更严格限制优先 |
| algorithmParameterSetId | string/version | 固定偏置、平均窗口、标定和拟合配置可追溯 |
| revision / createdAt / hash | version metadata | snapshot 创建后不可变；存储与结果引用同一版本 |

`IParameterService` 接收 draft，返回字段化 validation errors 或新的 `ParameterSnapshot`，并可读取当前 snapshot；不得直接调用设备。M3 的 `ParameterService` 校验必填项、AI 通道非空/唯一、有限正采样率、正块长、量程顺序、算法参数集、AO 通道/频率/非负峰值/10 倍输出采样率和 `[-10,+10] V` 软件边界。失败提交不改变当前快照。

成功快照包含递增 revision、UTC `createdAt`、SHA-256 和唯一 ID；后续 draft 修改或提交不会改变此前返回的快照值。`ParameterService` 的当前快照保存在进程内，已校验 draft 同时写入 `measurement-parameters.ini` schema 1 并可跨启动恢复；每次实验开始时，不可变 `ParameterSnapshot` 写入实验目录。设备能力范围校验和配置跨版本迁移仍是 TBD。未发现 NI 真机时可显式回退 `mock-acquisition-0`、`sim/ai0`、5120 Hz、每块 256 点；这些不是现场硬件默认值。

## 4. 采集合同

### 4.1 状态

- `DeviceConnectionState`: `Disconnected / Connecting / Connected / Disconnecting / Faulted`。
- `AcquisitionState`: `Idle / Configuring / Running / Stopping / Faulted`。
- 两类状态分开维护；状态转换由 acquisition service 单一发布，UI 不自行推断。

### 4.2 `RawDataBlock`（M2 IMPLEMENTED）

| 字段 | 类型/单位 | 规则 |
|---|---|---|
| runId / streamId / sequence | IDs | 必填；sequence 从 1 开始，用于顺序、丢块和迟到数据判断 |
| sampleStartTimestamp | UTC + monotonic context | 首样本时间，时钟来源 TBD |
| sampleRateHz | double / Hz | 与实际设备配置一致 |
| channels | list of `{channelId, samplesV[]}` | channel-major；每个同步通道一个电压数组，所有数组长度等于 `sampleCountPerChannel` |
| sampleCountPerChannel | integer | 所有同步通道一致，否则 Invalid |
| overrun / droppedBefore | flags/count | 不得静默丢块 |
| validity / diagnostic | common | NaN/Inf、长度不符、超范围等明确无效 |

### 4.3 `IAcquisitionDevice`（M2 IMPLEMENTED port）

- 查询/枚举能力：设备、AI/AO 通道、范围和支持能力；返回稳定 ID 与展示名。
- `connect(deviceId)`、`disconnect()`、`configure(snapshot)`、`start(runId)`、`stop()`；操作异步或在 worker 调用，不阻塞 UI。
- 事件：connection state、acquisition state、`RawDataBlock`、`ModuleError`。
- `stop()` 和 `disconnect()` 在合理范围内幂等；返回/事件需区分“请求已接受”和“资源已释放”。
- `MockAcquisitionDevice` 与真实 NI-DAQmx adapter 使用同一端口；真实 adapter 的阻塞 API、task handle 和清理只存在于基础设施层。

M3 状态：`IAcquisitionDevice` 与 `MockAcquisitionDevice` 已实现。mock 默认每 30 ms 生成一块确定性单通道数据，先进入默认 8 块的 `RawDataBuffer` 再交付；缓存满时丢弃最旧块，并把 `overrun/droppedBefore/diagnostic` 标记到下一块实际交付数据。容量 8 和 drop-oldest 只属于 mock/测试策略。

`MockAcquisitionOptions` 可在测试中配置周期、缓存容量和第 N 块后的确定性故障；正式组合根使用默认关闭的故障注入。故障发布 acquisition `Faulted` 与 `ModuleError`，应用层停止、清空并断开；`resetFault()` 后可回到 `Idle`。`stop()`/`disconnect()` 幂等清理；`MockAcquisitionDevice` 本身不加载、调用或探测 NI-DAQmx。

M6 adapter 状态：`NidaqmxAcquisitionDevice` 继续实现同一 `IAcquisitionDevice`，通过 `DynamicNidaqmxDriver` 在运行时加载 Windows `nicaiu.dll`，不要求构建机链接 NI import library。连接使用运行时 `deviceId` 查询产品类型；配置按 snapshot 创建 AI 电压通道和连续采样时钟，可选创建单 AO 电压通道、生成一个周期的波形并以连续模式输出。adapter 通过 `DAQmxGetSampClkRate` 读取设备实际 AI 采样率，并把它写入 `RawDataBlock.sampleRateHz` 和推算时间轴。为避免静默改变输出频率，当前 AO 要求 `outputSampleRateHz / outputFrequencyHz` 为整数且周期点数不超过 adapter 上限；驱动实际 AO 采样率换算后的频率也必须与请求值一致，否则配置失败。AI 读取采用 `DAQmxGetReadAvailSampPerChan` 后的零等待 channel-major `DAQmxReadAnalogF64`，不会用阻塞读等待占住调用线程；块序号从 1 递增，首样本时间按运行起点与实际采样率推算并在 diagnostic 中明确标注，不冒充硬件时间戳。

adapter 的默认驱动缓存为 8 块、轮询间隔 2 ms、完整块看门狗 2000 ms、单次轮询最多交付 8 块。超时发布 `NIDAQMX_READ_TIMEOUT`；运行中驱动查询/读取错误发布稳定 acquisition error、进入 `Faulted`、停止并清除 AI/AO task，断线同时把 connection state 置为 `Faulted`。`stop()`、`disconnect()` 与析构都尝试停止并 `DAQmxClearTask`，配置或启动中途失败也清理已创建资源。上述默认值、默认 AI terminal configuration、AO 软件启动顺序和推算时间戳均是待目标设备确认的 adapter 默认，不是现场批准配置。

`INidaqmxDriver` 只位于 acquisition 基础设施内部，用于隔离厂商 ABI 和注入确定性测试替身，不是新的上层业务端口。`NidaqmxDeviceDiscovery` 运行时查询系统设备名、产品类型和 AI/AO 物理通道；`HybridAcquisitionDevice` 按所选 ID 路由真实 NI 或 mock adapter。`MeasurementApplicationService` 根据当前设备把 display/storage source 标为 `RealDevice` 或 `Simulation`。设备刷新在专用短时线程执行，UI 线程不调用 NI 枚举。真实设备行为仍未实测。

## 5. 算法合同

### 5.1 `AlgorithmParameterSet`（M4 IMPLEMENTED named configs）

`TdlasAlgorithmConfig` 包含版本、samples-per-cycle、周期/光谱平均数、滤波、基线区间、4.2 V 偏置、频率多项式/比例和频率标定版本。命名配置如下：

- `tdlas-v1.6-reference`：500 点/周期 × 10 周期/spectrum × 20 spectra，窗口 100000 点；对应参考 MATLAB 文本的 `Sample=100000`、`single_fre=200`、`n=20`。
- `tdlas-v1.6-ui`：保留参数集 ID，算法版本为 `tdlas-v1.8-20-cycle-average-cpp`。由相邻同方向锯齿回落/回升边界提取连续 20 个完整周期，以不重叠组进行相位对齐、电压逐点平均，再对平均波形执行一次滤波、基线、吸光度和 Voigt 拟合。周期点数变化时线性重采样到组内首周期的相位网格；时间跨度为该组的平均周期时长，裁剪段与平均波形使用相同时间步长。不把 read block 当周期、不旋转到最高点。AO 启用时用实际 AI 采样率 / 输出频率校验周期长度（±20%），支持反向接线及跨块周期。不足 20 周期返回 Incomplete，保留上一组完整显示；序号缺口、overrun、droppedBefore、run/snapshot 或采样率变化清空未完成组。缓冲有上限；每个输入块至多输出一份结果，块内含多组时发布最后一组完整的 20 周期平均拟合，保留尾部未完成组。完整原始采集块仍逐块存储。

平均波形的 Voigt 拟合以观测峰位置和半高宽初始化中心/线宽，每组中心/线宽候选使用解析有界最小二乘求幅值；保留原公式和参数边界。参考配置和历史金标仍使用原优化路径。模拟 UI 数据为连续锯齿斜坡、吸收凹陷、逐周期变化的吸收深度及确定性传感噪声，默认 20 Hz，独立于读块大小；所有此类输出仍显式标为 SIM。

固定频率映射版本为 `relative-frequency-20260901`。它输出相对频率 cm⁻¹，但尚无标准样气证据证明其适用于目标硬件；不得把该版本解释为浓度标定。

### 5.2 `ProcessingResult`（M4 IMPLEMENTED）

| 字段 | 单位/语义 | 状态 |
|---|---|---|
| runId / sourceSequence / timestamp | 追溯 | 必填 |
| parameterSnapshotId / algorithmVersion / calibrationVersion | 版本 | 当前 calibrationVersion 仅标识相对频率映射，不代表浓度标定 |
| relativeFrequencyCm1[] | cm⁻¹ | 固定三次多项式映射并以吸光度最大点置零 |
| timeSeconds[] | s | 平均周期的裁剪曲线位置 `(cropStart + i) × 平均周期时长 / 相位网格点数`；不拉伸裁剪段 |
| cycleTimeSeconds[] / cycleVoltageV[] | s / V | 本次拟合来源的 20 周期平均波形及平均回落/回升端点；算法处理端点前的平均周期，原始块单独保存 |
| displayVoltageOffsetV | V | 叠加平均电压时从拟合电压中扣除；UI 配置为 4.2，旧结果默认为 0 |
| voltageV[] / baselineV[] / fittedVoltageV[] | V | 曲线长度关系明确 |
| absorbance[] / fittedAbsorbance[] | dimensionless | 非有限值使结果 Invalid |
| peakAbsorbance | dimensionless optional | 只在 valid 时有值 |
| lightPercent | % optional | 当前只是估计值，公式/适用性需确认 |
| Voigt center / amplitude / Gaussian FWHM / Lorentzian FWHM / residual | center/FWHM cm⁻¹，其余按模型 | 优化器、边界、容差和版本必填 |
| concentration | optional value + unit | 在 OQ-ALG-001 关闭前为空且 `Uncalibrated` |
| validity / diagnostic | common | 不用 0 填补失败结果 |

`IAlgorithmProcessor`：对固定输入执行确定性处理，或由 application worker 异步调用；不得依赖 Widgets、设备 SDK、摄像头或存储路径。`TdlasAlgorithmProcessor` 在算法适配器中按 run/snapshot/sequence 组窗；丢块或序号不连续会清空未完成窗口。

M4 状态：`TdlasAlgorithmProcessor` 实现四阶 Butterworth 等效 biquad 前向/反向滤波、周期/光谱平均、峰值旋转对齐、30%～90% 截取、首 35%/末 40% 四阶基线、`ln(baseline/voltage)`、相对频率映射、四参数 Voigt 有界坐标搜索、FV/拟合电压和峰值。Voigt 初值为 `[0, 0.004, 0.05, 0.05]`，边界为 `[-0.5,0.5]`、`[0,0.2]`、`[0.001,0.5]`、`[0.001,0.5]`。滤波边界状态和优化器不同于 MATLAB `filtfilt/lsqcurvefit`，没有外部参考输出时不声明逐点等价。

浓度公式、单位、标定版本、有效范围和标准样气参考结果仍全部缺失；因此光谱成功时 `concentration` 仍为空，整体 validity 为 `Uncalibrated`。这是安全合同，不是浓度实现完成。

## 6. 应用与展示合同

### 6.1 `IMeasurementApplicationService`

- 命令：`start(StartMeasurementRequest)`、`stop(runId)`、`resetFault()`、查询当前状态。
- 追溯：`StartMeasurementRequest` 可携带合法 experiment ID；为空时由应用生成；`currentExperimentId()` 返回本次/最近一次实验 ID。
- 状态：`Idle / Preparing / Running / Stopping / Faulted`。
- 责任：权限检查、参数 snapshot、设备/算法/存储编排、run ID、取消与清理、迟到数据过滤。
- 不负责：绘图、厂商调用、算法公式。

M5 状态：接口与 `MeasurementApplicationService` 已实现。状态机为 `Idle → Preparing → Running → Stopping → Idle`，活动态可进入 `Faulted`；仅接收当前 run 且 sequence 严格递增的数据。每个接受块分别通过 queued connection 进入算法 worker 和存储 worker；正常停止以 blocking flush 结束实验清单，确保此前排队写入先完成。写入失败转换为 storage `ModuleError`、进入 `Faulted`、停止并断开采集。展示默认每 33 ms 合并为最新帧；停止后保留最后一帧且不接受迟到结果。

### 6.2 `MeasurementDisplayModel`

包含运行/连接状态、模拟/真实来源标识、experiment ID、`ExperimentStorageState(NotStarted/Saving/Saved/Failed)`、曲线窗口、峰值/光强/浓度可选值、可追溯 `PeakRecord[]`、有效性、用户提示和最后更新时间。峰值记录按 `(runId, sourceSequence)` 唯一，保留采集 UTC 时间、elapsed、值/位置及单位、质量/原因、experiment/run、模拟来源、设备、参数 snapshot、算法与标定版本；序列按 run 后 sequence 排序并可跨显示刷新/测量 run 查询，最多保留最近 60000 条。

`ChartSeriesData{x[], y[], xUnit, yUnit, validity}` 的 x/y 长度必须一致且数值有限。实时原始波形按采样块直接发布，时间轴为 `sampleIndex / sampleRateHz` 秒；处理后的电压曲线与拟合电压共享时间轴；FV 图使用相对频率（cm⁻¹）和吸光度；峰值趋势时间坐标以 epoch 秒保存，按操作系统本地时间及时区显示。正式峰值趋势由 PeakRecord 源序列绘制：质量有效且数值有限的样点按连续 run 连线，空值/无效记录断线，不跨 run 连线。显示刷新默认 33 ms，算法仍在独立 worker 上执行。

管理员峰值页支持当前 run/单 run/全部 run 与 1/10/30/60 分钟/自定义本地时间过滤，表格与趋势使用同一记录集合；明细可折叠、排序，并可导出完整筛选来源记录。图上两点框选 X 或 Y 区间、滚轮切换选择轴，右键复位；查看历史后暂停自动跟随，显式返回实时恢复跟随。CSV 采用 UTF-8 BOM、原子提交，记录精度、空值和诊断，并附 UTC/local ISO 时间、system time-zone ID、UTC offset、完整参数 snapshot JSON、算法/标定、设备和 simulation 标识；导出通过 UI 外 worker，不从绘图像素或降采样点重建。

正式吸收光谱使用 `relativeFrequencyCm1` 和 `cm⁻¹` 横轴；原始 AI 通道使用 `sampleIndex / sampleRateHz` 与 V。`processedVoltageSeries` 使用完整平均波形 `cycleTimeSeconds/cycleVoltageV`，`fittedVoltageSeries` 使用对应裁剪段 `timeSeconds/fittedVoltageV` 并扣除偏置，两者共用平均周期时轴。拟合图、FV 和峰值由同一 ProcessingResult 原子更新；组间原始图刷新不会改变上一组平均结果。结果 timestamp 为组内首完整周期的采集起点，sourceSequence 为交付该组完成边界的输入块序号。峰值趋势使用采集时间 UTC epoch 秒并在本机时区格式化；峰值源缓存最多 60000 条。绘图按屏幕像素聚合桶内首、尾、最小、最大值；UI 刷新频率不改变 20 周期组窗。

UI intents 使用稳定枚举/command ID，例如 `StartAcquisition`、`StopAcquisition`、`SaveRun`、`OpenParameters`；不得把按钮显示文本作为业务标识。

## 7. 摄像合同（M7 IMPLEMENTED）

- `ICameraDevice` 负责枚举 device/format、连接/断开和开始/停止预览；发布 `CameraFrame`、设备状态与 `ModuleError(category=camera)`。拍照、录像和文件路径由上层 `CameraWorker` 编排，设备 adapter 不写实验文件。
- `CameraDeviceDescriptor` 含稳定 ID、展示名、运行时格式列表、模拟/真实来源与默认标记。`CameraFormat` 含 frame size、最小/最大帧率和 pixel format；不得把 4K/30 fps 硬编码为实际格式。
- `CameraFrame` 含 camera session ID、camera ID、从 1 递增的 sequence、UTC/单调时间、pixel format、拥有其存储的 `QImage`、validity 和 diagnostic。worker 只接受当前 session 且严格递增的有效帧；UI 最多约 15 fps 接收一份最大 1280×720 的预览副本，照片/录像仍使用原始帧。
- `CameraDisplayModel` 含设备列表、`Idle/Previewing/Recording/Faulted`、当前 session/device/format/source、最新预览、录像时长、最后媒体结果和用户/诊断消息。
- `MediaResult` 含 camera session ID、`ExperimentId`、camera ID、Photo/Video、起止 UTC、绝对路径、帧数、成功/失败、稳定错误码和诊断。

`CameraApplicationService` 创建单独 `tdlas-camera-worker` 线程，所有设备调用、JPEG 编码和媒体文件 I/O 都在该线程完成；测量、算法和 storage worker 不被复用。正常停止或窗口/进程退出会完成已开始的录像后释放预览与设备；运行中断线会取消未提交录像、删除 `QSaveFile` 临时文件、发布 Faulted 和 `requiresStop` 错误，再断开设备。

`MockCameraDevice` 生成确定性 RGB32 帧且显式标记 Simulation。正式组合默认使用 `QtMultimediaCameraDevice` 运行时枚举 UVC/系统视频输入并使用 `QCamera/QVideoSink`；未设置 `TDLAS_CAMERA_DEVICE_ID` 时只枚举，必须由操作员在现有下拉框明确选择后连接。`TDLAS_CAMERA_BACKEND=mock` 用于测试/显式模拟。本轮没有连接、打开或采集真实摄像头。

## 8. 存储与归档合同（M8 IMPLEMENTED）

`IStorageRepository` 提供 `beginExperiment`、`appendRawData`、`appendProcessingResult`、`finishExperiment` 和 `experimentDirectory`。`FileStorageRepository` 使用以下固定规则：

```text
<root>/yyyy/MM/dd/<experiment-id>/
  manifest.json
  parameters/parameter-r<revision>-<hash12>.json
  raw/raw-<sequence12>.csv
  results/result-<source-sequence12>.json
  logs/events.jsonl
  media/photo-<utc>-<suffix>.png
  media/video-<utc>-<suffix>.mjpeg
  media/index.jsonl
```

- 根目录必须为绝对路径；默认由 `storage.json` 配置，schema version 为 `1.0`。正式组合根支持 `TDLAS_STORAGE_CONFIG` 和 `TDLAS_STORAGE_ROOT` 作为部署/测试覆盖。
- 参数文件保留完整不可变 snapshot 与 SHA-256；原始块 CSV 保留实验/run/stream/sequence、UTC、采样率、通道、样本序号、电压、有效性和丢块标记；结果 JSON 保留完整曲线、算法/频率标定版本、Voigt 字段和未校准浓度语义。
- manifest 记录合同版本、来源、操作者、参数引用、开始/结束时间、完成状态和文件计数；事件日志至少记录 experiment started/finished。
- manifest、参数、每个原始块和每个结果使用 `QSaveFile` 原子替换；同 experiment ID 或同序号文件已存在时拒绝覆盖。JSONL 日志使用 append + flush，不声称跨进程事务原子性。
- 持续写入在独立 `StorageWorker/QThread` 顺序执行；开始和正常结束只同步等待目录/元数据建立与队列排空。任何打开、写入或提交失败均返回稳定错误码；运行中失败使测量安全停止而非静默丢失。
- M7 媒体由独立 camera worker 写入同一 experiment 目录：PNG 与 MJPEG 使用 `QSaveFile` 原子提交，`media/index.jsonl` 记录当前 1.6 合同版本、实验/摄像会话/设备、媒体类型、时间、文件名、帧数、尺寸和像素格式。断线时未提交录像不会留下最终文件。
- `ExperimentArchiveService.inspect` 校验目录名与 experiment ID、manifest 必填字段、完成态文件计数和状态；`replayRawData` 按文件名/块 sequence 严格递增读取 CSV，重建拥有存储的 `RawDataBlock`，元数据、样本索引或通道长度不一致时停止并返回稳定 `ARCHIVE_*` 错误。
- `exportProcessingResultsCsv` 把完整处理结果曲线展开为 UTF-8 CSV；使用 `QSaveFile` 原子提交、自动创建父目录且拒绝覆盖已有目标。1.5 在既有列末尾追加 `time_seconds`，原列顺序保持；旧归档缺少采样时间时保持空列。结果 JSON 同步保存 `timeSeconds`。1.6 新增的管理员峰值来源 CSV 按 run/time 筛选从 PeakRecord 导出全部源行，原子提交并保留参数快照、UTC/本地时间/时区、质量、算法与模拟来源元数据。
- `recoverInterruptedExperiment` 只接受 manifest 状态为 `running` 的显式目录，把现有 raw/result 文件数写回并原子标记 `aborted`，追加 `experiment-recovered` 事件；已完成归档拒绝二次恢复。当前不自动扫描根目录，避免在没有跨进程锁时误伤另一个活动进程。
- `ExperimentArchiveApplicationService` 在调用 storage 前执行授权：查看/回放=`ViewMeasurements`，导出=`SaveExperiment`，恢复=`ConfigureStorage`；允许、拒绝和失败均写 `experiment-archive` 审计。大文件调用为同步 API，UI 集成时必须从非 UI worker 调用。
- 当前不实现数据库查询/筛选、保留期/配额、加密、签名、跨进程并发写与自动崩溃扫描、媒体缩略图数据库、视频转码或远程存储；目标磁盘吞吐与现场长时容量仍需生产环境验证。

## 9. 身份、授权与审计合同（M5 边界 IMPLEMENTED）

- `SessionContext` 包含 session ID、principal ID、角色、签发/失效 UTC 和 authentication authority；缺字段、过期或未生效会话一律拒绝。
- `IAuthorizationService.authorize(session, operation)` 返回 `AuthorizationDecision`。`RoleBasedAuthorizationService` 在正式 application controller 边界检查查看、开始、停止、复位、改参、保存状态、`UseCamera`、存储配置、审计查看和权限管理；页面/控件可见性不参与授权决定。
- Administrator 允许全部已定义操作；Client 保持当前已批准行为，可查看/开始/停止/复位/改参/保存实验/使用摄像，但不能配置存储、查看审计或管理权限。
- `IAuditSink` / `FileAuditSink` 以月度 UTF-8 JSONL 记录登录、授权决定和参数提交，字段含 UTC、principal/session、category/action/outcome、experiment/run 和诊断；写入失败有错误码并输出运行诊断。保留期、轮转上限、集中收集和防篡改仍为 TBD。
- `TemporaryCredentialAuthenticator` 仍只是开发身份 adapter；它创建标记为 `temporary-local-development` 的 8 小时本地会话。M5 完成的是可替换、可测试的正式授权/审计边界，不是生产账号库、密码存储、单点登录或正式认证。

## 10. 错误、线程与生命周期规则

1. 端口不得向 UI 抛出厂商异常；转换为 `ModuleError`，保留原始诊断。
2. 需要安全停止的错误设置 `requiresStop`；M3 mock 错误路径进入测量 `Faulted`，停止采集、清空缓存并断开设备，直到显式复位。
3. QObject/worker 的线程归属在创建处固定；算法、测量存储和摄像分别只由各自 worker 调用，跨线程事件使用 queued connection 和值语义合同；不得传递悬空缓冲区。
4. `stop`、角色窗口销毁和进程退出共用确定性清理路径；camera shutdown 完成录像原子提交后停止预览、断开设备并等待 worker thread；真实设备停止超时仍需设备依据。
5. 新 run 创建后拒绝旧 run 的块、结果、帧和存储完成事件。

## 11. 合同变更流程

公共合同变更必须记录原因、受影响模块、兼容策略和版本；先更新本文与测试，再按 dependency 顺序修改实现/调用方并运行集成测试。M7 的 1.4 是仅增加类型/枚举值的向后兼容 minor 增量；M8 复用既有合同与权限枚举，没有改变版本或既有字段语义。真实摄像能力、编码性能、浓度标定、生产认证和生产存储运维仍不因此关闭。

## 12. M2～M8 实现与验证映射

| 合同/行为 | 实现 | 验证 |
|---|---|---|
| 公共类型与 1.5 版本 | `core/contracts/MeasurementTypes.*`、`core/camera/CameraTypes.*` | 采样时间坐标、既有参数/曲线/Voigt 回归、实验 ID、摄像会话/帧/媒体结果跨线程传递 |
| 参数校验与快照 | `core/parameter/*` | 多字段失败不提交、revision/hash/ID、旧快照值不变 |
| 状态机、runId、序号/迟到过滤 | `core/application/MeasurementStateMachine.*` | 合法/非法转换、重复与旧 run 数据拒绝 |
| 模拟采集端口与缓存 | `core/acquisition/*` | FIFO/drop-oldest 标记、连接、配置、连续块、停止、二次运行、注入故障/复位 |
| NI-DAQmx adapter（无硬件） | `tests/NidaqmxAcquisitionDeviceTest.cpp` | 驱动不可用/设备不存在、AI+AO 配置、实际 AI 采样率、AO 频率拒绝、channel-major 块、启动顺序、停止幂等、配置/启动失败、clear 重试、完整块超时、运行中断线、析构资源释放、application `RealDevice` 传播；设备行为使用注入驱动替身，另有只加载实际 DLL/解析符号的可选检查 |
| v1.6 光谱算法与 mock 回归端口 | `core/algorithm/*` | 100000 点固定窗口金标、已知 Voigt 曲线回归、39 点流式组窗、NaN 拒绝、浓度无伪值 |
| 应用协调、算法 worker 与限频展示 | `core/application/*` | 算法非创建/UI 线程、高频块/低频展示、停止静默、管理员/客户端离屏闭环 |
| 实际坐标图表 API | `apps/*/src/ChartWidget.*` | 原始 256 点秒/V、155 点处理电压与拟合共享时间轴、FV 频率跨零、峰值时钟窗口、无数据等待态 |
| 实验文件存储与配置 | `core/storage/*`、`core/application/StorageWorker.*` | 目录/命名、参数/原始/结果内容、原子文件、重复拒绝、配置往返、正常 flush、写失败安全停止 |
| 授权与审计边界 | `core/system/*`、`IntegratedApplicationController` | 管理员/客户端/过期会话矩阵、登录/授权/参数审计 JSONL、两角色 GUI 闭环 |
| 摄像闭环 | `core/camera/*`、两角色 `CameraPreviewWidget`、`IntegratedApplicationController` | mock 枚举/预览、PNG、MJPEG、实验索引、断线取消、退出完成并释放、两角色与测量并行；Qt Multimedia adapter 仅构建验证，未连接真实硬件 |
| 归档回放/导出/恢复 | `core/storage/ExperimentArchiveService.*`、`core/application/ExperimentArchiveApplicationService.*` | 完成归档检查、双通道原始块重建、严格 sequence、10 行结果导出、拒绝覆盖、running→aborted 恢复、二次恢复拒绝、客户端/管理员权限与审计 |
| 软件长稳与发布 | `tests/SystemStabilityTest.cpp`、`deploy.ps1`、`docs/DEPLOYMENT.md` | 可配置时长的启停/存储/摄像并行与 20 次故障复位；隔离 staging、Windows 平台隐藏启动、文件清单、SHA-256 和 zip |

## 相机设备控制与软件旋转合同 2.0（2026-11-12，V3.2.2）

替代 V3.2.1 的预览位移／缩放合同。测量持久化合同仍为 1.7，不修改实验文件 schema。

- `CameraViewOperation` 保留 UI 意图名称以兼容窗口信号。`operateView()` 将 MoveUp/Down/Left/Right、ZoomIn/Out 和 Reset 路由到设备 worker；只有 RotateClockwise 在软件视图生效。软件 zoom 恒为 1、offset 恒为 0，Reset 清零旋转。
- `CameraControlState` 提供会话／相机 ID、Pan/Tilt/Zoom 读取和手动写入能力、最小／最大／步长／默认／当前值，以及模拟来源、结果和提示。所有数值是设备原始单位，不表示倍率或实机机械角度。
- `ICameraDevice::readCameraControls()` / `setCameraControl()` 是设备端口，默认不支持，禁止隐式软件替代。Windows 适配器按当前选中相机路径精确匹配，归一化类别 GUID 后仍核对完整设备实例，拒绝使用其他相机替代。
- Windows 适配器使用独立控制过滤器的 IAMCameraControl，不运行另一套视频采集图；保留 Qt Multimedia/FFmpeg 预览。COM 在相机 worker 创建、使用及释放。Set 前检查能力／范围／步长，Set 后 Get 回读相等才算成功。
- 方向按标准驱动语义：Pan 增量对应向右取景，Tilt 增量对应向上取景；具体设备画面方向需人工确认。每次使用一个驱动步长，软件旋转不改变设备轴定义。
- 控制请求延迟／间隔 100 ms，最多一个在途请求和一个最新待发意图；新意图替换旧待发，不无限堆积。长按按钮仍为 400 ms 后每 80 ms 发出意图，实际设备写入由服务限频。
- 服务每秒回读当前值以跟踪 Windows 设置等外部变化。有效帧就绪后开放控制；设备边界禁用对应按钮。失败明确提示，不让测量服务 Faulted。
- 命令携带相机会话 ID，worker 执行前核对；切换设备、停止、故障与关闭清除待发意图。已经开始的单次驱动调用可能完成，停止不会追加控制指令。
- 初次连接、停止和退出不自动写 PTZ，也不恢复驱动出厂默认值。显式“复位”只写可用 PTZ 的驱动默认值并清零软件旋转，不动曝光／对焦，不修改 Windows 持久默认设置。
- 设备 PTZ 改变源视频，照片／录像自然反映设备取景；软件 90° 旋转仍不写入原始媒体。
- `MockCameraDevice` 返回明确标记的模拟 PTZ 状态，仅用于软件链路验证，不伪称真实相机；纯规则、队列取消、两端按钮测试与真实相机复验分别报告。
