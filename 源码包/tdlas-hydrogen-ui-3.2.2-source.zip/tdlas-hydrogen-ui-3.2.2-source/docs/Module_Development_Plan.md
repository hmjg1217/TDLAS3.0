# TDLAS 模块开发计划

## 1. 当前门禁

- 当前完成范围：阶段 0 基线 + 阶段 1 审计/架构/接口草案。
- 当前明确禁止：业务代码、真实硬件、算法移植、UI 重设计、空模块批量创建。
- 进入阶段 2 前：用户确认架构方向，并关闭/接受 `OPEN_QUESTIONS.md` 中影响公共合同的 P0 项。

## 2. 路线图

| 阶段 | 目标 | 主要交付 | 验收/退出条件 | 当前状态 |
|---|---|---|---|---|
| 0 | UI/Git 基线 | 初始提交/标签、版本化截图、构建测试证据、保护规则 | 全量 build、CTest、13 状态截图；可回退 | 完成（本轮） |
| 1 | 现状与架构准备 | Audit、Architecture、Interfaces、Plan、Open Questions | 模块/依赖/线程/错误/TBD 清晰；用户评审 | 草案完成，待确认 |
| 2 | 最小合同与 mock 骨架 | 公共类型、状态/错误、采集端口、可重复 mock、单测 | 无 Widgets/硬件依赖；mock 合同测试通过 | 未开始 |
| 3 | 第一条纵向闭环 | UI intent → application → mock acquisition → algorithm stub/reference → display → stop | 可重复开始/停止；无真实设备；UI 不冻结；迟到数据被拒绝 | 未开始 |
| 4 | 参数管理 | draft/validation/snapshot、配置 adapter、控件映射 | 单位/范围确认；非法参数阻止启动；snapshot 可追溯 | 未开始 |
| 5 | 采集完善（仍 mock） | 连接/配置/状态机、数据块、背压、故障注入 | 状态一致；停止后无新数据；超时/断线可测 | 未开始 |
| 6 | 算法独立验证 | 固定数据、处理库、Voigt 等价测试、版本/容差 | 不依赖硬件/UI；参考误差获批准；无效输入明确 | 未开始 |
| 7 | 展示集成 | 真实 display model、曲线/数值、节流/空/错状态 | 与结果一致；UI 流畅；截图回归通过 | 未开始 |
| 8 | 单一真实采集适配器 | NI-DAQmx adapter 与安全测试记录 | 驱动/设备/联锁确认；连接/停止/断线/退出实测 | 未开始/需授权 |
| 9 | 摄像 | mock → Qt Multimedia/UVC，拍照/录像/释放 | 不干扰采集；媒体可读；关闭/断线释放 | 未开始 |
| 10 | 数据与系统 | 存储、导出、认证/授权、审计、配置 | 可追溯；失败有反馈；权限服务生效 | 未开始 |
| 11 | 整机与发布 | 异常恢复、长稳、目标机部署、版本/依赖 | P0/P1 关闭，安全/数据/部署证据齐全 | 未开始 |

## 3. 下一批准工作包建议

### WP-02A 公共合同最小集

- In scope：RunId/Sequence/Timestamp、Validity、Error、ParameterSnapshot、RawDataBlock、两类状态枚举。
- Out of scope：浓度、真实 SDK、文件格式、UI 绑定。
- 测试：默认/无效值、序号、单位/范围校验、Qt metatype（若采用 queued signals）。
- Exit：接口文档与代码一致，无未经确认字段被当作有效测量。

### WP-02B 模拟采集端口

- In scope：`IAcquisitionDevice`、确定性 `MockAcquisitionDevice`、可控启动/停止/错误、合同测试。
- Out of scope：NI-DAQmx、随机算法正确性测试、主窗口改动。
- Exit：固定 seed/固定波形可重复；状态机和停止后无数据通过测试。

### WP-03A 最小应用编排

- In scope：measurement state machine、run ID、参数快照、mock 数据到最小处理替身、迟到事件过滤。
- UI 接入：只在现有 start/stop 与现有图表/数值 adapter 处建立连接；布局/QSS 不变。
- Exit：两角色的适用路径可重复开始/停止，模拟标签保留，关闭/错误清理通过。

每个工作包开始前给出准确 allowlist；不一次创建阶段 2–10 的空目录或接口。

## 4. 依赖顺序

```text
Common contracts
  ├─ Parameter snapshot
  ├─ Acquisition port + mock
  ├─ Algorithm port/test double
  └─ Error/state model
        ↓
Measurement application service
        ↓
Presentation adapter → existing UI
        ↓
Storage / camera / real device adapters (independent increments)
```

真实硬件、摄像、存储均不得反向迫使 UI 或算法依赖厂商类型。

## 5. 每个工作包固定流程

1. 读取 `AGENTS.md`、`docs/PROJECT_STATUS.md` 和相关合同/TBD。
2. 确认输入、输出、单位、线程、生命周期、allowlist/denylist。
3. 只实现一个可验收增量并增加针对性测试。
4. 先跑聚焦测试，再跑现有完整 CTest；UI 变化跑受影响截图矩阵。
5. 检查 diff、状态文档和未解决问题；模拟/实机证据分开。
6. 只有退出条件满足才建立阶段 Git 节点；不自动跨阶段。

## 6. 质量策略

- Contract tests：mock 与真实 adapter 的共同状态/错误/停止语义。
- Unit tests：参数、算法、状态机、错误映射、存储格式。
- Integration tests：offscreen UI intent 路由、worker 清理、迟到数据、失败路径。
- Golden/fixed-data tests：算法固定输入与批准输出/容差；不以随机图形代替。
- Visual regression：结构、状态、溢出、字体/颜色；目标环境未锁定前不要求跨环境逐像素哈希。
- Hardware tests：明确设备/驱动/通道/安全条件，单设备、可停止、记录真实结果。

## 7. 里程碑版本建议

- `ui-baseline`：本轮 UI/文档/Git 基线。
- `contracts-approved-v1`：公共合同与 mock 合同测试获批准后。
- `vertical-slice-approved`：模拟纵向闭环通过后。
- 后续每个真实 adapter 单独版本节点；最终发布标签在目标机部署和安全/数据验收后创建。
