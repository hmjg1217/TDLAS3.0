# 项目布局（3.2.2，2026-11-12）

正式交付物为以下两类：

| 相对路径 | 用途 |
|---|---|
| `发布包/tdlas-hydrogen-ui-3.2.2-win64/` | 可直接运行和整体复制的完整环境 |
| `发布包/tdlas-hydrogen-ui-3.2.2-win64.zip` | 复制到其他 Windows x64 电脑后解压运行 |
| `源码包/tdlas-hydrogen-ui-3.2.2-source/` | 可直接阅读、修改、重新构建的完整源码 |
| `源码包/tdlas-hydrogen-ui-3.2.2-source.zip` | 同一源码目录的完整压缩包 |

源码根目录包含 CMakeLists.txt、build.ps1、deploy.ps1、apps、core、shared、tests、docs、tools 和便携配置。原来位于工程外的技术/算法/硬件资料已归入 `docs/reference/`。

旧发布版本、重复工作区、Git 元数据、构建缓存、临时文件和实验运行数据不进入交付包。原文件集中在项目根“待删除旧文件”；工具自动安全策略拒绝删除，需手动删除该目录完成清理。后续构建会在本源码目录重新生成 build/；该目录不进入源码包。历史文档所列 N.UI、camera-work、dist 或旧绝对路径均为当时记录。

