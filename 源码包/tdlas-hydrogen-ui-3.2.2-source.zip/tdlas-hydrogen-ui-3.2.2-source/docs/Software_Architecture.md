# TDLAS 测氢上位机软件架构

## 1. 文档状态

- 版本：0.7 M7 摄像完整闭环，2026-11-04。
- 范围：在 M6 后增加独立摄像 application service、mock 与 Qt Multimedia/UVC adapter、预览、拍照、MJPEG 录像、实验关联、断线和退出释放；当前正式组合默认枚举真实设备并保留显式 mock 回退，真实硬件验收仍为 TBD。
- 事实来源：当前代码与运行验证、`TDLAS_模块化开发与增量集成规范_V1.0.md`、`技术参数.txt`、算法和摄像头参考资料。
- 标记：`IMPLEMENTED` 已由源码和自动化测试验证；`CONFIRMED` 已由当前工程/用户资料确认；`PROPOSED` 是尚未实现的后续设计；`TBD` 需要额外依据。

## 2. 架构目标与不变量

1. 保留 `apps/integrated` 为唯一正式应用，三个 preview target 只承担开发和截图回归。
2. 保留已批准页面、导航、QSS 和资源；功能通过适配器接入现有控件，不重建第二套 UI。
3. UI、应用协调、公共合同、领域/算法、硬件适配、存储和权限分层。
4. 模拟与真实适配器遵循同一上层合同；先完成可重复的模拟闭环，再逐一替换真实设备。
5. UI 线程只做有界展示；采集、算法、摄像、编码和持续存储不阻塞 UI。
6. 每个运行由稳定 ID、递增序号、时间戳、参数/算法版本和有效性贯穿；迟到数据不能污染新运行。
7. 未确认的浓度、标定、硬件范围和协议保持无效/TBD，不以 UI 示例数值代替测量事实。

## 3. 当前结构（CONFIRMED）

```text
QApplication
└─ IntegratedApplicationController
   ├─ StartupTemplateWindow
   ├─ TemporaryCredentialAuthenticator
   └─ AdminTemplateWindow | ClientTemplateWindow
      ├─ static ChartWidget
      └─ CameraPreviewWidget（静态 fixture 或 host-supplied frame）
```

M2 前 controller 只负责临时登录路由、窗口生命周期和 QSS 切换；角色窗口直接构造模拟页面与提示。`tdlas_integrated_core` 仍是整合应用静态库，不作为共享业务核心。

### 3.1 M2～M7 已实现结构（真实硬件验收待完成）

```text
tdlas_measurement_core (Qt Core only)
├─ contracts/MeasurementTypes
├─ parameter/IParameterService + ParameterService
├─ acquisition/RawDataBuffer
├─ acquisition/IAcquisitionDevice
│  + MockAcquisitionDevice
│  + NidaqmxAcquisitionDevice + INidaqmxDriver/DynamicNidaqmxDriver
├─ algorithm/IAlgorithmProcessor
│  + MockAlgorithmProcessor
│  + TdlasAlgorithmProcessor
├─ storage/IStorageRepository + FileStorageRepository
├─ system/IAuthorizationService + RoleBasedAuthorizationService
│  + IAuditSink + FileAuditSink
└─ application/MeasurementStateMachine
   + IMeasurementApplicationService
   + MeasurementApplicationService + AlgorithmWorker + StorageWorker

tdlas_camera_core (Qt Core + Gui + Multimedia, no Widgets)
├─ camera/CameraTypes + ICameraDevice
├─ MockCameraDevice + QtMultimediaCameraDevice
└─ CameraApplicationService + CameraWorker + experiment media writer

tdlas_integrated_core (Qt Widgets)
└─ IntegratedApplicationController
   ├─ composes measurement services + independent camera service
   └─ authorizes and audits typed parameter/measurement/save/camera intents before dispatch
```

UI 窗口不直接调用设备、算法、文件系统或授权策略；preview target 不创建业务核心，继续显示稳定静态 fixture。正式主程序通过 `HybridAcquisitionDevice` 自动枚举 NI 并按设备 ID 路由真实/mock adapter，摄像默认 Qt Multimedia 枚举；未明确选择的摄像头不会自动打开。算法、测量存储和摄像/编码分别在三个专用 worker 执行，NI 设备发现使用独立短时线程。

## 4. 目标分层（M7 部分 IMPLEMENTED）

```mermaid
flowchart TB
    UI[现有 Qt Widgets UI<br/>窗口/页面/图表] --> PA[UI Adapter / Presentation]
    PA --> APP[Application Services<br/>会话、测量编排、摄像编排]
    APP --> CONTRACT[Contracts + Domain Types]
    APP --> PARAM[Parameter Service]
    APP --> ACQ[Acquisition Port]
    APP --> ALG[Algorithm Port]
    APP --> CAM[Camera Port]
    APP --> STORE[Storage Port]
    APP --> SYS[Identity / Authorization / Audit]
    ACQ --> MOCKA[Mock Acquisition Adapter]
    ACQ --> NIA[NI-DAQmx Adapter]
    CAM --> MOCKC[Mock Camera Adapter]
    CAM --> UVC[Qt Multimedia / UVC Adapter]
    STORE --> FILE[CSV / media / config adapters]
```

代码依赖只允许向内：UI 依赖应用接口与展示模型；应用层依赖合同和端口；基础设施实现端口。算法不得包含 Qt Widgets、NI-DAQmx 或摄像头依赖。

### 4.1 正式主程序、预览程序与共享核心边界

- 正式主程序：`tdlas_hydrogen_ui` 是唯一组合根，负责选择真实/模拟 adapter、创建应用服务、连接 UI adapter，并管理全局生命周期。
- 预览程序：三个 preview target 只构造相应 UI、稳定模拟 display model 和截图入口；默认不加载认证、采集、算法、存储或真实硬件 adapter。
- 共享业务核心：measurement core 提供合同、参数、测量、算法、文件存储和系统边界；camera core 提供 M7 摄像合同、adapter、独立 worker 和媒体保存。二者由测试和正式主程序复用，均不依赖 Qt Widgets。
- UI 适配层：把稳定 UI intent 转成 application command，把 display model 映射到既有控件；位于 UI 一侧，可分别适配 admin/client，但不包含算法或设备调用。
- 设备边界：mock 与真实 adapter 都实现 contracts 定义的 port；只有正式组合根选择实现，UI 与共享核心不判断厂商类型。

## 5. 模块职责

| 模块 | 职责 | 明确不负责 |
|---|---|---|
| Parameter | 参数模型、与设备无关的单位/范围/组合校验、不可变快照、schema 1 draft 跨启动恢复 | 设备调用、绘图、算法计算；跨版本迁移尚未实现 |
| Acquisition | 设备发现、连接、配置、开始/停止、原始块、状态/错误 | 浓度计算、图表样式、页面导航 |
| Algorithm | 滤波、周期处理、基线、吸光度、Voigt、结果有效性 | 硬件、Widgets、文件路径 |
| Presentation | 节流/缓存、曲线与数值展示模型、空/无效/断连状态 | 重算算法、驱动调用 |
| Camera | M7 枚举、格式、预览帧、拍照/录像、实验媒体索引、断线/退出释放 | 光谱算法、DAQ 控制、Widgets |
| Storage | M5 参数 snapshot/原始块/结果/清单/事件日志持久化与追溯、失败报告；M7 camera worker 写同实验目录媒体；M8 归档校验、原始块回放、结果 CSV 导出和显式中断恢复 | 控件操作、算法判断、数据库查询/保留期/跨进程恢复 |
| System | M5 会话合同、角色授权和文件审计；后续接生产认证 | 页面布局、设备协议、当前临时凭据实现 |
| Application | 用例编排、运行状态机、取消/停止、跨模块错误策略 | 厂商实现细节、绘图 |

M4 的 Algorithm 已实现参考资料可支持的光谱部分：等效四阶低通、周期/光谱平均、对齐/截取、四阶基线、吸光度、相对频率、Voigt/FV 和峰值。C++ 滤波边界状态与 MATLAB `filtfilt` 不同，优化器为有界坐标搜索而非 `lsqcurvefit`；浓度公式、单位、有效标定范围和外部参考输出缺失，因此这两类等价/精度结论仍不可作出。

## 6. 关键运行流

### 6.1 测量纵向闭环

```mermaid
sequenceDiagram
    participant UI as Existing UI
    participant APP as MeasurementApplicationService
    participant P as ParameterService
    participant D as IAcquisitionDevice
    participant A as IAlgorithmProcessor
    participant S as StorageWorker/Repository
    participant V as PresentationAdapter
    UI->>P: submit(ParameterDraft)
    P-->>UI: ParameterSnapshot / field errors
    UI->>APP: start(snapshot)
    APP->>S: beginExperiment(id, run, snapshot)
    APP->>D: configure + start(runId)
    D-->>APP: stateChanged / RawDataBlock
    APP->>S: queued appendRawData(block)
    APP->>A: queued process(block, snapshot)
    A-->>APP: queued ProcessingResult
    APP->>S: queued appendProcessingResult(result)
    APP->>V: publish latest DisplayFrame (throttled)
    V-->>UI: queued UI update
    UI->>APP: stop(runId)
    APP->>D: stop()
    APP->>S: flush + finishExperiment(status)
    D-->>APP: Stopped
```

停止后，只有匹配当前 `runId` 且序号未过期的事件可进入展示/存储。正常停止会等待此前排队的文件写入并原子更新 manifest；保存失败进入 Faulted 并执行同一设备清理路径。开始和停止在合理范围内幂等。

### 6.2 摄像流

摄像由独立 `CameraApplicationService → CameraWorker → ICameraDevice` 管理，可与测量并行；视频帧不进入光谱算法。设备 adapter 只枚举、连接和发布拥有存储的帧；camera worker 在自己的线程完成 JPEG 编码和媒体文件 I/O。照片/录像仅共享实验 ID 和时间元数据，不共享 acquisition、algorithm 或 storage worker/缓冲区。

正式组合默认使用 Qt Multimedia adapter 枚举系统摄像头；未提供设备 ID 时只枚举，由操作员在既有相机下拉框选择后连接，页面进入不会自动打开未指定的真实设备。`TDLAS_CAMERA_BACKEND=mock` 提供测试/显式模拟回退。拍照/录像要求当前测量处于 Running 且有合法实验 ID，输出到该实验的 `media/`；照片/录像结束结果和授权决定进入 UI/审计轨迹。

录像使用逐帧 JPEG 的 MJPEG 流与 `QSaveFile`：正常停止/窗口关闭/进程退出提交完整文件并写 `media/index.jsonl`；设备断线或写入失败取消临时文件，不留下最终录像。预览跨线程发布约限制为 15 fps，超过 1280×720 的帧在 camera worker 生成展示副本；媒体仍使用原始帧，因此 UI 绘制和测量线程互不占用对方 worker。

## 7. 状态、线程与背压

- UI 线程：控件、轻量模型绑定、限频重绘。
- Acquisition worker：设备阻塞调用、读循环和确定性清理。
- Algorithm worker：M4 使用单一 `QThread` 顺序处理每个有效块/窗口；结果回到应用线程后按活动 run 和递增 sequence 二次过滤。
- Camera/encoder worker：M7 单一独立 `QThread` 管理枚举/设备/帧、PNG/MJPEG 编码和 media I/O；切页不改变会话，窗口/退出确定性完成或取消文件并释放设备。
- Storage worker：M5 以独立 `QThread` 顺序写入；正常停止排空，磁盘失败不得静默丢失；生产队列上限仍待负载依据。
- 跨线程：Qt queued signal/slot 或等价队列；公共类型注册元类型；不得跨线程直接访问 QWidget。
- 背压：原始处理缓存、算法组窗、存储写入和展示发布分开。M3 mock 使用默认 8 块 FIFO/drop-oldest，并把丢弃事实标到下一块实际交付数据；M4 算法按 run/snapshot/sequence 组窗，检测不连续即丢弃未完成窗口；M5 存储使用独立顺序 worker，但 Qt 事件队列容量仍未按目标磁盘吞吐标定；展示默认每 33 ms 只发布最新帧。真实设备负载下的算法/存储队列上限与降载策略仍需依据。

建议测量状态机：`Idle → Preparing → Running → Stopping → Idle`，任一活动态可进入 `Faulted`，清理完成后才允许回到 `Idle`。设备连接状态与测量运行状态分开，避免一个枚举混合两类生命周期。

## 8. 当前 UI 的渐进接入点

| 现有点 | 目标接法 | 约束 |
|---|---|---|
| Admin `actionRequested(QString)` | 由 UI adapter 转成稳定 command ID；最终移除对显示文本的依赖 | 不改按钮外观/布局 |
| Admin/Client 数据保存按钮 | 已发出 `saveExperimentRequested`，只查询自动保存状态 | 不在 UI lambda 中写文件 |
| 参数抽屉本地控件 | 已映射 `ParameterDraft`，提交后由 ParameterService 校验并生成 snapshot；schema 1 draft 跨启动恢复；实验开始时持久化 | 运行中拒绝改参；跨版本迁移/设备能力范围校验仍 TBD |
| ChartWidget | 接收 `ChartSeriesData{x,y,unit,validity}`，按各物理量值域绘图 | 无数据时显示等待采集；原始与处理电压分开，绘图不计算业务结果 |
| CameraPreviewWidget | 已通过 presentation adapter 接收拥有存储的预览帧/状态；preview targets 保留可重复静态 fixture | 不在 paintEvent 打开设备或编码；正式帧最多约 15 fps |
| Integrated controller | 保留 shell 路由；通过授权服务检查意图，组合测量/存储并写审计 | 临时身份 adapter 不能进入生产配置 |

## 9. M8 目录与后续演进

```text
core/
  contracts/       # 1.6 公共版本、实验 ID/Voigt/曲线时间坐标/PeakRecord；无 Widgets
  parameter/       # M3 implemented：草稿校验、版本化内存快照
  application/     # M8 current：测量编排、worker、展示节流、归档授权/审计 gate
  acquisition/     # M6 adapter：port + mock/缓存 + NI-DAQmx 运行时 adapter；真实设备实测待完成
  algorithm/       # M4 implemented：port + mock + v1.6 光谱/Voigt 算法
  storage/         # M8 current：repository、配置、归档校验/回放/导出/中断恢复
  system/          # M5 implemented：授权 port/角色策略、审计 port/文件 adapter
  camera/          # M7 implemented：合同、port、mock/Qt Multimedia adapter、独立 worker、媒体保存

future modules (not created):
  presentation/
```

M7 在既有边界内增加实际需要的 camera 模块，没有移动或重建 UI。M8 保持公共合同 1.4 和 UI 不变，在 storage/application 边界增加离线归档能力；大文件回放/导出是同步核心服务，未来接 UI 时必须放入专用 worker。当前 presentation adapter 与 application authorization gate 位于 integrated controller；后续接生产身份提供方时替换 authentication adapter，不把账号或设备逻辑下沉到窗口。

## 10. 架构决策

| ADR | 决定 | 状态 |
|---|---|---|
| ADR-001 | `apps/integrated` 是唯一正式产品；preview 不进入默认发布包 | Accepted / current baseline |
| ADR-002 | 已批准 UI 为保护基线，功能通过 adapter 增量接入 | Accepted / current baseline |
| ADR-003 | 模拟优先，真实适配器遵守相同端口；由正式组合根选择实现 | Accepted / M2 mock implemented |
| ADR-003A | 预览目标不启动共享业务核心或真实设备，只使用稳定 UI fixture | Accepted / implemented |
| ADR-004 | 测量采用无花括号 UUID run ID + 每 run 从 1 递增的 sequence 防止迟到数据污染 | Accepted / contract 1.0 |
| ADR-005 | 算法库不依赖 Widgets/硬件；浓度在标定未确认前无效 | Accepted as safety boundary |
| ADR-006 | 摄像与光谱测量独立，只通过实验 ID/时间元数据关联 | Accepted / M7 implemented |
| ADR-007 | mock 原始缓存默认 8 块、drop-oldest，丢弃事实附着下一块实际交付数据 | Accepted / M3 mock only |
| ADR-008 | 算法逐块消费，按真实边界累计连续 20 周期相位平均后拟合；拟合/FV/峰值由同一结果同步发布，主/调试峰值缓存同步；UI 默认 33 ms 合并最新帧，原始电压图直接来自采集块 | Accepted / 2026-11-09 updated |
| ADR-009 | v1.6 UI 配置按每块一个相位对齐周期、20 周期组窗；参考配置固定为 500×10×20 | Accepted / M4 mock integration only |
| ADR-010 | 正式算法在单一 Qt Core worker 顺序执行；结果返回后按 run/sequence 二次过滤 | Accepted / M4 implemented |
| ADR-011 | 相对频率标定与浓度标定分离；缺少浓度公式/单位/标准样气时浓度保持空且 Uncalibrated | Accepted / safety boundary |
| ADR-012 | 实验 ID 使用 UTC 毫秒时间 + 随机后缀；目录按 UTC `yyyy/MM/dd/<experiment-id>` 分区，拒绝覆盖已有实验/序号 | Accepted / M5 implemented |
| ADR-013 | 参数、原始块和结果为独立原子文件，manifest 原子更新，JSONL 日志 append+flush；写失败使测量 Faulted 并安全停止 | Accepted / M5 implemented |
| ADR-014 | 正式 UI 操作在 application controller 通过 `IAuthorizationService` 授权并审计；临时凭据只提供开发 session | Accepted boundary / production identity TBD |
| ADR-015 | NI-DAQmx 通过 acquisition 内部可注入 driver seam 与 `nicaiu.dll` 运行时加载接入；正式组合用 hybrid adapter 自动发现、真机优先、可显式 mock 回退 | Accepted / discovery implemented, hardware acceptance pending |
| ADR-016 | 摄像公共合同升至 1.4；设备 adapter 只发布帧，独立 camera worker 负责 PNG/MJPEG 与实验媒体索引 | Accepted / M7 implemented |
| ADR-017 | 正式组合默认 Qt Multimedia 枚举；operator/device ID 明确选择后才连接，mock 仅作显式回退 | Accepted / real hardware acceptance pending |
| ADR-018 | M8 归档能力不改变 1.4 测量合同；读取时先校验 manifest、目录 ID、计数、run/sequence/通道长度，导出使用原子新文件且拒绝覆盖 | Accepted / implemented |
| ADR-019 | 查看/回放沿用 `ViewMeasurements`，导出沿用 `SaveExperiment`，中断恢复沿用管理员 `ConfigureStorage`；application gate 统一授权并审计 | Accepted / implemented |
| ADR-020 | 发布包使用隔离 staging、Windows 平台启动冒烟、payload 清单与 SHA-256；真实 backend 可枚举但现场行为未验收 | Accepted / implemented |
| ADR-021 | 合同 1.5 追加处理曲线采样时间与原始块时长；原始采集直接进入 33 ms 展示节流，处理电压、拟合电压及 FV 频率各用对应坐标；无数据不绘制伪波形 | Accepted / 2026-11-06 |
| ADR-022 | 合同 1.6 统一 PeakRecord 来源：按采集 UTC/单调时间、runId+sourceSequence 保存，UI 趋势/明细/CSV 只消费同一有界源序列；无效/空 FV 不取峰且断线；导出在 UI 外 worker | Accepted / 2026-11-06 |

## 11. 验收门槛

- 合同字段、单位、有效性、错误、线程和生命周期均已记录；阻塞 TBD 有决定。
- 每个真实适配器都有同合同 mock 和不依赖硬件的测试。
- 开始/停止/注入故障/复位/窗口销毁/迟到数据路径可重复验证，UI 不冻结。
- 算法用固定输入、批准的预期值或明确容差验证；不能只看曲线“像”。
- UI 改动执行受影响截图矩阵；目标环境未校准时只做结构级结论。
- Git diff 不越出工作包 allowlist，状态文档与实际验证同步。
