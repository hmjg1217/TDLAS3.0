# TDLAS Hydrogen UI Suite 整合规格

## 1. 文档控制与目标

- 项目 / 目标：把启动/登录、管理员端、客户端三个 Qt Widgets 样板整合为一个可构建、可部署的单进程主程序，同时保留独立预览目标。
- 版本 / 日期 / 负责人：0.9.0 M7 Camera Closed Loop / 2026-11-04 / Codex。
- 本次模式：保留既有单进程整合、批准布局和 QSS，在正式主程序内把既有摄像控件接入独立 camera service；正式程序默认枚举 Qt Multimedia 摄像头，preview target 保持稳定 mock fixture。
- 包含：M2～M6 已有闭环、M7 相机枚举/预览/拍照/MJPEG 录像、实验 ID 关联、媒体保存、断线/退出释放、摄像授权/审计、两角色离屏集成与静态截图回归。
- 用户确认的临时路由：管理员 00/00；用户 01/01；其他组合无效。
- 不包含：浓度反演公式/单位/标准样气标定、MATLAB 逐点等价证明、真实 NI/摄像硬件实测、生产身份提供方/账号库、网络、视频转码、媒体查询导出或长期存储运维。
- 技术环境：C++17、Qt 6 Widgets/Gui/Multimedia、CMake 3.21+；本轮实测为 Qt 6.8.3 + MSVC 2022 x64。
- 用户授权来源：2026-11-02 当前请求；指定三个样板目录、侧栏控件目录、新工程输出目录及临时账号。
- AGENTS.md：Suite 根目录已有精简工程规则；当前阶段与证据见 `docs/PROJECT_STATUS.md`。

证据标记使用 CONFIRMED / INFERRED / TBD / N/A。各页面详细视觉、状态、数据与业务边界以 apps/*/docs/ui 下的原规格为准。

## 2. 输入与环境

| 字段 | 值 | 证据 | 来源 / TBD |
|---|---|---|---|
| 启动样板 | E:\AI\氢气3.0\UI设计\启动\codex-qt-template | CONFIRMED | 用户指定、只读审计 |
| 管理员样板 | E:\AI\氢气3.0\UI设计\管理员\codex-qt-template | CONFIRMED | 用户指定、只读审计 |
| 客户样板 | E:\AI\氢气3.0\UI设计\客户\codex-qt-template | CONFIRMED | 用户指定、只读审计 |
| 侧栏控件 | E:\AI\氢气3.0\UI设计\控件，5 张 1254×1254 ARGB PNG | CONFIRMED | 尺寸、透明度、SHA-256 实测 |
| 整合输出 | C:\Users\91463\Documents\ChatGPT\N.UI\TDLAS-Hydrogen-UI-Suite | CONFIRMED | 当前请求 |
| 验证环境 | Windows 10 SDK 10.0.26100.0、Qt 6.8.3、MSVC 19.44、VS 2022 x64 | CONFIRMED | CMake/MSBuild 输出 |
| 正式 DPI / DPR / 字体 / 客户区 | 继承各样板候选；正式目标未确认 | TBD | TBD-INT-002 |

## 3. 工程审计与不变量

| 项目 | 整合现状 | 证据 | 本次影响 |
|---|---|---|---|
| 主目标 | tdlas_hydrogen_ui | CONFIRMED | 登录后在同一 QApplication 内创建目标角色窗口 |
| 预览目标 | startup、admin、client 三个原 target | CONFIRMED | 仅开发回归；默认不部署 |
| 测试目标 | measurement/camera core、algorithm regression、authentication、login routing、measurement UI | CONFIRMED | CTest 覆盖数值、线程、生命周期、媒体文件、路由和真实 Qt 控件闭环 |
| 同名类 | 管理员/客户 ChartWidget、CameraPreviewWidget 实现不同 | CONFIRMED | 分别放入 adminui / clientui 命名空间 |
| QSS | 三份样式含应用级选择器 | CONFIRMED | 登录成功后替换为当前角色 QSS，不拼接 |
| QRC | 主程序编入启动、管理员、客户与共享侧栏资源 | CONFIRMED | 共享图标使用稳定英文 alias |
| 身份/授权 | TemporaryCredentialAuthenticator 提供开发身份；RoleBasedAuthorizationService 执行正式操作授权边界 | CONFIRMED | UI 不硬编码；生产身份 adapter 仍须替换 |
| 原目录 | 只读，未修改 | CONFIRMED | 回退只需删除新工程 |
| 旧产物 | 原 build*、dist 未复制 | CONFIRMED | 新工程重新配置、构建、部署 |

不变量：临时登录只用于当前样板路由，不声明为正式安全认证；页面可见性不替代授权；不得伪造设备连接、采集、摄像、算法结果或数据保存。

## 4. 页面与共享组件

| Page ID | 页面 / 角色 | 主程序入口 | 状态 | 详细规格 |
|---|---|---|---|---|
| PAGE-S-LOGIN | 登录 / 未认证 | 应用默认入口 | idle、validation、auth-error、success-route | apps/startup/docs/ui/UI_SPEC.md |
| PAGE-A-SHELL | 管理员 | 00/00 登录成功 | main、parameters、debug、peak、camera、camera-motion | apps/admin/docs/ui/UI_SPEC.md |
| PAGE-C-SHELL | 客户 | 01/01 登录成功 | main、parameters、camera、camera-motion | apps/client/docs/ui/UI_SPEC.md |
| PAGE-S-STARTUP | 启动展示 / 预览 | startup 预览 target | brand-visible | apps/startup/docs/ui/UI_SPEC.md |

| Component ID | 职责 | 实现 / 路径 | 证据 |
|---|---|---|---|
| CMP-INT-CONTROLLER | 登录窗口、角色路由、QSS 与窗口生命周期 | apps/integrated/src/IntegratedApplicationController.* | CONFIRMED、CTest PASS |
| CMP-INT-AUTH | 临时账号到角色映射 | apps/integrated/src/TemporaryCredentialAuthenticator.* | CONFIRMED、CTest PASS |
| CMP-INT-BUILD | 统一配置与构建 | CMakeLists.txt、build.ps1 | CONFIRMED、Release PASS |
| CMP-INT-DEPLOY | 默认只部署主程序及 app-local 运行库 | deploy.ps1 | CONFIRMED、deploy/run PASS |
| CMP-INT-CAPTURE | 整合登录 + 12 个预览状态截图 | tools/capture-all.ps1 | CONFIRMED、13/13 PASS |
| CMP-INT-SIDEBAR | 后续侧栏图标资源 | shared/resources/sidebar-icons.qrc | CONFIRMED；当前未绑定控件 |
| CMP-INT-CAMERA | 摄像合同、mock/Qt Multimedia adapter、独立 worker、媒体保存 | core/camera/* | IMPLEMENTED；真实硬件未连接 |

## 5. 整合结构

~~~text
TDLAS-Hydrogen-UI-Suite/
  CMakeLists.txt
  build.ps1
  deploy.ps1
  apps/
    integrated/
    startup/
    admin/
    client/
  shared/resources/sidebar-icons/
  docs/ui/
  artifacts/
    source-baselines/
    captures/
    qa/
  tools/capture-all.ps1
~~~

- apps/integrated 是正式主入口；三个原 main.cpp 只编入各自预览 target。
- 临时账号只存在 TemporaryCredentialAuthenticator.cpp。
- 原中文图标完整保留；compiled/ 是逐字节相同、仅英文命名的 RCC 输入。
- 原候选截图只作追溯；本次截图与 QA 联系表分别位于 artifacts/captures 和 artifacts/qa。

## 6. 导航、角色与状态

| From | Event | Guard | To | 失败行为 | 证据 |
|---|---|---|---|---|---|
| PAGE-S-LOGIN | 提交 00/00 | TemporaryCredentialAuthenticator → Administrator | PAGE-A-SHELL / Main | N/A | 用户确认 + CTest PASS |
| PAGE-S-LOGIN | 提交 01/01 | TemporaryCredentialAuthenticator → Client | PAGE-C-SHELL / Main | N/A | 用户确认 + CTest PASS |
| PAGE-S-LOGIN | 其他非空组合 | Invalid | 留在登录页 | 通用错误；清空密码并恢复焦点 | CTest PASS |
| PAGE-S-LOGIN | 空账号或密码 | 本地字段校验 | 留在登录页 | “请输入账号和密码” | 既有实现 |

成功顺序：禁用登录控件 → 清空密码 → 隐藏登录页 → 切换当前角色 QSS → 创建并显示角色窗口 → 关闭并销毁登录页。关闭角色窗口后退出应用。用户名沿用既有 trimmed() 处理；密码不裁剪空格。

## 7. 设计令牌与资源

- 各样板原 QSS 仍是角色视觉事实源；不创建冲突的跨角色 token。
- QApplication 同一时刻只加载 startup.qss、admin.qss 或 client.qss 之一。
- 公共侧栏资源提供 :/sidebar-icons/* alias，没有擅自决定 iconSize、状态变体或按钮替换范围。
- 详见 docs/ui/DESIGN_TOKENS.md 与 docs/ui/reference/MANIFEST.md。

## 8. TBD 与决定记录

| ID | 问题 / 决定 | 依据 | 影响 | 状态 |
|---|---|---|---|---|
| TBD-INT-001 | 单进程与临时角色路由 | 用户于 2026-11-02 指定 00/00 与 01/01 | 本轮主程序 | Closed / 已实施验证 |
| TBD-INT-002 | 正式 Qt、编译器、DPI/DPR、字体与客户区 | 只有本机 Qt 6.8.3 候选 | 像素级验收与发布 | Open |
| TBD-INT-003 | 样图、品牌与侧栏 PNG 的正式分发许可 | 用户提供并授权本轮内部整合 | 对外发布 | Open |
| TBD-INT-004 | 五张侧栏 PNG 的按钮映射、尺寸和状态图 | 用户说明后期需要时调用 | 实际替换控件 | Open；仅编译资源 |
| TBD-INT-005 | 生产认证、账号存储、会话撤销与退出登录 | M5 已有 session/授权/审计边界，身份来源仍为临时明文映射 | 生产安全与完整工作流 | Partially closed；生产身份 adapter 发布前必须替换 |

## 9. 工作包与修改边界

| Work Package | 目标 | allowlist | 不变量 / denylist | 验证 |
|---|---|---|---|---|
| WP-INT-01 | 复制三个样板与证据 | 新文件夹 apps、artifacts/source-baselines | 不修改原目录；不复制 build/dist | 初始 58/58 文件哈希一致 |
| WP-INT-02 | 根工程与预览 target | 根 CMake、脚本、apps/*/CMakeLists | 不改变页面结构/业务语义 | 全目标 Release build |
| WP-INT-03 | 单进程与角色路由 | apps/integrated、角色命名空间、登录清密接口 | 不实现正式权限或存储 | 2 项 CTest |
| WP-INT-04 | 共享侧栏资源 | shared/resources、相关 CMake | 不替换现有按钮 | RCC build、派生哈希 |
| WP-INT-05 | 部署与 QA | deploy.ps1、tools、artifacts/captures、docs | 默认包不含预览 EXE | deploy/run、13 截图、12 状态哈希 |

回退方式：删除 C:\Users\91463\Documents\ChatGPT\N.UI\TDLAS-Hydrogen-UI-Suite；三个原样板不受影响。

## 10. 验证与截图矩阵

| VER ID | 类型 | 命令 / 操作 | 实际结果 |
|---|---|---|---|
| VER-INT-001 | configure/build | .\build.ps1 -QtRoot C:\Qt\6.8.3\msvc2022_64 -Target all | PASS；主程序、3 预览、2 测试 EXE 生成 |
| VER-INT-002 | unit/GUI | ctest --test-dir build -C Release --output-on-failure | PASS；2/2，0.34 s |
| VER-INT-003 | render | .\tools\capture-all.ps1 | PASS；13/13 exit 0、PNG 非空 |
| VER-INT-004 | source parity | 原目录当前 dist EXE 现场捕获 12 个状态并与整合预览比较 SHA-256 | PASS；12/12 完全一致 |
| VER-INT-005 | visual | 查看 artifacts/qa/capture-contact-sheet.png | PASS（结构级）；无缺失、拉伸或主要溢出 |
| VER-INT-006 | deploy | .\deploy.ps1 | PASS；默认仅 tdlas_hydrogen_ui.exe，Qt/MSVC 必需文件齐全，55.88 MiB |
| VER-INT-007 | app-local run | 清除 Qt SDK PATH 后运行 dist 主程序 --capture | PASS；exit 0，截图与 build 版哈希一致 |

构建期间唯一工具提示为可选 Vulkan headers 未安装；本工程只链接 Qt Widgets，不使用 Vulkan。windeployqt 未找到可选 dxcompiler/dxil，不影响本轮 app-local 启动验证。

候选截图：artifacts/captures 下 14 张（13 状态 + 部署登录复验）；均为本轮实际运行输出。整合登录图与独立登录图哈希一致。

正式设备、算法、摄像、数据、授权和像素级目标环境回归未运行，因为相关接口与校准环境不在本轮范围。

## 11. 差异、确认与交付

- 差异日志：docs/ui/DISCREPANCY_LOG.md。
- 本次结构决定：一个正式单进程主程序 + 三个不随默认包发布的开发预览目标。
- 已关闭：同名 C++ 类冲突、三 main 冲突、跨角色 QSS 污染风险、旧 CMake cache 搬运风险、测试 Qt DLL 路径。
- allowlist 外变化：无；原 E:\AI\氢气3.0 目录未修改。
- 验证结论：本轮工程整合、临时登录路由、构建、测试、部署和结构级视觉回归通过。
- 剩余限制：TBD-INT-002～005；尤其临时凭据不是生产认证。

## 12. 2026-11-04 基线复验

- 正式主程序与全目标 Release build：PASS。
- CTest：2/2 PASS；初次 0.35 s，提交前复验 0.38 s。
- 版本化截图：`docs/ui/baseline/2026-11-04/`，13/13 成功并完成结构级目视检查。
- 用户指定 `dist/tdlas_hydrogen_ui.exe` 可 app-local 截图，且与本轮 build EXE 的 SHA-256 一致。
- build/dist 运行环境的登录截图有 0.083543% 局部像素差，未证明为 UI 结构差异；详见 `UI-DIFF-008` 和 `docs/Baseline_Audit.md`。
- 本轮未改 `.cpp`、`.h`、QSS、QRC、CMake 或脚本行为；未运行真实硬件、算法数值等价、摄像、存储和生产 DPI 验收。

## 13. M2 公共闭环增量

### 13.1 页面绑定

| 页面 | 稳定 intent | 展示输入 | 状态 |
|---|---|---|---|
| PAGE-A-SHELL | `startMeasurementRequested` / `stopMeasurementRequested` / `resetMeasurementRequested` | `MeasurementDisplayModel` | IMPLEMENTED |
| PAGE-C-SHELL | 同上 | `MeasurementDisplayModel` | IMPLEMENTED |

两端均复用既有侧栏、顶栏、结果卡和图表区域；没有新增、删除或移动可见控件。`startAcquisitionButton`、`stopAcquisitionButton`、`measurementStatusLabel`、`fvChart`、`peakTrendChart` 只作为稳定测试/绑定 ID，不改变布局或 QSS。

### 13.2 交互与状态

- Idle：开始可用、停止禁用；界面保留最后一次结果。
- Preparing/Running：开始禁用、停止可用；顶栏明确显示模拟设备/模拟采集，图表消费有界展示模型。
- Stopping：开始/停止均禁用，完成后回到 Idle。
- Faulted：开始/停止禁用，可通过既有复位按钮发出 typed reset intent。
- 浓度在所有 M2 状态保持“未校准”；峰值、光强和图表均标注“模拟”。

### 13.3 M2 验证

| VER ID | 类型 | 实际结果 |
|---|---|---|
| VER-M2-001 | Release 全目标构建 | PASS |
| VER-M2-002 | 核心单元与既有回归 | CTest 4/4 PASS，最终复验 0.94 s |
| VER-M2-003 | 管理员/客户端离屏开始→数据→图表→停止 | PASS（包含在 `tdlas_measurement_ui_flow`） |
| VER-M2-004 | 标准截图矩阵 | PASS，13/13 非空；管理员/客户端主页面结构目视无回归 |

正式算法数值等价、真实设备时序、目标机 DPI/DPR 和像素级视觉验收不属于本项通过结论。

## 14. M3 测量核心完善

### 14.1 参数交互

- 管理员端与客户端参数抽屉的既有控件映射为 `ParameterDraft`；保存发出 typed draft，由正式组合根调用 `ParameterService`。
- 校验成功生成新的进程内参数快照并显示 revision；校验失败显示首个字段错误且不替换当前快照；运行期间拒绝改参。
- 正式应用初始使用 mock 参数：5120 Hz、256 点、`sim/ai0`、AO 关闭。preview target 不注入这些运行值，继续保持批准的静态截图 fixture。
- 本轮不增加/移动控件，不修改 QSS；没有配置文件保存、设备枚举或真实硬件范围校验。

### 14.2 图表与刷新

- `ChartWidget` 的运行数据入口为 `ChartSeriesData{x[], y[], xUnit, yUnit, validity}`；主/拟合曲线分别携带实际坐标和值，坐标刻度由实际数据范围计算。
- mock 无批准频率换算，波形/吸光度横轴明确使用样本序号；峰值趋势使用 acquisition sequence。静态 preview 在没有运行数据时仍绘制原 fixture。
- application service 每块处理数据，但默认每 100 ms 最多向 UI 发布一次最新数据帧；状态变化即时发布。停止后保持最后一帧且无后续定时刷新。

### 14.3 生命周期状态

- `Idle`：开始可用、停止禁用、允许保存参数。
- `Preparing/Running`：开始禁用、停止可用、拒绝保存参数。
- `Stopping`：开始/停止均禁用；mock 资源释放后进入 `Idle`。
- `Faulted`：显示故障、开始/停止禁用；采集缓存已清空且设备已断开，通过既有复位 intent 回到 `Idle`。
- 角色窗口销毁与 controller 析构均触发同一停止清理路径；仍未实现退出登录/切换角色流程。

### 14.4 M3 验证

| VER ID | 类型 | 实际结果 |
|---|---|---|
| VER-M3-001 | Release 全目标构建 | PASS；Qt 6.8.3 + MSVC 2022 x64 |
| VER-M3-002 | 核心/既有回归 | CTest 4/4 PASS，最终 1.42 s |
| VER-M3-003 | 管理员/客户端离屏闭环 | PASS；256 点实际 x=0..255、开始→限频数据→停止 |
| VER-M3-004 | 标准截图矩阵 | PASS，13/13 非空 |
| VER-M3-005 | 静态视觉基线 | PASS，标准 13/13 PNG SHA-256 与版本化基线一致 |

本项不声明真实硬件时序、正式算法/频率轴、浓度、配置持久化或目标环境像素级验收通过。

## 15. M4 正式光谱算法接入

### 15.1 页面绑定与单位

- 管理员端和客户端没有新增、删除或移动可见控件，QSS 与既有布局不变。
- 正式组合根仍使用 mock acquisition，但算法改为 `tdlas-v1.6-ui`；256 点/周期、20 周期组为 5120 点窗口，输出 30%～90% 截取后的 155 点曲线。
- FV/拟合运行曲线的 x 使用 `relativeFrequencyCm1`，横轴标签切换为“相对频率（cm⁻¹）”；峰值趋势仍使用 acquisition sequence。
- 管理员 FV 图同时绘制吸光度与 Voigt 拟合吸光度；客户端 FV 图显示拟合吸光度。图表右上角继续标“SIM · 模拟数据”，因为采集输入仍来自 mock。
- 峰值和光强继续标注“模拟”；浓度保持“— 未校准”，不会用峰值或光强代替浓度。

### 15.2 线程与状态

- 原始块通过 queued connection 发送到单一算法 worker；UI 线程只接收处理结果并限频绘制。
- 停止、故障、窗口关闭后不接受迟到算法结果；service 析构会停止刷新、释放 mock acquisition 并等待算法线程退出。
- 算法组窗期间界面保持 Running，不发布空曲线；完整窗口处理成功后才替换展示模型。

### 15.3 M4 验证

| VER ID | 类型 | 实际结果 |
|---|---|---|
| VER-M4-001 | Release 全目标构建 | PASS；Qt 6.8.3 + MSVC 2022 x64 |
| VER-M4-002 | 算法数值回归 | PASS；参考配置 100000 点固定窗口金标、已知 Voigt 参数恢复、流式组窗、NaN 拒绝、浓度无伪值 |
| VER-M4-003 | worker/lifecycle 回归 | PASS；算法实际运行在线程 worker，旧 run/停止后结果不发布 |
| VER-M4-004 | 管理员/客户端离屏闭环 | PASS；155 点相对频率跨零、管理员拟合双曲线、开始→数据→停止 |
| VER-M4-005 | 静态视觉基线 | PASS；标准截图 13/13 非空且 SHA-256 与 `docs/ui/baseline/2026-11-04` 完全一致 |

M4 的“正式”只指已根据提供资料实现光谱处理代码，不代表 MATLAB `filtfilt/lsqcurvefit` 逐点等价、目标硬件频率标定有效或氢浓度已校准。

## 16. M5 数据管理与系统基础设施

### 16.1 页面绑定与不变量

- 管理员端、客户端既有“数据保存”按钮改为 typed `saveExperimentRequested`，仅查询当前自动保存状态；文件路径、目录创建和序列化全部位于 application/storage 层。
- 每次开始测量前生成实验 ID，并在现有状态提示中显示；运行中提示“正在自动保存”，正常停止后提示“已保存”。未生成实验时不伪造成功。
- 开始、停止、复位、改参和保存状态查询均在 `IntegratedApplicationController` 经过 `IAuthorizationService`；隐藏按钮或页面路由不作为授权依据。
- 没有新增、删除或移动可见控件，没有改 QSS、尺寸、布局或静态 fixture。preview target 不加载存储、权限或审计服务。

### 16.2 状态与失败反馈

- Preparing：实验目录、manifest 和参数快照创建成功后才启动 mock 采集；创建失败直接进入 Faulted。
- Running：原始块与完整处理结果在 storage worker 顺序写入；UI/算法线程不直接执行持续文件 I/O。
- Stopping：停止采集后排空此前写入并结束 manifest；成功进入 Idle，写失败进入 Faulted。
- Storage fault：显示 repository 返回的用户消息，停止并断开 mock 采集；错误码、路径和技术诊断进入 error/audit 轨迹。
- “数据保存”按钮不触发重复导出或覆盖，只按 `NotStarted/Saving/Saved/Failed` 反馈当前实验 ID 的自动保存状态；保存失败后复位也不会误报成功。

### 16.3 M5 验证

| VER ID | 类型 | 实际结果 |
|---|---|---|
| VER-M5-001 | Release 全目标构建 | PASS；Qt 6.8.3 + MSVC 2022 x64 |
| VER-M5-002 | 数据基础设施 | PASS；配置往返、UTC 目录/命名、参数/原始/结果/manifest/log 内容、重复拒绝、正常 flush、写失败安全停止 |
| VER-M5-003 | 权限/审计 | PASS；管理员/客户端/过期会话矩阵，JSONL 审计落盘 |
| VER-M5-004 | 管理员/客户端离屏闭环 | PASS；开始→自动保存提示→155 点曲线→停止，两角色均通过 |
| VER-M5-005 | 静态视觉基线 | PASS；标准截图 13/13 非空，SHA-256 与 `docs/ui/baseline/2026-11-04` 完全一致 |

M5 不把临时账号描述为生产认证，也不声明真实硬件吞吐、磁盘容量/保留期、崩溃恢复、媒体保存或导出已完成。

## 17. M7 摄像完整闭环

### 17.1 页面绑定与视觉不变量

- 管理员/客户端既有相机选择、拍照、开始录像、停止录像、录像时长、媒体项和 `CameraPreviewWidget` 已改为 typed intent / `CameraDisplayModel`；未新增、删除或移动可见控件，QSS 与批准布局不变。
- 正式组合的预览 surface 绘制 host-supplied `QImage` 和实际 source/format 状态；preview target 不创建 camera service，继续绘制原稳定模拟 fixture。
- 设备列表来自 adapter 运行时枚举。正式程序的 Qt Multimedia 真实列表在未选择时显示“请选择已授权摄像头”，不会因进入页面自动打开设备；preview/测试的 mock 自动预览并明确标“模拟”。
- 拍照/录像按钮只在预览就绪时可用；停止只在 Recording 可用。异步保存结果、断线和错误通过既有通知区及控件 tooltip 反馈，不移动键盘焦点；摄像按钮和状态标签增加 accessible name。

### 17.2 实验、线程与文件生命周期

- 拍照/录像要求测量 Running 且已有合法实验 ID；否则显示“请先开始实验”，不写孤立媒体。
- camera worker 独立于 acquisition、algorithm、storage 和 UI 线程，负责设备、帧、JPEG 编码和文件 I/O。UI 预览约 15 fps，最大展示副本 1280×720；媒体保存使用原始帧。
- 照片为 PNG；录像为逐帧 JPEG 的 `.mjpeg`。两者写入 `<experiment>/media/`，并由 `index.jsonl` 记录实验/摄像会话/设备/时间/帧数/格式。`QSaveFile` 保证最终文件只在成功完成后出现。
- 正常停止、窗口销毁和 controller 析构会完成录像并停止预览/断开设备/等待 worker；运行中断线取消未提交录像且不留下最终文件，UI 进入 Faulted。切换摄像页面或打开位移/缩放浮层不改变摄像会话。
- `UseCamera` 与 `SaveExperiment` 在 controller 边界授权；管理员和客户端均允许，结果写 camera audit。位移/缩放仍只解释为显示变换，不控制实体镜头。

### 17.3 M7 验证

| VER ID | 类型 | 实际结果 |
|---|---|---|
| VER-M7-001 | Release 全目标构建 | PASS；Qt 6.8.3 + MSVC 2022 x64，Qt Multimedia 链接成功 |
| VER-M7-002 | camera core | PASS；mock 枚举/预览、PNG、MJPEG、1.4 媒体索引、断线原子取消、shutdown 完成录像并释放 |
| VER-M7-003 | 管理员/客户端离屏闭环 | PASS；实验前拒绝拍照，测量 Running 时拍照/录像保存，录像期间测量保持 Running |
| VER-M7-004 | 真实 adapter 边界 | PASS（构建/代码路径）；默认未选择，未枚举后连接或打开真实硬件；实机行为未验收 |
| VER-M7-005 | 静态视觉基线 | PASS；标准截图 13/13 非空，SHA-256 与 `docs/ui/baseline/2026-11-04` 完全一致 |

M7 的“完整闭环”指 mock 与文件/线程/UI/生命周期端到端已验证，以及 Qt Multimedia adapter 已实现并可显式选择；不表示索尼 IMX415 或任一 UVC 摄像头的分辨率、帧率、曝光能力、断线时延、编码吞吐和图像质量已实机验证。

## 18. V3.1 管理员峰值页

- 趋势、明细和 CSV 共用按 `(runId, sourceSequence)` 排序的 PeakRecord 源序列；采集 UTC 时间以本机时区显示，CSV 同时保留 UTC、IANA 时区、offset、参数 snapshot、设备来源及算法/标定版本。
- 峰值从质量有效 FV 中有限拟合吸光度样点取最大值并保存对应 peakX；空/全无效曲线保留 null/原因并断线。不同 run 分色分段，不跨 run 连线。
- 时间筛选包括当前/全部 run、1/10/30/60 分钟和自定义；明细可排序和折叠。图上两点区间放大、滚轮选 X/Y、右键复位；查看历史暂停跟随，返回实时恢复。
- 导出全量筛选源记录，由独立 worker 原子提交并在成功后提示；绘图像素聚合不减少导出行数。交互及 6000+ 行 CSV 单测证据见 `artifacts/qa/peak-v3.1-20261106/`。
- 可用模拟源记录覆盖 UI/CSV；真实 NI 时间/曲线及标定仍待现场实测，不以 mock 验收替代实机结果。

## 19. 2026-11-09 20 周期平均拟合与 FV 同步

本节优先于前文历史数据展示描述：连续累计 20 个完整锯齿周期后进行相位对齐、逐点平均，再拟合并同步发布。调试页拟合图蓝线显示该组平均波形（含平均回落/回升端点），红线显示同一平均波形有效截取区间的 Voigt 拟合电压，共用平均周期秒轴与电压零点。标题及图例标注“20 周期平均”；不得把裁剪段横向拉伸成完整周期。组间保持上一组完整结果，不逐周期更新拟合/FV/峰值；原始信号图继续展示实时采集块。

管理员主页面、调试页和客户端 FV 图只显示同组平均波形的拟合吸光度。拟合图、FV、峰值使用同一个结果与来源时间，组窗互不重叠。序号缺口、overrun、丢块、run/参数快照/采样率变化后重新累计。一次采集期间 FV 纵轴仅在超出范围时扩展，无数据时清空范围历史。单帧 Voigt 保持模型平滑，幅值/线宽/峰位由当前 20 周期平均数据决定。

Windows 软件验收环境为 Qt 6.11.2 / MSVC 2022 x64 Release；本轮证据见 `artifacts/qa/average20-sync-20261109/`，此前单周期记录见 `artifacts/qa/single-cycle-fv-20261109/`。未连接 NI 或样气，不宣称实机或像素级等价验收。
