# V3.2.2 相机设备控制修改与验收报告

日期：2026-11-12（Asia/Shanghai）。

## 结论与交付

方向及缩放按钮已由 V3.2.1 的软件画布操作改为真实相机 Pan／Tilt／Zoom 控制。软件仅保留 90° 旋转。程序增加驱动当前值、范围／步长提示、边界禁用和写入失败反馈。

- 正式发布目录：`D:\V3.1\发布包\tdlas-hydrogen-ui-3.2.2-win64`。
- 发布 ZIP：`D:\V3.1\发布包\tdlas-hydrogen-ui-3.2.2-win64.zip`。
- 源码工程：`D:\V3.1\camera-work`。
- 干净源码 ZIP：`D:\V3.1\源码包\氢气测量-v3.2.2-camera-source.zip`。
- 人工复验入口：发布目录 `相机人工复验.cmd`，真实系统相机＋模拟 NI。
- 正式 EXE SHA-256：`43292FF797DCD3074D1AB7D87C575520BA452F9BEC029B72274C877818A34A95`。
- 保留 V3.2.0、V3.2.1 发布目录与源码包；本次没有覆盖这些版本。

## 人工复验结果

已打开正式 V3.2.2 程序，要求使用管理员 `00/00` 登录并选择 `4K ZOOM CAMERA`，先缩小，再验证上下左右、长按和 90° 旋转。

用户在本轮明确反馈：**“取景位移、缩放和旋转正常”。**

据此记录本轮人工视觉复验通过。没有将该反馈扩展为机械云台／光学变焦证明、客户端单独人工验收或其他未反馈项目的确认。用户继续操作后的设备当前值不再被测试脚本恢复或覆盖。

## 修改范围

- `CameraHardwareControls`：设备原始值、读取／手动写入能力、方向／步长／边界、复位规则。
- `WindowsCameraControls`：按当前设备实例匹配 Windows 控制接口，保留 Qt Multimedia/FFmpeg 采集；COM 对象在 worker 创建、使用、释放。写入前校验范围和步长，写入后回读确认。
- `ICameraDevice`、真实／模拟设备：增加控制端口。未实现的设备显式不支持，不静默用软件变换替代。
- `CameraWorker`、`CameraApplicationService`：设备命令异步执行；最多一个在途请求与一个最新待发意图；100 ms 调度、1 秒回读，会话变更／停止／故障取消待发。已开始的单次驱动调用可能完成。
- 两端窗口、正式控制器：连接设备控制与展示状态，支持边界禁用／错误反馈；软件缩放和位移始终保持默认，仅旋转改变。
- 新增设备规则与服务测试，更新两端按钮集成测试，新增显式真实设备复验工具。
- 版本与发布脚本升级为 3.2.2，提供相机人工复验入口和说明。测量持久化合同仍为 1.7，相机控制合同更新为 2.0。

详细文件清单：`changed-files.json`；相对 V3.2.1 主工程的文本补丁：`camera-device-controls.patch`。

## 自动化软件验证

环境：Windows x64、Qt 6.8.3、MSVC 2022 Release、CMake 3.30.5。

工程根执行：

```powershell
.\build.ps1 -QtRoot 'C:\Qt\6.8.3\msvc2022_64' -BuildDirectory build-ascii -RunTests
```

最终结果：**19/19 PASS，20.56 秒**。日志：工程根 `hardware-final-validation.log`，本目录 `logs/` 有副本。

验证范围包括：

- 驱动范围与步长、边界不重复写、失败反馈、默认值复位及不支持轴。
- 异步服务、突发请求合并、停止取消待发、会话隔离、软件缩放／位移不改变。
- 管理员和客户端的实际按钮到设备模拟状态链路、长按、切页、旋转和禁用状态。
- 原有算法金标、测量 UI、相机媒体保存、异常释放和软件稳定性回归。

## 真实相机验证

目标：`4K ZOOM CAMERA`，USB `VID_1BCF&PID_2CD1&MI_00`。按完整设备实例匹配，未选择 Integrated Camera 或 OBS Virtual Camera。

显式设备测试工具 `tdlas_camera_hardware_review.exe --exercise` 启动真实视频预览，经正式控制器与界面按钮发出操作，以独立原生控制句柄回读核对。NI 始终为模拟，未启动 NI 实采。

最终管理员端与客户端分别验证六个按钮：

| 按钮 | 期望值与驱动回读 | 结果 |
|---|---|---|
| 向右／向左 | Pan：18 → 19 → 18 | 两端通过 |
| 向上／向下 | Tilt：-29 → -28 → -29 | 两端通过 |
| 缩小／放大 | Zoom：260 → 259 → 260 | 两端通过 |

软件视图在六个操作中保持 zoom=1、offset=0。单独点击 90° 后设备 PTZ 不变。两轮测试结束均确认恢复 Pan=18、Tilt=-29、Zoom=260。测试使用最小驱动步长，没有执行全设备出厂恢复。

证据：

- `real-admin/real-control-verification.json`
- `real-client/real-control-verification.json`
- 两目录中的 `real-before.png`、各按钮截图及 `real-software-rotation-90.png`。
- 原生日志 `hardware-real-admin.log`、`hardware-real-client.log`，已复制到 `logs/`。

自动 JSON 中的 `humanVisualAcceptance: pending user review` 表示该测试工具运行时尚未收到人的反馈，属于保留的原始测试证据；本报告的人工结果来自之后收到的用户确认，不追改原始机器日志。

## 运行包验证

另外采集 13 组静态页面前后截图：与 V3.2.1 相比，11 组像素完全一致，只有两端控制面板变化（67171／71192 像素）。数据见 `visual-comparison.json`，复现脚本为 `compare-versions.ps1`。已查看两角色真实相机截图，状态与新增反馈完整可见。

```powershell
.\deploy.ps1 -QtRoot 'C:\Qt\6.8.3\msvc2022_64' -BuildDirectory build-ascii -PackageDirectory 'D:\V3.1\发布包' -ReleaseVersion 3.2.2
& 'D:\V3.1\发布包\tdlas-hydrogen-ui-3.2.2-win64\verify-package.ps1' -PackagePath 'D:\V3.1\发布包\tdlas-hydrogen-ui-3.2.2-win64'
```

- Windows 平台便携包登录启动冒烟通过。
- **49 个清单文件及 SHA256SUMS 校验通过**。
- 通过正式发布 EXE 打开人工复验会话，记录见 `manual-review-session.json`。
- 人工复验时清除 Qt 插件覆盖，显式使用 Windows 平台，避免将仅有 Windows 插件的包误以 offscreen 平台启动。

## 使用边界

- 参数范围为驱动原始单位，不宣称为倍率或实际机械角度。设备电子 PTZ 与机械／光学结构仍需厂商资料确认。
- Zoom=260 已达上限时，“放大”禁用正确，应先缩小。
- 设备取景变化会进入源视频及照片／录像；软件旋转仍只影响预览。
- 初始化、停止和退出不自动改写 PTZ；显式复位写入驱动默认值，曝光和自动对焦不变。Windows 持久默认设置不由本功能修改。
- 浓度标定、生产认证、其他型号相机、NI 实采及长时现场稳定性等原有 TBD 未关闭。
- 本次只扩展既有控制面板容纳设备状态，保持页面、导航与整体样式；未知目标机 DPI／主题不作像素级验收声明。
