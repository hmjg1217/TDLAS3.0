#include "camera/CameraApplicationService.h"
#include "camera/MockCameraDevice.h"

#include <QCoreApplication>
#include <QDir>
#include <QElapsedTimer>
#include <QFile>
#include <QFileInfo>
#include <QTemporaryDir>
#include <QThread>

#include <cstdio>
#include <functional>
#include <memory>

namespace {

bool waitFor(const std::function<bool()> &condition, int timeoutMilliseconds = 3000)
{
    QElapsedTimer timer;
    timer.start();
    while (!condition() && timer.elapsed() < timeoutMilliseconds) {
        QCoreApplication::processEvents(QEventLoop::AllEvents, 10);
        QThread::msleep(1);
    }
    return condition();
}

QString createExperimentDirectory(
    const QString &root,
    const tdlas::contracts::ExperimentId &experimentId)
{
    const QString directory = QDir(root).filePath(
        QStringLiteral("2026/11/04/%1").arg(experimentId.value));
    return QDir().mkpath(directory) ? directory : QString();
}

bool verifyMediaClosedLoop(const QString &root)
{
    tdlas::camera::MockCameraOptions options;
    options.frameIntervalMilliseconds = 12;
    options.frameSize = QSize(160, 90);
    tdlas::camera::CameraApplicationService service(
        std::make_unique<tdlas::camera::MockCameraDevice>(options), root);

    tdlas::camera::CameraDisplayModel latest;
    QVector<tdlas::camera::MediaResult> mediaResults;
    QVector<tdlas::contracts::ModuleError> errors;
    QObject::connect(&service, &tdlas::camera::CameraApplicationService::displayModelChanged,
        &service, [&](const tdlas::camera::CameraDisplayModel &model) { latest = model; });
    QObject::connect(&service, &tdlas::camera::CameraApplicationService::mediaCompleted,
        &service, [&](const tdlas::camera::MediaResult &result) { mediaResults.push_back(result); });
    QObject::connect(&service, &tdlas::camera::CameraApplicationService::errorOccurred,
        &service, [&](const tdlas::contracts::ModuleError &error) { errors.push_back(error); });

    service.refreshDevices();
    if (!waitFor([&]() { return latest.devices.size() == 1; })
        || latest.devices.first().id != QStringLiteral("mock-camera-0")
        || latest.devices.first().sourceKind != tdlas::contracts::DataSourceKind::Simulation) {
        std::fprintf(stderr, "camera enumeration failed\n");
        return false;
    }
    service.startPreview(QStringLiteral("mock-camera-0"));
    if (!waitFor([&]() {
            return latest.state == tdlas::camera::CameraSessionState::Previewing
                && latest.latestFrame.has_value()
                && latest.latestFrame->isValid();
        })) {
        std::fprintf(stderr, "camera preview failed: %s\n", latest.statusMessage.toUtf8().constData());
        return false;
    }

    const QDateTime fixedStart = QDateTime::fromString(
        QStringLiteral("2026-11-04T08:09:10.111Z"), Qt::ISODateWithMs);
    const tdlas::contracts::ExperimentId experimentId =
        tdlas::contracts::createExperimentId(fixedStart);
    const QString experimentDirectory = createExperimentDirectory(root, experimentId);
    if (experimentDirectory.isEmpty()) {
        return false;
    }

    service.capturePhoto(experimentId);
    if (!waitFor([&]() { return mediaResults.size() >= 1; })
        || !mediaResults.at(0).success
        || mediaResults.at(0).mediaType != tdlas::camera::MediaType::Photo
        || mediaResults.at(0).experimentId != experimentId
        || !QFileInfo::exists(mediaResults.at(0).path)
        || !QFileInfo(mediaResults.at(0).path).absoluteFilePath().startsWith(
            QDir(root).absoluteFilePath(QStringLiteral("拍照摄像")))) {
        std::fprintf(stderr, "photo capture failed\n");
        return false;
    }

    service.startRecording(experimentId);
    if (!waitFor([&]() { return latest.state == tdlas::camera::CameraSessionState::Recording; })
        || !waitFor([&]() { return latest.recordingDurationMilliseconds >= 70; })) {
        std::fprintf(stderr, "recording did not start\n");
        return false;
    }
    service.stopRecording();
    if (!waitFor([&]() { return mediaResults.size() >= 2; })
        || !mediaResults.at(1).success
        || mediaResults.at(1).mediaType != tdlas::camera::MediaType::Video
        || mediaResults.at(1).experimentId != experimentId
        || mediaResults.at(1).frameCount < 2
        || !QFileInfo::exists(mediaResults.at(1).path)
        || QFileInfo(mediaResults.at(1).path).size() <= 0) {
        std::fprintf(stderr, "video capture failed\n");
        return false;
    }

    QFile video(mediaResults.at(1).path);
    if (!video.open(QIODevice::ReadOnly) || video.read(2) != QByteArray::fromHex("ffd8")) {
        std::fprintf(stderr, "video is not an MJPEG stream\n");
        return false;
    }
    QFile index(QDir(root).filePath(QStringLiteral("拍照摄像/index.jsonl")));
    if (!index.open(QIODevice::ReadOnly | QIODevice::Text)) {
        return false;
    }
    const QByteArray indexBytes = index.readAll();
    if (indexBytes.count('\n') != 2
        || !indexBytes.contains(experimentId.value.toUtf8())
        || !indexBytes.contains("\"mediaType\":\"photo\"")
        || !indexBytes.contains("\"mediaType\":\"video\"")) {
        std::fprintf(stderr, "media index association failed\n");
        return false;
    }
    if (!errors.isEmpty()) {
        std::fprintf(stderr, "unexpected camera errors\n");
        return false;
    }

    service.shutdown();
    const bool passed = waitFor([&]() { return latest.state == tdlas::camera::CameraSessionState::Idle; })
        && latest.state == tdlas::camera::CameraSessionState::Idle
        && latest.statusMessage.contains(QStringLiteral("释放"))
        && !service.workerThreadRunning();
    return passed;
}

bool verifyDisconnectCleanup(const QString &root)
{
    tdlas::camera::MockCameraOptions options;
    options.frameIntervalMilliseconds = 5;
    options.frameSize = QSize(80, 45);
    options.disconnectAfterFrames = 40;
    tdlas::camera::CameraApplicationService service(
        std::make_unique<tdlas::camera::MockCameraDevice>(options), root);

    tdlas::camera::CameraDisplayModel latest;
    tdlas::contracts::ModuleError lastError;
    QVector<tdlas::camera::MediaResult> mediaResults;
    QObject::connect(&service, &tdlas::camera::CameraApplicationService::displayModelChanged,
        &service, [&](const tdlas::camera::CameraDisplayModel &model) { latest = model; });
    QObject::connect(&service, &tdlas::camera::CameraApplicationService::errorOccurred,
        &service, [&](const tdlas::contracts::ModuleError &error) { lastError = error; });
    QObject::connect(&service, &tdlas::camera::CameraApplicationService::mediaCompleted,
        &service, [&](const tdlas::camera::MediaResult &result) { mediaResults.push_back(result); });
    service.refreshDevices();
    if (!waitFor([&]() { return !latest.devices.isEmpty(); })) {
        return false;
    }
    service.startPreview(QStringLiteral("mock-camera-0"));
    if (!waitFor([&]() {
            return latest.state == tdlas::camera::CameraSessionState::Previewing
                && latest.latestFrame.has_value();
        })) {
        return false;
    }
    const tdlas::contracts::ExperimentId experimentId = tdlas::contracts::createExperimentId(
        QDateTime::fromString(QStringLiteral("2026-11-04T09:10:11.222Z"), Qt::ISODateWithMs));
    if (createExperimentDirectory(root, experimentId).isEmpty()) {
        return false;
    }
    service.startRecording(experimentId);
    if (!waitFor([&]() { return latest.state == tdlas::camera::CameraSessionState::Recording; })) {
        return false;
    }
    if (!waitFor([&]() { return latest.state == tdlas::camera::CameraSessionState::Faulted; })) {
        std::fprintf(stderr, "disconnect did not reach Faulted\n");
        return false;
    }
    if (lastError.code != QStringLiteral("MOCK_CAMERA_DISCONNECTED")
        || !lastError.requiresStop) {
        std::fprintf(stderr, "disconnect error contract failed\n");
        return false;
    }
    if (!waitFor([&]() { return !mediaResults.isEmpty(); })
        || mediaResults.last().success
        || mediaResults.last().errorCode != QStringLiteral("MOCK_CAMERA_DISCONNECTED")
        || QFileInfo::exists(mediaResults.last().path)) {
        std::fprintf(stderr, "disconnect did not abort the recording atomically\n");
        return false;
    }
    service.shutdown();
    const bool passed = waitFor([&]() { return latest.state == tdlas::camera::CameraSessionState::Idle; });
    return passed;
}

bool verifyShutdownFinalizesRecording(const QString &root)
{
    tdlas::camera::MockCameraOptions options;
    options.frameIntervalMilliseconds = 8;
    options.frameSize = QSize(120, 68);
    tdlas::camera::CameraApplicationService service(
        std::make_unique<tdlas::camera::MockCameraDevice>(options), root);

    tdlas::camera::CameraDisplayModel latest;
    QVector<tdlas::camera::MediaResult> mediaResults;
    QObject::connect(&service, &tdlas::camera::CameraApplicationService::displayModelChanged,
        &service, [&](const tdlas::camera::CameraDisplayModel &model) { latest = model; });
    QObject::connect(&service, &tdlas::camera::CameraApplicationService::mediaCompleted,
        &service, [&](const tdlas::camera::MediaResult &result) { mediaResults.push_back(result); });
    service.refreshDevices();
    if (!waitFor([&]() { return !latest.devices.isEmpty(); })) {
        return false;
    }
    service.startPreview(QStringLiteral("mock-camera-0"));
    if (!waitFor([&]() { return latest.latestFrame.has_value(); })) {
        return false;
    }
    const tdlas::contracts::ExperimentId experimentId = tdlas::contracts::createExperimentId(
        QDateTime::fromString(QStringLiteral("2026-11-04T10:11:12.333Z"), Qt::ISODateWithMs));
    if (createExperimentDirectory(root, experimentId).isEmpty()) {
        return false;
    }
    service.startRecording(experimentId);
    if (!waitFor([&]() {
            return latest.state == tdlas::camera::CameraSessionState::Recording
                && latest.recordingDurationMilliseconds >= 50;
        })) {
        return false;
    }
    service.shutdown();
    if (!waitFor([&]() {
            return latest.state == tdlas::camera::CameraSessionState::Idle
                && !mediaResults.isEmpty();
        })) {
        return false;
    }
    const tdlas::camera::MediaResult &result = mediaResults.last();
    return result.success
        && result.mediaType == tdlas::camera::MediaType::Video
        && result.experimentId == experimentId
        && result.frameCount > 0
        && QFileInfo::exists(result.path);
}

} // namespace

int main(int argc, char *argv[])
{
    QCoreApplication application(argc, argv);
    QTemporaryDir storage;
    if (!storage.isValid()) {
        return 1;
    }
    if (!verifyMediaClosedLoop(storage.path())) {
        return 2;
    }
    if (!verifyDisconnectCleanup(storage.path())) {
        return 3;
    }
    if (!verifyShutdownFinalizesRecording(storage.path())) {
        return 4;
    }
    return 0;
}
