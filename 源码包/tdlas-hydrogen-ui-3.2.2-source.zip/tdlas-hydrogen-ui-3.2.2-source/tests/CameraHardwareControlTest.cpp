#include "camera/CameraHardwareControls.h"
#include "camera/CameraApplicationService.h"
#include "camera/MockCameraDevice.h"
#include <QCoreApplication>
#include <QElapsedTimer>
#include <QTemporaryDir>
#include <QThread>
#include <cstdio>
#include <functional>

using namespace tdlas::camera;
namespace {
bool wait(const std::function<bool()> &condition)
{
    QElapsedTimer clock; clock.start();
    while (!condition() && clock.elapsed() < 4000) {
        QCoreApplication::processEvents(QEventLoop::AllEvents, 10); QThread::msleep(1);
    }
    return condition();
}
bool rules()
{
    CameraControlState state;
    state.pan = {true, true, -100, 100, 5, 0, 0};
    state.tilt = state.pan;
    state.zoom = {true, true, 0, 260, 1, 0, 260};
    int writes = 0;
    const auto write = [&](CameraControlAxis, int, QString &) { ++writes; return true; };
    if (cameraHardwareOperationEnabled(state, CameraViewOperation::ZoomIn)) return false;
    if (!applyCameraHardwareOperation(state, CameraViewOperation::ZoomIn, write) || writes) return false;
    if (!applyCameraHardwareOperation(state, CameraViewOperation::MoveLeft, write) || state.pan.value != -5) return false;
    if (!applyCameraHardwareOperation(state, CameraViewOperation::MoveUp, write) || state.tilt.value != 5) return false;
    const auto failing = [](CameraControlAxis, int, QString &error) { error = QStringLiteral("injected driver failure"); return false; };
    if (applyCameraHardwareOperation(state, CameraViewOperation::ZoomOut, failing)
        || state.zoom.value != 260 || !state.message.contains(QStringLiteral("injected"))) return false;
    state.tilt.writable = false;
    if (applyCameraHardwareOperation(state, CameraViewOperation::MoveDown, write) || state.tilt.value != 5) return false;
    if (!applyCameraHardwareOperation(state, CameraViewOperation::Reset, write)
        || state.pan.value != 0 || state.zoom.value != 0 || state.tilt.value != 5) return false;
    return true;
}

bool service(const QString &root)
{
    CameraApplicationService app(std::make_unique<MockCameraDevice>(), root);
    app.startPreview(QStringLiteral("mock-camera-0"));
    if (!wait([&]() { return app.cameraControls().pan.writable; })) return false;
    app.operateView(CameraViewOperation::MoveRight);
    if (!wait([&]() { return app.cameraControls().pan.value == 1; })) return false;
    if (app.viewState().zoom != 1 || !app.viewState().offset.isNull()) return false;
    // Burst is bounded to a single latest intent rather than a queued 200-step move.
    for (int i = 0; i < 200; ++i) app.operateView(CameraViewOperation::MoveRight);
    if (!wait([&]() { return app.cameraControls().pan.value >= 2; }) || app.cameraControls().pan.value > 3) return false;
    app.operateView(CameraViewOperation::ZoomIn);
    app.stopPreview();
    if (!wait([&]() { return app.displayModel().state == CameraSessionState::Idle; })) return false;
    app.startPreview(QStringLiteral("mock-camera-0"));
    if (!wait([&]() { return app.cameraControls().zoom.readable; }) || app.cameraControls().zoom.value != 0) return false;
    app.operateView(CameraViewOperation::RotateClockwise);
    if (app.viewState().quarterTurns != 1 || app.cameraControls().zoom.value != 0) return false;
    app.operateView(CameraViewOperation::Reset);
    if (!wait([&]() { return app.cameraControls().pan.value == 0; }) || app.viewState().quarterTurns != 0) return false;
    app.shutdown();
    return !app.workerThreadRunning();
}
}
int main(int argc, char **argv)
{
    QCoreApplication app(argc, argv); QTemporaryDir directory;
    if (!rules()) { std::fprintf(stderr,"HARDWARE_CONTROL rules failed\n"); return 1; }
    if (!service(directory.path())) { std::fprintf(stderr,"HARDWARE_CONTROL service failed\n"); return 2; }
    std::printf("HARDWARE_CONTROL limits/step/failure/reset/coalescing/cancel/software-isolation PASS\n");
    return 0;
}
