#include "acquisition/MockAcquisitionDevice.h"
#include "algorithm/MockAlgorithmProcessor.h"
#include "application/MeasurementApplicationService.h"
#include "storage/FileStorageRepository.h"
#include "system/IAuditSink.h"
#include "system/RoleBasedAuthorizationService.h"

#include <QCoreApplication>
#include <QBuffer>
#include <QDir>
#include <QElapsedTimer>
#include <QFile>
#include <QJsonDocument>
#include <QJsonArray>
#include <QJsonObject>
#include <QTemporaryDir>
#include <QThread>
#include <QTextStream>
#include <QStringConverter>

#include <cstdio>
#include <functional>

namespace {

bool waitFor(const std::function<bool()> &condition, int timeoutMilliseconds = 2000)
{
    QElapsedTimer timer;
    timer.start();
    while (!condition() && timer.elapsed() < timeoutMilliseconds) {
        QCoreApplication::processEvents(QEventLoop::AllEvents, 10);
        QThread::msleep(1);
    }
    return condition();
}

tdlas::contracts::RawDataBlock rawBlock(
    const tdlas::contracts::RunId &runId,
    tdlas::contracts::Sequence sequence)
{
    tdlas::contracts::RawDataBlock block;
    block.runId = runId;
    block.streamId = QStringLiteral("test-stream");
    block.sequence = sequence;
    block.sampleStart.utc = QDateTime::fromString(
        QStringLiteral("2026-11-04T03:04:05.678Z"), Qt::ISODateWithMs);
    block.sampleRateHz = 1000.0;
    block.channels = {{QStringLiteral("sim/ai0"), {0.9, 0.7, 0.4, 0.7, 0.9}}};
    block.sampleCountPerChannel = 5;
    block.validity = tdlas::contracts::DataValidity::Valid;
    return block;
}

QJsonObject readJson(const QString &path)
{
    QFile file(path);
    if (!file.open(QIODevice::ReadOnly)) {
        return {};
    }
    return QJsonDocument::fromJson(file.readAll()).object();
}

class FailingStorageRepository final : public tdlas::storage::IStorageRepository
{
public:
    tdlas::storage::StorageOperationResult beginExperiment(
        const tdlas::storage::ExperimentContext &context) override
    {
        activeId_ = context.experimentId;
        return tdlas::storage::StorageOperationResult::succeeded(QStringLiteral("test://experiment"));
    }

    tdlas::storage::StorageOperationResult appendRawData(
        const tdlas::contracts::ExperimentId &,
        const tdlas::contracts::RawDataBlock &) override
    {
        return tdlas::storage::StorageOperationResult::failed(
            QStringLiteral("TEST_DISK_FULL"),
            QStringLiteral("测试磁盘已满。"),
            QStringLiteral("deterministic injected storage failure"));
    }

    tdlas::storage::StorageOperationResult appendProcessingResult(
        const tdlas::contracts::ExperimentId &,
        const tdlas::contracts::ProcessingResult &) override
    {
        return tdlas::storage::StorageOperationResult::succeeded();
    }

    tdlas::storage::StorageOperationResult finishExperiment(
        const tdlas::contracts::ExperimentId &,
        tdlas::storage::ExperimentCompletionStatus,
        const QDateTime &,
        const QString &) override
    {
        return tdlas::storage::StorageOperationResult::succeeded();
    }

    QString experimentDirectory(const tdlas::contracts::ExperimentId &) const override
    {
        return QStringLiteral("test://experiment");
    }

private:
    tdlas::contracts::ExperimentId activeId_;
};

} // namespace

int main(int argc, char *argv[])
{
    QCoreApplication application(argc, argv);
    QTemporaryDir temporary;
    if (!temporary.isValid()) {
        return 1;
    }

    const QDateTime fixedTime = QDateTime::fromString(
        QStringLiteral("2026-11-04T03:04:05.678Z"), Qt::ISODateWithMs);
    const tdlas::contracts::ExperimentId generated = tdlas::contracts::createExperimentId(fixedTime);
    if (!generated.isValid() || !generated.value.startsWith(QStringLiteral("EXP-20261104T030405678Z-"))
        || tdlas::contracts::ExperimentId{QStringLiteral("../escape")}.isValid()) {
        return 2;
    }

    tdlas::storage::StorageConfiguration configuration;
    configuration.rootDirectory = QDir(temporary.path()).filePath(QStringLiteral("data"));
    const QString configurationPath = QDir(temporary.path()).filePath(QStringLiteral("config/storage.json"));
    const auto configurationSave = tdlas::storage::StorageConfigurationStore::save(
        configurationPath, configuration);
    tdlas::storage::StorageOperationResult configurationLoad;
    const auto loaded = tdlas::storage::StorageConfigurationStore::loadOrCreate(
        configurationPath, {}, &configurationLoad);
    if (!configurationSave.success || !configurationLoad.success
        || loaded.rootDirectory != configuration.rootDirectory
        || !loaded.saveRawData || !loaded.saveProcessingResults || !loaded.writeEventLog) {
        return 3;
    }

    tdlas::storage::FileStorageRepository repository(loaded);
    tdlas::storage::ExperimentContext context;
    context.experimentId = generated;
    context.runId = {QStringLiteral("11111111-2222-3333-4444-555555555555")};
    context.parameters = tdlas::contracts::ParameterSnapshot::mockDefaults();
    context.startedAt.utc = fixedTime;
    context.operatorId = QStringLiteral("test-operator");
    const auto begin = repository.beginExperiment(context);
    if (!begin.success) {
        std::fprintf(stderr, "begin failed: %s %s\n",
            begin.code.toUtf8().constData(), begin.diagnostic.toUtf8().constData());
        return 4;
    }
    const QString expectedDirectory = QDir(configuration.rootDirectory).filePath(
        QStringLiteral("2026/11/04/%1").arg(generated.value));
    if (QDir::cleanPath(begin.path) != QDir::cleanPath(expectedDirectory)
        || repository.experimentDirectory(generated) != QDir::cleanPath(expectedDirectory)) {
        return 5;
    }

    const tdlas::contracts::RawDataBlock block = rawBlock(context.runId, 1);
    tdlas::algorithm::MockAlgorithmProcessor algorithm;
    tdlas::contracts::ProcessingResult processing = algorithm.process(block, context.parameters);
    processing.cycleTimeSeconds = {0.0, 0.001, 0.002};
    processing.cycleVoltageV = {0.7, 1.2, 0.7};
    processing.displayVoltageOffsetV = 4.2;
    const auto rawSave = repository.appendRawData(generated, block);
    const auto duplicateRawSave = repository.appendRawData(generated, block);
    const auto resultSave = repository.appendProcessingResult(generated, processing);
    const auto finish = repository.finishExperiment(
        generated,
        tdlas::storage::ExperimentCompletionStatus::Completed,
        fixedTime.addSecs(5));
    if (!rawSave.success || duplicateRawSave.success
        || duplicateRawSave.code != QStringLiteral("STORAGE_SEQUENCE_EXISTS")
        || !resultSave.success || !finish.success) {
        return 6;
    }

    const QJsonObject manifest = readJson(QDir(expectedDirectory).filePath(QStringLiteral("manifest.json")));
    const QJsonObject parameters = readJson(QDir(expectedDirectory).filePath(
        QStringLiteral("parameters/parameter-r1-%1.json").arg(context.parameters.hash.left(12))));
    const QJsonObject result = readJson(QDir(expectedDirectory).filePath(
        QStringLiteral("results/result-000000000001.json")));
    QFile rawFile(QDir(expectedDirectory).filePath(QStringLiteral("raw/raw-000000000001.csv")));
    QFile eventLog(QDir(expectedDirectory).filePath(QStringLiteral("logs/events.jsonl")));
    QByteArray expectedRawCsv;
    {
        QBuffer buffer(&expectedRawCsv);
        buffer.open(QIODevice::WriteOnly);
        QTextStream stream(&buffer);
        stream.setEncoding(QStringConverter::Utf8);
        stream << "experiment_id,run_id,stream_id,sequence,sample_start_utc,sample_rate_hz,channel_id,sample_index,voltage_v,validity,overrun,dropped_before\n";
        for (const auto &channel : block.channels) {
            for (qsizetype index = 0; index < channel.samplesV.size(); ++index) {
                stream << generated.value << ',' << block.runId.value << ',' << block.streamId << ','
                    << block.sequence << ',' << block.sampleStart.utc.toUTC().toString(Qt::ISODateWithMs) << ','
                    << QString::number(block.sampleRateHz, 'g', 17) << ',' << channel.channelId << ','
                    << index << ',' << QString::number(channel.samplesV.at(index), 'g', 17) << ','
                    << "valid" << ',' << (block.overrun ? 1 : 0) << ',' << block.droppedBefore << '\n';
            }
        }
        stream.flush();
    }
    if (!rawFile.open(QIODevice::ReadOnly) || !eventLog.open(QIODevice::ReadOnly)
        || manifest.value(QStringLiteral("experimentId")).toString() != generated.value
        || manifest.value(QStringLiteral("status")).toString() != QStringLiteral("completed")
        || manifest.value(QStringLiteral("rawBlockCount")).toInt() != 1
        || manifest.value(QStringLiteral("resultCount")).toInt() != 1
        || parameters.value(QStringLiteral("hashSha256")).toString() != context.parameters.hash
        || result.value(QStringLiteral("parameterSnapshotId")).toString() != context.parameters.id
        || result.value(QStringLiteral("concentration")).isNull() == false
        || result.value(QStringLiteral("cycleTimeSeconds")).toArray().size() != 3
        || result.value(QStringLiteral("cycleVoltageV")).toArray().at(1).toDouble() != 1.2
        || result.value(QStringLiteral("displayVoltageOffsetV")).toDouble() != 4.2
        || QByteArray(rawFile.readAll()).replace("\r\n", "\n") != expectedRawCsv
        || eventLog.readAll().count('\n') != 2) {
        return 7;
    }
    const auto duplicate = repository.beginExperiment(context);
    if (duplicate.success || duplicate.code != QStringLiteral("STORAGE_EXPERIMENT_EXISTS")) {
        return 8;
    }
    tdlas::storage::FileStorageRepository restartedRepository(loaded);
    const auto restartDuplicate = restartedRepository.beginExperiment(context);
    if (restartDuplicate.success || restartDuplicate.code != QStringLiteral("STORAGE_EXPERIMENT_EXISTS")) {
        return 17;
    }

    const QString impossibleRoot = QDir(temporary.path()).filePath(QStringLiteral("root-is-file"));
    QFile rootFile(impossibleRoot);
    if (!rootFile.open(QIODevice::WriteOnly) || rootFile.write("x") != 1) {
        return 9;
    }
    rootFile.close();
    tdlas::storage::StorageConfiguration impossibleConfiguration;
    impossibleConfiguration.rootDirectory = impossibleRoot;
    tdlas::storage::FileStorageRepository impossibleRepository(impossibleConfiguration);
    tdlas::storage::ExperimentContext impossibleContext = context;
    impossibleContext.experimentId = tdlas::contracts::createExperimentId(fixedTime.addSecs(1));
    const auto impossibleBegin = impossibleRepository.beginExperiment(impossibleContext);
    if (impossibleBegin.success || impossibleBegin.code != QStringLiteral("STORAGE_DIRECTORY_FAILED")) {
        return 10;
    }

    tdlas::system::RoleBasedAuthorizationService authorization;
    tdlas::system::SessionContext administrator{
        QStringLiteral("admin-session"), QStringLiteral("admin"),
        tdlas::system::SystemRole::Administrator,
        fixedTime.addSecs(-1), fixedTime.addSecs(3600), QStringLiteral("test")};
    tdlas::system::SessionContext client{
        QStringLiteral("client-session"), QStringLiteral("client"),
        tdlas::system::SystemRole::Client,
        fixedTime.addSecs(-1), fixedTime.addSecs(3600), QStringLiteral("test")};
    if (!authorization.authorize(administrator, tdlas::system::ProtectedOperation::ManageAuthorization, fixedTime).allowed
        || !authorization.authorize(client, tdlas::system::ProtectedOperation::StartMeasurement, fixedTime).allowed
        || !authorization.authorize(client, tdlas::system::ProtectedOperation::UseCamera, fixedTime).allowed
        || authorization.authorize(client, tdlas::system::ProtectedOperation::ConfigureStorage, fixedTime).allowed
        || authorization.authorize(client, tdlas::system::ProtectedOperation::StartMeasurement, fixedTime.addSecs(7200)).allowed) {
        return 11;
    }

    const QString auditRoot = QDir(temporary.path()).filePath(QStringLiteral("audit"));
    tdlas::system::FileAuditSink audit(auditRoot);
    const auto auditResult = audit.record({
        fixedTime, QStringLiteral("admin"), QStringLiteral("admin-session"),
        QStringLiteral("authorization"), QStringLiteral("configure-storage"),
        QStringLiteral("allowed"), generated.value, context.runId.value, {}});
    QFile auditFile(QDir(auditRoot).filePath(QStringLiteral("audit-2026-11.jsonl")));
    if (!auditResult.success || !auditFile.open(QIODevice::ReadOnly)
        || !auditFile.readAll().contains("configure-storage")) {
        return 12;
    }

    tdlas::acquisition::MockAcquisitionOptions fastOptions;
    fastOptions.blockIntervalMilliseconds = 1;
    tdlas::acquisition::MockAcquisitionDevice storedDevice(fastOptions);
    tdlas::storage::StorageConfiguration serviceConfiguration;
    serviceConfiguration.rootDirectory = QDir(temporary.path()).filePath(QStringLiteral("service-data"));
    tdlas::storage::FileStorageRepository serviceRepository(serviceConfiguration);
    tdlas::application::MeasurementApplicationService storedService(
        storedDevice, algorithm, serviceRepository);
    tdlas::contracts::StartMeasurementRequest request;
    request.parameters = tdlas::contracts::ParameterSnapshot::mockDefaults();
    request.operatorId = QStringLiteral("service-test");
    if (!storedService.start(request)
        || !storedService.currentExperimentId().isValid()
        || !waitFor([&]() { return storedService.displayModel().peakHistory.size() >= 2; })) {
        return 13;
    }
    const tdlas::contracts::ExperimentId storedExperimentId = storedService.currentExperimentId();
    const tdlas::contracts::RunId storedFirstRun = storedService.currentRunId();
    if (!storedService.stop(storedFirstRun)
        || !storedService.start(request)
        || !waitFor([&]() {
            return storedService.state() == tdlas::contracts::MeasurementState::Running
                && storedService.currentRunId() != storedFirstRun;
        })
        || !storedService.stop(storedService.currentRunId())
        || !waitFor([&]() {
            return storedService.state() == tdlas::contracts::MeasurementState::Idle
                && storedService.displayModel().storageState
                    == tdlas::contracts::ExperimentStorageState::Saved;
        })) {
        return 14;
    }
    const QString storedDirectory = serviceRepository.experimentDirectory(storedExperimentId);
    const QJsonObject storedManifest = readJson(QDir(storedDirectory).filePath(QStringLiteral("manifest.json")));
    if (storedManifest.value(QStringLiteral("status")).toString() != QStringLiteral("completed")
        || storedManifest.value(QStringLiteral("rawBlockCount")).toInt() < 2
        || storedManifest.value(QStringLiteral("resultCount")).toInt() < 2) {
        return 15;
    }

    FailingStorageRepository failingRepository;
    tdlas::acquisition::MockAcquisitionDevice failingDevice(fastOptions);
    tdlas::application::MeasurementApplicationService failingService(
        failingDevice, algorithm, failingRepository);
    QString storageErrorCode;
    QObject::connect(
        &failingService,
        &tdlas::application::MeasurementApplicationService::errorOccurred,
        &application,
        [&](const tdlas::contracts::ModuleError &error) {
            if (error.category == QStringLiteral("storage")) {
                storageErrorCode = error.code;
            }
        });
    if (!failingService.start(request)
        || !waitFor([&]() {
            return failingService.state() == tdlas::contracts::MeasurementState::Faulted;
        })
        || storageErrorCode != QStringLiteral("TEST_DISK_FULL")
        || failingDevice.acquisitionState() != tdlas::contracts::AcquisitionState::Idle
        || failingDevice.connectionState() != tdlas::contracts::DeviceConnectionState::Disconnected
        || failingService.displayModel().storageState
            != tdlas::contracts::ExperimentStorageState::Failed
        || !failingService.resetFault()) {
        return 16;
    }

    return 0;
}

