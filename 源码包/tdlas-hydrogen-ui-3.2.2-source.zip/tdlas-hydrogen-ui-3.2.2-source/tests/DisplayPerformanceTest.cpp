#include "acquisition/MockAcquisitionDevice.h"
#include "algorithm/IAlgorithmProcessor.h"
#include "application/MeasurementApplicationService.h"
#include "parameter/ParameterService.h"

#include <QCoreApplication>
#include <QElapsedTimer>
#include <QThread>
#include <QTimer>

#include <cstdio>

namespace {

class FastAlgorithm final : public tdlas::algorithm::IAlgorithmProcessor
{
public:
    tdlas::contracts::ProcessingResult process(
        const tdlas::contracts::RawDataBlock &block,
        const tdlas::contracts::ParameterSnapshot &parameters) const override
    {
        tdlas::contracts::ProcessingResult result;
        result.runId = block.runId;
        result.sourceSequence = block.sequence;
        result.timestamp = block.sampleStart;
        result.parameterSnapshotId = parameters.id;
        result.algorithmVersion = QStringLiteral("display-benchmark");
        result.validity = tdlas::contracts::DataValidity::Uncalibrated;
        result.voltageV = {0.9};
        result.fittedVoltageV = {0.9};
        result.absorbance = {0.1};
        result.fittedAbsorbance = {0.1};
        result.timeSeconds = {0.0};
        result.relativeFrequencyCm1 = {0.0};
        return result;
    }
};

bool runScenario(int records, const tdlas::contracts::ParameterSnapshot &parameters)
{
    tdlas::acquisition::MockAcquisitionOptions acquisitionOptions;
    acquisitionOptions.blockIntervalMilliseconds = 1000000;
    tdlas::acquisition::MockAcquisitionDevice device(acquisitionOptions);
    FastAlgorithm algorithm;
    tdlas::application::MeasurementApplicationService service(device, algorithm);
    int publications = 0;
    int observedRecords = 0;
    bool idlePublished = false;
    QObject::connect(&service, &tdlas::application::MeasurementApplicationService::displayModelChanged,
        &service, [&](const tdlas::contracts::MeasurementDisplayModel &model) {
            ++publications;
            observedRecords = static_cast<int>(model.peakRecords.size());
            idlePublished = idlePublished || model.state == tdlas::contracts::MeasurementState::Idle;
        });
    if (!service.start({parameters})
        || service.state() != tdlas::contracts::MeasurementState::Running) return false;

    const QDateTime startTime = QDateTime::currentDateTimeUtc();
    const auto runId = service.currentRunId();
    QElapsedTimer elapsed;
    elapsed.start();
    for (int sequence = 1; sequence <= records; ++sequence) {
        tdlas::contracts::RawDataBlock block;
        block.runId = runId;
        block.sequence = static_cast<tdlas::contracts::Sequence>(sequence);
        block.sampleStart.utc = startTime.addSecs(sequence);
        block.sampleRateHz = 100000.0;
        block.sampleCountPerChannel = 1;
        block.validity = tdlas::contracts::DataValidity::Valid;
        block.channels.push_back({parameters.aiChannelIds.constFirst(), {0.9}});
        device.rawDataReady(block);
    }
    qint64 longestLoopGapMs = 0;
    QElapsedTimer loopGap;
    loopGap.start();
    QTimer monitor;
    monitor.setInterval(1);
    QObject::connect(&monitor, &QTimer::timeout, &monitor, [&]() {
        longestLoopGapMs = qMax(longestLoopGapMs, loopGap.restart());
    });
    monitor.start();
    while (observedRecords < records && elapsed.elapsed() < 120000) {
        QCoreApplication::processEvents(QEventLoop::AllEvents, 10);
        QThread::msleep(1);
    }
    const qint64 totalMs = elapsed.elapsed();
    monitor.stop();
    const auto snapshot = service.displayModel();
    if (snapshot.peakRecords.size() != records
        || snapshot.peakTrendSeries.x.size() != records
        || snapshot.peakTrendSeries.y.size() != records
        || snapshot.peakHistory.size() != records
        || snapshot.peakRecords.constLast().sequence != static_cast<tdlas::contracts::Sequence>(records)
        || snapshot.peakTrendSeries.y.constLast() != 0.1) return false;
    std::printf("DISPLAY_HISTORY records=%d elapsed_ms=%lld publications=%d max_loop_gap_ms=%lld complete=%d\n",
        records, static_cast<long long>(totalMs), publications,
        static_cast<long long>(longestLoopGapMs), observedRecords == records);
    return observedRecords == records && publications < records
        && service.stop(runId) && idlePublished;
}

bool runWaveformScenario(qsizetype sampleCount, const tdlas::contracts::ParameterSnapshot &parameters)
{
    tdlas::acquisition::MockAcquisitionOptions acquisitionOptions;
    acquisitionOptions.blockIntervalMilliseconds = 1000000;
    tdlas::acquisition::MockAcquisitionDevice device(acquisitionOptions);
    FastAlgorithm algorithm;
    tdlas::application::MeasurementApplicationService service(device, algorithm);
    int rawPublications = 0;
    qint64 firstRawLatencyMs = -1;
    QElapsedTimer timer;
    QObject::connect(&service, &tdlas::application::MeasurementApplicationService::displayModelChanged,
        &service, [&](const tdlas::contracts::MeasurementDisplayModel &model) {
            if (!model.rawSeries.y.isEmpty()) {
                ++rawPublications;
                if (firstRawLatencyMs < 0) firstRawLatencyMs = timer.elapsed();
            }
        });
    if (!service.start({parameters})) return false;
    const auto runId = service.currentRunId();
    tdlas::contracts::RawDataBlock block;
    block.runId = runId;
    block.sampleRateHz = 100000.0;
    block.sampleCountPerChannel = sampleCount;
    block.validity = tdlas::contracts::DataValidity::Valid;
    block.channels.push_back({parameters.aiChannelIds.constFirst(), QVector<double>(sampleCount, 0.9)});
    timer.start();
    QElapsedTimer buildTimer;
    buildTimer.start();
    for (tdlas::contracts::Sequence sequence = 1; sequence <= 20; ++sequence) {
        block.sequence = sequence;
        block.sampleStart.utc = QDateTime::currentDateTimeUtc().addMSecs(sequence);
        device.rawDataReady(block);
    }
    const qint64 dispatchMs = buildTimer.elapsed();
    const bool displayed = service.displayModel().rawSeries.y.size() == sampleCount
        && service.displayModel().rawSeries.x.size() == sampleCount
        && qAbs(service.displayModel().waveformDurationSeconds
            - static_cast<double>(sampleCount) / block.sampleRateHz) < 1e-12;
    QElapsedTimer waitTimer;
    waitTimer.start();
    while (rawPublications < 2 && waitTimer.elapsed() < 500) {
        QCoreApplication::processEvents(QEventLoop::AllEvents, 10);
        QThread::msleep(1);
    }
    std::printf("RAW_DISPLAY samples=%lld dispatch_ms=%lld first_raw_ms=%lld publications=%d complete=%d\n",
        static_cast<long long>(sampleCount), static_cast<long long>(dispatchMs),
        static_cast<long long>(firstRawLatencyMs), rawPublications, displayed);
    return displayed && rawPublications >= 2 && rawPublications < 20
        && firstRawLatencyMs >= 0 && firstRawLatencyMs < 33
        && service.stop(runId);
}

bool verifyHistoryEdges(const tdlas::contracts::ParameterSnapshot &parameters)
{
    tdlas::acquisition::MockAcquisitionOptions acquisitionOptions;
    acquisitionOptions.blockIntervalMilliseconds = 1000000;
    tdlas::acquisition::MockAcquisitionDevice device(acquisitionOptions);
    FastAlgorithm algorithm;
    tdlas::application::MeasurementApplicationOptions options;
    options.peakHistoryCapacity = 3;
    tdlas::application::MeasurementApplicationService service(device, algorithm, options);
    const QDateTime base = QDateTime::currentDateTimeUtc();
    auto feed = [&](tdlas::contracts::Sequence sequence, int second) {
        tdlas::contracts::RawDataBlock block;
        block.runId = service.currentRunId();
        block.sequence = sequence;
        block.sampleStart.utc = base.addSecs(second);
        block.sampleRateHz = 100000.0;
        block.sampleCountPerChannel = 1;
        block.validity = tdlas::contracts::DataValidity::Valid;
        block.channels.push_back({parameters.aiChannelIds.constFirst(), {0.9}});
        device.rawDataReady(block);
    };
    auto waitForLast = [&](tdlas::contracts::Sequence sequence) {
        QElapsedTimer wait;
        wait.start();
        while (wait.elapsed() < 2000) {
            QCoreApplication::processEvents(QEventLoop::AllEvents, 10);
            const auto snapshot = service.displayModel();
            if (!snapshot.peakRecords.isEmpty()
                && snapshot.peakRecords.constLast().sequence == sequence) return true;
            QThread::msleep(1);
        }
        return false;
    };
    if (!service.start({parameters})) return false;
    const auto firstRun = service.currentRunId();
    feed(1, 1); feed(2, 3); feed(3, 2); feed(4, 4); feed(5, 5);
    if (!waitForLast(5)) return false;
    auto snapshot = service.displayModel();
    if (snapshot.peakRecords.size() != 3 || snapshot.peakTrendSeries.x.size() != 3
        || snapshot.peakRecords.constFirst().sequence != 3
        || snapshot.peakTrendSeries.x.at(0) != static_cast<double>(base.addSecs(2).toMSecsSinceEpoch()) / 1000.0
        || snapshot.peakTrendSeries.x.at(1) != static_cast<double>(base.addSecs(4).toMSecsSinceEpoch()) / 1000.0
        || !service.stop(firstRun) || service.state() != tdlas::contracts::MeasurementState::Idle
        || !service.start({parameters})) return false;
    const auto secondRun = service.currentRunId();
    feed(1, 6); feed(2, 7);
    if (!waitForLast(2)) return false;
    snapshot = service.displayModel();
    const bool correct = snapshot.peakRecords.size() == 3
        && snapshot.peakRecords.constLast().runId == secondRun
        && snapshot.peakTrendSeries.x.size() == 2
        && snapshot.peakTrendSeries.x.constFirst() == static_cast<double>(base.addSecs(6).toMSecsSinceEpoch()) / 1000.0;
    return correct && service.stop(secondRun);
}

} // namespace

int main(int argc, char **argv)
{
    QCoreApplication application(argc, argv);
    tdlas::parameter::ParameterService parameters;
    const auto commit = parameters.commit(tdlas::contracts::ParameterDraft::mockDefaults());
    if (!commit.isSuccess()) return 1;
    if (!runWaveformScenario(1000, *commit.snapshot)
        || !runWaveformScenario(2000, *commit.snapshot)) return 3;
    if (!verifyHistoryEdges(*commit.snapshot)) return 4;
    for (const int count : {60, 600, 3600}) {
        if (!runScenario(count, *commit.snapshot)) return 2;
    }
    return 0;
}
