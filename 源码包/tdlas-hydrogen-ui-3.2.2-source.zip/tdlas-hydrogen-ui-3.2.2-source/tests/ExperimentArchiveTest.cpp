#include "algorithm/MockAlgorithmProcessor.h"
#include "application/ExperimentArchiveApplicationService.h"
#include "storage/ExperimentArchiveService.h"
#include "storage/FileStorageRepository.h"
#include "system/IAuditSink.h"
#include "system/RoleBasedAuthorizationService.h"

#include <QCoreApplication>
#include <QDir>
#include <QFile>
#include <QJsonDocument>
#include <QJsonObject>
#include <QTemporaryDir>

#include <cmath>

namespace {

tdlas::contracts::RawDataBlock makeBlock(
    const tdlas::contracts::RunId &runId,
    tdlas::contracts::Sequence sequence,
    const QDateTime &startedAtUtc)
{
    tdlas::contracts::RawDataBlock block;
    block.runId = runId;
    block.streamId = QStringLiteral("archive-test-stream");
    block.sequence = sequence;
    block.sampleStart.utc = startedAtUtc.addMSecs(static_cast<qint64>(sequence));
    block.sampleRateHz = 2000.0;
    block.channels = {
        {QStringLiteral("sim/ai0"), {0.9, 0.7, 0.5, 0.7, 0.9}},
        {QStringLiteral("sim/ai1"), {0.8, 0.6, 0.4, 0.6, 0.8}}};
    block.sampleCountPerChannel = 5;
    block.validity = tdlas::contracts::DataValidity::Valid;
    return block;
}

QJsonObject readObject(const QString &path)
{
    QFile file(path);
    if (!file.open(QIODevice::ReadOnly)) {
        return {};
    }
    return QJsonDocument::fromJson(file.readAll()).object();
}

class RecordingAuditSink final : public tdlas::system::IAuditSink
{
public:
    tdlas::system::AuditWriteResult record(const tdlas::system::AuditEvent &event) override
    {
        events.append(event);
        return {true, {}, {}};
    }

    QVector<tdlas::system::AuditEvent> events;
};

} // namespace

int main(int argc, char *argv[])
{
    QCoreApplication application(argc, argv);
    QTemporaryDir temporary;
    if (!temporary.isValid()) {
        return 1;
    }

    const QDateTime startedAt = QDateTime::fromString(
        QStringLiteral("2026-11-05T01:02:03.456Z"), Qt::ISODateWithMs);
    tdlas::storage::StorageConfiguration configuration;
    configuration.rootDirectory = QDir(temporary.path()).filePath(QStringLiteral("data"));
    tdlas::storage::FileStorageRepository repository(configuration);
    tdlas::storage::ExperimentContext context;
    context.experimentId = tdlas::contracts::createExperimentId(startedAt);
    context.runId = {QStringLiteral("aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee")};
    context.parameters = tdlas::contracts::ParameterSnapshot::mockDefaults();
    context.startedAt.utc = startedAt;
    context.operatorId = QStringLiteral("archive-test");
    const auto begin = repository.beginExperiment(context);
    if (!begin.success) {
        return 2;
    }

    tdlas::algorithm::MockAlgorithmProcessor algorithm;
    for (tdlas::contracts::Sequence sequence = 1; sequence <= 2; ++sequence) {
        const auto block = makeBlock(context.runId, sequence, startedAt);
        auto result = algorithm.process(block, context.parameters);
        result.relativeFrequencyCm1 = {-0.2, -0.1, 0.0, 0.1, 0.2};
        if (sequence == 2) {
            result.timeSeconds.clear(); // Older archives do not carry time coordinates.
        }
        if (!repository.appendRawData(context.experimentId, block).success
            || !repository.appendProcessingResult(context.experimentId, result).success) {
            return 3;
        }
    }
    if (!repository.finishExperiment(
            context.experimentId,
            tdlas::storage::ExperimentCompletionStatus::Completed,
            startedAt.addSecs(2)).success) {
        return 4;
    }

    tdlas::storage::ExperimentArchiveSummary summary;
    const auto inspect = tdlas::storage::ExperimentArchiveService::inspect(begin.path, &summary);
    if (!inspect.success || summary.experimentId != context.experimentId
        || summary.runId != context.runId || summary.status != QStringLiteral("completed")
        || summary.rawBlockCount != 2 || summary.resultCount != 2) {
        return 5;
    }

    quint64 replayed = 0;
    tdlas::contracts::Sequence expectedSequence = 1;
    const auto replay = tdlas::storage::ExperimentArchiveService::replayRawData(
        begin.path,
        [&](const tdlas::contracts::RawDataBlock &block) {
            const bool valid = block.sequence == expectedSequence
                && block.runId == context.runId && block.channels.size() == 2
                && block.sampleCountPerChannel == 5
                && block.channels.first().samplesV.at(2) == 0.5;
            ++expectedSequence;
            return valid;
        },
        &replayed);
    if (!replay.success || replayed != 2 || expectedSequence != 3) {
        return 6;
    }

    const QString exportPath = QDir(temporary.path()).filePath(QStringLiteral("export/results.csv"));
    quint64 exportedRows = 0;
    const auto exportResult = tdlas::storage::ExperimentArchiveService::exportProcessingResultsCsv(
        begin.path, exportPath, &exportedRows);
    QFile exportFile(exportPath);
    if (!exportResult.success || exportedRows != 10
        || !exportFile.open(QIODevice::ReadOnly | QIODevice::Text)) {
        return 7;
    }
    const QList<QByteArray> csvLines = exportFile.readAll().split('\n');
    if (csvLines.size() != 12 || !csvLines.first().endsWith("time_seconds")
        || csvLines.at(1).split(',').size() != 19
        || std::abs(csvLines.at(5).split(',').last().toDouble() - 4.0 / 2000.0) > 1.0e-12
        || !csvLines.at(6).split(',').last().isEmpty()) {
        return 7;
    }
    const auto overwrite = tdlas::storage::ExperimentArchiveService::exportProcessingResultsCsv(
        begin.path, exportPath);
    if (overwrite.success || overwrite.code != QStringLiteral("ARCHIVE_EXPORT_TARGET_INVALID")) {
        return 8;
    }

    tdlas::storage::ExperimentContext interrupted = context;
    interrupted.experimentId = tdlas::contracts::createExperimentId(startedAt.addSecs(10));
    interrupted.runId = {QStringLiteral("11111111-2222-3333-4444-555555555555")};
    interrupted.startedAt.utc = startedAt.addSecs(10);
    const auto interruptedBegin = repository.beginExperiment(interrupted);
    if (!interruptedBegin.success
        || !repository.appendRawData(
                interrupted.experimentId,
                makeBlock(interrupted.runId, 1, interrupted.startedAt.utc)).success) {
        return 9;
    }
    const auto recovered = tdlas::storage::ExperimentArchiveService::recoverInterruptedExperiment(
        interruptedBegin.path, startedAt.addSecs(20), QStringLiteral("deterministic crash recovery test"));
    tdlas::storage::ExperimentArchiveSummary recoveredSummary;
    const auto recoveredInspect = tdlas::storage::ExperimentArchiveService::inspect(
        interruptedBegin.path, &recoveredSummary);
    const QJsonObject recoveredManifest = readObject(
        QDir(interruptedBegin.path).filePath(QStringLiteral("manifest.json")));
    if (!recovered.success || !recoveredInspect.success
        || recoveredSummary.status != QStringLiteral("aborted")
        || recoveredSummary.rawBlockCount != 1 || recoveredSummary.resultCount != 0
        || recoveredManifest.value(QStringLiteral("diagnostic")).toString()
            != QStringLiteral("deterministic crash recovery test")) {
        return 10;
    }
    const auto recoverAgain = tdlas::storage::ExperimentArchiveService::recoverInterruptedExperiment(
        interruptedBegin.path, startedAt.addSecs(21));
    if (recoverAgain.success || recoverAgain.code != QStringLiteral("ARCHIVE_NOT_INTERRUPTED")) {
        return 11;
    }

    tdlas::system::RoleBasedAuthorizationService authorization;
    RecordingAuditSink audit;
    tdlas::application::ExperimentArchiveApplicationService applicationService(
        authorization, audit);
    const tdlas::system::SessionContext administrator{
        QStringLiteral("admin-session"), QStringLiteral("admin"),
        tdlas::system::SystemRole::Administrator,
        startedAt.addSecs(-1), startedAt.addSecs(3600), QStringLiteral("test")};
    const tdlas::system::SessionContext client{
        QStringLiteral("client-session"), QStringLiteral("client"),
        tdlas::system::SystemRole::Client,
        startedAt.addSecs(-1), startedAt.addSecs(3600), QStringLiteral("test")};
    tdlas::storage::ExperimentArchiveSummary authorizedSummary;
    quint64 authorizedReplayCount = 0;
    const QString authorizedExportPath = QDir(temporary.path()).filePath(
        QStringLiteral("authorized/results.csv"));
    const auto clientInspect = applicationService.inspect(
        client, begin.path, &authorizedSummary, startedAt);
    const auto clientReplay = applicationService.replayRawData(
        client, begin.path, [](const auto &) { return true; },
        &authorizedReplayCount, startedAt);
    const auto clientExport = applicationService.exportProcessingResultsCsv(
        client, begin.path, authorizedExportPath, nullptr, startedAt);
    const auto clientRecovery = applicationService.recoverInterruptedExperiment(
        client, interruptedBegin.path, startedAt.addSecs(30),
        QStringLiteral("must be denied"), startedAt);
    if (!clientInspect.success || !clientReplay.success || authorizedReplayCount != 2
        || !clientExport.success || clientRecovery.success
        || clientRecovery.code != QStringLiteral("OPERATION_FORBIDDEN")
        || audit.events.size() != 4
        || audit.events.constLast().outcome != QStringLiteral("denied")) {
        return 12;
    }
    const auto administratorRecovery = applicationService.recoverInterruptedExperiment(
        administrator, interruptedBegin.path, startedAt.addSecs(31),
        QStringLiteral("already recovered"), startedAt);
    if (administratorRecovery.success
        || administratorRecovery.code != QStringLiteral("ARCHIVE_NOT_INTERRUPTED")
        || audit.events.size() != 5 || audit.events.constLast().outcome != QStringLiteral("failed")) {
        return 13;
    }

    return 0;
}
