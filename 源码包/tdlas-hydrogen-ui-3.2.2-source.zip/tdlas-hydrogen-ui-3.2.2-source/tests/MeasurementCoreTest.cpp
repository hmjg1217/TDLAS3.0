#include "acquisition/MockAcquisitionDevice.h"
#include "acquisition/ThreadedAcquisitionDevice.h"
#include "acquisition/RawDataBuffer.h"
#include "algorithm/MockAlgorithmProcessor.h"
#include "application/MeasurementApplicationService.h"
#include "application/MeasurementStateMachine.h"
#include "parameter/ParameterService.h"

#include <QCoreApplication>
#include <QElapsedTimer>
#include <QThread>

#include <functional>
#include <atomic>
#include <cmath>

namespace {

bool waitFor(const std::function<bool()> &condition, int timeoutMilliseconds = 1500)
{
    QElapsedTimer timer;
    timer.start();
    while (!condition() && timer.elapsed() < timeoutMilliseconds) {
        QCoreApplication::processEvents(QEventLoop::AllEvents, 10);
        QThread::msleep(1);
    }
    return condition();
}

tdlas::contracts::RawDataBlock fixedBlock()
{
    tdlas::contracts::RawDataBlock block;
    block.runId = {QStringLiteral("fixed-run")};
    block.streamId = QStringLiteral("test-stream");
    block.sequence = 1;
    block.sampleStart.utc = QDateTime::fromMSecsSinceEpoch(1000, Qt::UTC);
    block.sampleRateHz = 1000.0;
    block.sampleCountPerChannel = 5;
    block.validity = tdlas::contracts::DataValidity::Valid;
    block.channels.push_back({QStringLiteral("sim/ai0"), {0.90, 0.75, 0.40, 0.75, 0.90}});
    return block;
}

class ThreadRecordingAlgorithm final : public tdlas::algorithm::IAlgorithmProcessor
{
public:
    ThreadRecordingAlgorithm()
        : creatingThread_(QThread::currentThread())
    {
    }

    tdlas::contracts::ProcessingResult process(
        const tdlas::contracts::RawDataBlock &block,
        const tdlas::contracts::ParameterSnapshot &parameters) const override
    {
        processedOffCreatingThread_.store(
            QThread::currentThread() != creatingThread_,
            std::memory_order_release);
        return delegate_.process(block, parameters);
    }

    [[nodiscard]] bool processedOffCreatingThread() const
    {
        return processedOffCreatingThread_.load(std::memory_order_acquire);
    }

private:
    QThread *creatingThread_ = nullptr;
    tdlas::algorithm::MockAlgorithmProcessor delegate_;
    mutable std::atomic_bool processedOffCreatingThread_{false};
};

} // namespace

int main(int argc, char *argv[])
{
    QCoreApplication application(argc, argv);

    tdlas::parameter::ParameterService parameterService;
    if (parameterService.currentSnapshot().has_value()) {
        return 17;
    }
    tdlas::contracts::ParameterDraft invalidDraft = tdlas::contracts::ParameterDraft::mockDefaults();
    invalidDraft.sampleRateHz = 0.0;
    invalidDraft.inputRangeMinV = invalidDraft.inputRangeMaxV;
    invalidDraft.aiChannelIds.push_back(invalidDraft.aiChannelIds.constFirst());
    const tdlas::contracts::ParameterCommitResult invalidCommit = parameterService.commit(invalidDraft);
    if (invalidCommit.isSuccess() || invalidCommit.validation.errors.size() != 3
        || parameterService.currentSnapshot().has_value()) {
        return 18;
    }
    const tdlas::contracts::ParameterDraft defaultDraft = tdlas::contracts::ParameterDraft::mockDefaults();
    const tdlas::contracts::ParameterCommitResult firstCommit = parameterService.commit(defaultDraft);
    if (!firstCommit.isSuccess() || firstCommit.snapshot->revision != 1
        || firstCommit.snapshot->hash.size() != 64 || !firstCommit.snapshot->isValid()) {
        return 19;
    }
    tdlas::contracts::ParameterDraft revisedDraft = defaultDraft;
    revisedDraft.readSamplesPerBlock = 128;
    const tdlas::contracts::ParameterCommitResult secondCommit = parameterService.commit(revisedDraft);
    if (!secondCommit.isSuccess() || secondCommit.snapshot->revision != 2
        || secondCommit.snapshot->id == firstCommit.snapshot->id
        || firstCommit.snapshot->readSamplesPerBlock != 256
        || parameterService.currentSnapshot()->id != secondCommit.snapshot->id) {
        return 20;
    }

    tdlas::acquisition::RawDataBuffer rawBuffer(2);
    for (tdlas::contracts::Sequence sequence = 1; sequence <= 3; ++sequence) {
        tdlas::contracts::RawDataBlock block = fixedBlock();
        block.sequence = sequence;
        rawBuffer.push(block);
    }
    const auto bufferedSecond = rawBuffer.takeOldest();
    const auto bufferedThird = rawBuffer.takeOldest();
    if (rawBuffer.droppedBlockCount() != 1 || !bufferedSecond.has_value()
        || !bufferedThird.has_value() || bufferedSecond->sequence != 2
        || bufferedThird->sequence != 3 || !bufferedSecond->overrun
        || bufferedSecond->droppedBefore != 1 || bufferedThird->overrun
        || rawBuffer.takeOldest().has_value()) {
        return 21;
    }

    tdlas::application::MeasurementStateMachine machine;
    const tdlas::contracts::RunId firstRun{QStringLiteral("run-1")};
    if (!machine.begin(firstRun) || machine.state() != tdlas::contracts::MeasurementState::Preparing) {
        return 1;
    }
    if (machine.begin({QStringLiteral("run-2")})) {
        return 2;
    }
    if (!machine.transitionTo(tdlas::contracts::MeasurementState::Running)) {
        return 3;
    }
    if (!machine.acceptData(firstRun, 1)
        || machine.acceptData(firstRun, 1)
        || machine.acceptData({QStringLiteral("late-run")}, 2)
        || !machine.acceptData(firstRun, 2)) {
        return 4;
    }
    if (!machine.transitionTo(tdlas::contracts::MeasurementState::Stopping)
        || !machine.transitionTo(tdlas::contracts::MeasurementState::Idle)
        || machine.activeRunId().isValid()) {
        return 5;
    }
    machine.fault();
    if (machine.state() != tdlas::contracts::MeasurementState::Faulted
        || machine.begin(firstRun) || !machine.resetFault()
        || machine.state() != tdlas::contracts::MeasurementState::Idle) {
        return 16;
    }

    tdlas::algorithm::MockAlgorithmProcessor algorithm;
    const tdlas::contracts::ParameterSnapshot parameters = tdlas::contracts::ParameterSnapshot::mockDefaults();
    const tdlas::contracts::ProcessingResult firstResult = algorithm.process(fixedBlock(), parameters);
    const tdlas::contracts::ProcessingResult secondResult = algorithm.process(fixedBlock(), parameters);
    if (firstResult.validity != tdlas::contracts::DataValidity::Uncalibrated
        || firstResult.concentration.has_value()
        || !firstResult.peakAbsorbance.has_value()
        || firstResult.absorbance != secondResult.absorbance
        || firstResult.absorbance.size() != fixedBlock().sampleCountPerChannel) {
        return 6;
    }

    tdlas::acquisition::MockAcquisitionDevice device;
    ThreadRecordingAlgorithm threadedAlgorithm;
    tdlas::application::MeasurementApplicationService service(device, threadedAlgorithm);
    tdlas::contracts::MeasurementDisplayModel latest;
    int displayCount = 0;
    QObject::connect(&service, &tdlas::application::MeasurementApplicationService::displayModelChanged,
        &application, [&](const tdlas::contracts::MeasurementDisplayModel &model) {
            latest = model;
            ++displayCount;
        });

    tdlas::contracts::StartMeasurementRequest request{parameters};
    if (!service.start(request) || !service.currentRunId().isValid()) {
        return 7;
    }
    const tdlas::contracts::RunId serviceFirstRun = service.currentRunId();
    if (!waitFor([&]() { return latest.sequence >= 3; })) {
        return 8;
    }
    if (service.state() != tdlas::contracts::MeasurementState::Running
        || latest.sourceKind != tdlas::contracts::DataSourceKind::Simulation
        || latest.absorbance.isEmpty() || latest.peakHistory.isEmpty()
        || latest.concentration.has_value() || !latest.rawSeries.isConsistent()
        || !latest.processedVoltageSeries.isConsistent()
        || !latest.fittedVoltageSeries.isConsistent()
        || !latest.absorbanceSeries.isConsistent()
        || latest.rawSeries.x.constFirst() != 0.0
        || std::abs(latest.rawSeries.x.constLast()
                    - static_cast<double>(parameters.readSamplesPerBlock - 1) / 5120.0) > 1.0e-12
        || latest.rawSeries.xUnit != QStringLiteral("s")
        || latest.rawSeries.yUnit != QStringLiteral("V")
        || latest.processedVoltageSeries.x != latest.fittedVoltageSeries.x
        || latest.processedVoltageSeries.y.size() != latest.fittedVoltageSeries.y.size()
        || std::abs(latest.fittedVoltageSeries.x.constLast()
                    - static_cast<double>(parameters.readSamplesPerBlock - 1) / 5120.0) > 1.0e-12
        || latest.peakTrendSeries.xUnit != QStringLiteral("HH:mm:ss")
        || !threadedAlgorithm.processedOffCreatingThread()) {
        return 9;
    }
    if (service.start(request)) {
        return 10;
    }
    if (!service.stop(serviceFirstRun)
        || service.state() != tdlas::contracts::MeasurementState::Idle) {
        return 11;
    }
    const int stoppedDisplayCount = displayCount;
    QElapsedTimer quietTimer;
    quietTimer.start();
    while (quietTimer.elapsed() < 80) {
        QCoreApplication::processEvents(QEventLoop::AllEvents, 10);
        QThread::msleep(1);
    }
    if (displayCount != stoppedDisplayCount) {
        return 12;
    }

    if (!service.start(request) || service.currentRunId() == serviceFirstRun) {
        return 13;
    }
    if (!waitFor([&]() { return latest.sequence >= 1; })) {
        return 14;
    }
    if (!service.stop(service.currentRunId())) {
        return 15;
    }

    tdlas::acquisition::ThreadedAcquisitionDevice threadedDevice(
        tdlas::acquisition::AcquisitionBackendPolicy::MockOnly);
    tdlas::application::MeasurementApplicationService threadedService(threadedDevice, algorithm);
    if (!threadedService.start(request)
        || !waitFor([&]() {
            return threadedService.state() == tdlas::contracts::MeasurementState::Running
                && threadedService.displayModel().sequence > 0;
        })) {
        return 27;
    }
    const tdlas::contracts::RunId threadedFirstRun = threadedService.currentRunId();
    if (!threadedService.stop(threadedFirstRun)
        || !waitFor([&]() {
            return threadedService.state() == tdlas::contracts::MeasurementState::Idle;
        })
        || !threadedService.start(request)
        || threadedService.currentRunId() == threadedFirstRun
        || !waitFor([&]() {
            return threadedService.state() == tdlas::contracts::MeasurementState::Running
                && threadedService.displayModel().sequence > 0;
        })
        || !threadedService.stop(threadedService.currentRunId())
        || !waitFor([&]() {
            return threadedService.state() == tdlas::contracts::MeasurementState::Idle;
        })) {
        return 28;
    }

    tdlas::acquisition::MockAcquisitionOptions fastOptions;
    fastOptions.blockIntervalMilliseconds = 1;
    tdlas::acquisition::MockAcquisitionDevice fastDevice(fastOptions);
    tdlas::application::MeasurementApplicationOptions throttledOptions;
    throttledOptions.displayRefreshIntervalMilliseconds = 50;
    tdlas::application::MeasurementApplicationService throttledService(
        fastDevice, algorithm, throttledOptions);
    int dataRefreshCount = 0;
    QElapsedTimer firstWaveformTimer;
    qint64 firstWaveformLatencyMs = -1;
    QObject::connect(&throttledService, &tdlas::application::MeasurementApplicationService::displayModelChanged,
        &application, [&](const tdlas::contracts::MeasurementDisplayModel &model) {
            if (model.state == tdlas::contracts::MeasurementState::Running && model.sequence > 0) {
                ++dataRefreshCount;
                if (firstWaveformLatencyMs < 0 && !model.rawSeries.y.isEmpty()) {
                    firstWaveformLatencyMs = firstWaveformTimer.elapsed();
                }
            }
        });
    firstWaveformTimer.start();
    if (!throttledService.start({*firstCommit.snapshot})
        || !waitFor([&]() { return throttledService.displayModel().sequence >= 25; })
        || !waitFor([&]() { return dataRefreshCount >= 1; })
        || firstWaveformLatencyMs < 0 || firstWaveformLatencyMs >= 50) {
        return 22;
    }
    const tdlas::contracts::Sequence processedSequence = throttledService.displayModel().sequence;
    if (static_cast<tdlas::contracts::Sequence>(dataRefreshCount) >= processedSequence
        || !throttledService.stop(throttledService.currentRunId())) {
        return 23;
    }

    tdlas::acquisition::MockAcquisitionOptions faultOptions;
    faultOptions.blockIntervalMilliseconds = 1;
    faultOptions.faultAfterGeneratedBlocks = 3;
    tdlas::acquisition::MockAcquisitionDevice faultDevice(faultOptions);
    tdlas::application::MeasurementApplicationService faultService(faultDevice, algorithm);
    QString faultCode;
    QObject::connect(&faultService, &tdlas::application::MeasurementApplicationService::errorOccurred,
        &application, [&](const tdlas::contracts::ModuleError &error) {
            faultCode = error.code;
        });
    if (!faultService.start({*firstCommit.snapshot})
        || !waitFor([&]() { return faultService.state() == tdlas::contracts::MeasurementState::Faulted; })
        || faultCode != QStringLiteral("MOCK_INJECTED_FAULT")
        || faultDevice.connectionState() != tdlas::contracts::DeviceConnectionState::Disconnected
        || faultDevice.acquisitionState() != tdlas::contracts::AcquisitionState::Idle
        || !faultService.resetFault()
        || faultService.state() != tdlas::contracts::MeasurementState::Idle) {
        return 24;
    }

    tdlas::acquisition::MockAcquisitionDevice lifecycleDevice;
    {
        tdlas::application::MeasurementApplicationService lifecycleService(lifecycleDevice, algorithm);
        if (!lifecycleService.start({*firstCommit.snapshot})
            || !waitFor([&]() { return lifecycleService.displayModel().sequence >= 1; })) {
            return 25;
        }
    }
    if (lifecycleDevice.acquisitionState() != tdlas::contracts::AcquisitionState::Idle
        || lifecycleDevice.connectionState() != tdlas::contracts::DeviceConnectionState::Disconnected) {
        return 26;
    }

    return 0;
}
