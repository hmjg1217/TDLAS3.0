#include "acquisition/NidaqmxAcquisitionDevice.h"
#include "acquisition/DynamicNidaqmxDriver.h"
#include "algorithm/MockAlgorithmProcessor.h"
#include "application/MeasurementApplicationService.h"

#include <QCoreApplication>
#include <QElapsedTimer>
#include <QHash>
#include <QSet>
#include <QThread>

#include <cmath>
#include <functional>
#include <memory>

namespace {

using tdlas::acquisition::INidaqmxDriver;
using tdlas::acquisition::NidaqmxStatus;
using tdlas::acquisition::NidaqmxTaskHandle;

struct FakeDriverState {
    bool loadSucceeds = true;
    bool produceData = true;
    bool failAiChannelConfiguration = false;
    bool failAiStart = false;
    NidaqmxStatus availableError = 0;
    double aiActualRateOverrideHz = 0.0;
    double aoActualRateOverrideHz = 0.0;
    int createCount = 0;
    int stopCount = 0;
    int clearCount = 0;
    int clearFailuresRemaining = 0;
    int readCount = 0;
    int nextHandle = 0;
    NidaqmxTaskHandle aiTask = nullptr;
    NidaqmxTaskHandle aoTask = nullptr;
    QSet<NidaqmxTaskHandle> liveTasks;
    QStringList aiChannels;
    QString aoChannel;
    QVector<double> aoWaveform;
    QStringList startOrder;
    QHash<NidaqmxTaskHandle, double> configuredRatesHz;
};

class FakeNidaqmxDriver final : public INidaqmxDriver
{
public:
    explicit FakeNidaqmxDriver(std::shared_ptr<FakeDriverState> state)
        : state_(std::move(state))
    {
    }

    bool load(QString *diagnostic) override
    {
        loaded_ = state_->loadSucceeds;
        if (!loaded_ && diagnostic) {
            *diagnostic = QStringLiteral("injected driver load failure");
        }
        return loaded_;
    }

    bool isLoaded() const override
    {
        return loaded_;
    }

    NidaqmxStatus deviceProductType(const QString &deviceId, QString *productType) override
    {
        if (deviceId.compare(QStringLiteral("Dev1"), Qt::CaseInsensitive) != 0) {
            return -200220;
        }
        if (productType) {
            *productType = QStringLiteral("Fake NI DAQ");
        }
        return 0;
    }

    NidaqmxStatus createTask(NidaqmxTaskHandle *taskHandle) override
    {
        ++state_->createCount;
        ++state_->nextHandle;
        *taskHandle = reinterpret_cast<NidaqmxTaskHandle>(
            static_cast<quintptr>(state_->nextHandle));
        state_->liveTasks.insert(*taskHandle);
        return 0;
    }

    NidaqmxStatus createAiVoltageChannel(
        NidaqmxTaskHandle taskHandle,
        const QString &physicalChannel,
        double,
        double) override
    {
        if (state_->failAiChannelConfiguration) {
            return -200077;
        }
        state_->aiTask = taskHandle;
        state_->aiChannels.push_back(physicalChannel);
        return 0;
    }

    NidaqmxStatus createAoVoltageChannel(
        NidaqmxTaskHandle taskHandle,
        const QString &physicalChannel,
        double,
        double) override
    {
        state_->aoTask = taskHandle;
        state_->aoChannel = physicalChannel;
        return 0;
    }

    NidaqmxStatus configureContinuousSampleClock(
        NidaqmxTaskHandle taskHandle,
        double sampleRateHz,
        quint64) override
    {
        state_->configuredRatesHz.insert(taskHandle, sampleRateHz);
        return 0;
    }

    NidaqmxStatus sampleClockRate(
        NidaqmxTaskHandle taskHandle,
        double *sampleRateHz) override
    {
        if (taskHandle == state_->aiTask && state_->aiActualRateOverrideHz > 0.0) {
            *sampleRateHz = state_->aiActualRateOverrideHz;
        } else if (taskHandle == state_->aoTask && state_->aoActualRateOverrideHz > 0.0) {
            *sampleRateHz = state_->aoActualRateOverrideHz;
        } else {
            *sampleRateHz = state_->configuredRatesHz.value(taskHandle);
        }
        return 0;
    }

    NidaqmxStatus writeAnalogF64(
        NidaqmxTaskHandle,
        const QVector<double> &channelMajorSamples,
        qint32 samplesPerChannel,
        qint32 *samplesWrittenPerChannel) override
    {
        state_->aoWaveform = channelMajorSamples;
        *samplesWrittenPerChannel = samplesPerChannel;
        return 0;
    }

    NidaqmxStatus startTask(NidaqmxTaskHandle taskHandle) override
    {
        if (taskHandle == state_->aoTask) {
            state_->startOrder.push_back(QStringLiteral("AO"));
        } else if (taskHandle == state_->aiTask) {
            state_->startOrder.push_back(QStringLiteral("AI"));
            if (state_->failAiStart) {
                return -200452;
            }
        }
        return 0;
    }

    NidaqmxStatus availableSamplesPerChannel(
        NidaqmxTaskHandle,
        quint32 *availableSamples) override
    {
        if (state_->availableError < 0) {
            return state_->availableError;
        }
        *availableSamples = state_->produceData ? 1024U : 0U;
        return 0;
    }

    NidaqmxStatus readAnalogF64(
        NidaqmxTaskHandle,
        qint32 samplesPerChannel,
        QVector<double> *channelMajorSamples,
        qint32 *samplesReadPerChannel) override
    {
        const qsizetype channelCount = state_->aiChannels.size();
        for (qsizetype channel = 0; channel < channelCount; ++channel) {
            for (qint32 sample = 0; sample < samplesPerChannel; ++sample) {
                (*channelMajorSamples)[channel * samplesPerChannel + sample]
                    = static_cast<double>(channel) + static_cast<double>(sample) / 1000.0;
            }
        }
        *samplesReadPerChannel = samplesPerChannel;
        ++state_->readCount;
        return 0;
    }

    NidaqmxStatus stopTask(NidaqmxTaskHandle) override
    {
        ++state_->stopCount;
        return 0;
    }

    NidaqmxStatus clearTask(NidaqmxTaskHandle taskHandle) override
    {
        ++state_->clearCount;
        if (state_->clearFailuresRemaining > 0) {
            --state_->clearFailuresRemaining;
            return -50103;
        }
        state_->liveTasks.remove(taskHandle);
        return 0;
    }

    QString errorText(NidaqmxStatus status) const override
    {
        return QStringLiteral("injected NI-DAQmx status %1").arg(status);
    }

private:
    std::shared_ptr<FakeDriverState> state_;
    bool loaded_ = false;
};

bool waitFor(const std::function<bool()> &condition, int timeoutMilliseconds = 1000)
{
    QElapsedTimer timer;
    timer.start();
    while (!condition() && timer.elapsed() < timeoutMilliseconds) {
        QCoreApplication::processEvents(QEventLoop::AllEvents, 10);
        QThread::msleep(1);
    }
    return condition();
}

tdlas::contracts::ParameterSnapshot realSnapshot(bool aoEnabled)
{
    tdlas::contracts::ParameterSnapshot snapshot = tdlas::contracts::ParameterSnapshot::mockDefaults();
    snapshot.id = QStringLiteral("nidaqmx-test-parameters");
    snapshot.deviceId = QStringLiteral("Dev1");
    snapshot.aiChannelIds = {QStringLiteral("Dev1/ai0"), QStringLiteral("Dev1/ai1")};
    snapshot.sampleRateHz = 1000.0;
    snapshot.readSamplesPerBlock = 16;
    snapshot.inputRangeMinV = -5.0;
    snapshot.inputRangeMaxV = 5.0;
    snapshot.aoEnabled = aoEnabled;
    snapshot.aoChannelId = aoEnabled ? QStringLiteral("Dev1/ao0") : QString();
    snapshot.waveform = tdlas::contracts::Waveform::Triangle;
    snapshot.outputFrequencyHz = aoEnabled ? 50.0 : 0.0;
    snapshot.outputAmplitudePeakV = aoEnabled ? 1.5 : 0.0;
    snapshot.outputOffsetV = aoEnabled ? 2.0 : 0.0;
    snapshot.outputSampleRateHz = aoEnabled ? 1000.0 : 0.0;
    snapshot.hash = QString(64, QLatin1Char('a'));
    return snapshot;
}

tdlas::acquisition::NidaqmxAcquisitionOptions fastOptions()
{
    tdlas::acquisition::NidaqmxAcquisitionOptions options;
    options.pollIntervalMilliseconds = 1;
    options.acquisitionTimeoutMilliseconds = 40;
    options.driverBufferBlocks = 4;
    options.maxBlocksPerPoll = 1;
    return options;
}

} // namespace

int main(int argc, char *argv[])
{
    QCoreApplication application(argc, argv);

    if (qEnvironmentVariableIntValue("TDLAS_TEST_NIDAQMX_RUNTIME") == 1) {
        tdlas::acquisition::DynamicNidaqmxDriver runtimeDriver;
        QString diagnostic;
        if (!runtimeDriver.load(&diagnostic)) {
            return 14;
        }
    }

    {
        auto state = std::make_shared<FakeDriverState>();
        tdlas::acquisition::NidaqmxAcquisitionDevice device(
            std::make_unique<FakeNidaqmxDriver>(state), fastOptions());
        QString errorCode;
        QObject::connect(&device, &tdlas::acquisition::NidaqmxAcquisitionDevice::errorOccurred,
            &application, [&](const tdlas::contracts::ModuleError &error) {
                errorCode = error.code;
            });
        if (device.connectDevice(QStringLiteral("Missing"))
            || device.connectionState() != tdlas::contracts::DeviceConnectionState::Faulted
            || errorCode != QStringLiteral("NIDAQMX_DEVICE_NOT_FOUND")
            || !device.disconnectDevice()) {
            return 1;
        }
    }

    {
        auto state = std::make_shared<FakeDriverState>();
        state->aiActualRateOverrideHz = 999.5;
        tdlas::acquisition::NidaqmxAcquisitionDevice device(
            std::make_unique<FakeNidaqmxDriver>(state), fastOptions());
        tdlas::contracts::RawDataBlock latest;
        int blockCount = 0;
        QObject::connect(&device, &tdlas::acquisition::NidaqmxAcquisitionDevice::rawDataReady,
            &application, [&](const tdlas::contracts::RawDataBlock &block) {
                latest = block;
                ++blockCount;
            });
        const tdlas::contracts::ParameterSnapshot snapshot = realSnapshot(true);
        const tdlas::contracts::RunId runId{QStringLiteral("nidaqmx-run-1")};
        if (!device.connectDevice(snapshot.deviceId)
            || !device.configure(snapshot)
            || state->createCount != 2
            || state->aiChannels != snapshot.aiChannelIds
            || state->aoChannel != snapshot.aoChannelId
            || state->aoWaveform.size() != 20
            || !device.start(runId)
            || state->startOrder != QStringList({QStringLiteral("AO"), QStringLiteral("AI")})
            || !waitFor([&]() { return blockCount >= 1; })) {
            return 2;
        }
        if (latest.runId != runId
            || latest.streamId != QStringLiteral("Dev1:ai")
            || latest.sequence != 1
            || latest.sampleRateHz != state->aiActualRateOverrideHz
            || latest.sampleCountPerChannel != snapshot.readSamplesPerBlock
            || latest.channels.size() != 2
            || latest.channels.at(0).channelId != QStringLiteral("Dev1/ai0")
            || latest.channels.at(1).samplesV.at(3) != 1.003
            || latest.validity != tdlas::contracts::DataValidity::Valid
            || latest.sampleStart.monotonicNanoseconds != 0) {
            return 3;
        }
        if (!device.stop()
            || device.acquisitionState() != tdlas::contracts::AcquisitionState::Idle
            || !state->liveTasks.isEmpty()
            || state->stopCount != 2
            || state->clearCount != 2
            || !device.stop()
            || state->clearCount != 2
            || !device.disconnectDevice()
            || device.connectionState() != tdlas::contracts::DeviceConnectionState::Disconnected) {
            return 4;
        }
    }

    {
        auto state = std::make_shared<FakeDriverState>();
        state->failAiChannelConfiguration = true;
        tdlas::acquisition::NidaqmxAcquisitionDevice device(
            std::make_unique<FakeNidaqmxDriver>(state), fastOptions());
        QString errorCode;
        QObject::connect(&device, &tdlas::acquisition::NidaqmxAcquisitionDevice::errorOccurred,
            &application, [&](const tdlas::contracts::ModuleError &error) {
                errorCode = error.code;
            });
        const auto snapshot = realSnapshot(false);
        if (!device.connectDevice(snapshot.deviceId)
            || device.configure(snapshot)
            || errorCode != QStringLiteral("NIDAQMX_CONFIGURE_FAILED")
            || device.acquisitionState() != tdlas::contracts::AcquisitionState::Faulted
            || !state->liveTasks.isEmpty()
            || state->clearCount != 1
            || !device.disconnectDevice()) {
            return 5;
        }
    }

    {
        auto state = std::make_shared<FakeDriverState>();
        state->failAiStart = true;
        tdlas::acquisition::NidaqmxAcquisitionDevice device(
            std::make_unique<FakeNidaqmxDriver>(state), fastOptions());
        const auto snapshot = realSnapshot(true);
        if (!device.connectDevice(snapshot.deviceId)
            || !device.configure(snapshot)
            || device.start({QStringLiteral("start-failure")})
            || device.acquisitionState() != tdlas::contracts::AcquisitionState::Faulted
            || !state->liveTasks.isEmpty()
            || state->stopCount != 1
            || state->clearCount != 2
            || !device.disconnectDevice()) {
            return 6;
        }
    }

    {
        auto state = std::make_shared<FakeDriverState>();
        tdlas::acquisition::NidaqmxAcquisitionDevice device(
            std::make_unique<FakeNidaqmxDriver>(state), fastOptions());
        QString errorCode;
        QObject::connect(&device, &tdlas::acquisition::NidaqmxAcquisitionDevice::errorOccurred,
            &application, [&](const tdlas::contracts::ModuleError &error) {
                errorCode = error.code;
            });
        auto snapshot = realSnapshot(true);
        snapshot.outputFrequencyHz = 48.0;
        if (!device.connectDevice(snapshot.deviceId)
            || device.configure(snapshot)
            || errorCode != QStringLiteral("NIDAQMX_AO_WAVEFORM_INVALID")
            || !state->liveTasks.isEmpty()
            || !device.disconnectDevice()) {
            return 15;
        }
    }

    {
        auto state = std::make_shared<FakeDriverState>();
        state->aoActualRateOverrideHz = 990.0;
        tdlas::acquisition::NidaqmxAcquisitionDevice device(
            std::make_unique<FakeNidaqmxDriver>(state), fastOptions());
        QString errorCode;
        QObject::connect(&device, &tdlas::acquisition::NidaqmxAcquisitionDevice::errorOccurred,
            &application, [&](const tdlas::contracts::ModuleError &error) {
                errorCode = error.code;
            });
        const auto snapshot = realSnapshot(true);
        if (!device.connectDevice(snapshot.deviceId)
            || device.configure(snapshot)
            || errorCode != QStringLiteral("NIDAQMX_AO_RATE_COERCED")
            || !state->liveTasks.isEmpty()
            || !device.disconnectDevice()) {
            return 16;
        }
    }

    {
        auto state = std::make_shared<FakeDriverState>();
        state->produceData = false;
        tdlas::acquisition::NidaqmxAcquisitionDevice device(
            std::make_unique<FakeNidaqmxDriver>(state), fastOptions());
        QString errorCode;
        bool requiresStop = false;
        QObject::connect(&device, &tdlas::acquisition::NidaqmxAcquisitionDevice::errorOccurred,
            &application, [&](const tdlas::contracts::ModuleError &error) {
                errorCode = error.code;
                requiresStop = error.requiresStop;
            });
        const auto snapshot = realSnapshot(false);
        if (!device.connectDevice(snapshot.deviceId)
            || !device.configure(snapshot)
            || !device.start({QStringLiteral("timeout-run")})
            || !waitFor([&]() {
                return device.acquisitionState() == tdlas::contracts::AcquisitionState::Faulted;
            })
            || errorCode != QStringLiteral("NIDAQMX_READ_TIMEOUT")
            || !requiresStop
            || device.connectionState() != tdlas::contracts::DeviceConnectionState::Connected
            || !state->liveTasks.isEmpty()
            || !device.stop()
            || !device.disconnectDevice()) {
            return 7;
        }
    }

    {
        auto state = std::make_shared<FakeDriverState>();
        tdlas::acquisition::NidaqmxAcquisitionDevice device(
            std::make_unique<FakeNidaqmxDriver>(state), fastOptions());
        QString errorCode;
        QObject::connect(&device, &tdlas::acquisition::NidaqmxAcquisitionDevice::errorOccurred,
            &application, [&](const tdlas::contracts::ModuleError &error) {
                errorCode = error.code;
            });
        const auto snapshot = realSnapshot(false);
        if (!device.connectDevice(snapshot.deviceId)
            || !device.configure(snapshot)
            || !device.start({QStringLiteral("disconnect-run")})
            || !waitFor([&]() { return state->readCount >= 1; })) {
            return 8;
        }
        state->availableError = -88705;
        if (!waitFor([&]() {
                return device.connectionState() == tdlas::contracts::DeviceConnectionState::Faulted;
            })
            || device.acquisitionState() != tdlas::contracts::AcquisitionState::Faulted
            || errorCode != QStringLiteral("NIDAQMX_DEVICE_DISCONNECTED")
            || !state->liveTasks.isEmpty()
            || !device.disconnectDevice()
            || device.connectionState() != tdlas::contracts::DeviceConnectionState::Disconnected
            || device.acquisitionState() != tdlas::contracts::AcquisitionState::Idle) {
            return 9;
        }
    }

    {
        auto state = std::make_shared<FakeDriverState>();
        state->loadSucceeds = false;
        tdlas::acquisition::NidaqmxAcquisitionDevice device(
            std::make_unique<FakeNidaqmxDriver>(state), fastOptions());
        QString errorCode;
        QObject::connect(&device, &tdlas::acquisition::NidaqmxAcquisitionDevice::errorOccurred,
            &application, [&](const tdlas::contracts::ModuleError &error) {
                errorCode = error.code;
            });
        if (device.connectDevice(QStringLiteral("Dev1"))
            || errorCode != QStringLiteral("NIDAQMX_DRIVER_UNAVAILABLE")
            || !device.disconnectDevice()) {
            return 10;
        }
    }

    {
        auto state = std::make_shared<FakeDriverState>();
        tdlas::acquisition::NidaqmxAcquisitionDevice device(
            std::make_unique<FakeNidaqmxDriver>(state), fastOptions());
        QString errorCode;
        QObject::connect(&device, &tdlas::acquisition::NidaqmxAcquisitionDevice::errorOccurred,
            &application, [&](const tdlas::contracts::ModuleError &error) {
                errorCode = error.code;
            });
        const auto snapshot = realSnapshot(false);
        if (!device.connectDevice(snapshot.deviceId)
            || !device.configure(snapshot)
            || !device.start({QStringLiteral("release-retry-run")})) {
            return 17;
        }
        state->clearFailuresRemaining = 1;
        if (device.stop()
            || errorCode != QStringLiteral("NIDAQMX_RESOURCE_RELEASE_FAILED")
            || device.acquisitionState() != tdlas::contracts::AcquisitionState::Faulted
            || state->liveTasks.size() != 1
            || !device.disconnectDevice()
            || !state->liveTasks.isEmpty()
            || device.connectionState() != tdlas::contracts::DeviceConnectionState::Disconnected
            || device.acquisitionState() != tdlas::contracts::AcquisitionState::Idle) {
            return 18;
        }
    }

    {
        auto state = std::make_shared<FakeDriverState>();
        {
            tdlas::acquisition::NidaqmxAcquisitionDevice device(
                std::make_unique<FakeNidaqmxDriver>(state), fastOptions());
            const auto snapshot = realSnapshot(true);
            if (!device.connectDevice(snapshot.deviceId)
                || !device.configure(snapshot)
                || !device.start({QStringLiteral("destructor-run")})) {
                return 11;
            }
        }
        if (!state->liveTasks.isEmpty() || state->stopCount != 2 || state->clearCount != 2) {
            return 12;
        }
    }

    {
        auto state = std::make_shared<FakeDriverState>();
        tdlas::acquisition::NidaqmxAcquisitionDevice device(
            std::make_unique<FakeNidaqmxDriver>(state), fastOptions());
        tdlas::algorithm::MockAlgorithmProcessor algorithm;
        tdlas::application::MeasurementApplicationOptions options;
        options.displayRefreshIntervalMilliseconds = 1;
        options.sourceKind = tdlas::contracts::DataSourceKind::RealDevice;
        tdlas::application::MeasurementApplicationService service(device, algorithm, options);
        const auto snapshot = realSnapshot(false);
        if (!service.start({snapshot})
            || !waitFor([&]() { return service.displayModel().sequence >= 1; })
            || service.displayModel().sourceKind != tdlas::contracts::DataSourceKind::RealDevice
            || !service.displayModel().statusMessage.startsWith(QStringLiteral("真实设备采集中"))
            || !service.stop(service.currentRunId())
            || service.state() != tdlas::contracts::MeasurementState::Idle
            || !state->liveTasks.isEmpty()) {
            return 13;
        }
    }

    return 0;
}
