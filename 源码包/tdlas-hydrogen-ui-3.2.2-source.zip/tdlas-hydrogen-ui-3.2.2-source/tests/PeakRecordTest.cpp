#include "application/PeakRecordBuilder.h"
#include "storage/PeakRecordCsvExporter.h"
#include <QCoreApplication>
#include <QDir>
#include <QFile>
#include <QJsonDocument>
#include <QJsonObject>
#include <QTemporaryDir>
#include <QTimeZone>
#include <cmath>
#include <cstdio>
#include <limits>

#define CHECK(condition) do { if (!(condition)) { std::fprintf(stderr, "PeakRecord assertion failed at line %d\n", __LINE__); return 1; } } while (false)

QVector<QStringList> parseCsv(const QByteArray &bytes) {
    const QString text = QString::fromUtf8(bytes.mid(3));
    QVector<QStringList> rows; QStringList row; QString field; bool quoted = false;
    for (qsizetype i = 0; i < text.size(); ++i) {
        const QChar c = text.at(i);
        if (c == QLatin1Char('"')) {
            if (quoted && i + 1 < text.size() && text.at(i + 1) == QLatin1Char('"')) { field += c; ++i; }
            else quoted = !quoted;
        } else if (!quoted && c == QLatin1Char(',')) { row << field; field.clear(); }
        else if (!quoted && c == QLatin1Char('\n')) { row << field; rows << row; row.clear(); field.clear(); }
        else if (quoted || c != QLatin1Char('\r')) field += c;
    }
    return rows;
}

int main(int argc, char **argv) {
    QCoreApplication app(argc, argv);
    using namespace tdlas;
    const auto parameters = contracts::ParameterSnapshot::mockDefaults();
    contracts::ProcessingResult result;
    result.runId = {QStringLiteral("run-a")}; result.sourceSequence = 3;
    result.timestamp.utc = QDateTime::fromString(QStringLiteral("2026-11-06T03:04:05.123Z"), Qt::ISODateWithMs);
    result.timestamp.monotonicNanoseconds = 1500000000;
    result.validity = contracts::DataValidity::Uncalibrated;
    result.algorithmVersion = QStringLiteral("algorithm-test-v1"); result.calibrationVersion = QStringLiteral("relative-frequency-test");
    result.fittedAbsorbance = {-5.0, -2.0, -3.0}; result.relativeFrequencyCm1 = {-1.0, 0.0, 1.0}; result.peakAbsorbance = 99.0;
    const auto started = result.timestamp.utc.addSecs(-4);
    auto build = [&]() { return application::buildPeakRecord(result, parameters, {QStringLiteral("EXP-20261106T030400123Z-12345678")}, contracts::DataSourceKind::Simulation, started); };
    auto record = build();
    CHECK(record.peakValue && *record.peakValue == -2.0 && record.peakX && *record.peakX == 0.0);
    CHECK(record.validity == contracts::DataValidity::Valid && record.acquiredAtUtc == result.timestamp.utc && record.elapsedSeconds == 1.5);
    CHECK(record.parameters.id == parameters.id && record.algorithmVersion == result.algorithmVersion);
    result.fittedAbsorbance = {std::numeric_limits<double>::quiet_NaN(), 0.12345678901234566, std::numeric_limits<double>::infinity()};
    record = build(); CHECK(record.peakValue && *record.peakValue == result.fittedAbsorbance.at(1));
    result.relativeFrequencyCm1 = {0.0, std::numeric_limits<double>::quiet_NaN(), 1.0};
    record = build(); CHECK(!record.peakValue && record.validity == contracts::DataValidity::Invalid);
    result.relativeFrequencyCm1 = {-1.0, 0.0, 1.0};
    result.fittedAbsorbance = {-5.0, -2.0, -3.0};
    record = build();
    result.fittedAbsorbance = {std::numeric_limits<double>::quiet_NaN(), std::numeric_limits<double>::infinity()};
    CHECK(!build().peakValue && build().validity == contracts::DataValidity::Invalid && !build().reason.isEmpty());
    result.fittedAbsorbance.clear(); CHECK(!build().peakValue && !build().reason.isEmpty());
    result.fittedAbsorbance = {5.0}; result.validity = contracts::DataValidity::Invalid;
    CHECK(!build().peakValue);
    QVector<contracts::PeakRecord> history;
    record.sequence = 3; CHECK(application::insertPeakRecord(history, record, 3));
    record.sequence = 1; CHECK(application::insertPeakRecord(history, record, 3));
    record.sequence = 2; CHECK(application::insertPeakRecord(history, record, 3));
    CHECK(history.at(0).sequence == 1 && history.at(1).sequence == 2 && history.at(2).sequence == 3);
    CHECK(!application::insertPeakRecord(history, record, 3) && history.size() == 3);
    record.runId = {QStringLiteral("run-b")}; record.sequence = 1;
    CHECK(application::insertPeakRecord(history, record, 3) && history.size() == 3 && history.last().runId == record.runId);
    CHECK(history.first().sequence == 2);
    // Records from separate runs may arrive interleaved; ordering and
    // duplicate detection must still use the complete run + sequence key.
    record.runId = {QStringLiteral("run-a")}; record.sequence = 4;
    CHECK(application::insertPeakRecord(history, record, 4));
    record.runId = {QStringLiteral("run-b")}; record.sequence = 2;
    CHECK(application::insertPeakRecord(history, record, 5));
    CHECK(history.at(0).runId.value == QStringLiteral("run-a") && history.at(0).sequence == 2);
    CHECK(history.at(1).runId.value == QStringLiteral("run-a") && history.at(1).sequence == 3);
    CHECK(history.at(2).runId.value == QStringLiteral("run-a") && history.at(2).sequence == 4);
    CHECK(history.at(3).runId.value == QStringLiteral("run-b") && history.at(3).sequence == 1);
    CHECK(history.at(4).runId.value == QStringLiteral("run-b") && history.at(4).sequence == 2);
    CHECK(!application::insertPeakRecord(history, record, 5));
    QTemporaryDir directory; CHECK(directory.isValid());
    QVector<contracts::PeakRecord> records;
    record = history.first(); record.reason = QStringLiteral("中文, \"引号\"\n第二行");
    for (int i = 0; i < 6001; ++i) { auto r = record; r.sequence = i + 1; r.acquiredAtUtc = record.acquiredAtUtc.addMSecs(i); records.push_back(r); }
    records[1].peakValue.reset(); records[1].peakX.reset(); records[1].validity = contracts::DataValidity::Invalid;
    const QString path = directory.filePath(QStringLiteral("子目录/峰值.csv"));
    const auto saved = storage::exportPeakRecordsCsv(records, path); CHECK(saved.success);
    QFile file(path); CHECK(file.open(QIODevice::ReadOnly)); const QByteArray bytes = file.readAll();
    CHECK(bytes.startsWith(QByteArray::fromHex("efbbbf")));
    const auto rows = parseCsv(bytes); CHECK(rows.size() == records.size() + 1);
    const QStringList fields = rows.first();
    auto cell = [&](int row, const char *name) { return rows.at(row).at(fields.indexOf(QString::fromLatin1(name))); };
    CHECK(cell(1, "peak_value").toDouble() == *records.first().peakValue);
    CHECK(cell(2, "peak_value").isEmpty() && cell(2, "peak_x").isEmpty() && cell(2, "validity") == QStringLiteral("Invalid"));
    CHECK(cell(1, "reason") == record.reason && cell(1, "time_zone") == QString::fromUtf8(QTimeZone::systemTimeZoneId()));
    CHECK(QDateTime::fromString(cell(1, "acquisition_time_local"), Qt::ISODateWithMs) == record.acquiredAtUtc);
    CHECK(cell(1, "acquisition_time_utc") == record.acquiredAtUtc.toUTC().toString(Qt::ISODateWithMs));
    CHECK(QJsonDocument::fromJson(cell(1, "parameters_json").toUtf8()).object().value(QStringLiteral("id")).toString() == parameters.id);
    CHECK(cell(1, "device_id") == parameters.deviceId && cell(1, "is_simulation") == QStringLiteral("1"));
    CHECK(!storage::exportPeakRecordsCsv({}, path).success);
    const QString occupied = directory.filePath(QStringLiteral("occupied")); CHECK(QDir().mkpath(occupied));
    CHECK(!storage::exportPeakRecordsCsv(records, occupied).success);
    std::printf("Peak extraction, nulls, negative maxima, ordering, duplicate rejection, metadata and 6001 CSV source rows: PASS\n");
    return 0;
}
