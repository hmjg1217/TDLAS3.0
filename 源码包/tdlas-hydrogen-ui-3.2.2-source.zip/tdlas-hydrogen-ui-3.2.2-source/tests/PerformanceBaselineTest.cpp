#include "algorithm/TdlasAlgorithmProcessor.h"

#include <QCoreApplication>
#include <QElapsedTimer>

#include <algorithm>
#include <cmath>
#include <cstdio>

namespace {

QVector<double> fixedInput(qsizetype count)
{
    QVector<double> samples;
    samples.reserve(count);
    for (qsizetype index = 0; index < count; ++index) {
        const double phase = static_cast<double>(index % 500) / 500.0;
        const double baseline = 0.92 + 0.01 * std::exp(-0.5 * std::pow(std::min(phase, 1.0 - phase) / 0.05, 2.0));
        const double absorption = 0.08 * std::exp(-0.5 * std::pow((phase - 0.55) / 0.035, 2.0));
        samples.push_back(baseline - absorption);
    }
    return samples;
}

bool measure(const char *label, const QVector<double> &input,
             const tdlas::algorithm::TdlasAlgorithmConfig &config,
             int iterations)
{
    tdlas::algorithm::TdlasStageTimings accumulated;
    QVector<double> durationsMs;
    durationsMs.reserve(iterations);
    for (int warmup = 0; warmup < 2; ++warmup) {
        const auto result = tdlas::algorithm::processTdlasWindow(input, config);
        if (!result.valid) {
            std::fprintf(stderr, "%s warmup failed: %s\n", label, result.diagnostic.toUtf8().constData());
            return false;
        }
    }
    QElapsedTimer timer;
    timer.start();
    double checksum = 0.0;
    for (int iteration = 0; iteration < iterations; ++iteration) {
        tdlas::algorithm::TdlasStageTimings timings;
        const auto result = tdlas::algorithm::processTdlasWindow(input, config, &timings);
        if (!result.valid) {
            std::fprintf(stderr, "%s iteration failed: %s\n", label, result.diagnostic.toUtf8().constData());
            return false;
        }
        checksum += result.peakAbsorbance;
        accumulated.filterNs += timings.filterNs;
        accumulated.baselineFitNs += timings.baselineFitNs;
        accumulated.preprocessingNs += timings.preprocessingNs;
        accumulated.voigtFitNs += timings.voigtFitNs;
        accumulated.resultAssemblyNs += timings.resultAssemblyNs;
        accumulated.totalNs += timings.totalNs;
        durationsMs.push_back(static_cast<double>(timings.totalNs) / 1.0e6);
    }
    std::sort(durationsMs.begin(), durationsMs.end());
    const double totalMs = static_cast<double>(timer.nsecsElapsed()) / 1.0e6;
    std::printf("ALGORITHM_BASELINE label=%s input_points=%lld iterations=%d total_ms=%.3f mean_ms=%.3f checksum=%.17g\n",
                label, static_cast<long long>(input.size()), iterations, totalMs,
                totalMs / static_cast<double>(iterations), checksum);
    const double scale = 1.0e-6 / static_cast<double>(iterations);
    std::printf("ALGORITHM_STAGES label=%s filter_ms=%.3f baseline_ms=%.3f preprocessing_ms=%.3f voigt_ms=%.3f assembly_ms=%.3f instrumented_total_ms=%.3f\n",
                label, accumulated.filterNs * scale, accumulated.baselineFitNs * scale,
                accumulated.preprocessingNs * scale, accumulated.voigtFitNs * scale,
                accumulated.resultAssemblyNs * scale, accumulated.totalNs * scale);
    std::printf("ALGORITHM_DISTRIBUTION label=%s p50_ms=%.3f p95_ms=%.3f max_ms=%.3f\n",
                label, durationsMs.at(durationsMs.size() / 2),
                durationsMs.at((durationsMs.size() * 95 + 99) / 100 - 1),
                durationsMs.constLast());
    return true;
}

} // namespace

int main(int argc, char *argv[])
{
    QCoreApplication application(argc, argv);
    constexpr int iterations = 30;

    auto ui = tdlas::algorithm::uiAlgorithmConfig();
    ui.samplesPerCycle = 256;
    ui.averagedCyclesPerSpectrum = 20;
    ui.averagedSpectra = 1;
    ui.windowSamples = 5120;
    ui.samplesPerCycleFromBlock = false;

    const auto reference = tdlas::algorithm::referenceAlgorithmConfig();
    if (!measure("ui_256_window", fixedInput(ui.windowSamples), ui, iterations)
        || !measure("reference_100000_window", fixedInput(reference.windowSamples), reference, iterations)) {
        return 1;
    }
    return 0;
}
