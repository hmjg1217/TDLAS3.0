#include "PortableEnvironment.h"

#include <QCoreApplication>
#include <QFile>
#include <QTemporaryDir>
#include <QTextStream>

int main(int argc, char **argv)
{
    QCoreApplication application(argc, argv);
    const char *names[] = {"TDLAS_STORAGE_ROOT", "TDLAS_STORAGE_CONFIG", "TDLAS_PARAMETER_CONFIG",
                           "TDLAS_ACQUISITION_BACKEND", "TDLAS_CAMERA_BACKEND"};
    const auto clear = [&]() { for (const char *name : names) { qunsetenv(name); } };
    clear();
    QTemporaryDir directory(QDir::temp().filePath(QStringLiteral("TDLAS-\u6d4b\u8bd5 \u76ee\u5f55-XXXXXX")));
    if (!directory.isValid()) { return 1; }
    const QDir base(directory.path());
    configurePortableEnvironment(base.path());
    if (!qEnvironmentVariableIsEmpty("TDLAS_STORAGE_ROOT")) { return 2; }
    if (!base.mkpath(QStringLiteral("portable-config"))) { return 3; }
    QFile marker(base.filePath(QStringLiteral("portable-config/runtime.ini")));
    if (!marker.open(QIODevice::WriteOnly)) { return 4; }
    marker.write("[paths]\ndataDirectory=data\nconfigurationDirectory=config\n[backends]\nacquisition=mock\ncamera=mock\n");
    marker.close();
    // A package copied into a new directory must resolve against that directory, never the build host.
    configurePortableEnvironment(base.path());
    if (qEnvironmentVariable("TDLAS_STORAGE_ROOT") != base.filePath(QStringLiteral("data"))
        || qEnvironmentVariable("TDLAS_STORAGE_CONFIG") != base.filePath(QStringLiteral("config/storage.json"))
        || qEnvironmentVariable("TDLAS_PARAMETER_CONFIG") != base.filePath(QStringLiteral("config/measurement-parameters.ini"))
        || qEnvironmentVariable("TDLAS_ACQUISITION_BACKEND") != QStringLiteral("mock")
        || qEnvironmentVariable("TDLAS_CAMERA_BACKEND") != QStringLiteral("mock")) { return 5; }
    qputenv("TDLAS_STORAGE_ROOT", "D:/explicit-data");
    qputenv("TDLAS_ACQUISITION_BACKEND", "nidaqmx");
    configurePortableEnvironment(base.path());
    if (qEnvironmentVariable("TDLAS_STORAGE_ROOT") != QStringLiteral("D:/explicit-data")
        || qEnvironmentVariable("TDLAS_ACQUISITION_BACKEND") != QStringLiteral("nidaqmx")) { return 6; }
    clear();
    QTextStream(stdout) << "Portable defaults, relocation and explicit overrides PASS\n";
    return 0;
}
