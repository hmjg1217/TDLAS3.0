#include "acquisition/MockAcquisitionDevice.h"
#include "algorithm/TdlasAlgorithmProcessor.h"
#include "application/MeasurementApplicationService.h"
#include "parameter/ParameterService.h"
#include "storage/FileStorageRepository.h"

#include <QCoreApplication>
#include <QDir>
#include <QElapsedTimer>
#include <QFile>
#include <QJsonDocument>
#include <QJsonObject>
#include <QTemporaryDir>
#include <QThread>

#include <atomic>
#include <cstdio>
#ifdef Q_OS_WIN
#include <Windows.h>
#include <Psapi.h>
#endif

namespace {

qint64 workingSetBytes()
{
#ifdef Q_OS_WIN
    PROCESS_MEMORY_COUNTERS counters{};
    if (GetProcessMemoryInfo(GetCurrentProcess(), &counters, sizeof(counters)))
        return static_cast<qint64>(counters.WorkingSetSize);
#endif
    return -1;
}

class MeasuredAlgorithm final : public tdlas::algorithm::IAlgorithmProcessor
{
public:
    tdlas::contracts::ProcessingResult process(
        const tdlas::contracts::RawDataBlock &block,
        const tdlas::contracts::ParameterSnapshot &parameters) const override
    {
        auto result = processor.process(block, parameters);
        consumed.fetch_add(1, std::memory_order_relaxed);
        return result;
    }
    mutable tdlas::algorithm::TdlasAlgorithmProcessor processor;
    mutable std::atomic<quint64> consumed{0};
};

class MeasuredStorage final : public tdlas::storage::IStorageRepository
{
public:
    explicit MeasuredStorage(const QString &root, int delayMs)
        : repository(tdlas::storage::StorageConfiguration{root}), delayMilliseconds(delayMs) {}

    tdlas::storage::StorageOperationResult beginExperiment(
        const tdlas::storage::ExperimentContext &context) override
    { return repository.beginExperiment(context); }

    tdlas::storage::StorageOperationResult appendRawData(
        const tdlas::contracts::ExperimentId &id,
        const tdlas::contracts::RawDataBlock &block) override
    {
        if (delayMilliseconds > 0) QThread::msleep(delayMilliseconds);
        auto result = repository.appendRawData(id, block);
        if (result.success) rawConsumed.fetch_add(1, std::memory_order_relaxed);
        else failures.fetch_add(1, std::memory_order_relaxed);
        return result;
    }

    tdlas::storage::StorageOperationResult appendProcessingResult(
        const tdlas::contracts::ExperimentId &id,
        const tdlas::contracts::ProcessingResult &resultValue) override
    {
        auto result = repository.appendProcessingResult(id, resultValue);
        if (result.success) resultConsumed.fetch_add(1, std::memory_order_relaxed);
        else failures.fetch_add(1, std::memory_order_relaxed);
        return result;
    }

    tdlas::storage::StorageOperationResult finishExperiment(
        const tdlas::contracts::ExperimentId &id,
        tdlas::storage::ExperimentCompletionStatus status,
        const QDateTime &completedAtUtc, const QString &diagnostic) override
    { return repository.finishExperiment(id, status, completedAtUtc, diagnostic); }

    QString experimentDirectory(const tdlas::contracts::ExperimentId &id) const override
    { return repository.experimentDirectory(id); }

    tdlas::storage::FileStorageRepository repository;
    int delayMilliseconds = 0;
    std::atomic<quint64> rawConsumed{0};
    std::atomic<quint64> resultConsumed{0};
    std::atomic<quint64> failures{0};
};

void pump(int milliseconds)
{
    QElapsedTimer timer;
    timer.start();
    while (timer.elapsed() < milliseconds) {
        QCoreApplication::processEvents(QEventLoop::AllEvents, 5);
        QThread::msleep(1);
    }
}

} // namespace

int main(int argc, char *argv[])
{
    QCoreApplication application(argc, argv);
    bool ok = false;
    int seconds = qEnvironmentVariableIntValue("TDLAS_P3_SECONDS", &ok);
    if (!ok || seconds <= 0) seconds = 3;
    int points = qEnvironmentVariableIntValue("TDLAS_P3_BLOCK_POINTS", &ok);
    if (!ok || points <= 0) points = 1000;
    int interval = qEnvironmentVariableIntValue("TDLAS_P3_INTERVAL_MS", &ok);
    if (!ok || interval <= 0) interval = points / 100;
    int delay = qEnvironmentVariableIntValue("TDLAS_P3_STORAGE_DELAY_MS", &ok);
    if (!ok || delay < 0) delay = 0;
    QTemporaryDir temporary;
    const QString root = qEnvironmentVariable("TDLAS_P3_ROOT", temporary.path());
    if (root.isEmpty() || !QDir().mkpath(root)) return 1;

    tdlas::acquisition::MockAcquisitionOptions acquisitionOptions;
    acquisitionOptions.blockIntervalMilliseconds = interval;
    tdlas::acquisition::MockAcquisitionDevice device(acquisitionOptions);
    MeasuredAlgorithm algorithm;
    MeasuredStorage storage(root, delay);
    tdlas::application::MeasurementApplicationOptions options;
    options.peakHistoryCapacity = 120;
    tdlas::application::MeasurementApplicationService service(device, algorithm, storage, options);
    tdlas::contracts::StartMeasurementRequest request;
    auto draft = tdlas::contracts::ParameterDraft::mockDefaults();
    draft.readSamplesPerBlock = points;
    draft.sampleRateHz = 100000;
    draft.waveform = tdlas::contracts::Waveform::Sawtooth;
    tdlas::parameter::ParameterService parameterService;
    const auto commit = parameterService.commit(draft);
    if (!commit.isSuccess()) return 2;
    request.parameters = *commit.snapshot;

    quint64 algorithmProduced = 0, rawProduced = 0, resultProduced = 0;
    QObject::connect(&service, &tdlas::application::MeasurementApplicationService::algorithmProcessingRequested,
        &service, [&](const auto &, const auto &) { ++algorithmProduced; });
    QObject::connect(&service, &tdlas::application::MeasurementApplicationService::storageRawDataRequested,
        &service, [&](const auto &, const auto &) { ++rawProduced; });
    QObject::connect(&service, &tdlas::application::MeasurementApplicationService::storageResultRequested,
        &service, [&](const auto &, const auto &) { ++resultProduced; });
    if (!service.start(request)) return 3;

    quint64 peakAlgorithmQueue = 0, peakRawQueue = 0, peakResultQueue = 0;
    qint64 peakMemory = workingSetBytes();
    const qint64 startMemory = peakMemory;
    QElapsedTimer timer;
    timer.start();
    while (timer.elapsed() < seconds * 1000) {
        pump(20);
        peakAlgorithmQueue = qMax(peakAlgorithmQueue, algorithmProduced - algorithm.consumed.load());
        peakRawQueue = qMax(peakRawQueue, rawProduced - storage.rawConsumed.load());
        peakResultQueue = qMax(peakResultQueue, resultProduced - storage.resultConsumed.load());
        peakMemory = qMax(peakMemory, workingSetBytes());
        if (service.state() == tdlas::contracts::MeasurementState::Faulted) return 4;
    }
    const qint64 runningMilliseconds = timer.elapsed();
    const quint64 algorithmAtStop = algorithmProduced;
    const quint64 rawAtStop = rawProduced;
    if (!service.stop(service.currentRunId())) return 5;
    QElapsedTimer drain;
    drain.start();
    while (service.state() != tdlas::contracts::MeasurementState::Idle && drain.elapsed() < 120000)
        pump(10);
    const qint64 drainMilliseconds = drain.elapsed();
    pump(100);
    const auto model = service.displayModel();
    const quint64 finalResultProduced = resultProduced;
    const auto experimentDir = storage.experimentDirectory(model.experimentId);
    const auto rawFiles = QDir(experimentDir + QStringLiteral("/raw")).entryList({QStringLiteral("*.csv")}, QDir::Files).size();
    const auto resultFiles = QDir(experimentDir + QStringLiteral("/results")).entryList({QStringLiteral("*.json")}, QDir::Files).size();
    QFile manifestFile(experimentDir + QStringLiteral("/manifest.json"));
    const QJsonObject manifest = manifestFile.open(QIODevice::ReadOnly)
        ? QJsonDocument::fromJson(manifestFile.readAll()).object() : QJsonObject{};
    std::printf("P3_THROUGHPUT points=%d interval_ms=%d seconds=%d delay_ms=%d running_ms=%lld "
        "algorithm_produced=%llu algorithm_consumed=%llu algorithm_peak_queue=%llu "
        "raw_produced=%llu raw_consumed=%llu raw_peak_queue=%llu "
        "result_produced=%llu result_consumed=%llu result_peak_queue=%llu "
        "drain_ms=%lld memory_start_bytes=%lld memory_peak_bytes=%lld memory_end_bytes=%lld "
        "raw_files=%d result_files=%d failures=%llu state=%d storage_state=%d\n",
        points, interval, seconds, delay, static_cast<long long>(runningMilliseconds),
        static_cast<unsigned long long>(algorithmAtStop),
        static_cast<unsigned long long>(algorithm.consumed.load()),
        static_cast<unsigned long long>(peakAlgorithmQueue),
        static_cast<unsigned long long>(rawAtStop),
        static_cast<unsigned long long>(storage.rawConsumed.load()),
        static_cast<unsigned long long>(peakRawQueue),
        static_cast<unsigned long long>(finalResultProduced),
        static_cast<unsigned long long>(storage.resultConsumed.load()),
        static_cast<unsigned long long>(peakResultQueue),
        static_cast<long long>(drainMilliseconds),
        static_cast<long long>(startMemory), static_cast<long long>(peakMemory),
        static_cast<long long>(workingSetBytes()), static_cast<int>(rawFiles), static_cast<int>(resultFiles),
        static_cast<unsigned long long>(storage.failures.load()),
        static_cast<int>(model.state), static_cast<int>(model.storageState));
    return model.state == tdlas::contracts::MeasurementState::Idle
        && model.storageState == tdlas::contracts::ExperimentStorageState::Saved
        && algorithm.consumed.load() == algorithmAtStop
        && storage.rawConsumed.load() == rawAtStop
        && storage.resultConsumed.load() == finalResultProduced
        && finalResultProduced == algorithmAtStop / 20
        && rawFiles == static_cast<int>(rawAtStop)
        && resultFiles == static_cast<int>(storage.resultConsumed.load())
        && manifest.value(QStringLiteral("status")).toString() == QStringLiteral("completed")
        && manifest.value(QStringLiteral("rawBlockCount")).toInt() == rawFiles
        && manifest.value(QStringLiteral("resultCount")).toInt() == resultFiles
        && storage.failures.load() == 0 ? 0 : 6;
}
