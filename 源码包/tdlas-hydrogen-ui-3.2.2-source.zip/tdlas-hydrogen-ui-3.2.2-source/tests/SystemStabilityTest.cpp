#include "acquisition/MockAcquisitionDevice.h"
#include "algorithm/MockAlgorithmProcessor.h"
#include "application/MeasurementApplicationService.h"
#include "camera/CameraApplicationService.h"
#include "camera/MockCameraDevice.h"
#include "storage/IStorageRepository.h"

#include <QCoreApplication>
#include <QElapsedTimer>
#include <QMutex>
#include <QMutexLocker>
#include <QSet>
#include <QTemporaryDir>
#include <QThread>

#include <cstdio>
#include <functional>
#include <memory>

namespace {

bool waitFor(const std::function<bool()> &condition, int timeoutMilliseconds = 3000)
{
    QElapsedTimer timer;
    timer.start();
    while (!condition() && timer.elapsed() < timeoutMilliseconds) {
        QCoreApplication::processEvents(QEventLoop::AllEvents, 10);
        QThread::msleep(1);
    }
    return condition();
}

class CountingStorageRepository final : public tdlas::storage::IStorageRepository
{
public:
    tdlas::storage::StorageOperationResult beginExperiment(
        const tdlas::storage::ExperimentContext &context) override
    {
        QMutexLocker locker(&mutex_);
        if (active_ || !context.experimentId.isValid() || !context.runId.isValid()
            || experimentIds_.contains(context.experimentId.value)) {
            return tdlas::storage::StorageOperationResult::failed(
                QStringLiteral("SOAK_BEGIN_INVALID"), QStringLiteral("soak begin invalid"), {});
        }
        active_ = true;
        experimentId_ = context.experimentId;
        runId_ = context.runId;
        lastRawSequence_ = 0;
        lastResultSequence_ = 0;
        experimentIds_.insert(context.experimentId.value);
        ++beginCount_;
        return tdlas::storage::StorageOperationResult::succeeded(
            QStringLiteral("soak://%1").arg(context.experimentId.value));
    }

    tdlas::storage::StorageOperationResult appendRawData(
        const tdlas::contracts::ExperimentId &experimentId,
        const tdlas::contracts::RawDataBlock &block) override
    {
        QMutexLocker locker(&mutex_);
        if (!active_ || experimentId != experimentId_ || block.runId != runId_
            || block.sequence <= lastRawSequence_) {
            return tdlas::storage::StorageOperationResult::failed(
                QStringLiteral("SOAK_RAW_INVALID"), QStringLiteral("soak raw invalid"), {});
        }
        lastRawSequence_ = block.sequence;
        ++rawCount_;
        return tdlas::storage::StorageOperationResult::succeeded();
    }

    tdlas::storage::StorageOperationResult appendProcessingResult(
        const tdlas::contracts::ExperimentId &experimentId,
        const tdlas::contracts::ProcessingResult &result) override
    {
        QMutexLocker locker(&mutex_);
        if (!active_ || experimentId != experimentId_ || result.runId != runId_
            || result.sourceSequence <= lastResultSequence_) {
            return tdlas::storage::StorageOperationResult::failed(
                QStringLiteral("SOAK_RESULT_INVALID"), QStringLiteral("soak result invalid"), {});
        }
        lastResultSequence_ = result.sourceSequence;
        ++resultCount_;
        return tdlas::storage::StorageOperationResult::succeeded();
    }

    tdlas::storage::StorageOperationResult finishExperiment(
        const tdlas::contracts::ExperimentId &experimentId,
        tdlas::storage::ExperimentCompletionStatus status,
        const QDateTime &,
        const QString &) override
    {
        QMutexLocker locker(&mutex_);
        if (!active_ || experimentId != experimentId_
            || status != tdlas::storage::ExperimentCompletionStatus::Completed) {
            return tdlas::storage::StorageOperationResult::failed(
                QStringLiteral("SOAK_FINISH_INVALID"), QStringLiteral("soak finish invalid"), {});
        }
        active_ = false;
        ++finishCount_;
        return tdlas::storage::StorageOperationResult::succeeded();
    }

    QString experimentDirectory(const tdlas::contracts::ExperimentId &experimentId) const override
    {
        return QStringLiteral("soak://%1").arg(experimentId.value);
    }

    struct Counts {
        quint64 begins = 0;
        quint64 finishes = 0;
        quint64 raw = 0;
        quint64 results = 0;
        bool active = false;
    };

    Counts counts() const
    {
        QMutexLocker locker(&mutex_);
        return {beginCount_, finishCount_, rawCount_, resultCount_, active_};
    }

private:
    mutable QMutex mutex_;
    bool active_ = false;
    tdlas::contracts::ExperimentId experimentId_;
    tdlas::contracts::RunId runId_;
    tdlas::contracts::Sequence lastRawSequence_ = 0;
    tdlas::contracts::Sequence lastResultSequence_ = 0;
    QSet<QString> experimentIds_;
    quint64 beginCount_ = 0;
    quint64 finishCount_ = 0;
    quint64 rawCount_ = 0;
    quint64 resultCount_ = 0;
};

} // namespace

int main(int argc, char *argv[])
{
    QCoreApplication application(argc, argv);
    QTemporaryDir temporary;
    if (!temporary.isValid()) {
        return 1;
    }
    bool secondsOk = false;
    int soakSeconds = qEnvironmentVariableIntValue("TDLAS_SOAK_SECONDS", &secondsOk);
    if (!secondsOk || soakSeconds <= 0) {
        soakSeconds = 3;
    }

    tdlas::camera::MockCameraOptions cameraOptions;
    cameraOptions.frameIntervalMilliseconds = 5;
    cameraOptions.frameSize = QSize(160, 90);
    tdlas::camera::CameraApplicationService camera(
        std::make_unique<tdlas::camera::MockCameraDevice>(cameraOptions), temporary.path());
    tdlas::camera::CameraDisplayModel cameraModel;
    QObject::connect(
        &camera, &tdlas::camera::CameraApplicationService::displayModelChanged,
        &camera, [&](const tdlas::camera::CameraDisplayModel &model) { cameraModel = model; });
    camera.refreshDevices();
    if (!waitFor([&]() { return !cameraModel.devices.isEmpty(); })) {
        return 2;
    }
    camera.startPreview(QStringLiteral("mock-camera-0"));
    if (!waitFor([&]() {
            return cameraModel.state == tdlas::camera::CameraSessionState::Previewing
                && cameraModel.latestFrame.has_value();
        })) {
        return 3;
    }

    tdlas::acquisition::MockAcquisitionOptions acquisitionOptions;
    acquisitionOptions.blockIntervalMilliseconds = 1;
    tdlas::acquisition::MockAcquisitionDevice device(acquisitionOptions);
    tdlas::algorithm::MockAlgorithmProcessor algorithm;
    CountingStorageRepository storage;
    tdlas::application::MeasurementApplicationOptions applicationOptions;
    applicationOptions.displayRefreshIntervalMilliseconds = 2;
    applicationOptions.peakHistoryCapacity = 120;
    tdlas::application::MeasurementApplicationService service(
        device, algorithm, storage, applicationOptions);
    tdlas::contracts::StartMeasurementRequest request;
    request.parameters = tdlas::contracts::ParameterSnapshot::mockDefaults();
    request.operatorId = QStringLiteral("m8-soak-test");

    QSet<QString> runIds;
    QElapsedTimer soakTimer;
    soakTimer.start();
    quint64 cycles = 0;
    while (soakTimer.elapsed() < soakSeconds * 1000) {
        if (!service.start(request)) {
            return 4;
        }
        const auto runId = service.currentRunId();
        if (!runId.isValid() || runIds.contains(runId.value)) {
            return 5;
        }
        runIds.insert(runId.value);
        if (!waitFor([&]() { return service.displayModel().peakHistory.size() >= 8; })) {
            return 6;
        }
        const auto model = service.displayModel();
        if (model.state != tdlas::contracts::MeasurementState::Running
            || model.rawVoltageV.isEmpty() || model.absorbance.isEmpty()
            || model.concentration.has_value() || model.peakHistory.size() > 120) {
            return 7;
        }
        const bool stopped = service.stop(runId);
        if (!stopped || !waitFor([&]() {
                return service.state() == tdlas::contracts::MeasurementState::Idle
                    && service.displayModel().storageState
                        == tdlas::contracts::ExperimentStorageState::Saved;
            })
            || device.connectionState() != tdlas::contracts::DeviceConnectionState::Connected
            || device.acquisitionState() != tdlas::contracts::AcquisitionState::Idle) {
            std::fprintf(
                stderr, "stop mismatch stopped=%d state=%d storage=%d connection=%d acquisition=%d\n",
                stopped ? 1 : 0,
                static_cast<int>(service.state()),
                static_cast<int>(service.displayModel().storageState),
                static_cast<int>(device.connectionState()),
                static_cast<int>(device.acquisitionState()));
            return 8;
        }
        ++cycles;
    }

    const auto counts = storage.counts();
    if (cycles < static_cast<quint64>(soakSeconds)
        || counts.active || counts.begins != cycles || counts.finishes != cycles
        || counts.raw < cycles * 8 || counts.results < cycles * 8
        || cameraModel.latestFrame->sequence < static_cast<quint64>(soakSeconds * 20)) {
        std::fprintf(
            stderr,
            "soak mismatch seconds=%d cycles=%llu begin=%llu finish=%llu raw=%llu result=%llu camera=%llu\n",
            soakSeconds,
            static_cast<unsigned long long>(cycles),
            static_cast<unsigned long long>(counts.begins),
            static_cast<unsigned long long>(counts.finishes),
            static_cast<unsigned long long>(counts.raw),
            static_cast<unsigned long long>(counts.results),
            static_cast<unsigned long long>(cameraModel.latestFrame->sequence));
        return 9;
    }
    if (!device.disconnectDevice()
        || device.connectionState() != tdlas::contracts::DeviceConnectionState::Disconnected) {
        return 12;
    }

    tdlas::acquisition::MockAcquisitionOptions faultOptions;
    faultOptions.blockIntervalMilliseconds = 1;
    faultOptions.faultAfterGeneratedBlocks = 3;
    tdlas::acquisition::MockAcquisitionDevice faultDevice(faultOptions);
    tdlas::application::MeasurementApplicationService faultService(faultDevice, algorithm);
    for (int cycle = 0; cycle < 20; ++cycle) {
        if (!faultService.start(request)
            || !waitFor([&]() {
                return faultService.state() == tdlas::contracts::MeasurementState::Faulted;
            })
            || faultDevice.connectionState()
                != tdlas::contracts::DeviceConnectionState::Disconnected
            || faultDevice.acquisitionState() != tdlas::contracts::AcquisitionState::Idle
            || !faultService.resetFault()
            || faultService.state() != tdlas::contracts::MeasurementState::Idle) {
            return 10;
        }
    }

    const quint64 cameraFrames = cameraModel.latestFrame.has_value()
        ? cameraModel.latestFrame->sequence : 0;
    camera.shutdown();
    if (!waitFor([&]() {
            return cameraModel.state == tdlas::camera::CameraSessionState::Idle;
        })
        || camera.workerThreadRunning()) {
        return 11;
    }

    std::printf(
        "M8_SOAK_PASS seconds=%d cycles=%llu raw=%llu results=%llu camera_frames=%llu fault_recoveries=20\n",
        soakSeconds,
        static_cast<unsigned long long>(cycles),
        static_cast<unsigned long long>(counts.raw),
        static_cast<unsigned long long>(counts.results),
        static_cast<unsigned long long>(cameraFrames));
    return 0;
}
