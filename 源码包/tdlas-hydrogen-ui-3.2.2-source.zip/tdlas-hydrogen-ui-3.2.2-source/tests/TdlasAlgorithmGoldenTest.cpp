#include "algorithm/TdlasAlgorithmProcessor.h"

#include <QCoreApplication>
#include <QFile>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <limits>
#include <optional>

namespace {

using tdlas::algorithm::TdlasAlgorithmConfig;
using tdlas::contracts::ProcessingResult;

QVector<double> fixedInput(qsizetype count)
{
    QVector<double> samples;
    samples.reserve(count);
    for (qsizetype index = 0; index < count; ++index) {
        const double phase = static_cast<double>(index % 500) / 500.0;
        const double baseline = 0.92 + 0.01 * std::exp(-0.5 * std::pow(std::min(phase, 1.0 - phase) / 0.05, 2.0));
        const double absorption = 0.08 * std::exp(-0.5 * std::pow((phase - 0.55) / 0.035, 2.0));
        samples.push_back(baseline - absorption);
    }
    return samples;
}

QJsonArray arrayOf(const QVector<double> &values)
{
    QJsonArray array;
    for (double value : values) {
        array.append(value);
    }
    return array;
}

QJsonValue optionalNumber(const std::optional<double> &value)
{
    return value ? QJsonValue(*value) : QJsonValue(QJsonValue::Null);
}

QJsonObject serialize(const ProcessingResult &result)
{
    return {
        {QStringLiteral("runId"), result.runId.value},
        {QStringLiteral("sourceSequence"), static_cast<double>(result.sourceSequence)},
        {QStringLiteral("timestampUtc"), result.timestamp.utc.toString(Qt::ISODateWithMs)},
        {QStringLiteral("timestampMonotonicNs"), QString::number(result.timestamp.monotonicNanoseconds)},
        {QStringLiteral("parameterSnapshotId"), result.parameterSnapshotId},
        {QStringLiteral("algorithmVersion"), result.algorithmVersion},
        {QStringLiteral("calibrationVersion"), result.calibrationVersion},
        {QStringLiteral("timeSeconds"), arrayOf(result.timeSeconds)},
        {QStringLiteral("relativeFrequencyCm1"), arrayOf(result.relativeFrequencyCm1)},
        {QStringLiteral("voltageV"), arrayOf(result.voltageV)},
        {QStringLiteral("baselineV"), arrayOf(result.baselineV)},
        {QStringLiteral("fittedVoltageV"), arrayOf(result.fittedVoltageV)},
        {QStringLiteral("absorbance"), arrayOf(result.absorbance)},
        {QStringLiteral("fittedAbsorbance"), arrayOf(result.fittedAbsorbance)},
        {QStringLiteral("voigtCenterCm1"), optionalNumber(result.voigtCenterCm1)},
        {QStringLiteral("voigtAmplitude"), optionalNumber(result.voigtAmplitude)},
        {QStringLiteral("voigtGaussianFwhmCm1"), optionalNumber(result.voigtGaussianFwhmCm1)},
        {QStringLiteral("voigtLorentzianFwhmCm1"), optionalNumber(result.voigtLorentzianFwhmCm1)},
        {QStringLiteral("voigtResidualSumSquares"), optionalNumber(result.voigtResidualSumSquares)},
        {QStringLiteral("peakAbsorbance"), optionalNumber(result.peakAbsorbance)},
        {QStringLiteral("lightPercent"), optionalNumber(result.lightPercent)},
        {QStringLiteral("concentration"), optionalNumber(result.concentration)},
        {QStringLiteral("concentrationUnit"), result.concentrationUnit},
        {QStringLiteral("validity"), static_cast<int>(result.validity)},
        {QStringLiteral("diagnostic"), result.diagnostic},
    };
}

tdlas::contracts::RawDataBlock blockFor(const QVector<double> &samples, tdlas::contracts::Sequence sequence)
{
    tdlas::contracts::RawDataBlock block;
    block.runId = {QStringLiteral("p0-fixed-run")};
    block.streamId = QStringLiteral("p0-fixed-stream");
    block.sequence = sequence;
    block.sampleStart.utc = QDateTime::fromMSecsSinceEpoch(1767225600123, Qt::UTC);
    block.sampleStart.monotonicNanoseconds = 987654321;
    block.sampleRateHz = 100000.0;
    block.sampleCountPerChannel = samples.size();
    block.validity = tdlas::contracts::DataValidity::Valid;
    block.channels.push_back({QStringLiteral("sim/ai0"), samples});
    return block;
}

QJsonObject scenario(qsizetype inputCount, TdlasAlgorithmConfig config)
{
    const QVector<double> samples = fixedInput(inputCount);
    tdlas::contracts::ParameterSnapshot parameters = tdlas::contracts::ParameterSnapshot::mockDefaults();
    parameters.id = QStringLiteral("p0-fixed-parameters");
    parameters.algorithmParameterSetId = config.parameterSetId;
    parameters.readSamplesPerBlock = inputCount;
    parameters.sampleRateHz = 100000.0;
    tdlas::algorithm::TdlasAlgorithmProcessor processor(config);
    const auto result = processor.process(blockFor(samples, 7), parameters);
    return serialize(result);
}

QJsonObject actualResults()
{
    TdlasAlgorithmConfig ui = tdlas::algorithm::uiAlgorithmConfig();
    // Freeze the historical averaged configuration as a numerical baseline.
    ui.algorithmVersion = QStringLiteral("tdlas-v1.6-cpp");
    ui.alignAtMaximum = true;
    ui.useMeasuredVoigtSeed = false;
    ui.samplesPerCycle = 256;
    ui.averagedCyclesPerSpectrum = 20;
    ui.averagedSpectra = 1;
    ui.windowSamples = 5120;
    ui.samplesPerCycleFromBlock = false;

    QJsonObject results;
    results.insert(QStringLiteral("ui_256_window"), scenario(5120, ui));
    results.insert(QStringLiteral("reference_100000_window"),
                   scenario(100000, tdlas::algorithm::referenceAlgorithmConfig()));

    tdlas::contracts::ParameterSnapshot parameters = tdlas::contracts::ParameterSnapshot::mockDefaults();
    parameters.id = QStringLiteral("p0-fixed-parameters");
    parameters.readSamplesPerBlock = 5120;
    tdlas::algorithm::TdlasAlgorithmProcessor processor(ui);
    auto invalidBlock = blockFor(fixedInput(5120), 8);
    invalidBlock.channels[0].samplesV[7] = std::numeric_limits<double>::quiet_NaN();
    results.insert(QStringLiteral("nonfinite_input"), serialize(processor.process(invalidBlock, parameters)));
    invalidBlock = blockFor(fixedInput(5120), 9);
    invalidBlock.channels.clear();
    results.insert(QStringLiteral("missing_channel"), serialize(processor.process(invalidBlock, parameters)));
    invalidBlock = blockFor(fixedInput(5120), 10);
    invalidBlock.sampleCountPerChannel = 5119;
    results.insert(QStringLiteral("invalid_block_length"), serialize(processor.process(invalidBlock, parameters)));
    const auto invalidFit = tdlas::algorithm::fitVoigt({0.0}, {});
    results.insert(QStringLiteral("invalid_fit"), QJsonObject{
        {QStringLiteral("valid"), invalidFit.valid},
        {QStringLiteral("diagnostic"), invalidFit.diagnostic},
    });
    return results;
}

struct Difference {
    double maxAbsolute = 0.0;
    double maxRelative = 0.0;
    bool match = true;
};

void compare(const QJsonValue &expected, const QJsonValue &actual, const QString &path, Difference *difference)
{
    if (expected.type() != actual.type()) {
        std::fprintf(stderr, "%s: JSON type differs\n", qPrintable(path));
        difference->match = false;
        return;
    }
    if (expected.isObject()) {
        const QJsonObject expectedObject = expected.toObject();
        const QJsonObject actualObject = actual.toObject();
        if (expectedObject.size() != actualObject.size()) {
            std::fprintf(stderr, "%s: object size differs\n", qPrintable(path));
            difference->match = false;
        }
        for (auto item = expectedObject.begin(); item != expectedObject.end(); ++item) {
            compare(item.value(), actualObject.value(item.key()), path + QLatin1Char('.') + item.key(), difference);
        }
    } else if (expected.isArray()) {
        const QJsonArray expectedArray = expected.toArray();
        const QJsonArray actualArray = actual.toArray();
        if (expectedArray.size() != actualArray.size()) {
            std::fprintf(stderr, "%s: array size differs: %lld versus %lld\n", qPrintable(path),
                         static_cast<long long>(expectedArray.size()), static_cast<long long>(actualArray.size()));
            difference->match = false;
        }
        for (qsizetype index = 0; index < std::min(expectedArray.size(), actualArray.size()); ++index) {
            compare(expectedArray.at(index), actualArray.at(index),
                    path + QLatin1Char('[') + QString::number(index) + QLatin1Char(']'), difference);
        }
    } else if (expected.isDouble()) {
        const double reference = expected.toDouble();
        const double measured = actual.toDouble();
        const double absolute = std::abs(reference - measured);
        const double relative = absolute / std::max(std::abs(reference), 1.0e-12);
        difference->maxAbsolute = std::max(difference->maxAbsolute, absolute);
        difference->maxRelative = std::max(difference->maxRelative, relative);
        if (!std::isfinite(measured) || absolute > 1.0e-12 + 1.0e-12 * std::abs(reference)) {
            std::fprintf(stderr, "%s: %.17g versus %.17g\n", qPrintable(path), reference, measured);
            difference->match = false;
        }
    } else if (expected != actual) {
        std::fprintf(stderr, "%s: JSON value differs\n", qPrintable(path));
        difference->match = false;
    }
}

} // namespace

int main(int argc, char *argv[])
{
    QCoreApplication application(argc, argv);
    const QJsonObject actual = actualResults();
    QFile file(QStringLiteral(TDLAS_ALGORITHM_GOLDEN_PATH));
    if (application.arguments().contains(QStringLiteral("--capture"))) {
        if (!file.open(QIODevice::WriteOnly | QIODevice::Truncate)
            || file.write(QJsonDocument(actual).toJson(QJsonDocument::Indented)) < 0) {
            std::fprintf(stderr, "could not capture algorithm golden fixture\n");
            return 2;
        }
        return 0;
    }
    if (!file.open(QIODevice::ReadOnly)) {
        std::fprintf(stderr, "could not read algorithm golden fixture\n");
        return 2;
    }
    QJsonParseError error;
    const QJsonDocument expected = QJsonDocument::fromJson(file.readAll(), &error);
    if (error.error != QJsonParseError::NoError || !expected.isObject()) {
        std::fprintf(stderr, "invalid algorithm golden fixture\n");
        return 2;
    }
    Difference difference;
    compare(expected.object(), actual, QStringLiteral("algorithm"), &difference);
    std::printf("ALGORITHM_GOLDEN max_absolute=%.17g max_relative=%.17g match=%d\n",
                difference.maxAbsolute, difference.maxRelative, difference.match ? 1 : 0);
    return difference.match ? 0 : 1;
}
