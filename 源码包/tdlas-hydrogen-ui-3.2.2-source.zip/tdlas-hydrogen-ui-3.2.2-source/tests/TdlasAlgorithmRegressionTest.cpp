#include "algorithm/TdlasAlgorithmProcessor.h"

#include <QCoreApplication>
#include <QDateTime>
#include <QDebug>

#include <algorithm>
#include <cstdio>
#include <cmath>
#include <limits>

namespace {

bool near(double actual, double expected, double tolerance)
{
    return std::abs(actual - expected) <= tolerance;
}

double gaussian(double x, double center, double width)
{
    const double normalized = (x - center) / width;
    return std::exp(-0.5 * normalized * normalized);
}

QVector<double> repeatedCycles(qsizetype samplesPerCycle, qsizetype cycles)
{
    QVector<double> samples;
    samples.reserve(samplesPerCycle * cycles);
    for (qsizetype cycle = 0; cycle < cycles; ++cycle) {
        for (qsizetype index = 0; index < samplesPerCycle; ++index) {
            const double phase = static_cast<double>(index) / static_cast<double>(samplesPerCycle);
            const double edgeDistance = std::min(phase, 1.0 - phase);
            const double baseline = 0.92 + 0.01 * gaussian(edgeDistance, 0.0, 0.05);
            const double absorption = 0.08 * gaussian(phase, 0.55, 0.035);
            samples.push_back(baseline - absorption);
        }
    }
    return samples;
}

QVector<double> repeatedCyclesWithoutAbsorption(qsizetype samplesPerCycle, qsizetype cycles)
{
    QVector<double> samples;
    samples.reserve(samplesPerCycle * cycles);
    for (qsizetype cycle = 0; cycle < cycles; ++cycle) {
        for (qsizetype index = 0; index < samplesPerCycle; ++index) {
            const double phase = static_cast<double>(index) / static_cast<double>(samplesPerCycle);
            const double edgeDistance = std::min(phase, 1.0 - phase);
            samples.push_back(0.92 + 0.01 * gaussian(edgeDistance, 0.0, 0.05));
        }
    }
    return samples;
}

tdlas::contracts::RawDataBlock blockFor(
    tdlas::contracts::Sequence sequence,
    const QVector<double> &samples)
{
    tdlas::contracts::RawDataBlock block;
    block.runId = {QStringLiteral("algorithm-regression-run")};
    block.streamId = QStringLiteral("algorithm-regression-stream");
    block.sequence = sequence;
    block.sampleStart.utc = QDateTime::fromMSecsSinceEpoch(
        1000 + static_cast<qint64>(sequence), Qt::UTC);
    block.sampleRateHz = 5120.0;
    block.sampleCountPerChannel = samples.size();
    block.validity = tdlas::contracts::DataValidity::Valid;
    block.channels.push_back({QStringLiteral("sim/ai0"), samples});
    return block;
}

} // namespace

int main(int argc, char *argv[])
{
    QCoreApplication application(argc, argv);

    const tdlas::algorithm::TdlasAlgorithmConfig reference = tdlas::algorithm::referenceAlgorithmConfig();
    QString configDiagnostic;
    if (!tdlas::algorithm::isValidConfig(reference, &configDiagnostic)
        || reference.samplesPerCycle != 500
        || reference.averagedCyclesPerSpectrum != 10
        || reference.averagedSpectra != 20
        || reference.windowSamples != 100000
        || reference.lowPassNormalizedCutoff != 0.1
        || reference.voltageOffsetV != 4.2
        || reference.frequencyScale != 0.8761 / 30.0) {
        return 1;
    }

    tdlas::algorithm::VoigtParameters knownVoigt;
    knownVoigt.centerCm1 = 0.03;
    knownVoigt.amplitude = 0.006;
    knownVoigt.gaussianFwhmCm1 = 0.08;
    knownVoigt.lorentzianFwhmCm1 = 0.04;
    knownVoigt.valid = true;
    QVector<double> frequency;
    frequency.reserve(161);
    for (int index = 0; index < 161; ++index) {
        frequency.push_back(-0.4 + 0.005 * index);
    }
    const QVector<double> knownCurve = tdlas::algorithm::evaluateVoigt(knownVoigt, frequency);
    const tdlas::algorithm::VoigtParameters fitted = tdlas::algorithm::fitVoigt(frequency, knownCurve);
    if (!fitted.valid
        || !near(fitted.centerCm1, knownVoigt.centerCm1, 2.0e-4)
        || !near(fitted.amplitude, knownVoigt.amplitude, 2.0e-5)
        || !near(fitted.gaussianFwhmCm1, knownVoigt.gaussianFwhmCm1, 5.0e-4)
        || !near(fitted.lorentzianFwhmCm1, knownVoigt.lorentzianFwhmCm1, 5.0e-4)
        || fitted.residualSumSquares > 1.0e-8) {
        qWarning() << "Voigt regression mismatch"
                   << fitted.centerCm1 << fitted.amplitude
                   << fitted.gaussianFwhmCm1 << fitted.lorentzianFwhmCm1
                   << fitted.residualSumSquares;
        return 2;
    }

    const QVector<double> referenceWindow = repeatedCycles(
        reference.samplesPerCycle,
        reference.averagedCyclesPerSpectrum * reference.averagedSpectra);
    const tdlas::algorithm::TdlasSpectrumResult spectrum =
        tdlas::algorithm::processTdlasWindow(referenceWindow, reference);
    if (!spectrum.valid || spectrum.relativeFrequencyCm1.size() != 301
        || spectrum.voltageV.size() != 301 || spectrum.baselineV.size() != 301
        || spectrum.absorbance.size() != 301 || spectrum.fittedAbsorbance.size() != 301
        || spectrum.fittedVoltageV.size() != 301 || spectrum.sampleOffset != 149
        || spectrum.cycleSamples != 500 || !spectrum.voigt.valid) {
        qWarning() << "window regression shape mismatch" << spectrum.diagnostic;
        return 3;
    }
    const qsizetype absorbancePeakIndex = std::distance(
        spectrum.absorbance.cbegin(),
        std::max_element(spectrum.absorbance.cbegin(), spectrum.absorbance.cend()));
    if (spectrum.relativeFrequencyCm1.at(absorbancePeakIndex) != 0.0) {
        return 4;
    }
    for (qsizetype index = 0; index < spectrum.absorbance.size(); ++index) {
        const double expectedAbsorbance = std::log(
            std::max(1.0e-12, spectrum.baselineV.at(index))
            / std::max(1.0e-12, spectrum.voltageV.at(index)));
        if (!near(spectrum.absorbance.at(index), expectedAbsorbance, 1.0e-12)) {
            return 5;
        }
    }
    const tdlas::algorithm::TdlasSpectrumResult noHydrogenSpectrum =
        tdlas::algorithm::processTdlasWindow(
            repeatedCyclesWithoutAbsorption(
                reference.samplesPerCycle,
                reference.averagedCyclesPerSpectrum * reference.averagedSpectra),
            reference);
    const double noHydrogenPeak = noHydrogenSpectrum.valid
        ? *std::max_element(noHydrogenSpectrum.absorbance.cbegin(), noHydrogenSpectrum.absorbance.cend())
        : std::numeric_limits<double>::infinity();
    const double withHydrogenPeak = *std::max_element(
        spectrum.absorbance.cbegin(), spectrum.absorbance.cend());
    if (!noHydrogenSpectrum.valid || withHydrogenPeak <= noHydrogenPeak + 1.0e-4
        || spectrum.peakAbsorbance <= noHydrogenSpectrum.peakAbsorbance + 1.0e-4) {
        std::fprintf(stderr, "absorption sign regression: no-gas=%.17g gas=%.17g (%s)\n",
                     noHydrogenPeak, withHydrogenPeak, noHydrogenSpectrum.diagnostic.toUtf8().constData());
        return 10;
    }
    std::printf("ABSORPTION_DIRECTION no_absorption_raw=%.9g absorption_raw=%.9g no_absorption_fit=%.9g absorption_fit=%.9g\n",
        noHydrogenPeak, withHydrogenPeak, noHydrogenSpectrum.peakAbsorbance, spectrum.peakAbsorbance);
    if (!near(spectrum.peakAbsorbance, 0.0019975058284404704, 5.0e-10)
        || !near(spectrum.voigt.centerCm1, -0.0859375, 1.0e-7)
        || !near(spectrum.voigt.amplitude, 0.0014609375, 1.0e-9)
        || !near(spectrum.voigt.gaussianFwhmCm1, 0.33845849609374234, 1.0e-7)
        || !near(spectrum.voigt.lorentzianFwhmCm1, 0.32115917968749153, 1.0e-7)
        || !near(spectrum.voigt.residualSumSquares, 0.0046685547847076601, 1.0e-9)
        || !near(spectrum.baselineV.at(80), 5.1134610616039904, 1.0e-9)
        || !near(spectrum.absorbance.at(80), -0.00078428032553733607, 1.0e-10)
        || !near(spectrum.relativeFrequencyCm1.constFirst(), -0.091474759043578269, 1.0e-12)
        || !near(spectrum.relativeFrequencyCm1.constLast(), 0.13322945560089106, 1.0e-12)) {
        std::fprintf(
            stderr,
            "fixed-window numerical regression mismatch: %.17g %.17g %.17g %.17g %.17g %.17g %.17g %.17g %.17g %.17g\n",
            spectrum.peakAbsorbance,
            spectrum.voigt.centerCm1,
            spectrum.voigt.amplitude,
            spectrum.voigt.gaussianFwhmCm1,
            spectrum.voigt.lorentzianFwhmCm1,
            spectrum.voigt.residualSumSquares,
            spectrum.baselineV.at(80),
            spectrum.absorbance.at(80),
            spectrum.relativeFrequencyCm1.constFirst(),
            spectrum.relativeFrequencyCm1.constLast());
        return 9;
    }

    tdlas::contracts::ParameterSnapshot parameters = tdlas::contracts::ParameterSnapshot::mockDefaults();
    parameters.readSamplesPerBlock = 64;
    parameters.algorithmParameterSetId = QStringLiteral("tdlas-v1.6-ui");
    tdlas::algorithm::TdlasAlgorithmProcessor processor(tdlas::algorithm::uiAlgorithmConfig());
    tdlas::contracts::ProcessingResult streamed;
    QVector<double> oneCycle;
    for (int index = 0; index < 64; ++index) {
        const double phase = index / 64.0;
        oneCycle.push_back(0.7 + 0.5 * phase - 0.1 * gaussian(phase, 0.56, 0.035));
    }
    for (tdlas::contracts::Sequence sequence = 1; sequence <= 22; ++sequence) {
        streamed = processor.process(blockFor(sequence, oneCycle), parameters);
        if (sequence < 22 && streamed.validity != tdlas::contracts::DataValidity::Incomplete) {
            return 6;
        }
        if (sequence == 22 && streamed.validity != tdlas::contracts::DataValidity::Uncalibrated) return 6;
    }
    if (streamed.validity != tdlas::contracts::DataValidity::Uncalibrated
        || streamed.algorithmVersion != QStringLiteral("tdlas-v1.8-20-cycle-average-cpp")
        || streamed.calibrationVersion != QStringLiteral("relative-frequency-20260901")
        || streamed.relativeFrequencyCm1.size() != 39
        || streamed.timeSeconds.size() != 39
        || streamed.cycleVoltageV.size() != 65
        || !near(streamed.timeSeconds.constFirst(), 18.0 / 5120.0, 1.0e-12)
        || !near(streamed.timeSeconds.constLast(), 56.0 / 5120.0, 1.0e-12)
        || !streamed.peakAbsorbance.has_value()
        || !streamed.voigtCenterCm1.has_value()
        || !streamed.voigtAmplitude.has_value()
        || !streamed.voigtGaussianFwhmCm1.has_value()
        || !streamed.voigtLorentzianFwhmCm1.has_value()
        || !streamed.voigtResidualSumSquares.has_value()
        || streamed.concentration.has_value()
        || !streamed.concentrationUnit.isEmpty()) {
        qWarning() << "streaming contract regression mismatch" << streamed.diagnostic;
        return 7;
    }

    QVector<double> invalidSamples = oneCycle;
    invalidSamples[7] = std::numeric_limits<double>::quiet_NaN();
    const tdlas::contracts::ProcessingResult invalid = processor.process(
        blockFor(23, invalidSamples), parameters);
    if (invalid.validity != tdlas::contracts::DataValidity::Invalid) {
        return 8;
    }

    return 0;
}
