#include "algorithm/TdlasAlgorithmProcessor.h"

#include <QCoreApplication>
#include <algorithm>
#include <cmath>
#include <cstdio>

namespace {

using namespace tdlas;

QVector<double> cycle(double depth, bool inverted = false)
{
    QVector<double> values;
    for (int i = 0; i < 256; ++i) {
        const double phase = i / 256.0;
        const double voltage = 0.7 + 0.5 * phase
            - depth * std::exp(-0.5 * std::pow((phase - 0.56) / 0.035, 2));
        values.push_back(inverted ? 1.9 - voltage : voltage);
    }
    return values;
}

contracts::RawDataBlock block(const QVector<double> &samples, quint64 sequence)
{
    contracts::RawDataBlock value;
    value.runId = {QStringLiteral("single-cycle-run")};
    value.sequence = sequence;
    const double startSeconds = static_cast<double>((sequence - 1) * samples.size()) / 5120.0;
    value.sampleStart.utc = QDateTime::fromMSecsSinceEpoch(100000 + qRound64(startSeconds * 1000), Qt::UTC);
    value.sampleStart.monotonicNanoseconds = qRound64(startSeconds * 1.e9);
    value.sampleRateHz = 5120;
    value.sampleCountPerChannel = samples.size();
    value.channels.push_back({QStringLiteral("sim/ai0"), samples});
    value.validity = contracts::DataValidity::Valid;
    return value;
}

bool close(const QVector<double> &a, const QVector<double> &b)
{
    if (a.size() != b.size()) return false;
    for (qsizetype i = 0; i < a.size(); ++i) if (std::abs(a.at(i) - b.at(i)) > 1.e-12) return false;
    return true;
}

bool verifyReadSize(int readSize, bool nominal, bool inverted)
{
    auto parameters = contracts::ParameterSnapshot::mockDefaults();
    parameters.readSamplesPerBlock = readSize;
    parameters.aoEnabled = nominal;
    parameters.outputFrequencyHz = 20;
    algorithm::TdlasAlgorithmProcessor processor;
    QVector<double> input;
    for (int i = 0; i < 100; ++i) input += cycle(0.03 + (i / 20) * 0.03, inverted);
    input.remove(0, 73); // Begin partway through a ramp, across arbitrary read boundaries.
    int valid = 0;
    int lastBatch = -1;
    double firstPeak = -1, lastPeak = -1;
    for (int first = 0; first + readSize <= input.size(); first += readSize) {
        const auto result = processor.process(block(input.mid(first, readSize), first / readSize + 1), parameters);
        const int latestBatch = (first + readSize - 1 - (256 - 73)) / (20 * 256) - 1;
        if (result.validity == contracts::DataValidity::Incomplete) {
            if (latestBatch > lastBatch) return false;
            continue;
        }
        if (result.validity != contracts::DataValidity::Uncalibrated
            || result.cycleVoltageV.size() != 257
            || result.cycleTimeSeconds.size() != 257
            || std::abs(result.cycleTimeSeconds.last() - 0.05) > 1.e-12
            || result.timeSeconds.size() != 155) return false;
        if (latestBatch <= lastBatch) return false;
        lastBatch = latestBatch;
        const int sourceStart = 256 - 73 + latestBatch * 20 * 256;
        if (first + readSize <= sourceStart + 20 * 256) return false;
        QVector<double> mean(257, 0.0);
        for (int c = 0; c < 20; ++c) {
            for (int i = 0; i <= 256; ++i) mean[i] += input.at(sourceStart + c * 256 + i) / 20.0;
        }
        if (!close(result.cycleVoltageV, mean)
            || std::abs(result.timestamp.utc.toMSecsSinceEpoch()
                - (100000 + qRound64(sourceStart * 1000.0 / 5120))) > 1
            || std::abs(result.timestamp.monotonicNanoseconds - qRound64(sourceStart * 1.e9 / 5120)) > 1) return false;
        auto config = algorithm::uiAlgorithmConfig();
        config.samplesPerCycleFromBlock = false;
        config.samplesPerCycle = 256;
        config.averagedCyclesPerSpectrum = 1;
        config.windowSamples = 256;
        const auto expected = algorithm::processTdlasWindow(mean.mid(0, 256), config);
        if (!expected.valid || !close(result.fittedAbsorbance, expected.fittedAbsorbance)
            || !close(result.voltageV, expected.voltageV)
            || !close(result.fittedVoltageV, expected.fittedVoltageV)
            || !close(result.relativeFrequencyCm1, expected.relativeFrequencyCm1)
            || result.displayVoltageOffsetV != 4.2) return false;
        if (!inverted) {
            const auto fittedPeak = std::max_element(result.fittedAbsorbance.cbegin(), result.fittedAbsorbance.cend());
            const qsizetype peakIndex = std::distance(result.fittedAbsorbance.cbegin(), fittedPeak);
            const qsizetype measuredIndex = std::distance(result.absorbance.cbegin(),
                std::max_element(result.absorbance.cbegin(), result.absorbance.cend()));
            const auto oldFit = algorithm::fitVoigt(result.relativeFrequencyCm1, result.absorbance);
            if (std::abs(peakIndex - measuredIndex) > 5
                || result.fittedAbsorbance.first() > *fittedPeak * 0.25
                || result.fittedAbsorbance.last() > *fittedPeak * 0.25
                || *result.voigtResidualSumSquares > oldFit.residualSumSquares * 0.5) return false;
        }
        if (firstPeak < 0) firstPeak = *result.peakAbsorbance;
        lastPeak = *result.peakAbsorbance;
        ++valid;
    }
    // Disjoint batch means must respond to the source depth, without displaying
    // any individual-cycle fit or publishing a sliding average on each read.
    if (!inverted && !(lastPeak > firstPeak * 1.2)) return false;
    std::printf("AVERAGE_20_CYCLES read=%d nominal=%d inverted=%d results=%d peak_first=%.9g peak_last=%.9g\n",
        readSize, nominal, inverted, valid, firstPeak, lastPeak);
    return valid == (readSize > 20 * 256 ? 2 : 4);
}

bool verifyDiscontinuity()
{
    auto parameters = contracts::ParameterSnapshot::mockDefaults();
    algorithm::TdlasAlgorithmProcessor processor;
    const auto samples = cycle(0.08);
    quint64 seq = 0;
    for (int scenario = 0; scenario < 6; ++scenario) {
        // Partially assemble 19 cycles, then interrupt this group in six ways.
        for (int i = 0; i < 19; ++i) (void)processor.process(block(samples, ++seq), parameters);
        if (scenario == 0) ++seq;
        if (scenario == 3) parameters.id += QStringLiteral("-changed");
        for (int i = 0; i < 22; ++i) {
            auto next = block(samples, ++seq);
            if (scenario == 1 && i == 0) next.overrun = true;
            if (scenario == 2 && i == 0) next.droppedBefore = 1;
            if (scenario == 4) next.runId = {QStringLiteral("new-run")};
            if (scenario == 5) next.sampleRateHz = 10240;
            const auto result = processor.process(next, parameters);
            const auto expected = i < 21 ? contracts::DataValidity::Incomplete : contracts::DataValidity::Uncalibrated;
            if (result.validity != expected) {
                std::fprintf(stderr, "reset scenario=%d cycle=%d: %s\n", scenario, i, qPrintable(result.diagnostic));
                return false;
            }
        }
    }
    return true;
}

bool verifyNoSawtooth()
{
    auto parameters = contracts::ParameterSnapshot::mockDefaults();
    algorithm::TdlasAlgorithmProcessor processor;
    for (int seq = 1; seq <= 24; ++seq) {
        QVector<double> samples;
        for (int i = 0; i < 256; ++i) samples.push_back(1.0 + 0.02 * std::sin((seq * 256 + i) * 0.01));
        if (processor.process(block(samples, seq), parameters).validity
            != contracts::DataValidity::Incomplete) return false;
    }
    return true;
}

bool verifyPeriodVariation()
{
    auto parameters = contracts::ParameterSnapshot::mockDefaults();
    parameters.aoEnabled = true;
    parameters.outputFrequencyHz = 20;
    parameters.readSamplesPerBlock = 173;
    algorithm::TdlasAlgorithmProcessor processor;
    QVector<double> input;
    // A linear ramp makes the exact phase mean independently calculable even
    // when periods alternate between 255 and 257 samples.
    for (int c = 0; c < 25; ++c) {
        const int length = c % 2 ? 255 : 257;
        for (int i = 0; i < length; ++i) input.push_back(0.7 + 0.5 * i / length);
    }
    int outputs = 0;
    for (int first = 0; first + 173 <= input.size(); first += 173) {
        const auto result = processor.process(block(input.mid(first, 173), first / 173 + 1), parameters);
        if (result.validity == contracts::DataValidity::Incomplete) continue;
        if (result.validity != contracts::DataValidity::Uncalibrated
            || result.cycleVoltageV.size() != 256
            || std::abs(result.cycleTimeSeconds.last() - 0.05) > 1.e-12) return false;
        for (int i = 0; i < 255; ++i) {
            // The last phase bin may interpolate across the physical return;
            // all interior bins must equal the analytic ramp mean.
            if (i < 254 && std::abs(result.cycleVoltageV.at(i) - (0.7 + 0.5 * i / 255.0)) > 1.e-12) return false;
        }
        if (std::abs(result.cycleVoltageV.last() - 0.7) > 1.e-12) return false;
        const qsizetype crop = 75;
        if (std::abs(result.timeSeconds.first() - result.cycleTimeSeconds.at(crop)) > 1.e-12) return false;
        ++outputs;
    }
    return outputs == 1;
}

} // namespace

int main(int argc, char **argv)
{
    QCoreApplication app(argc, argv);
    for (int readSize : {64, 173, 256, 1000, 12000}) {
        for (bool nominal : {false, true}) {
            for (bool inverted : {false, true}) {
                if (!verifyReadSize(readSize, nominal, inverted)) {
                    std::fprintf(stderr, "20-cycle mean failure read=%d nominal=%d inverted=%d\n", readSize, nominal, inverted);
                    return 1;
                }
            }
        }
    }
    if (!verifyDiscontinuity() || !verifyNoSawtooth() || !verifyPeriodVariation()) return 2;
    return 0;
}
