param(
    [string]$ProjectRoot = (Join-Path $PSScriptRoot '..'),
    [string]$OutputPath
)
$ErrorActionPreference = 'Stop'
$root = (Resolve-Path -LiteralPath $ProjectRoot).Path
$cmakePath = Join-Path $root 'CMakeLists.txt'
if (-not (Test-Path -LiteralPath $cmakePath)) { throw 'ProjectRoot must contain CMakeLists.txt.' }
$versionMatch = [regex]::Match((Get-Content -LiteralPath $cmakePath -Raw), 'project\([^\r\n]*VERSION\s+([0-9.]+)')
if (-not $versionMatch.Success) { throw 'Cannot read project version.' }
$packageName = 'tdlas-hydrogen-ui-' + $versionMatch.Groups[1].Value + '-source'
if (-not $OutputPath) { $OutputPath = Join-Path (Split-Path -Parent $root) ($packageName + '.zip') }
$OutputPath = [IO.Path]::GetFullPath($OutputPath)
if ($OutputPath.StartsWith($root.TrimEnd('\') + '\', [StringComparison]::OrdinalIgnoreCase)) {
    throw 'Write the source archive outside ProjectRoot.'
}
New-Item -ItemType Directory -Path (Split-Path -Parent $OutputPath) -Force | Out-Null
Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem
$stream = [IO.File]::Open($OutputPath, [IO.FileMode]::Create)
$archive = [IO.Compression.ZipArchive]::new($stream, [IO.Compression.ZipArchiveMode]::Create)
$count = 0
try {
    foreach ($file in (Get-ChildItem -LiteralPath $root -Recurse -Force -File)) {
        $relative = [IO.Path]::GetRelativePath($root, $file.FullName).Replace('\', '/')
        if ($relative -match '(^|/)(\.git|\.vs|build[^/]*|dist|config|data|发布包|源码包|__pycache__|\.smoke[^/]*|\.staging[^/]*)/' -or
            $relative -match '(^|/)\.git$' -or
            $relative -match '(\.user|\.log|\.tmp|\.bak|\.obj|\.pdb|\.exe|\.dll|CMakeUserPresets\.json)$') { continue }
        [IO.Compression.ZipFileExtensions]::CreateEntryFromFile(
            $archive, $file.FullName, ($packageName + '/' + $relative), [IO.Compression.CompressionLevel]::Optimal) | Out-Null
        $count++
    }
} finally {
    $archive.Dispose()
    $stream.Dispose()
}
Write-Output "Source package: $OutputPath ($count files; no build caches, runtime data or Git metadata)."
