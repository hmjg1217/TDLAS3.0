function Resolve-TdlasEnvironment {
    param([string]$QtRoot)
    $ErrorActionPreference = 'Stop'
    $qtCandidates = @($QtRoot, $env:QTDIR)
    if (Test-Path -LiteralPath 'C:\Qt') {
        $qtCandidates += Get-ChildItem -LiteralPath 'C:\Qt' -Directory |
            Where-Object { $_.Name -match '^\d+\.\d+\.\d+$' } |
            Sort-Object { [version]$_.Name } -Descending |
            ForEach-Object { Join-Path $_.FullName 'msvc2022_64' }
    }
    $qt = $qtCandidates | Where-Object {
        $_ -and (Test-Path -LiteralPath (Join-Path $_ 'lib\cmake\Qt6'))
    } | Select-Object -First 1
    if (-not $qt) { throw 'Qt 6 MSVC x64 was not found. Specify -QtRoot or QTDIR.' }
    $qt = (Resolve-Path -LiteralPath $qt).Path
    $cmakeCandidates = @((Join-Path (Split-Path -Parent (Split-Path -Parent $qt)) 'Tools\CMake_64\bin\cmake.exe'))
    $cmakeCandidates += 'C:\Qt\Tools\CMake_64\bin\cmake.exe'
    $fromPath = Get-Command cmake.exe -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($fromPath) { $cmakeCandidates += $fromPath.Source }
    $cmake = $cmakeCandidates | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1
    if (-not $cmake) { throw 'CMake >= 3.21 was not found. Install CMake and add it to PATH.' }
    $vswhere = Join-Path ${env:ProgramFiles(x86)} 'Microsoft Visual Studio\Installer\vswhere.exe'
    if (-not (Test-Path -LiteralPath $vswhere)) { throw 'Install Visual Studio 2022 with Desktop development with C++.' }
    $vsRoot = & $vswhere -latest -version '[17.0,18.0)' -products '*' -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath
    if (-not $vsRoot) { throw 'MSVC 2022 x64 and Windows SDK are required.' }
    return @{ QtRoot=$qt; CMake=$cmake; CTest=(Join-Path (Split-Path -Parent $cmake) 'ctest.exe'); VisualStudioRoot=[string]$vsRoot }
}
